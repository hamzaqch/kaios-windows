# For AI agents: how to install this package

You have been handed the Kai package. To install it on this Windows machine, follow `INSTALL.md` exactly:

1. Open PowerShell in this folder.
2. **Ask the user first** whether to migrate their existing Copilot setup. Check for `%USERPROFILE%\.copilot`. If it exists, ask:
   - "Migrate your existing skills, agents, plugins, hooks, workflows, MCP servers, instructions and settings into Kai, or start fresh?" (They can also pick per category: `instructions, skills, agents, plugins, hooks, mcp, workflows, settings, memory`.)
   - "Delete past chat and session history?" (The default is yes.)
   - If they use the Copilot app, tell them deleting history also clears the app's chat list and they will sign in to the app again.
3. Ask the user to close the Copilot app and any `copilot` terminals. Then run `powershell -ExecutionPolicy Bypass -File .\install.ps1 -Migrate <all|none|cat,cat>`, adding `-KeepHistory` if they want history kept and `-InstallPython` if Python 3.8+ is missing. A full zip backup always goes to `%USERPROFILE%\.copilot-backups\` first. The installer refuses to run non-interactively without `-Migrate`: never guess this answer for the user.
4. Confirm the output ends with `RESULT: HEALTHY`. If it doesn't, read the `[!!]` lines and fix them. Never weaken a safety check to get a pass.
5. Tell the user to start a fresh Copilot CLI or Copilot app session.

**Constraints:**
- Install no other software. Kai needs only Python and PowerShell.
- Do not modify files outside `%USERPROFILE%\.copilot\`.
- Delete nothing yourself. All removal goes through the installer, after the user's answer and the automatic backup.
