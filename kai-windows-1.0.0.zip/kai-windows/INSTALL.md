# Installing Kai (instructions for any AI agent or human)

Kai is a Life Operating System for **GitHub Copilot CLI** and the **GitHub Copilot app** on Windows 11. It installs into `%USERPROFILE%\.copilot\`, the folder both products read.

**Requirements:** Windows PowerShell 5.1 (built into Windows) and Python 3.8+. Kai uses only the Python standard library: no pip, npm or other packages.

## Steps

Run these from the unzipped folder, the one that contains `install.ps1`.

1. **Check for Python:**
   `py -3 --version` or `python --version`.
   If neither prints `Python 3.8` or newer, step 2 can install it for you.

2. **Install Kai:**
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\install.ps1
   ```
   If Python is missing, add `-InstallPython`. That downloads the official python.org installer, checks its signature, and installs it for the current user only, with no admin rights needed.

3. **Confirm the install worked.** The installer ends with `RESULT: HEALTHY`. Re-check any time with:
   ```powershell
   py -3 "$env:USERPROFILE\.copilot\kai\bin\kai.py" doctor
   ```

4. **Start a new Copilot session** (`copilot` in a terminal, or a new session in the Copilot app). The first reply should open with `════ Kai ════` and end with `🗣️ Kai:`.

## Existing Copilot setup: migrate or start fresh

If `%USERPROFILE%\.copilot` already exists, the installer lists what it found and asks what to do with it. The categories are instructions, skills, agents, plugins, hooks, MCP servers, workflows, settings, and Kai memory from a previous install.

- **Migrate (`a`, or `-Migrate all`):** everything you have keeps working alongside Kai. Your instructions move under "Your rules".
- **Start fresh (`f`, or `-Migrate none`):** everything in `.copilot` is removed except your sign-in (`config.json`).
- **Choose (`c`, or `-Migrate skills,agents,...`):** keep only the categories you pick.

Chat and session history (`session-state`, `session-store.db`, `logs`, `chats`) is deleted in all three cases unless you answer no or pass `-KeepHistory`. The Copilot desktop app lists its chats from its own database (`data.db`) but loads them from the session history, so deleting history also resets that database: the app's chat list is cleared and you sign in to the app again. Pass `-KeepHistory` to keep both. **A full zip backup is always written first** to `%USERPROFILE%\.copilot-backups\copilot-<timestamp>.zip`. Close the Copilot app and any `copilot` terminals before installing, because Windows locks the session database while they run.

## What the installer does

| Path under `%USERPROFILE%\.copilot\` | Purpose |
|---|---|
| `copilot-instructions.md` | Kai's constitution, inside a `KAI:BEGIN/END` block. Anything already in the file is kept under "Your rules". |
| `agents\kai-*.agent.md` | 13 custom agents: explorer, planner, architect, engineer, simplifier, reviewer, code-reviewer, deep-analyst, researcher, silent-failure-hunter, test-analyzer, comment-analyzer, type-design-analyzer. |
| `skills\<name>\SKILL.md` | 53 skills: algorithm, isa, memory, cortex, workflow, optimize, loop, the thinking skills, research, evals, Windows diagnostics and more. The full list is in the constitution. |
| `settings.json` → `hooks` | Hooks on 9 events (`sessionStart`, `userPromptSubmitted`, `userPromptTransformed`, `preToolUse`, `postToolUse`, `postToolUseFailure`, `subagentStart`, `agentStop`, `sessionEnd`): safety gate, verification gate, ISA gates, guards, memory and learning capture, per-turn format contract, format gate. Kai's entries are merged in, and other hooks are kept. |
| `kai\` | The Kai home: ALGORITHM.md, ISA_FORMAT.md, RULES, bin\kai.py, bin\kai_workflow.py, hooks\kai_hook.py plus hooks\ext\, MEMORY\ |

- **Re-running is safe.** It upgrades in place and never deletes `kai\MEMORY`.
- **Backups.** Any file it replaces is backed up to `kai-backups\<timestamp>\` first.

## Prerequisite (not part of Kai): Copilot CLI

Copilot CLI needs PowerShell 7+, per GitHub's docs. If `copilot` isn't installed yet, use one of these:

- `winget install GitHub.Copilot`
- the standalone binary from https://github.com/github/copilot-cli/releases

Then sign in with `copilot` and `/login`. Your GitHub account needs Copilot CLI access enabled at https://github.com/settings/copilot.

## Alternative: install as a Copilot plugin

`python build_plugin.py` builds `dist/kai-plugin/`, which is also a one-plugin local marketplace. Install it with `copilot plugin marketplace add <path-to>\kai-plugin` and `copilot plugin install kai@kai-local`. Plugin agents are namespaced (`@kai:kai-engineer`), and the constitution arrives as session-start context. Pick one route, not both. Details: `dist/kai-plugin/README.md`.

## Uninstall

```powershell
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1
```

This removes Kai's files and restores anything it replaced. Your memory (`kai\MEMORY`) and the backups stay.

## Troubleshooting

- **Hooks don't fire:** run `kai.py doctor`. Check that the Kai entries under `hooks` in `settings.json` point to a Python path that exists. Re-run the installer after moving or upgrading Python.
- **Every tool call is denied:** Copilot treats a crashing `preToolUse` hook as a deny. Run `kai.py doctor` (its safety self-test shows the problem), or run `uninstall.ps1` while you debug.
- **A gate or guard gets in the way:** each one has a switch. Set it as a user environment variable, then start a new session. Leave the rest on.

| Switch | Effect |
|---|---|
| `KAI_FORMAT_GATE=0` | Turn off the response-format gate. |
| `KAI_VERIFY_GATE=0` | Turn off the verification gate (no "done" without evidence). |
| `KAI_VERIFY_<TYPE>=0` or `=log` | Turn off one claim type, or log it without blocking. Types: `T1` deploy, `T2` flow, `T3` appearance, `T4` tests, `T5` publicity, `TC` completion, `TF` contradicted completion, `TH` "should work". |
| `KAI_VERIFY_MAX_BLOCKS=<n>` | Blocks per session before the verification gate stops (default 3). |
| `KAI_ISA_GATES=0` | Turn off all ISA stop gates. |
| `KAI_ISA_CLOSE_GATE=0`, `KAI_ISA_FOLD_GATE=0`, `KAI_ISA_STRUCTURE_GATE=0`, `KAI_ISA_STALE_GUARD=0`, `KAI_ISC_CHECKPOINT=0` | Turn off one ISA gate. |
| `KAI_ISA_STRIP=0`, `KAI_ISA_COMPLETE_CHECK=0`, `KAI_ISA_REOPEN=0`, `KAI_ISA_QUALITY_NUDGE=0` | Silence one ISA notice: the ascent strip, the check when `phase: complete` is written, the reopen notice, or the eval nudge for unprobed quality claims. |
| `KAI_ISA_CLOSE_THRESHOLD=<n>` | Tool calls without an ISA edit before the close gate fires (default 10). |
| `KAI_GUARDS=0` | Turn off every guard. |
| `KAI_GUARDS_INFRA=0` | Turn off the ask before deleting cloud or infrastructure resources. |
| `KAI_GUARDS_SELF_EDIT=1` | Edit Kai's own hooks, rules and settings without being asked. Use only for deliberate Kai maintenance. |
| `KAI_MAX_TASKS=<n>` | Subagent launches allowed per session (default 50). |
| `KAI_WRITING_NUDGE=0` | Silence the AI-writing nudge on prose files. |
| `KAI_CONFIG_EVAL_NUDGE=0` | Silence the reminder to run your eval suite after edits to the constitution, agents, hooks or rules. |
| `KAI_STOP_WAIT_MS=<ms>` | How long stop gates wait for the transcript to settle (default 1500). |
