# Removes Kai from %USERPROFILE%\.copilot and restores anything it replaced. Memory is kept.
& (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'install.ps1') -Uninstall
exit $LASTEXITCODE
