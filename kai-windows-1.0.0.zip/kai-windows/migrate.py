"""Pre-install migration step for Kai: decide what happens to an existing Copilot home.

Before Kai installs, the user chooses, per category, whether existing customizations are
migrated (kept and used alongside Kai) or removed. History is always cleared (unless
--keep-history). A full zip backup of the Copilot home is ALWAYS written first.

Choices come from the --migrate flag or, when run in a terminal, from an interactive prompt.
Non-interactive runs (an AI agent driving the install) must pass --migrate explicitly: the
installer refuses to guess, so the agent has to ask the user.

  --migrate all              keep every existing customization
  --migrate none             fresh start: remove everything except sign-in (config.json)
  --migrate skills,agents    keep only the listed categories
  --keep-history             do not delete sessions/logs/chat history
  --reset-login              also remove config.json (you will sign in again)
  --reset-app                reset the Copilot desktop app's local database (data.db) even when history
                             is kept. Deleting history ALWAYS resets it too: the app lists chats from
                             data.db but loads them from session-state, so keeping one without the other
                             leaves "Failed to restore session" entries. You sign in to the app again.
"""
import datetime as dt
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

KAI_BEGIN, KAI_END = "<!-- KAI:BEGIN", "<!-- KAI:END -->"

CATEGORIES = {
    "instructions": "your global instructions (copilot-instructions.md, instructions/)",
    "skills": "your skills (skills/)",
    "agents": "your custom agents (agents/)",
    "plugins": "your installed plugins (installed-plugins/, plugin-data/)",
    "hooks": "your hooks (settings.json hooks, hooks/*.json)",
    "mcp": "your MCP servers (mcp-config.json, mcp-oauth-config/, mcp-secrets/)",
    "workflows": "your workflows (workflows/, Kai workflow definitions)",
    "settings": "your other settings (settings.json, permissions-config.json, lsp-config.json, providers.json)",
    "memory": "Kai memory from a previous install (kai/MEMORY: ISAs, knowledge, learnings)",
}
HISTORY = ["session-state", "session-store.db", "session-store.db-shm", "session-store.db-wal",
           "logs", "chats", "history", "command-history", "settings.json.lock"]
APP_STATE = ["data.db", "data.db-shm", "data.db-wal", "data.db.open-lock", "data.db.startup-lock",
             "repo-metadata-cache.db", "repo-metadata-cache.db-shm", "repo-metadata-cache.db-wal",
             "media-cache", "canvas-catalog-probe"]
KEEP_ALWAYS = {"config.json"}  # sign-in + trusted folders; removed only with --reset-login


def log(msg):
    print(f"[kai] {msg}", flush=True)


def _kai_owned_names(manifest):
    return set(manifest.get("installed", []))


def _is_kai_hook(entry):
    return "kai_hook.py" in json.dumps(entry)


def inventory(home):
    """What exists today, per category, excluding anything Kai itself installed."""
    try:
        manifest = json.loads((home / "kai" / "manifest.json").read_text(encoding="utf-8"))
    except Exception:
        manifest = {}
    kai = _kai_owned_names(manifest)
    inv = {c: [] for c in CATEGORIES}

    ci = home / "copilot-instructions.md"
    if ci.exists():
        text = ci.read_text(encoding="utf-8", errors="replace")
        if KAI_BEGIN in text and KAI_END in text:
            text = text[:text.index(KAI_BEGIN)] + text[text.index(KAI_END) + len(KAI_END):]
        text = text.replace("## Your rules", "").replace(
            "<!-- Add your own preferences below this line. The Kai installer never touches this section. -->", "")
        if text.strip():
            inv["instructions"].append("copilot-instructions.md")
    if (home / "instructions").exists():
        inv["instructions"] += [f"instructions/{p.name}" for p in (home / "instructions").iterdir()]

    for d in sorted((home / "skills").glob("*")) if (home / "skills").exists() else []:
        if f"skills{os.sep}{d.name}" not in kai and f"skills/{d.name}" not in kai:
            inv["skills"].append(f"skills/{d.name}")
    for f in sorted((home / "agents").glob("*")) if (home / "agents").exists() else []:
        if f"agents{os.sep}{f.name}" not in kai and f"agents/{f.name}" not in kai:
            inv["agents"].append(f"agents/{f.name}")
    for name in ("installed-plugins", "plugin-data"):
        p = home / name
        if p.exists() and any(p.iterdir()):
            inv["plugins"] += [f"{name}/{c.name}" for c in p.iterdir()]

    st = home / "settings.json"
    settings = {}
    if st.exists():
        try:
            settings = json.loads(st.read_text(encoding="utf-8"))
        except Exception:
            settings = {}
    for ev, arr in (settings.get("hooks") or {}).items():
        for e in arr:
            if not _is_kai_hook(e):
                inv["hooks"].append(f"settings.json hooks.{ev}")
    if (home / "hooks").exists():
        inv["hooks"] += [f"hooks/{p.name}" for p in (home / "hooks").iterdir() if p.name != "kai.json"]
    if any(k != "hooks" for k in settings):
        inv["settings"].append("settings.json (" + ", ".join(k for k in settings if k != "hooks") + ")")
    for name in ("permissions-config.json", "lsp-config.json", "providers.json"):
        if (home / name).exists():
            inv["settings"].append(name)

    for name in ("mcp-config.json", "mcp-oauth-config", "mcp-secrets"):
        if (home / name).exists():
            inv["mcp"].append(name)
    if (home / "workflows").exists():
        inv["workflows"].append("workflows/")
    kwf = home / "kai" / "workflows"
    if kwf.exists():
        inv["workflows"].append("kai/workflows/")

    mem = home / "kai" / "MEMORY"
    if mem.exists() and any(f.is_file() for f in mem.rglob("*") if f.name not in ("learnings.md",)):
        inv["memory"].append("kai/MEMORY/")
    return {c: v for c, v in inv.items() if v}


def history_items(home):
    return [n for n in HISTORY if (home / n).exists()]


def copilot_running():
    """Copilot holds session-store.db open; deleting history while it runs fails on Windows."""
    if os.name != "nt":
        return []
    try:
        out = subprocess.run(["tasklist", "/fo", "csv", "/nh"], capture_output=True, text=True, timeout=20).stdout
    except Exception:
        return []
    names = {line.split('","')[0].strip('"').lower() for line in out.splitlines() if line}
    return sorted(n for n in names if n in ("copilot.exe", "github.exe"))


def backup(home, dry):
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = home.parent / ".copilot-backups" / f"copilot-{stamp}.zip"
    log(f"backup  full copy of {home} -> {dest}")
    if dry:
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for f in home.rglob("*"):
            if f.is_file():
                try:
                    z.write(f, f.relative_to(home))
                except (PermissionError, OSError) as e:
                    log(f"  skipped locked file {f.name}: {e}")
    return dest


def _rm(path, dry):
    if not path.exists() and not path.is_symlink():
        return
    log(f"remove  {path.name if path.parent.name == '.copilot' else path}")
    if dry:
        return
    try:
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()
    except (PermissionError, OSError) as e:
        log(f"  could not remove {path}: {e} (close Copilot and re-run to finish)")


def remove_category(home, cat, items, dry):
    if cat == "instructions":
        ci = home / "copilot-instructions.md"
        if ci.exists():
            text = ci.read_text(encoding="utf-8", errors="replace")
            if KAI_BEGIN in text and KAI_END in text:
                block = text[text.index(KAI_BEGIN):text.index(KAI_END) + len(KAI_END)]
                log("remove  your rules from copilot-instructions.md (Kai block kept)")
                if not dry:
                    ci.write_text(block + "\n\n## Your rules\n\n", encoding="utf-8")
            else:
                _rm(ci, dry)
        _rm(home / "instructions", dry)
    elif cat == "hooks":
        st = home / "settings.json"
        if st.exists():
            try:
                s = json.loads(st.read_text(encoding="utf-8"))
                kept = {ev: [e for e in arr if _is_kai_hook(e)] for ev, arr in (s.get("hooks") or {}).items()}
                kept = {ev: arr for ev, arr in kept.items() if arr}
                if kept:
                    s["hooks"] = kept
                else:
                    s.pop("hooks", None)
                log("remove  your hooks from settings.json")
                if not dry:
                    st.write_text(json.dumps(s, indent=2), encoding="utf-8")
            except Exception as e:
                log(f"  settings.json unreadable, left as-is: {e}")
        if (home / "hooks").exists():
            for p in (home / "hooks").iterdir():
                _rm(p, dry)
    elif cat == "settings":
        st = home / "settings.json"
        if st.exists():
            try:
                s = json.loads(st.read_text(encoding="utf-8"))
                s = {"hooks": s["hooks"]} if "hooks" in s else {}
                log("remove  your other settings from settings.json (hooks handled separately)")
                if not dry:
                    st.write_text(json.dumps(s, indent=2), encoding="utf-8")
            except Exception:
                pass
        for name in ("permissions-config.json", "lsp-config.json", "providers.json"):
            _rm(home / name, dry)
    elif cat == "memory":
        _rm(home / "kai" / "MEMORY", dry)
    elif cat == "workflows":
        _rm(home / "workflows", dry)
        _rm(home / "kai" / "workflows", dry)
    else:
        for it in items:
            _rm(home / it.split(" ")[0], dry)


def parse_choice(raw, available):
    raw = (raw or "").strip().lower()
    if raw in ("all", "yes", "y"):
        return set(available)
    if raw in ("none", "no", "n", "fresh"):
        return set()
    picked = {c.strip() for c in raw.split(",") if c.strip()}
    unknown = picked - set(CATEGORIES)
    if unknown:
        raise ValueError(f"unknown categories: {', '.join(sorted(unknown))} (valid: {', '.join(CATEGORIES)})")
    return picked & set(available)


def ask(question, default="y"):
    ans = input(f"{question} [{'Y/n' if default == 'y' else 'y/N'}] ").strip().lower()
    return (ans or default).startswith("y")


def run(home, argv, dry=False):
    """Returns 0 to continue the install, non-zero to stop."""
    if "--migrate" in argv:
        try:
            parse_choice(argv[argv.index("--migrate") + 1], CATEGORIES)
        except (ValueError, IndexError) as e:
            log(f"bad --migrate value: {e}")
            return 2
    if not home.exists() or not any(home.iterdir()):
        log("no existing Copilot home found: fresh install")
        return 0
    inv = inventory(home)
    hist = history_items(home)
    if not inv and not hist:
        log("nothing to migrate")
        return 0

    log("found an existing Copilot setup:")
    for cat, items in inv.items():
        shown = ", ".join(items[:6]) + (f", +{len(items) - 6} more" if len(items) > 6 else "")
        log(f"  {cat:12} {shown}")
    if hist:
        log(f"  {'history':12} {', '.join(hist)}")

    flag = argv[argv.index("--migrate") + 1] if "--migrate" in argv else None
    interactive = sys.stdin.isatty() and flag is None
    if flag is None and not interactive:
        log("STOP: an existing Copilot setup was found and this run is non-interactive.")
        log("Ask the user, then re-run with one of:")
        log("  --migrate all | --migrate none | --migrate " + ",".join(inv) if inv else "  --migrate none")
        log("  (add --keep-history to keep past sessions; history is deleted by default)")
        return 3

    if interactive:
        print()
        print("Kai can MIGRATE your existing customizations (keep them working alongside Kai),")
        print("or START FRESH (remove everything from .copilot except your sign-in).")
        print("Either way a full zip backup is written first, and chat/session history is cleared.")
        mode = input("Migrate everything [a], start fresh [f], or choose per category [c]? [a/f/c] ").strip().lower() or "a"
        if mode.startswith("f"):
            keep = set()
        elif mode.startswith("c"):
            keep = {cat for cat in inv if ask(f"  Migrate {CATEGORIES[cat]}?")}
        else:
            keep = set(inv)
        app_note = (" This also resets the Copilot app's chat list, and you sign in to the app again."
                    if any((home / n).exists() for n in APP_STATE) else "")
        keep_history = not ask("Delete chat/session history?" + app_note, "y") if hist else True
        reset_app = False
    else:
        try:
            keep = parse_choice(flag, inv)
        except ValueError as e:
            log(str(e))
            return 2
        keep_history = "--keep-history" in argv
        reset_app = "--reset-app" in argv

    running = copilot_running()
    if running and not dry:
        log(f"Copilot is running ({', '.join(running)}). Close the Copilot app and any `copilot` terminals first.")
        if interactive and not ask("Continue anyway? Locked files will be skipped.", "n"):
            return 4
        if not interactive:
            return 4

    backup(home, dry)
    drop = [c for c in inv if c not in keep]
    log("migrate " + (", ".join(sorted(keep)) if keep else "nothing (fresh start)"))
    for cat in drop:
        remove_category(home, cat, inv[cat], dry)
    if not keep:
        # fresh start: everything except sign-in, Kai's own manifest-tracked files are reinstalled anyway
        for p in list(home.iterdir()):
            if p.name in KEEP_ALWAYS and "--reset-login" not in argv:
                continue
            if p.name == "kai":
                for c in list(p.iterdir()):
                    _rm(c, dry)
                continue
            _rm(p, dry)
    if not keep_history:
        for n in hist:
            _rm(home / n, dry)
    elif keep_history:
        log("history kept")
    if not keep_history and hist:
        reset_app = True  # app chat list (data.db) must go with the session files it points at
    if reset_app:
        for n in APP_STATE:
            _rm(home / n, dry)
    elif keep and any((home / n).exists() for n in APP_STATE):
        log("app database kept (its chat list stays); pass --reset-app to clear it")
    if "--reset-login" in argv:
        _rm(home / "config.json", dry)
    log("migration step done")
    return 0
