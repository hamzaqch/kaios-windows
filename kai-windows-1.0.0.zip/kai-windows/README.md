# Kai: a Life Operating System for GitHub Copilot (Windows 11)

Kai turns GitHub Copilot CLI and the GitHub Copilot app into an intent-engineering assistant. Every task moves from its current state to an ideal state, through claims you can verify.

- **One response format.** The answer comes first, with change and verification sections when work happened. A hook checks the banner and closer.
- **The Algorithm.** Substantial work gets an ISA (Ideal State Artifact) of falsifiable claims, and claims close only on tool evidence.
- **Hooks (Python, 9 events):** session context, a safety gate for destructive commands, a verification gate (no "done" without evidence), ISA gates, guards (self-edit, secrets egress, publish, deploy and outbound-message asks), memory and learning capture, a per-turn format contract, loop detection and a format gate.
- **Memory** in `~/.copilot/kai/MEMORY`: task ISAs, typed knowledge notes, learnings, ratings and session logs, searchable with `kai.py memory search`.
- **53 skills**, including the algorithm, ISA, memory and cortex, optimize and loop, a thinking set (first principles, red team, council, science, systems thinking), research, evals, hardening, Windows diagnostics and multi-agent workflows (`kai_workflow.py`). The full list is in `kai/copilot-instructions.md`.
- **13 agents**: explorer, planner, architect, engineer, simplifier, reviewer, code reviewer, deep analyst, researcher and four focused auditors (silent failures, tests, comments, types).

Kai has no personal data and no interview. Make it yours by writing under "Your rules" in `%USERPROFILE%\.copilot\copilot-instructions.md`.

Install: see [INSTALL.md](INSTALL.md). If you're an AI agent, start with [AGENTS.md](AGENTS.md).
