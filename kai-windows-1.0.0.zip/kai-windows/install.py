"""Kai installer for GitHub Copilot CLI and the GitHub Copilot app. Stdlib only.

  python install.py              install or upgrade (idempotent)
  python install.py --dry-run    show what would change
  python install.py --uninstall  remove Kai, restore anything it replaced (MEMORY is kept)
  python install.py --copilot-home <dir>   target a non-default Copilot home
  python install.py --migrate all|none|<cat,cat>  [--keep-history] [--reset-login]
      what to do with an existing Copilot setup (see migrate.py). In a terminal you are asked.

Never touches anything outside the Copilot home (plus .copilot-backups next to it).
Always writes a full zip backup before migrating or removing anything.
"""
import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent / "kai"
BEGIN, END = "<!-- KAI:BEGIN", "<!-- KAI:END -->"
# userPromptTransformed: Copilot applies only ONE transformer (last wins), so Kai registers it
# exactly once; kai_hook.py merges every extension's per-turn text into that single output.
EVENTS = ["sessionStart", "userPromptSubmitted", "userPromptTransformed", "preToolUse", "postToolUse",
          "postToolUseFailure", "subagentStart", "agentStop", "sessionEnd"]
FAST_EVENTS = ("preToolUse", "postToolUse", "userPromptSubmitted", "userPromptTransformed", "subagentStart")
# Never installed into the Copilot home: bytecode and test suites (doctor runs them from the repo).
COPY_IGNORE = shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", "tests", "test_*.py")


def log(msg):
    print(f"[kai] {msg}", flush=True)


def copilot_home(argv):
    if "--copilot-home" in argv:
        return Path(argv[argv.index("--copilot-home") + 1]).expanduser()
    return Path(os.environ.get("COPILOT_HOME") or Path.home() / ".copilot")


def ps_quote(s):
    return "'" + str(s).replace("'", "''") + "'"


def sh_quote(s):
    return "'" + str(s).replace("'", "'\\''") + "'"


def hooks_config(home):
    py = Path(sys.executable).resolve()
    hook = home / "kai" / "hooks" / "kai_hook.py"
    cfg = {"version": 1, "hooks": {}}
    for ev in EVENTS:
        ps = ("$OutputEncoding=[System.Text.UTF8Encoding]::new($false); "
              f"$input | & {ps_quote(py)} {ps_quote(hook)} {ev}; exit 0")
        cfg["hooks"][ev] = [{
            "type": "command",
            "powershell": ps,
            "bash": f"{sh_quote(py)} {sh_quote(hook)} {ev}",
            "timeoutSec": 15 if ev in FAST_EVENTS else 30,
        }]
    return cfg


def hooks_sha256(hooks):
    """Stable digest of Kai's own hook entries (sorted JSON), stored in the manifest so doctor
    and sessionStart can notice hooks rewritten out of band."""
    kai = {ev: [e for e in arr if is_kai_hook(e)] for ev, arr in (hooks or {}).items()}
    kai = {ev: arr for ev, arr in kai.items() if arr}
    blob = json.dumps(kai, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def is_kai_hook(entry):
    return "kai_hook.py" in json.dumps(entry)


def merge_hooks(existing, kai):
    out = {}
    for ev, arr in (existing or {}).items():
        keep = [e for e in arr if not is_kai_hook(e)]
        if keep:
            out[ev] = keep
    for ev, arr in kai.items():
        out.setdefault(ev, []).extend(arr)
    return out


def merge_instructions(existing, kai_block):
    if BEGIN in existing and END in existing:
        pre = existing[:existing.index(BEGIN)]
        post = existing[existing.index(END) + len(END):]
        return pre + kai_block + post
    user = existing.strip()
    return kai_block + "\n\n## Your rules\n\n" + (user + "\n" if user else "")


def kai_block_of(text):
    return text[text.index(BEGIN):text.index(END) + len(END)]


class Installer:
    def __init__(self, home, dry):
        self.home, self.dry = home, dry
        self.stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        self.backup = home / "kai-backups" / self.stamp
        self.manifest_path = home / "kai" / "manifest.json"
        old = {}
        try:
            old = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        except Exception:
            pass
        self.manifest = {"installed": sorted(set(old.get("installed", []))),
                         "backups": old.get("backups", {}), "version": None}

    def backup_if_foreign(self, target):
        """Back up a pre-existing path that Kai did not create."""
        rel = str(target.relative_to(self.home))
        if target.exists() and rel not in self.manifest["installed"] and rel not in self.manifest["backups"]:
            dest = self.backup / rel
            log(f"backup  {rel} -> kai-backups/{self.stamp}/")
            if not self.dry:
                dest.parent.mkdir(parents=True, exist_ok=True)
                (shutil.copytree if target.is_dir() else shutil.copy2)(target, dest)
            self.manifest["backups"][rel] = str(dest)

    def track(self, target):
        rel = str(target.relative_to(self.home))
        if rel not in self.manifest["installed"]:
            self.manifest["installed"].append(rel)

    def copy_tree(self, src, dst):
        self.backup_if_foreign(dst)
        log(f"install {dst.relative_to(self.home)}")
        if not self.dry:
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst, ignore=COPY_IGNORE)
        self.track(dst)

    def copy_file(self, src, dst):
        self.backup_if_foreign(dst)
        log(f"install {dst.relative_to(self.home)}")
        if not self.dry:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        self.track(dst)

    def run(self):
        h = self.home
        log(f"Copilot home: {h}")
        log(f"Python: {sys.executable} ({sys.version.split()[0]})")
        if not self.dry:
            h.mkdir(parents=True, exist_ok=True)

        # 1. Kai home (MEMORY preserved)
        kh = h / "kai"
        for item in sorted((SRC / "kai").iterdir()):
            if item.name in ("MEMORY", "manifest.json") or item.name == "__pycache__":
                continue  # never replace the user's memory or the live manifest
            dst = kh / item.name
            log(f"install kai/{item.name}")
            if not self.dry:
                kh.mkdir(parents=True, exist_ok=True)
                if item.is_dir():
                    if dst.exists():
                        shutil.rmtree(dst)
                    shutil.copytree(item, dst, ignore=COPY_IGNORE)
                else:
                    shutil.copy2(item, dst)
        self.track(kh)
        if not self.dry:
            for d in ("WORK", "KNOWLEDGE", "LEARNING/sessions", "STATE/sessions", "OBSERVABILITY"):
                (kh / "MEMORY" / d).mkdir(parents=True, exist_ok=True)
            learn = kh / "MEMORY" / "LEARNING" / "learnings.md"
            if not learn.exists():
                learn.write_text("# Learnings\n\n", encoding="utf-8")

        # 2. Agents and skills
        for f in sorted((SRC / "agents").glob("*.agent.md")):
            self.copy_file(f, h / "agents" / f.name)
        for d in sorted(p for p in (SRC / "skills").iterdir() if (p / "SKILL.md").exists()):
            self.copy_tree(d, h / "skills" / d.name)

        # 3. Global instructions (merged; user content preserved)
        target = h / "copilot-instructions.md"
        block = kai_block_of((SRC / "copilot-instructions.md").read_text(encoding="utf-8"))
        if target.exists():
            existing = target.read_text(encoding="utf-8")
            if BEGIN not in existing:
                self.backup_if_foreign(target)
            merged = merge_instructions(existing, block)
        else:
            merged = (SRC / "copilot-instructions.md").read_text(encoding="utf-8")
        log("install copilot-instructions.md (Kai block merged, your content kept)")
        if not self.dry:
            target.write_text(merged, encoding="utf-8")

        # 4. Hooks: merged into settings.json (Copilot loads inline hooks from there); other hooks kept
        st = h / "settings.json"
        try:
            settings = json.loads(st.read_text(encoding="utf-8-sig")) if st.exists() else {}  # PS 5.1 writes a BOM
        except Exception:
            log("settings.json is not valid JSON; refusing to touch it. Fix it and re-run.")
            return 1
        if st.exists() and "settings.json" not in self.manifest["backups"]:
            self.backup_if_foreign(st)
        settings["hooks"] = merge_hooks(settings.get("hooks", {}), hooks_config(h)["hooks"])
        log("install settings.json hooks (Kai entries merged, other hooks kept)")
        self.manifest["hooks_sha256"] = hooks_sha256(settings["hooks"])
        if not self.dry:
            st.write_text(json.dumps(settings, indent=2), encoding="utf-8")
        legacy = h / "hooks" / "kai.json"
        if legacy.exists() and not self.dry:
            legacy.unlink()

        self.manifest["version"] = (SRC / "kai" / "VERSION").read_text(encoding="utf-8").strip()
        self.manifest["installed_at"] = dt.datetime.now().isoformat(timespec="seconds")
        self.manifest["python"] = sys.executable
        if not self.dry:
            self.manifest_path.write_text(json.dumps(self.manifest, indent=2), encoding="utf-8")
            log("running doctor...")
            env = dict(os.environ, KAI_HOME=str(kh), COPILOT_HOME=str(h), PYTHONDONTWRITEBYTECODE="1")
            return subprocess.call([sys.executable, str(kh / "bin" / "kai.py"), "doctor"], env=env)
        return 0


def uninstall(home):
    mp = home / "kai" / "manifest.json"
    try:
        m = json.loads(mp.read_text(encoding="utf-8"))
    except Exception:
        log("no Kai manifest found; nothing to uninstall")
        return 1
    for rel in sorted(m.get("installed", []), reverse=True):
        p = home / rel
        if rel == "kai":
            # keep MEMORY, remove everything else
            for child in p.iterdir():
                if child.name != "MEMORY":
                    (shutil.rmtree if child.is_dir() else os.remove)(child)
            log("removed kai/ (MEMORY kept)")
            continue
        if p.exists():
            (shutil.rmtree if p.is_dir() else os.remove)(p)
            log(f"removed {rel}")
    st = home / "settings.json"
    if st.exists():
        try:
            s = json.loads(st.read_text(encoding="utf-8-sig"))
            s["hooks"] = merge_hooks(s.get("hooks", {}), {})
            if not s["hooks"]:
                del s["hooks"]
            st.write_text(json.dumps(s, indent=2), encoding="utf-8")
            log("removed Kai hooks from settings.json (other hooks kept)")
        except Exception as e:
            log(f"could not clean settings.json: {e}")
    ci = home / "copilot-instructions.md"
    if ci.exists():
        t = ci.read_text(encoding="utf-8")
        if BEGIN in t and END in t:
            rest = (t[:t.index(BEGIN)] + t[t.index(END) + len(END):]).replace("## Your rules", "", 1)
            rest = "\n".join(l for l in rest.splitlines()
                             if "Add your own preferences below this line" not in l).strip()
            if rest:
                ci.write_text(rest + "\n", encoding="utf-8")
                log("removed Kai block from copilot-instructions.md (your rules kept)")
            else:
                ci.unlink()
                log("removed copilot-instructions.md")
    for rel, src in m.get("backups", {}).items():
        if rel in ("settings.json", "copilot-instructions.md"):
            continue  # merged files are cleaned in place; backups stay in kai-backups/
        s, d = Path(src), home / rel
        if s.exists():
            if d.exists():
                (shutil.rmtree if d.is_dir() else os.remove)(d)
            (shutil.copytree if s.is_dir() else shutil.copy2)(s, d)
            log(f"restored {rel}")
    log("Kai uninstalled. Memory kept at kai/MEMORY; backups kept at kai-backups/.")
    return 0


def main(argv):
    if sys.version_info < (3, 8):
        log("Python 3.8+ required")
        return 1
    if not SRC.exists():
        log(f"payload folder missing: {SRC}")
        return 1
    home = copilot_home(argv)
    if "--uninstall" in argv:
        return uninstall(home)
    import migrate
    dry = "--dry-run" in argv
    rc = migrate.run(home, argv, dry=dry)
    if rc != 0:
        return rc
    return Installer(home, dry).run()


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
