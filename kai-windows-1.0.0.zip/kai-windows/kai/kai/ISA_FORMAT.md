# ISA Format Specification (Ideal State Artifact)

> Format version 2.21 (generic port), paired with Algorithm doctrine 8.20.3 (`~/.copilot/kai/ALGORITHM.md`). This file is the file-shape contract. The `/isa` skill implements it (workflows, examples). When the skill and this file disagree, this file wins. The deterministic reader is `python ~/.copilot/skills/isa/Tools/isa_tool.py` (`check`, `progress`, `ascent`, `frontier`, `status`, `validate`, `claim`, `release`, `asklog`, `reflect`).

Kai moves people from current state to ideal state by writing down what done looks like as testable claims, then refining the writing until every claim survives every test it can be subjected to. The ISA is that written record: the whole loop at single-artifact scale.

**Every ISA shares one meta-ideal-state above its specific one: euphoric surprise in the human using the system.** The specific ideal state varies with the work; the general one never does. `## Vision` is where the universal target takes specific shape (what euphoric surprise looks like for this work), which is why good ISAs write it as a concrete scene, not a feature list. The claims verify the specific summit; the Vision keeps the universal one in view.

**Ownership: the AI is the sole writer; hooks only read.** The AI writes all ISA content directly (Copilot's file-write tools, or `apply_patch`) and through the `/isa` workflows. Hooks read ISAs to mirror state and to gate. `isa_tool.py` never writes the ISA either; its lock and log state lives centrally under `~/.copilot/kai/MEMORY/`.

## What an ISA is

**One primitive with five identities:**

1. **Ideal state articulation.** The written hard-to-vary explanation of "done", in David Deutsch's sense: an account where every detail plays a functional role.
2. **Test harness.** The ISCs ARE the tests, each with a named probe. For a complex project they cover application logic, performance, security, access control, build and deploy.
3. **Build verification.** Passing the ISCs verifies what was built.
4. **Done condition.** The task is complete when all ISCs pass.
5. **System of record.** For the thing being articulated: the application, the library, the essay, the decision.

The same primitive applies in any domain: code, science, art, writing, life decisions, business strategy, applications, CLI tools, libraries, infrastructure.

**Don't invent parallel artifacts.** No `acceptance.yaml`, no separate test spec. The ISA covers that surface. A complex app's ISA naturally has many more ISCs, because its ideal state includes API behavior, performance budgets, the security model, access control, the auth flow and data-integrity invariants alongside task-specific deliverables. They aren't "in addition to" the ISA; they ARE the ISA.

Each ISC is a testable claim: one part of the explanation that can be tried against reality and either pass or fail. Hard-to-variability and testability are the same property. An ISC is hard to vary **if and only if** you can name a test that would falsify it. If you can't say what failure looks like, the ISC can be satisfied with anything. The whole ISA is hard to vary when removing or weakening any part changes what "done" actually means.

**The ISA is a living explanation.** It tightens through pursuit. The Goal sharpens, claims split or merge, decompositions clarify, driven by the user's feedback, by tool outputs, by research, and by claims failing verification. The ISA at scaffold is the best initial articulation; by the close it has been refined by everything the work surfaced. Hard-to-variability is the **outcome** of the process, not its precondition.

**Worked example.** Same goal, two framings:

```
Goal: ship the onboarding email with paid-tier confirmation.

Fluff:        - [ ] ISC-N: Email is delivered to the user.
              (Trivially passable. You can't name a test that would distinguish
              "delivered" from "delivered to spam.")

Load-bearing: - [ ] ISC-N: Email arrives in the primary inbox (not Promotions/Spam) within 60s.
              (Names a test that would fail. Removing it lets a "delivered to spam"
              outcome pass, and the goal silently mutates from "user sees the
              confirmation" to "the mail provider logged a send".)
```

The granularity rule (one binary tool probe per ISC) and the hard-to-vary quality bar are the same rule, seen from the operational and the epistemic side.

## Location

- **Project ISAs:** `<project-root>/ISA.md`, for anything with a lasting identity. The project's repo is the system of record. Tasks on the project read, modify and extend this one file; iteration on the project IS iteration on it.
- **Task ISAs:** `~/.copilot/kai/MEMORY/WORK/<slug>/ISA.md`, for ad-hoc, one-shot work: design sessions, investigations, exploratory tasks. The directory is created at scaffold (`kai.py isa new` creates it).

The format is identical for both; the lifecycle differs. Project ISAs grow continuously across many tasks. Task ISAs are created at the start of a run and closed at `phase: complete`. The session-start hook lists a project ISA in the working directory and recent open task ISAs; the postToolUse hook mirrors every ISA write to `MEMORY/STATE/work.json`.

## Frontmatter (YAML)

**Minimal by design.** Two load-bearing fields; the rest are recommended or conditional.

```yaml
---
phase: climbing                           # REQUIRED: minimal lifecycle value (see Field rules)
progress: 3/8                             # REQUIRED: closed claims / total claims, a mechanical count
task: "add --json output to the CLI"      # recommended; falls back to the H1 title
slug: 20260723-cli-json-flag              # recommended; falls back to the directory name
started: 2026-07-23T02:00:00Z             # recommended (ISO 8601)
updated: 2026-07-23T02:00:00Z             # recommended (ISO 8601)
---
```

**Rework and continuation** (written on reopen):

```yaml
iteration: 2                              # incremented when revisiting a completed ISA
resumed_at: 2026-07-23T02:00:00Z          # stamped on reopen
resumed_from_phase: complete              # stamped on reopen
frozen: true                              # opt-out: body edits do NOT reopen a completed ISA
```

**Hierarchy** (only when ISAs link into a tree):

```yaml
parent: 20260706-game-world               # slug of the parent ISA (omit for a standalone ISA)
children:                                 # slugs of child ISAs this one rolls up (omit for a leaf)
  - 20260706-combat-system
  - 20260706-magic-system
```

A child **inherits every ancestor `## Constraints`**. An inherited Constraint cannot be violated by a child ISC; overriding one is a parent-level renegotiation logged in the parent's `## Decisions`, never a silent child override. A parent's `progress:` may roll up its children (`3/5 children closed`). A change to any linked ISA triggers a blast-radius pass that lists downstream ISCs to re-verify: conflict detection is mechanical, resolution stays human. Standalone ISAs (the common case, more than 96% of them) omit both fields.

**The stated goal** (when goal detection fires and the minimum-content rule passes):

```yaml
principal_stated_goal: "verbatim user quote, byte-for-byte"   # NEVER paraphrased
principal_stated_goal_source: prompt                          # prompt | conversation | explicit-revision
principal_stated_goal_signal: 2                               # 1-4: which detection signal fired
principal_stated_goal_locked: 2026-05-12T17:23:56Z            # ISO 8601 time of capture
```

Detection signals:

| # | Signal | Pattern |
|---|--------|---------|
| 1 | Named metric + threshold | a quantitative target ("p95 < 200ms", "open rate above 35%") |
| 2 | Explicit outcome assertion | "I want X" / "achieve X" / "do this" |
| 3 | Completion condition | "until X" / "such that X" |
| 4 | Structural or design directive | an explicit verb-object on the system ("absorb", "replace", "unify") |

- **Fail-closed:** if the candidate literal is under 6 tokens OR has no propositional content ("make it good"), write `principal_stated_goal: null` and log the candidate to Decisions. Better silent than anchoring against useless text.
- **Multi-literal:** when a prompt holds several candidate literals, the first wins as `principal_stated_goal`; the others become derived Constraints.
- **Lifecycle:** the four fields are immutable unless the user explicitly revises the literal. A revision is recorded as a `## Decisions` row `refined: principal_stated_goal: was "<old>" now "<new>"`, and `principal_stated_goal_source` flips to `explicit-revision`.

**Ambiguity-check outcome** (substantial work):

```yaml
context_sufficient: true    # false when an ambiguity flag was used or `proceed` accepted reasoned defaults
interview_invoked: false    # true when targeted questions were actually asked
```

**Journey summary** (optional one-liners, useful on dashboards and session-start context):

```yaml
current_state: "Code has 47 type errors blocking deploy"   # the before; immutable once written
ideal_state: "Zero type errors, deploy passes CI"          # the after; aligned with the Goal, may sharpen
capabilities_invoked: [isa, first-principles, kai-reviewer] # append-only: capabilities actually invoked
```

**Tolerated legacy keys, never written on new ISAs:** `effort`, `effort_source` (effort tiers are retired; spend is discovered from the work), `mode`, `algorithm_config` and optimize/ideate blocks (the mode system is retired), `response_mode`, `algorithm_mode`, and the old density-gate keys (`density_score`, `divergence_risk`, `density_gate_acknowledged`, `context_checks_fired`, `frame_drift`, `frame_drift_summary`). Their presence is never a failure and their values are never validated. `created:` is accepted as a synonym for `started:`.

### Field rules

- `phase`: **a minimal lifecycle bracket, not a station walk.** Write an active value at run start: `marking` while articulating what done means (`scoping` is an accepted synonym; `starting` may appear before the scaffold settles), `climbing` during the build. `learn` on reopen. `complete` at the close. Update it in between only when it genuinely changes. The retired station names (`observe`, `think`, `plan`, `build`, `execute`, `verify`) parse everywhere but are never written on new ISAs. **Nothing switches on the literal.** It resolves through `PHASE_TO_ASCENT` in `isa_tool.py`, the one table that names every run state (see ALGORITHM.md § The ascent states).
- `progress`: `M/N` where M = closed claims and N = total counted claims (non-dropped leaves). Updated the moment a claim closes; never batched at the end. `isa_tool.py progress <isa>` prints the mechanical value.
- `task`: imperative mood, at most 60 characters. Describes the deliverable, not the process.
- `slug`: `YYYYMMDD-kebab-description` (or `YYYYMMDD-HHMMSS_kebab-description`).
- `started`: set once at creation, never modified.
- `updated`: set on every edit (ISO 8601).
- `iteration`: omitted on the first run; `2` on the first continuation, incremented after that.

## Body sections

**Seventeen sections in fixed order.** Each appears only when populated: never create empty placeholder sections. The substance-scaled Completeness Gate (below) decides which are required for a given piece of work.

Heading vocabulary: the claims section is headed `## Claims` (current) or `## Criteria` / `## ISC Criteria` (legacy, still parsed). Claim IDs may be `ISC-N` or short form (`C1`, `A3`, `EQ-12`; `A`-prefixed short IDs are anti-claims). The ID separator may be `:` or an em-dash. Anti-claims may live inline (`Anti:` prefix) or in a dedicated `## Anti-claims` section. The provenance section may be headed `## Verification` or `## Log`.

| # | Section | Purpose | Written at |
|---|---------|---------|------------|
| 1 | `## Problem` | What is broken or missing right now that makes the ideal state worth pursuing | scoping |
| 2 | `## Vision` | Experiential intent: what euphoric surprise looks like, 1–5 sentences, a concrete scene | scoping |
| 3 | `## Out of Scope` | Anti-vision: what is *not* included, declared in prose | scoping |
| 4 | `## Language` | The project's ubiquitous language. One block per term: meaning, an `_Avoid_:` line naming what it displaces, relationships. Glossary only. **A term enters only after it has actually caused a confusion.** Project ISAs; task ISAs inherit by reference | scoping → any point |
| 5 | `## Principles` | Substrate-independent truths the work must respect | scoping |
| 6 | `## Constraints` | Immovable architectural mandates (plus every Constraint inherited from `parent:`) | scoping |
| 7 | `## Dependencies` | Cross-ISA needs, one machine-readable line each: `requires: <slug> — <what/contract>`. Load those ISAs before scaffolding claims. Only when the ISA has cross-ISA needs | scoping |
| 8 | `## Goal` | The hard-to-vary spine: 1–3 sentences naming verifiable done. Opens with the verbatim stated goal in quotes when one was captured | scoping |
| 9 | `## Claims` | **Feature-less mode:** the flat home for atomic claims (one binary probe each) when the work has no distinct features. Includes `Anti:` and `Antecedent:` claims. When the work HAS distinct features, omit this and use `## Features` blocks (#13) | scoping → climbing |
| 10 | `## Not yet specified` | Fog: in-scope questions too dim to be claims yet. One line each: `- fog: <the question, as precisely as it can be stated now> — <what must resolve before it sharpens>`. Graduates to an ISC (or dies via Decisions); never checked, never counted. Empty at close. Only when the work has fog | scoping → any point |
| 11 | `## Bridge Criteria` | Cross-ISA integration claims: `- [ ] ISC-N: Bridge: <what must hold across the seam>`, with `anchors_to: cross: <slug>` in Test Strategy. Verified as a distinct pass after leaf claims. Only when the ISA has siblings | scoping → climbing |
| 12 | `## Test Strategy` | Per-claim verification: the harness contract `isa_tool.py` reads positionally (see below) | scoping |
| 13 | `## Features` | **Feature mode:** holds the claims as blocks, `### F<n> · <name>` + a one-line `Why:` + its ISCs. `F0 · Cross-cutting` holds spanning claims. Use this OR flat `## Claims`, never both | scoping → climbing |
| 14 | `## Decisions` | Timestamped log including dead ends; `refined:` prefix for Goal or claim-set restructures | any point |
| 15 | `## Learning` | Conjectured / refuted by / learned / criterion now entries: the error-correction trail, written only when understanding changed. **Not a changelog** | learning |
| 16 | `## Verification` | One-line provenance stub per closed claim (leaf and bridge). May be headed `## Log` | climbing → close |
| 17 | `## Remaining Work` | Concrete work this ISA still owes that was never a claim of *this* run: follow-ups, handoffs, things noticed at close. `- [ ] <the work> — <why not a claim of this run / what it waits on>`. **Recording an item here IS a complete disposition** (no card or issue also required). Advisory, omit when empty, never gated, never counted toward coverage | learning |

The **backlog** of an ISA is the union of its unchecked claims and its unchecked Remaining Work items, so "what does this ISA still owe" is answerable from the artifact alone. Unchecked claims stay in their claims section (the ID-stability rule forbids moving them); Remaining Work is only for work that was never a claim of the run. Fog is different again: in-scope questions too dim to be claims.

### `## Test Strategy`: the column contract

Column order is positional and is the contract `isa_tool.py` reads (cells 0–7):

```
| isc | type | check | threshold | tool | anchors_to | severity | tier |
```

- **`isc`**: the claim ID. One row per leaf claim.
- **`type`**: one of the ISC type vocabulary below.
- **`check`**: what is checked, in words.
- **`threshold`**: the pass condition. Keep the column even when empty; drop it only by writing an empty cell, never by deleting the column, or `anchors_to` shifts into the wrong slot and the anchor check misfires on rows that visibly carry an anchor.
- **`tool`**: the exact command or probe. Backticks around it are stripped as formatting. Escape a literal pipe inside a cell as `\|`.
- **`anchors_to`**: `literal` (traces to the stated goal), `derived: <sub-claim>`, or `cross: <slug>` (bridge claims). Required on every row when `principal_stated_goal` is set.
- **`severity`** (optional): `critical` or blank (= normal). A failing `critical` probe means the thing is DOWN even when every other probe passes: use it for claims asserting the thing does its JOB, not merely that it answers. *(Cause: a service answered HTTP 200 for 24 hours over a dead content pipeline while every probe stayed green.)* Any other single word is reported as an unknown severity rather than silently downgraded.
- **`tier`** (optional): `deep` or blank (= fast). A row with a tier writes the severity cell too (blank when normal) so slots stay aligned.

## Feature blocks: the exact shape

When the work has distinct features, `## Features` holds the claims as blocks:

```markdown
## Features

### F0 · Cross-cutting
Why: invariants that hold across every feature: security, deploy, data integrity.

- [x] ISC-1: Every response carries HSTS and X-Content-Type-Options headers.
- [x] ISC-2: All database access is parameterized: no string interpolation of values into SQL.

### F1 · Billing
Why: a visitor becomes a paying subscriber and can cancel on their own, without support.

- [x] ISC-3: Checkout creates a payment session with server-side pricing.
- [x] ISC-4: A 14-day trial charges exactly once, on day 15.
- [ ] ISC-5: Anti: a replayed payment webhook never double-charges (idempotent on event ID).
```

Four rules (all structure, none a new gate):

- **`F0` is reserved** for cross-cutting claims; feature blocks are `F1`, `F2`, … in build or read order. Feature numbers are display order, not identity: reordering blocks is free.
- **ISC IDs stay global and stable across the whole ISA** (`ISC-N`), never per feature. That keeps Test Strategy (keyed by ISC) working and preserves ID stability for Reconcile. Moving an ISC between features never renumbers it.
- **The `Why:` line is the feature's ideal state in one sentence:** why it exists, what done means for it. It must say what the name and the claims don't. A `Why:` that restates the name is noise; cut it.
- **Either flat `## Claims` or `## Features` blocks, never both.** Trivial and small work stays flat. `## Anti-claims`, `## Bridge Criteria` and `## Not yet specified` stay their own H2 sections in both modes.

**Features are vertical slices, not horizontal layers.** Each feature cuts end to end to a verifiable increment satisfying at least one ISC; not "the data layer" then "the API layer". A feature you can't verify on its own is a horizontal slice: re-slice it. The one exception is the **wide sweep**, a single mechanical change whose blast radius fans across the whole artifact (renaming a concept across a corpus, retyping a shared symbol, migrating a convention), where no vertical slice can land verified alone. Sequence it **expand–contract**: expand (introduce the new form beside the old, nothing breaks), migrate in blast-radius-sized batches that each verify on their own, then contract (remove the old form once nothing references it).

Free consequences of the shape: **query** (`rg "^### F" ISA.md` lists every feature and its Why), **doc generation** organized by feature, and **intent** (each feature carries why it was added).

## The changelog is git; evidence collapses on close

**The ISA carries NO in-document changelog section.** `git log -- <isa-path>` is the authoritative change record and commit messages are its entries, so the design doc never rots into a growing log. What the ISA keeps is the **living surface**: `## Decisions` (including dead ends) and the `## Learning` trail, written only when understanding actually changed. A legacy section literally named `## Changelog` that holds the conjectured/refuted/learned trail is accepted as an alias for `## Learning` (rename it on next touch); one that holds iteration-by-iteration narrative is a hard failure.

**Evidence collapses on close.** The moment a claim goes `[x]`, its `## Verification` entry shrinks to a **one-line provenance stub** (a commit hash, a test name, a probe ref), never a retained paragraph. The proof lives in git and CI; the ISA points at it.

## Completeness Gate (substance-scaled)

The gate scales with the **substance of the work**, discovered from the work itself, never predicted from a label:

| Substance | Required sections |
|-----------|-------------------|
| **Trivial** (mechanical, single-probe, minutes) | Goal, Claims. A minimal direct-written ISA; shape check noted inline |
| **Substantial** (multi-claim build, real blast radius) | Problem, Vision, Out of Scope, Constraints, Goal, Claims (flat or Features blocks), Test Strategy* |
| **Deepest** (frontier multi-component work) | Everything above plus Principles, Decisions, Learning*, and the Interview workflow run before building |

\* `## Dependencies` and `## Bridge Criteria` are **conditional-required**: mandatory when the ISA has any `parent:` / `children:` / cross-ISA relationship, omitted (like any empty section) for a standalone ISA. `## Not yet specified` appears only when the work genuinely has fog. `## Language` appears only when a term has actually been confused; an empty or speculative glossary is worse than none. `## Remaining Work` is never required at any substance.

**Project ISA override:** any `<project>/ISA.md` requires at least substantial-grade structure regardless of how small the current task is. The project file is the long-lived source of truth; one transient task must not downgrade it.

**The mechanical gate.** `isa_tool.py check <isa>` enforces the un-gameable structural subset and reports the rest:

- **Hard at every substance:** frontmatter present; `phase` a known value; Goal present; at least one claim; flat Claims and Features not both present; duplicate IDs, self-edges, unknown-ID edges and edge cycles; a stated goal under the minimum-content rule, or a recorded signal with a null literal; a `## Changelog` holding narrative.
- **Hard at `phase: complete`:** `progress` that is not a mechanical `M/N` matching the claims; any line left in `## Not yet specified`.
- **Hard when `principal_stated_goal` is set:** a Test Strategy row without `anchors_to`.
- **Hard on substantial and deepest:** the required sections above; zero anti-claims; a leaf claim with no probe (no Test Strategy row and no inline `Probe:`).
- **Hard with `--experiential`:** no `Antecedent:` claim.
- **Soft (reported, never blocking):** a stale `progress` mid-run, an empty section left in place, Verification lines that are paragraphs instead of stubs, an unknown type, severity or tier value, a Test Strategy row keying an unknown claim, and a missing `context_sufficient` on substantial work.

Count-gameable checks stay advisory on purpose: a gate that blocks on a count manufactures the count. The richer semantic review (coverage of every named subsystem, granularity, artifact presence) is the model-run CheckCompleteness workflow in `/isa`. `ext/isa_gates.py` runs the mechanical gate when `phase: complete` is written in the current turn, so legacy closed ISAs are never gated retroactively.

## Three-guardrail taxonomy

Adjacent concepts, distinguished by *who they bind*:

| Guardrail | Binds | Tone | Example | Lives in |
|-----------|-------|------|---------|----------|
| **Principles** | the *thinking* | aspirational, generalizable | "User-facing systems prioritize responsiveness." | `## Principles` |
| **Constraints** | the *solution space* | immovable, non-negotiable | "No home-grown cryptography: OAuth through a standard library only." | `## Constraints` |
| **Out of Scope** | the *vision* | declared, explicit prose | "Mobile native apps are not part of v1." | `## Out of Scope` |
| **Anti-claims** | the *test surface* | granular, yes/no | "Anti: /admin returns 200 in the v1 build." | claims section (`Anti:`) or `## Anti-claims` |

The first three are author-stated and declarative. Anti-claims are derived: they are how Out of Scope, Constraints and Principles become probe-able.

## ID-stability rule

**Claim IDs never renumber on edit.** Splits become `ISC-N.M` with the parent preserved; drops become tombstones (`- [ ] ISC-N: [DROPPED — see Decisions 2026-04-15]`). References in Decisions, Learning and Verification stay valid, and Reconcile (which merges ephemeral feature files back by ID) depends on it: renumbering breaks those merges silently, and the failure looks like "the worker's checkmarks didn't land".

## Claims: the rules

```markdown
- [ ] ISC-1: Criterion text, 8–12 words, binary testable, a state not an action
- [ ] ISC-2: Antecedent: the precondition that reliably produces the target experience
- [ ] ISC-3: Anti: what must NOT happen
```

- Each claim describes an **end state**, not an action, in about 8–12 words.
- **Binary testable:** true or false, no judgment required (attested claims are the explicit exception, closed by the user).
- **Atomic:** one verifiable thing per claim, no compound statements.
- All claims number **sequentially in one pool**; the `Anti:` / `Antecedent:` prose prefixes carry the doctrinal kind. (Legacy bracket tags like `[F]` and the old `ISC-A-N` anti numbering still parse; never write them.)
- Check (`[x]`) a claim **immediately** when its probe passes, never batched at the end, and update `progress` on every change.

**The Splitting Test** (apply to every claim):

| Split when the claim… |
|---|
| contains "and" / "with" / "including" joining two verifiable things |
| has a part A that can pass while part B fails |
| contains "all" / "every" / "complete": enumerate what that means |
| crosses a domain boundary (UI / API / data / logic): one claim per boundary |
| verifies a change to a shared symbol or derived artifact: enumerate its consumers, one probe each (one stale consumer means the whole class is suspect) |
| has no nameable probe: it is not yet atomic |

**The Variation test:** if you can rephrase a claim without changing what would falsify it, it is too vague. If you can weaken it and no probe would notice, it is not load-bearing.

**Granularity rule:** split until each claim is one binary tool probe: a single tool call (read the file, search, run a command, `curl -i`, a screenshot you look at, a `SELECT`, or the user recognizing it on encounter for experiential claims) returns yes or no. This IS the operational form of hard-to-variability.

**Nested claims** are allowed when they help organize a complex ISA: markdown nested checkboxes with hierarchical IDs (`ISC-1` → `ISC-1.1`, `ISC-1.2` → `ISC-1.1.1`). The granularity rule applies at the **leaf**: leaves are atomic claims; a parent is a container that passes when all its leaves pass, and only leaves count toward `progress`. Don't nest for its own sake; flat is fine for small ISAs.

**Two doctrinal minimums:**

| Kind | Surface form | Rule |
|------|--------------|------|
| Anti-claim | `- [ ] ISC-N: Anti: what must NOT happen` | at least 1 (a goal with zero failure modes worth naming is under-specified) |
| Antecedent | `- [ ] ISC-N: Antecedent: precondition that produces the target experience` | at least 1 when the goal is experiential |

**Coverage Gate (replaces any numeric claim count).** Every subsystem named in Vision or Goal has a container claim, and every container decomposes through the Splitting Test until each leaf is one binary probe. A 24-leaf ISA passes if it covers the surface; a 300-leaf ISA fails if a named subsystem has none. Never split to hit a number; split until each leaf is one probe, then stop.

**Coverage is assessed at the close, not at scaffold.** A subsystem whose shape is genuinely unknown at scaffold is not covered by inventing speculative claims for it. It is held as fog in `## Not yet specified` and graduates into claims as the work sharpens it. At `phase: complete` the gate is strict: every named subsystem has real coverage AND the fog section is empty. **The graduation test:** can you state the question precisely now (not answer it, *state* it)? Statable with a nameable falsifier → a claim, even if blocked. Statable but not yet probe-able → fog. Beyond the vision → Out of Scope.

**Anti-claims default to universal form on substantial work.** "API_KEY isn't in the env" becomes "every env-var name spawned into a child process fails the pattern `/API_KEY|AUTH_TOKEN/i`": a property covering the failure pattern, not one instance. Example-shaped anti-claims are fine when the input domain is small and finite, or when a Decisions row records why universal form doesn't apply.

## ISC type vocabulary

The `type` column of `## Test Strategy` accepts a closed vocabulary. Each names a verification mechanism with a known probe form.

| Type | Probe form | When to use |
|------|------------|-------------|
| `test` | the project's test runner exits 0 for a named test (`python -m unittest tests.test_x`, `pytest -k`, `npm test -- -t`, `go test -run`…) | example-based correctness: fixed-input deterministic code |
| `property` | a property-based test over generated inputs (the project's PBT library, or a seeded generator loop in a plain unit test) with a stated run budget | universally quantified correctness: pure functions, parsers, serializers, math, data transforms |
| `mutation` | a mutation-testing run whose kill rate meets the threshold | proving the tests themselves can fail; security and core surfaces |
| `shell` | a shell command (PowerShell or bash) exits 0 / its output matches | file, search, diff, JSON probes |
| `http` | an HTTP probe whose status, headers or body match (`curl -i`, `Invoke-WebRequest`) | reachability and contract probes. Kept distinct from `shell` because an HTTP probe can run from anywhere (a scheduled remote monitor), while a general shell probe needs the local machine |
| `screenshot` | a real-browser capture of the actual URL, viewed | UI rendering and appearance |
| `eval` | an eval suite reaching pass^k ≥ threshold | behavioral, quality or regression properties one direct probe can't close (tone survival, skill routing, no-fabrication). The multi-sample class only; elected by judgment, never the default |
| `manual` | the user recognizes it on encounter | experiential claims: design, voice, "feels right" |

Accepted legacy aliases: `bash`, `powershell` (= `shell`), `curl` (= `http`), `unit-test`, `unittest`, `pytest` (= `test`), `sql`.

**`property` row shape:**

```
| isc   | type     | check                                   | threshold  | tool | anchors_to |
| ISC-N | property | round trip: parse(serialize(x)) == x    | 1000 runs  | python -m unittest tests.test_roundtrip | literal |
```

State the universal claim in `check`, bound the generator to the function's real input domain, and give a run budget (default 1000; 10000 for invariant-critical claims; 100 for slow generators).

**On substantial work**, every pure-function claim SHOULD have at least one `property` row. **On core or security surfaces** (hooks, the ISA primitive itself, auth, secrets, identity code, release gates), a pure-function claim MUST name a probe stronger than a single example test (a `property` row or a `mutation` check), because an example test on a security boundary proves one input, not the class. When property form doesn't apply (impure function, infinite-state machine, externally driven dependency), record why in Decisions.

## Verifier classes and execution tiers

Every claim closes through one of three **verifier classes**: who or what can say no to it. The class is **derived from the `type` column**; there is no field to author.

| Class | `type` values | Who says no | Failure semantics |
|-------|---------------|-------------|-------------------|
| **deterministic** | `test`, `property`, `mutation`, `shell`, `http`, `screenshot` | a tool | the only class that may block: deploy gates and close gates run here |
| **judged** | `eval` | a model bound to a stated rubric, over multiple samples | repeatable and evidence-producing; a failure flips the claim open and raises a finding, never blocks a ship |
| **attested** | `manual` | the user, on encounter | a dated verdict plus an evidence pointer; tracked for staleness, never auto-failed, never blocking |

- **Prose sections have no class.** Problem, Vision, Principles, Out of Scope and fog steer scope; they can never fail. Only claims verify.
- **The schema is constant across domains; only the class mix varies.** An application skews deterministic, a story skews judged ("the wound surfaces before the midpoint" closes through a rubric), a watercolor skews attested ("the gradient reads luminous" closes when the user looks and says yes). Same sections, same claim shape, same Test Strategy contract.
- **An unavailable verifier means DEFER, never fail** (`RULES/Verification.md`). The claim goes open with a reason. An ISA never breaks; it shows honest state.

**Execution tier** (optional `tier` column):

- **fast** (default, blank): seconds. Runs in the dev loop and the deploy gate; the only tier that may block anything.
- **deep**: minutes to hours (soak, load, full browser sweeps, multi-sample eval suites). Runs on a schedule; a failure alerts and flips the claim open, never blocks work. `eval` rows are deep by default; mark one fast only when its suite provably runs in seconds.

## Probe conventions

**Blast-radius probe strictness.** Match probe strictness to what the claim touches. When a claim touches **high-blast** surface (secrets or `.env`, auth, user data, money movement, a push to a *public* remote, a production deploy), its Test Strategy row names a deterministic probe (never `manual`), and the change satisfying it lands in a small, line-readable diff. **Low-blast** claims (static content, internal plumbing, anything reaching no network, database or user data) can be verified empirically (test, output match, screenshot) without a line-by-line read, and tolerate large diffs.

**Probe placement: the seam rule.** Probes attach at the boundary where the thing meets its consumer, at the **highest boundary that exercises the claim**, and that boundary is agreed (written into Test Strategy) before building, never chosen afterwards to fit what got built. Verify behavior through the boundary, never internals: an essay by what a reader encounters, a service by its public interface, a deploy by the live URL, an album by the listening experience, a CLI by its invocation. Prefer existing boundaries over inventing new ones; the fewer distinct probe boundaries, the more each one proves. A probe that reaches past the consumer boundary into internals verifies structure, not the claim.

**Prototype as probe.** When a claim hinges on an unresolved **design question** (how should this behave, what should this look like, does this model of the problem hold), the cheapest honest probe is a throwaway concrete artifact to react to: a sketch, an outline, a rough take, a stub, runnable code. Mark it disposable and keep it out of the main line (a scratch folder, a throwaway branch). Only the *decision* it settles folds back: into the claim it sharpens, a Decisions row, and, when a fragment encodes the decision more precisely than prose, that fragment inlined and attributed. The prototype answers the question and dies; the decision persists.

**Render states for async UI.** When a claim covers a surface that fills asynchronously (a panel, list or view fed by a fetch, query or job), "renders correctly" is four states: **loading, error, empty, populated**. The claim enumerates them (or splits into one leaf per state), and the probe names which state it captured. A check that only exercises the populated, fresh-load state leaves three states unverified, which is how a broken loading skeleton, an unhandled fetch error, or a fixture rendering in place of a real empty set ships as done.

**Pre-build probe run.** Before building, run the deterministic probes for any claim that could plausibly already hold. A probe that passes before the work exists means either the claim was **already true** (delete it, or sharpen it until it isn't) or the probe **cannot fail** (it is tautological, asserts structure rather than the claim, or reaches past the seam: fix it before it certifies anything). Scope: deterministic types only. It is never applied to `manual` / experiential claims, where demanding a falsifying observation is ceremony. A habit, not a gate.

**Prefer red before build.** Where a claim's probe is a runnable test, write it so it FAILS before the build and passes after. Probes that can only be a screenshot or a manual check are exempt. This governs *when the probe is written and run*, not how to write code.

**Unclaimed-work check.** At the close, read the diff against the claim set and name anything that shipped which no claim asked for. An ISA verifies the claims it holds, so uncovered work is structurally invisible to it. Findings go to Decisions as either a retroactive claim (it was wanted: articulate it) or a removal (it wasn't). Advisory, never blocking, and deliberately not a standing `Anti:` line, because a mandatory anti-claim manufactures its own count.

## Dependency edges and the frontier

When claims have real execution ordering, encode it on the claim line as a trailing parenthetical:

```markdown
- [x] C1: Schema migrated to v2 with a verified rollback script.
- [ ] C2: Import pipeline reads v2 rows (after: C1).
- [ ] C3: Dashboard renders imported data (after: C2).
- [ ] C4: Docs page updated.                      ← no edge: independent, takeable now
```

- **Syntax.** `(after: ID[, ID...])` as the LAST parenthetical of the description, optionally before a final period. IDs are claim IDs from the same ISA (any legal form). Backticked code spans and mid-line parentheticals never parse as edges, so a claim can quote the syntax safely. Edges are intra-ISA only; cross-ISA needs stay in `## Dependencies`.
- **Semantics.** A claim is **takeable** when it is open (unchecked, not tombstoned), every `after:` blocker is resolved (checked or dropped, so a killed claim never blocks forever), and no fresh lock is held on it. The frontier is the set of takeable claims, computed, never re-derived by rereading the whole ISA.

**The tool:** `python ~/.copilot/skills/isa/Tools/isa_tool.py <cmd> <isa>`

| Command | Does |
|---------|------|
| `frontier` | takeable claims plus taken / blocked counts (`--json` for structured output) |
| `status` | full partition: takeable / taken by whom / blocked on what / closed / stale locks |
| `claim --id C4 --session S` | atomic take; exit 2 if closed, blocked or held; re-claiming with your own session refreshes the lock (heartbeat) |
| `release --id C4 --session S` | release your own lock (`--force` overrides) |
| `validate` | edge integrity only: cycles, unknown IDs, self-references, duplicates, all loud |

**Concurrent sessions.** Locks are exclusively created files at `~/.copilot/kai/MEMORY/STATE/isa-locks/<sha1(real path)>/<claim-id>.lock`, atomic on one machine. `--session` is the Copilot session ID, never a shared label (a shared label would make every session "the owner" and defeat the exclusion). Long-running work re-claims periodically to stay fresh. Stale locks (older than 2 hours; tune with `--ttl-hours`) are surfaced and takeable. A session sharing an ISA claims before building and releases at the close; a solo run never needs the protocol. Multi-session **planning** works the same way: when the fog exceeds one context window, the ISA holds the map and each scoping or research session takes a takeable unit.

**Three invariants:** the tool never writes the ISA (lock state is central, never beside the ISA, never in a project repo); edges ride inside free-text descriptions that every other reader treats as opaque; and edges are **optional forever** (no gate requires, counts or rewards them; a fully edged ISA whose work was actually parallel is decoration).

## `## Language`: the shape

One block per term. The `_Avoid_:` line is load-bearing: it names what the term *displaces*, which is what actually stops drift.

```markdown
## Language

**Cut**: staging a release candidate locally. Produces an RC; publishes nothing.
_Avoid_: ship, release, publish (all three imply the public repo, which only the release workflow touches).

**Skill**: a packaged capability with a SKILL.md the model invokes.
_Avoid_: agent (an agent is a spawned executor), command (a thin invoker over a skill).
```

- **Entry on confusion, never on speculation.** A term earns a block after a real collision: a wrong name shipped, one word covering two things, the user and the model meaning different things by it. A proactively written glossary predicts which words will bite, and predicts badly.
- **Glossary only.** No implementation detail, no claims, no scratch. The moment a block explains *how* something works, it duplicates the Goal or the claims and gets cut back to naming.
- **Project ISAs.** A task ISA inherits its project's language by reference and never restates it.

## Section specs

### `## Goal`

**The hard-to-vary spine, 1 to 3 sentences.** States what done looks like in coherent prose. When a stated goal was captured, the Goal opens with it verbatim, in quotes, before any derived prose. Required whenever the ideal state isn't trivially captured by `task` (large or experiential work, multiple deliverables, ambiguous targets).

The Goal is the tightest verbal form of the ISA. The rest of the document elaborates and tests it; the claim set is its decomposition into testable claims. If you can edit the Goal without changing the claim set, the Goal isn't load-bearing. If the Goal stays and the claims drift away from it, the decomposition is wrong. The Goal is a living statement: sharpen it as the work surfaces signal, and log structural changes in Decisions with a `refined:` prefix.

### `## Decisions`

A timestamped log, written at any point when a non-obvious choice is made. Include dead ends: failed approaches stop future sessions from re-exploring them. Use `refined:` when a decision changes the Goal or restructures the claim set (split, merge, drop, add); refinements are how the living-document property shows up in the artifact.

```markdown
- 2026-02-24 02:00: Chose X over Y because Z.
- 2026-02-24 02:30: ❌ DEAD END: Tried B. It failed because C (don't retry).
- 2026-02-24 03:00: refined: Goal sharpened: added "without breaking the external API" after research surfaced the consumer count.
- 2026-02-24 03:15: refined: ISC-7 split into ISC-7.1 / ISC-7.2: the verify probe revealed two distinct failure modes.
- 2026-02-24 04:00: [arch] JSONL for streaming state: append-only, crash-safe, tailable; replaces a single-file JSON snapshot.
```

**The `[arch]` tag.** Prefix a decision with `[arch]` iff it establishes or changes a structure, contract or convention that work in *other* tasks must conform to (a file format, a state-management pattern, a naming convention, a cross-task protocol). Choices local to this task (which library for this feature, solo vs delegated) are not `[arch]`. Tagged decisions are what a project's architecture log is harvested from (`rg "\[arch\]" -g ISA.md`).

### `## Learning`

The error-correction trail, written only when understanding changed. Every entry has all four pieces, in this order; a partial entry is a Decision, not a Learning entry.

```markdown
- 2026-02-22 | conjectured: buyer self-attestation will scale verification at low ops cost
  refuted by: 3 of the first 8 attestations were the wrong buyer profile
  learned: verification is the load-bearing trust signal; attestation without review degrades the pool
  criterion now: ISC-18 adds the manual review step explicitly
```

### `## Verification`

One-line provenance stub per closed claim:

```markdown
- ISC-1: screenshot pass — MEMORY/WORK/<slug>/proof/layout.png
- ISC-2: `python -m unittest` 14/14 green — commit a1b2c3d
- ISC-3: no-secrets sweep green — `rg` probe, commit a1b2c3d
```

## Continuation and rework

When a follow-up prompt continues the same task:

1. The session-start hook lists recent open ISAs; the AI picks the one matching the work (or the edit lands on a `phase: complete` ISA).
2. A body edit on a completed ISA is a **reopen**: `phase:` rewinds to `learn`, `iteration` increments, `resumed_at` / `resumed_from_phase` are stamped. `frozen: true` opts out. `ext/isa_gates.py` flags the reopen; the AI writes it.
3. The run continues against the same artifact. Resume reads the ISA, never the conversation.
4. `MEMORY/STATE/work.json` mirrors the reopened state.

A genuinely new task gets a new ISA with a new slug.

## Ephemeral feature files

When a feature is worked in an isolated context (a parallel `copilot -p` worker, a `task` subagent, a fresh session), the `/isa` Scaffold workflow in ephemeral mode (deterministically: `kai.py isa excerpt <master> <F-id>`) writes a derived slice to `<master-dir>/_ephemeral/<F-id>-<feature>.md`, headed by a `<!-- KAI:EPHEMERAL derived-from: <master> feature: <F-id> -->` marker: Vision and Goal as read-only context, the relevant Constraints, that feature's claims with their stable IDs, the matching Test Strategy rows, and an empty Verification section. The worker operates on the slice alone; the Reconcile workflow (`kai.py isa reconcile <ephemeral>`) merges checkmarks, provenance stubs, decisions and learning back to the master by ID, then archives the slice. **Ephemeral files are derived views, never sources of truth, and never hand-edited as policy.**

## Sync pipeline

1. **The AI writes the ISA** with Copilot's file tools.
2. **Core `kai_hook.py`** (postToolUse) sees the write, parses frontmatter and claims, mirrors `phase` and closed/total into `MEMORY/STATE/work.json`, and emits a `⚙️ SYSTEM: ISA <slug> — M/N claims closed` line.
3. **`ext/isa_gates.py`** derives the ascent state and, on a change, injects the `════ Kai | Algorithm | <icon> <Label> ════` strip; at agentStop it runs the mechanical gate on a `phase: complete` written this turn.
4. **The session-start hook** reads open ISAs back as resume candidates.

The AI is the sole writer. Hooks only read. `work.json` is derived state.

## Design rationale

- **Few fields.** Only fields something consumes. Dead fields waste tokens and rot.
- **Fixed section order, sections only when populated.** Each section has one purpose; empty sections never appear.
- **Checkboxes over formal spec languages.** Simpler to parse, write and verify.
- **YAML frontmatter.** The universal convention.
- **Reference file, not inline instructions.** This spec loads on demand; the always-loaded instructions only point at it.
- **Universal primitive.** One structure serves software, science, art, writing, decisions and strategy. Hard-to-variability is the universal quality bar, testability its operational form, and refinement through pursuit the living document.
- **No scaffolding a smarter model wouldn't need.** Separate probe fields, separate current/ideal-state sections, variation-audit sections and tier-gated additions were all proposed and rejected: clear claim text and real probes do the same work.

## Examples

### A well-formed ISA in miniature

The task: **add a `--json` output flag to a small CLI tool.** The whole ISA, closed:

```markdown
---
task: "add --json output flag to the CLI"
slug: 20260723-cli-json-flag
phase: complete
progress: 3/3
started: 2026-07-23T14:00:00Z
updated: 2026-07-23T14:40:00Z
---

## Goal
The CLI accepts a `--json` flag that prints one valid JSON object carrying the
same data it prints as text, and the default text output is unchanged.

## Claims
- [x] C1: `--json` prints output that parses as a single JSON object.
- [x] C2: The JSON carries the same fields the text output shows.
- [x] C3: Anti: running without `--json` produces byte-identical text to before.

## Test Strategy
| claim | type  | check                                  | threshold | tool                                           | anchors_to |
| C1    | shell | `--json` output parses as JSON          | exit 0    | `cli --json \| python -m json.tool`             | literal |
| C2    | test  | fields(json) == fields(text)            | equal     | `python -m unittest tests.test_cli.JsonParity` | literal |
| C3    | shell | plain output vs saved baseline          | empty     | `cli > now.txt; git diff --no-index --exit-code baseline.txt now.txt` | derived: text-parity |
```

What it shows: minimal frontmatter with no invented or retired keys; `progress: 3/3` is a mechanical count; claims number in one pool and the anti-claim is `C3`, carried by its `Anti:` prefix; every claim names one binary probe, and `anchors_to` traces each to the literal or a named derivation; empty sections simply don't appear.

### ID stability in action

Mid-build, `ISC-2` turns out to hide two failure modes (the JSON parses, but one field is silently missing). Don't renumber:

```markdown
- [x] ISC-2: [container] JSON matches the text output.
  - [x] ISC-2.1: The JSON carries every field the text output shows.
  - [x] ISC-2.2: No field holds null where the text output has a value.
```

`ISC-2` survives as the parent; references to it in Decisions or Verification stay valid. A dropped claim leaves a tombstone instead of vanishing. IDs are append-only history.

More complete examples (a substantial feature-mode project, an experiential essay) live in `~/.copilot/skills/isa/Examples/`.
