# Self-Healing: where a rule belongs

> The routing table for where a new rule, preference or learning lives. `copilot-instructions.md` § Memory carries the one-line summary; this file is the full table. Load it when deciding where a new rule lives, or when the system looks broken (missing context after compaction, hooks misfiring) before acting.

When the system fails (a rule was missed, a behavior recurred, an instruction wasn't followed), **fix the system, not your notes.** An operating system doesn't accumulate sticky notes about its own bugs; it patches itself.

**But "the system failed" and "I failed" are different diagnoses, and only the first takes a patch.** When the rule was already encoded correctly, already loaded, and simply not consulted, the right remediation is **nothing**: read it and don't repeat it. Building a gate to catch yourself obeying doctrine you already hold is the over-engineering reflex to watch for. Getting caught creates pressure to produce a visible artifact as proof of remediation, and a hook is the most legible artifact available. Resist that. A lapse is not a missing mechanism.

Two invariants when anything looks broken: never "fix" it by weakening a gate, and encode the fix in infrastructure, not in a memo.

## The routing table

| What you're encoding | Where it goes |
|---|---|
| Operational preferences (tool choice, repo conventions, naming, model role classes) | the "Your rules" section of `~/.copilot/copilot-instructions.md` (the installer never touches it) |
| A checkable property of an **artifact**, or a gate on an **irreversible** act | a hook: `~/.copilot/kai/hooks/ext/<name>.py` — and only these two classes. A hook must not encode how I work (which tool I reach for, which language, which style). If the answer to *"would a smarter model make this hook pointless?"* is yes, the rule belongs in doctrine and the lapse belongs nowhere |
| Permissions (allowed / denied tools, paths, URLs) | Copilot's own permission settings (`--allow-tool` / `--deny-tool`, trusted folders), plus the `preToolUse` safety gate for destructive commands |
| Domain-specific behavior (how to do X-class work) | the relevant skill's `SKILL.md` and `Workflows/` under `~/.copilot/skills/<name>/` |
| Algorithm doctrine (the loop, the gates, the done-claims) | `~/.copilot/kai/ALGORITHM.md`; ISA shape in `ISA_FORMAT.md` |
| Identity, voice, persona | the KAI block of `copilot-instructions.md` (managed) or "Your rules" (yours) |
| Project state | that project's `ISA.md` |
| Per-task work product (ISA, decisions, verification evidence) | `~/.copilot/kai/MEMORY/WORK/<slug>/ISA.md` |
| Reusable knowledge (people, tools, companies, ideas, research notes) | `~/.copilot/kai/MEMORY/KNOWLEDGE/<topic>.md` (`kai.py memory add`) |
| A one-line correction or gotcha | `~/.copilot/kai/MEMORY/LEARNING/learnings.md` (`kai.py learn`); the session-start hook replays the latest ones |
| A dated, verified failure narrative (a self-improvement signal, not world knowledge) | `~/.copilot/kai/MEMORY/LEARNING/INCIDENTS/INC-YYYYMMDD-<slug>.md`. The story lives there only; rules and doctrine cite the INC id |
| A deliberate rejection with recurrence risk (a proposal killed, a rule cut, an ask declined) | `~/.copilot/kai/MEMORY/KNOWLEDGE/REJECTED/no-<gist>.md`. Check it BEFORE re-analyzing any familiar-sounding proposal; append recurrences, never re-litigate silently |

## Copilot's built-in memory is not a rule surface

Copilot can keep its own memory (for example with `--enable-memory`). **For rules, preferences and operational behavior, don't use it.** That store is a host feature, not a Kai surface: writing a memo there treats the symptom (the AI didn't remember) instead of the cause (the rule wasn't encoded where it actually lives). Every "feedback memo" is a missed system patch.

The test before writing anything into host memory:

- *"Does this describe how I should behave, which rule to follow, which tool to prefer, which convention applies?"* → it belongs in "Your rules", a skill or doctrine. Not in host memory, and not in a hook.
- *"Does this describe a state of the world to recall later (a person's role, a project's pending state, a one-time fact)?"* → host memory may be acceptable, but `MEMORY/KNOWLEDGE/` is usually a better home.

The infrastructure is the memory. When you patch the infrastructure, every future session starts with the rule already in effect: nothing to remember to consult, because the rule is structurally there. That's self-healing.

## The autonomic loop

Failures leave evidence in `MEMORY/OBSERVABILITY/events.jsonl` (gate blocks, denials, tool failures, spend breaks) and `MEMORY/LEARNING/ratings.jsonl` (low ratings, frustration). The loop has three steps:

1. **Detect.** `python ~/.copilot/kai/bin/kai.py recurrence` groups those signals into failure classes. A class seen three or more times in 30 days is a system problem, not bad luck.
2. **Propose.** For each recurring class, propose where the fix structurally lives (the routing table above), with a failing probe that reproduces it.
3. **Patch with consent.** The user approves, then the fix goes through the normal Algorithm (below). Run detection when a session feels familiar-bad, and during `/upgrade`.

## Patching enforcement code

When a recurring failure does call for a hook, the fix goes through the normal Algorithm: an ISA, a failing probe first (a synthetic hook event that shows the class isn't caught), then the hook change, then the same probe passing, then a unit test that keeps it caught. Nothing auto-writes to a hook, a rule or a setting. A model writing diffs to enforcement code is in tension with "security code must be deterministic and injection-proof", so the failing test comes before the code, and the user sees the change.
