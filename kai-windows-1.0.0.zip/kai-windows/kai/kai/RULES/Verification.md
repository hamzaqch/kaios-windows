# Verification Doctrine

> **This file is the ONE home of the seven incident-derived verification rules.** The always-loaded instructions (`copilot-instructions.md` § Verification) keep the constitutional core: the pre-done self-check, the "should work" ban, and confidence-requires-source. They point here. Algorithm claims 8 and 16 bind these rules into runs. Nothing else restates them.
>
> **Load this file when:** verifying web or UI output, making a claim about how something looks, deleting or replacing live infrastructure, verifying anything that must expire or propagate, or when the verifier is unavailable.
>
> **Enforced by:** `ext/verification_gate.py` (agentStop) and `ext/guards.py` (destructive-infra row). Each rule below came from a real failure.

**Web output is verified in a real browser before the user sees it.** That means a real browser rendering the actual URL: a browser automation MCP server configured in Copilot, a headless capture you then look at, or, when no browser capability exists in this session, handing the look to the user and marking the claim `manual` (attested). "curl returns 200" is not verification of a page. A DOM dump is not a look. Every time you create, fix, deploy or claim anything works on the web, verify it in a browser, or say plainly that you didn't.

## The seven rules

1. **Modality fidelity.** The probe must exercise the SAME path the user does. A web or UI claim closes only on a real browser navigating to the actual URL. A `curl`, a DOM read of a *different* page, or a check of a sibling path is a different request and proves nothing about what the browser renders at the path in question; curl and a real browser can literally receive different pages (redirects, cookies, user-agent rules, single-page-app fallbacks). "I curled it and got the right thing" is not "the user's browser gets the right thing."

2. **Unavailable verifier means DEFER, never substitute.** When the browser tool is broken or missing, the credentials aren't there, or the service is down, the claim is NOT verified. Say "deployed, not browser-verified", mark the claim `[DEFERRED-VERIFY]` with the reason, and do NOT claim live, works, shipped or locked down. Fix the verifier, wait, or hand the human-only step to the user. Never relabel weaker evidence as verification.

3. **Appearance is not existence: look at the pixels, from a faithful renderer.** A DOM read proves an element EXISTS at coordinates; it proves NOTHING about how it looks. And pixels only count when the render path is faithful to what the user's device paints. Reconstructed captures (DOM-to-image renderers) often skip the browser's default widget styling, CSS pseudo-element content and programmatically set input values, so a contrast bug can look fine in them while rendering white-on-white on a real phone. A claim about native form-control appearance or CONTRAST closes only on a true pixel capture from the browser, or a computed-style probe (`getComputedStyle`; a transparent background means the browser default shows). Any claim about *appearance* (an image renders, is centered, is transparent, is the right color, "looks right") closes ONLY on a **non-degenerate image you actually looked at**: open the image file and view it. A black or uniform frame is not a look; recapture. **View every asset before wiring it in.**

4. **Reproduce before fixing.** For ANY reported UI or page bug, open the page in a real browser FIRST: before reading code, before theorizing, before writing fixes. Check console errors. Check network failures (404s, CORS, mixed content). See the failure yourself. For non-UI bugs, trigger the failing path and capture its output first. Code analysis without reproduction is speculation, not debugging. After the fix, show the same trigger passing.

5. **Temporal fidelity: probe when the failure can exist.** For cache-mediated surfaces (DNS, certificates, CDN caches, negative caches), a probe at T+0 rides warm caches and proves nothing about steady state. A claim about DNS, certificate or routing state closes on the provider's records API or the authoritative name server (`dig @<zone-ns>`, `Resolve-DnsName -Server <zone-ns>`), never solely on a request that succeeded through a resolver cache. If only runtime probes are possible, the claim holds `[DEFERRED-VERIFY]` until a T+TTL re-probe, and the watcher (a scheduled task, a background re-check) is named before the run closes. *(Incident: every post-deletion DNS probe passed on a warm resolver; the domain went dark for the world within the hour.)*

6. **Restore parity on replace or delete: enumerate ownership before AND after.** Changing or deleting anything that serves live traffic or produces a flowing metric requires all of:
   - the flow's **baseline captured BEFORE** the change (its rate over a stated window, plus a function inventory);
   - what the resource **OWNS, enumerated through the provider's authority API before** the operation (for example a worker platform's custom-domain listing, a DNS zone's records listing). A dependent record "already existing" is NOT evidence it survives the delete: managed records look identical to independent ones in a listing and die with their owner;
   - the authority **re-listed AFTER** the operation. A runtime probe through a warm cache is not the authority;
   - post-change evidence that the flow continues **at baseline within a stated tolerance**.

   One synthetic event landing is an example claim and never closes parity; "the flow continues at its baseline rate" is the universal claim that catches the outage. A safety mitigation written into Decisions is promoted to a claim with a falsifier BEFORE the operation executes, because prose mitigations have no teeth. Metered pipelines hold `[DEFERRED-VERIFY]` until a delayed delta check against baseline (at least an hour later, or T+TTL for cache-mediated surfaces, whichever is longer). *(Incident: an end-to-end probe passed while ingest ran at about 3% of a baseline measured in the same run.)*

7. **Cache fidelity: a cache can sit between the probe and the truth in THREE places.** Rule 5 covers DNS and CDN caches on the response path. Three distinct layers each produced a passing probe over a broken system in one session:
   - **Response path.** Any liveness or health endpoint must answer `no-store` (`Cache-Control` and any CDN-specific cache header), and that header is itself a claim with a probe. *(Caught live: two probes seconds apart returned byte-identical bodies while new items landed every few seconds. A cached 200 during an outage is exactly the failure the endpoint exists to catch.)*
   - **Deploy path.** A single post-deploy probe reads whichever edge copy answered. Verification converges or it does not count: repeat until N consecutive identical results (or wait on an explicit convergence signal), and never report a fix on one probe. *(Caught three times in one session: mixed 200/401/000 from the same endpoint, twice nearly reported as a partial fix.)*
   - **Data path.** The app's own storage reads may be cached too, so behavior that depends on a value EXPIRING cannot be verified from the code alone. Make expiry structural (rotate the key or the query so a new period reads a key that doesn't exist yet) rather than trusting a TTL on the read path. *(Caught live: a rate limiter whose unit tests all passed locked a real identity out indefinitely, because the capped counter kept being served from an edge cache long past its 60-second TTL.)*

   The through-line: **a mock cannot reproduce a cache.** Unit tests over a faked store prove the logic, never the deployment. Any claim about expiry, freshness or propagation closes on a live probe against the real system, run to convergence.

## Evidence coverage: the probe set spans the claim

When a claim quantifies over a container (a site, a corpus, a fleet, a data set), the container passing is not evidence for its members. The probe set touches every member TYPE the user actually consumes, one rendered or executed instance each, and a deterministic sweep covers the rest where one exists. Shell pages and HTTP 200s verify nothing on a single-page app. *(Incident: "site is live" closed on a verified homepage while all 21 content pages shipped broken.)*

**Viewport is a member type.** People read products on phones. A shipped UI change verifies at a mobile width (480px or less) in addition to desktop, or the claim says "desktop-verified only" out loud.

## Briefing a verifier: steps and evidence, never the expected result

A verification or review brief carries the steps to execute and the evidence to return, never the answer it is expected to find. A verifier told what the pass looks like rationalizes its way to that pass instead of driving the actual path; withholding the expected result forces it to produce real evidence. This is why a fresh-context second look (Algorithm claim 11, `@kai-reviewer`) restates the goal and the claims but not the build plan or the "should be" outcome.

## Enforcement summary

- `ext/verification_gate.py` (agentStop): blocks a final message that claims done / works / live / verified when the transcript's actual tool calls show no evidence-bearing probe after the last edit. It grades evidence from the transcript's tool calls, not from the message's wording, so rewording never passes it. It respects `stop_hook_active` and a per-session cap, so it cannot loop.
- `ext/guards.py` (always on): any delete of a cloud worker, domain, zone, DNS record, bucket or route fires the ownership + authority re-list + baseline-flow ask.
- Algorithm claims 8 (modality, coverage and timing per claim) and 16 (restore parity) bind these rules into every run.

Constitutional core (in `copilot-instructions.md`, never restated here): never claim done without tool evidence; the pre-done self-check; confidence requires a source verified this session.
