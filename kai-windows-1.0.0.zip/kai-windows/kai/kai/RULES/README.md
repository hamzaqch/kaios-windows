# Kai rules on demand

These files are not loaded every turn. The constitution (`copilot-instructions.md`, "Rules on demand") points here. Read the file when its trigger fires; never guess at what it says.

| When | Read |
|---|---|
| Verifying web or UI output, appearance claims, deleting live infrastructure, or the verifier is unavailable | `Verification.md` |
| Deciding where a new rule lives, or the system looks broken | `SelfHealing.md` |
| Explaining Kai, or writing a prompt, skill or agent brief | `Philosophy.md` |
| Auditing your own writing, or a drift reminder fired | `WritingStyle.md` |
| Writing or checking an ISA | `../ISA_FORMAT.md` |
