"""Kai hook engine for GitHub Copilot CLI / Copilot app.

One entry point for every hook event:  python kai_hook.py <eventName>
Reads the event JSON on stdin, writes the honored output JSON on stdout.
Stdlib only. Never raises: preToolUse is fail-closed in Copilot, so any
internal error must still exit 0 with an "allow" decision.

Events (registered by install.py): sessionStart, userPromptSubmitted,
userPromptTransformed, preToolUse, postToolUse, postToolUseFailure, subagentStart,
agentStop, sessionEnd. Core runs first, then every hooks/ext/*.py HANDLERS entry.
userPromptTransformed always yields at most ONE modifiedTransformedPrompt (the
original transformedPrompt plus every extension's appended text), because Copilot
applies only the last transformer. KAI_EVAL=1 / KAI_WORKFLOW_CHILD=1 runs skip the
format gate and all learning/session-log writes.
"""
import datetime as _dt
import json
import os
import re
import sys
import time
from pathlib import Path

KAI_HOME = Path(os.environ.get("KAI_HOME") or Path(__file__).resolve().parent.parent)
MEM = KAI_HOME / "MEMORY"
STATE = MEM / "STATE"
EVENTS = MEM / "OBSERVABILITY" / "events.jsonl"
COPILOT_HOME = Path(os.environ.get("COPILOT_HOME") or KAI_HOME.parent)

# ---------------------------------------------------------------- utilities

def now_iso():
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def read_stdin():
    try:
        raw = sys.stdin.buffer.read().decode("utf-8-sig", errors="replace")
        return json.loads(raw) if raw.strip() else {}
    except Exception:
        return {}


def emit(obj):
    if obj:
        sys.stdout.write(json.dumps(obj, ensure_ascii=False))
        sys.stdout.flush()


def append_jsonl(path, obj):
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")
    except Exception:
        pass


def load_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path, obj):
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)
    except Exception:
        pass


def tool_args(evt):
    a = evt.get("toolArgs")
    if isinstance(a, str):
        try:
            a = json.loads(a)
        except Exception:
            return {"_raw": a}
    return a if isinstance(a, dict) else {}


def args_text(args):
    try:
        return json.dumps(args, ensure_ascii=False)
    except Exception:
        return str(args)


def session_state(sid):
    return STATE / "sessions" / f"{re.sub(r'[^A-Za-z0-9_-]', '_', sid or 'unknown')}.json"


def child_mode():
    """True for eval and workflow-worker runs (set by evals/tools/llm.py and kai_workflow.py).
    Those runs must not write learning/session logs or be held by the format gate."""
    return os.environ.get("KAI_EVAL") == "1" or os.environ.get("KAI_WORKFLOW_CHILD") == "1"


def ensure_tree():
    for d in ("WORK", "KNOWLEDGE", "LEARNING/sessions", "STATE/sessions", "OBSERVABILITY"):
        (MEM / d).mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- ISA parsing

CLAIM_RE = re.compile(r"^\s*[-*]\s*\[( |x|X)\]\s*(?:\*\*)?((?=[A-Z0-9.-]*\d)[A-Z][A-Z0-9]*(?:[-.][A-Z0-9]+)*)", re.M)


def parse_isa(path):
    try:
        text = Path(path).read_text(encoding="utf-8-sig")
    except Exception:
        return None
    fm = {}
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.S)
    if m:
        for line in m.group(1).splitlines():
            if ":" in line and not line.startswith(" "):
                k, v = line.split(":", 1)
                fm[k.strip()] = v.strip().strip('"')
    claims = CLAIM_RE.findall(text)
    done = sum(1 for c in claims if c[0].lower() == "x")
    return {"path": str(path), "frontmatter": fm, "claims": len(claims), "closed": done,
            "open_ids": [c[1] for c in claims if c[0] == " "]}


def _same_dir(a, b):
    try:
        return os.path.normcase(os.path.abspath(str(a).strip().strip('"'))) == os.path.normcase(os.path.abspath(str(b)))
    except Exception:
        return False


def active_isas(limit=3, cwd=None):
    """Open task ISAs. With cwd: only ISAs started in that folder (ISAs are folder-scoped, so two
    sessions in different folders never resume each other's work). ISAs without a cwd field
    (older installs) only match when no cwd filter is given."""
    out = []
    work = MEM / "WORK"
    if not work.exists():
        return out
    for isa in sorted(work.glob("*/ISA.md"), key=lambda p: p.stat().st_mtime, reverse=True):
        info = parse_isa(isa)
        if not info or info["frontmatter"].get("phase", "") == "complete":
            continue
        if cwd is not None and not _same_dir(info["frontmatter"].get("cwd", ""), cwd):
            continue
        out.append(info)
        if len(out) >= limit:
            break
    return out

# ---------------------------------------------------------------- sessionStart

def on_session_start(evt):
    ensure_tree()
    sid = evt.get("sessionId", "")
    cwd = evt.get("cwd") or os.getcwd()
    save_json(session_state(sid), {"sessionId": sid, "started": now_iso(), "cwd": cwd,
                                   "tools": 0, "since_isa": 0, "last_calls": [], "prompts": [],
                                   "isas": [], "nudged": False, "format_blocks": 0})
    lines = ["# Kai session context (hook-fed, current as of session start)", ""]
    lines.append(f"- Local time: {_dt.datetime.now().astimezone().strftime('%A %Y-%m-%d %H:%M %Z')}")
    ver = (KAI_HOME / "VERSION").read_text(encoding="utf-8").strip() if (KAI_HOME / "VERSION").exists() else "?"
    lines.append(f"- Kai version: {ver} · Kai home: {KAI_HOME}")
    lines.append(f"- Working directory: {cwd}")

    proj = Path(cwd) / "ISA.md"
    if proj.exists():
        info = parse_isa(proj)
        if info:
            lines.append(f"- Project ISA here: {proj} — {info['closed']}/{info['claims']} claims closed; "
                         f"open: {', '.join(info['open_ids'][:8]) or 'none'}")
    act = active_isas(cwd=cwd)
    if act:
        lines.append("- Open task ISAs started in THIS folder (resume candidates):")
        for i in act:
            goal = i["frontmatter"].get("principal_stated_goal", "")[:120]
            lines.append(f"  - {i['path']} [{i['frontmatter'].get('phase','?')}] "
                         f"{i['closed']}/{i['claims']} — {goal}")
    lines.append("- ISAs are folder-scoped: new work in this folder gets its own ISA via `kai.py isa new`; "
                 "never reopen an ISA that was started in a different folder.")

    learn = MEM / "LEARNING" / "learnings.md"
    if learn.exists():
        tail = [l for l in learn.read_text(encoding="utf-8").splitlines() if l.startswith("- ")][-5:]
        if tail:
            lines.append("- Recent learnings (apply them):")
            lines += ["  " + l for l in tail]

    kroot = MEM / "KNOWLEDGE"
    know = sorted((p for p in kroot.glob("**/*.md")
                   if not any(part.startswith("_") for part in p.relative_to(kroot).parts)),
                  key=lambda p: p.stat().st_mtime, reverse=True)[:10]
    if know:
        lines.append("- Knowledge notes available (read on demand): " +
                     ", ".join(p.stem for p in know))

    lines.append("")
    lines.append("Reminder: every response uses the Kai format (banner first line, `🗣️ Kai:` closer last), "
                 "unless the user runs one of their own (non-kai) agents: then that agent's format and voice win. "
                 "Substantial work runs the Algorithm (`~/.copilot/kai/ALGORITHM.md`).")
    append_jsonl(EVENTS, {"ts": now_iso(), "event": "sessionStart", "session": sid, "source": evt.get("source")})
    return {"additionalContext": "\n".join(lines)}

# ---------------------------------------------------------------- userPromptSubmitted

def on_prompt(evt):
    sid = evt.get("sessionId", "")
    st = load_json(session_state(sid), {})
    prompt = (evt.get("prompt") or "")
    st.setdefault("prompts", []).append({"ts": now_iso(), "text": prompt[:500]})
    st["prompts"] = st["prompts"][-50:]
    save_json(session_state(sid), st)
    append_jsonl(EVENTS, {"ts": now_iso(), "event": "userPromptSubmitted", "session": sid, "chars": len(prompt)})
    return None

# ---------------------------------------------------------------- preToolUse (safety)

DENY = [
    (r"\bformat(-volume)?\s+[a-z]:", "formats a drive"),
    (r"\bdiskpart\b", "runs diskpart"),
    (r"\bbcdedit\b", "edits boot configuration"),
    (r"\bvssadmin\s+delete\b", "deletes shadow copies"),
    (r"\bcipher\s+/w\b", "wipes free space"),
    (r"\bclear-disk\b|\binitialize-disk\b", "wipes a disk"),
    (r"\brm\s+-[a-z]*r[a-z]*f?[a-z]*\s+(/|~|\$home|c:\\?)(\s|$|\")", "recursively deletes a root or home directory"),
    (r"remove-item\b[^|;]*-recurse[^|;]*\s(['\"]?)(c:\\?|c:/|\$env:userprofile|\$home|~)\1(\s|$|;)",
     "recursively deletes a root or home directory"),
    (r"\brd\s+/s\s+/q\s+(c:\\?|%userprofile%)(\s|$)", "recursively deletes a root or home directory"),
    (r"\breg(\.exe)?\s+delete\s+hk(lm|ey_local_machine)", "deletes machine registry keys"),
    (r"\bgit\s+push\b[^;|&]*\s(--force|-f)(\s|$)(?![^;|&]*--force-with-lease)", "force-pushes git history"),
    (r"(stop-computer|restart-computer|shutdown(\.exe)?\s+/[sr])", "shuts down or restarts the machine"),
]
ASK = [
    (r"\bgit\s+reset\s+--hard\b", "discards uncommitted git work"),
    (r"\bgit\s+clean\s+-[a-z]*f", "deletes untracked files"),
    (r"\bgit\s+push\b", "pushes code to a remote"),
    (r"\bgit\s+branch\s+-D\b", "deletes a git branch"),
    # download piped into an interpreter that runs stdin as code; `| python -m json.tool`,
    # `| python script.py` and `| bash -c ...` treat stdin as data and are not matched
    (r"\b(iwr|invoke-webrequest|curl|wget|irm|invoke-restmethod)\b[^|]*\|\s*(?:(?:iex|invoke-expression)\b"
     r"|(?:sudo\s+)?(?:bash|sh|zsh|pwsh|powershell)\b(?!\s+-c\b)(?!\s+[\w./\\-]+\.(?:sh|ps1)\b)"
     r"|(?:sudo\s+)?(?:python3?|py|node)(?:\s+-[a-z0-9]*)*(?:\s+-)?\s*(?:$|[;&|)]))", "pipes downloaded code into an interpreter"),
    (r"set-executionpolicy\s+(unrestricted|bypass)\s", "weakens PowerShell execution policy machine-wide"),
    (r"remove-item\b[^|;]*-recurse", "recursively deletes files"),
    (r"\brm\s+-[a-z]*r", "recursively deletes files"),
    (r"\bnpm\s+publish\b|\btwine\s+upload\b|\bgh\s+release\s+create\b", "publishes a package or release"),
]
SECRET_PATH = re.compile(r"(^|[\\/])(\.env(\.(?!example$|sample$|template$)[a-z]+)?|id_rsa|id_ed25519|credentials(\.json)?|\.git-credentials|\.npmrc|\.pypirc)$", re.I)


def on_pre_tool(evt):
    name = (evt.get("toolName") or "").lower()
    args = tool_args(evt)
    text = args_text(args).lower()
    is_shell = any(k in name for k in ("shell", "powershell", "bash", "terminal", "command", "exec"))
    if is_shell:
        cmd = str(args.get("command") or args.get("cmd") or args.get("script") or args.get("_raw") or text).lower()
        for pat, why in DENY:
            if re.search(pat, cmd, re.I):
                return deny(evt, f"Kai safety gate: this command {why}. Blocked. If you really intend this, run it yourself.")
        for pat, why in ASK:
            if re.search(pat, cmd, re.I):
                return ask(evt, f"Kai safety gate: this command {why}. Confirm before running.")
        if re.search(r"\b(get-content|cat|type|gc|more)\s+[^|;]*\.env(?!\.(?:example|sample|template)\b)\b", cmd):
            return ask(evt, "Kai safety gate: reads a secrets file. Confirm before exposing credentials.")
    for key in ("path", "file_path", "filePath", "target", "filename"):
        p = args.get(key)
        if isinstance(p, str) and SECRET_PATH.search(p.replace("/", "\\").strip()):
            return ask(evt, f"Kai safety gate: touches a credentials file ({Path(p.replace(chr(92), '/')).name}). Confirm first.")
    return {"permissionDecision": "allow"}


def deny(evt, reason):
    if evt.get("sessionId") != "doctor":
        append_jsonl(EVENTS, {"ts": now_iso(), "event": "preToolUse.deny", "session": evt.get("sessionId"),
                          "tool": evt.get("toolName"), "reason": reason})
    return {"permissionDecision": "deny", "permissionDecisionReason": reason}


def ask(evt, reason):
    if evt.get("sessionId") != "doctor":
        append_jsonl(EVENTS, {"ts": now_iso(), "event": "preToolUse.ask", "session": evt.get("sessionId"),
                          "tool": evt.get("toolName"), "reason": reason})
    return {"permissionDecision": "ask", "permissionDecisionReason": reason}


# ---------------------------------------------------------------- Kai self-tool pre-approval
# Copilot asks before tools touch files outside the working folder, and a non-interactive run
# (copilot -p) has nobody to answer. Kai's own read paths and deterministic tools are
# pre-approved here; everything else stays silent so Copilot's normal permission flow applies.
_SELF_READ_TOOLS = ("view", "read", "rg", "grep", "glob", "search")
_CHAIN = re.compile(r"[;&|`\n]|\$\(|>")
_PY_LAUNCH = re.compile(r"""^\s*(?:&\s*)?(?:(['"])?[^'"\s]*?(?:python3?|py)(?:\.exe)?\1?)(?:\s+-3)?\s+(['"]?)([^'"]+?\.py)\2(?:\s+(.*))?$""", re.I)


def _under(path, roots):
    try:
        s = re.sub(r"\$env:([A-Za-z_][A-Za-z0-9_]*)", lambda m: os.environ.get(m.group(1), m.group(0)), str(path), flags=re.I)
        s = re.sub(r"^\$(home|HOME)(?=[\\/])", lambda m: str(Path.home()), s.strip().strip("'\""))
        p = os.path.normcase(os.path.abspath(os.path.expanduser(os.path.expandvars(s))))
    except Exception:
        return False
    return any(p == r or p.startswith(r + os.sep) for r in roots)


def _self_roots():
    return [os.path.normcase(os.path.abspath(str(r))) for r in
            (KAI_HOME, COPILOT_HOME / "skills", COPILOT_HOME / "agents", COPILOT_HOME / "copilot-instructions.md")]


def _strip_quoted(cmd):
    """Blank out quoted literals so argument DATA isn't mistaken for commands.
    Returns (stripped, unsafe). Double-quoted text containing $( or a backtick can execute in
    PowerShell/bash, so it marks the command unsafe instead of being blanked."""
    out, i, n, unsafe = [], 0, len(cmd), False
    while i < n:
        c = cmd[i]
        if c in ("'", '"'):
            j = cmd.find(c, i + 1)
            if j < 0:
                return cmd, True  # unbalanced quote: don't guess
            body = cmd[i + 1:j]
            if c == '"' and ("$(" in body or "`" in body):
                unsafe = True
            out.append(c + c)
            i = j + 1
        else:
            out.append(c)
            i += 1
    return "".join(out), unsafe


def kai_self_call(evt):
    name = (evt.get("toolName") or "").lower()
    args = tool_args(evt)
    roots = _self_roots()
    if any(name.startswith(r) for r in _SELF_READ_TOOLS):
        paths = args.get("path") or args.get("paths") or args.get("file_path") or args.get("filePath")
        if isinstance(paths, str):
            paths = [paths]
        return bool(paths) and isinstance(paths, list) and all(isinstance(p, str) and _under(p, roots) for p in paths)
    if any(name.startswith(w) for w in ("apply_patch", "edit", "create", "write", "str_replace")):
        targets = written_paths(evt.get("toolName"), args)
        mem_root = [os.path.normcase(os.path.abspath(str(MEM)))]
        return bool(targets) and all(_under(p, mem_root) for p in targets)
    if not any(k in name for k in ("shell", "powershell", "bash")):
        return False
    cmd = str(args.get("command") or "")
    stripped, unsafe = _strip_quoted(cmd)
    if not cmd or unsafe or _CHAIN.search(stripped):
        return False
    m = _PY_LAUNCH.match(cmd)
    if m:
        script, rest = m.group(3), (m.group(4) or "")
        if not _under(script, roots):
            return False
        base = os.path.basename(script).lower()
        if base == "kai_workflow.py" or (base == "kai.py" and rest.strip().lower().startswith("workflow")):
            return False  # spawns agents: keep Copilot's own approval
        return True
    rd = re.match(r"^\s*(?:get-content|gc|type|cat)\s+(?:-raw\s+)?(['\"]?)([^'\"]+)\1(?:\s+-raw)?\s*$", cmd, re.I)
    return bool(rd and _under(rd.group(2), roots))

# ---------------------------------------------------------------- postToolUse

# Kai's own surfaces, as paths relative to the Copilot home (forward slashes, lower case).
# Keys ending in "/" are directory prefixes; the rest are exact files.
SELF_SURFACES = {
    "doctrine": ("/copilot-instructions.md", "/kai/algorithm.md", "/kai/isa_format.md", "/kai/rules/"),
    "machinery": ("/kai/hooks/", "/kai/bin/", "/skills/", "/agents/", "/settings.json", "/mcp-config.json"),
}


READ_ONLY_TOOLS = ("view", "read", "glob", "grep", "search", "list", "fetch", "web")
SHELL_TOOL_HINTS = ("shell", "powershell", "bash", "terminal", "command", "exec", "pwsh")
PATCH_FILE_RE = re.compile(r"^\*\*\*\s+(?:Add|Update|Delete)\s+File:\s*(.+?)\s*$", re.M)


def written_paths(tool, args):
    """Paths a tool call wrote. Read-only tools return nothing."""
    name = (tool or "").lower()
    if any(name.startswith(r) for r in READ_ONLY_TOOLS):
        return []
    out = []
    for key in ("path", "file_path", "filePath", "target", "filename"):
        v = args.get(key)
        if isinstance(v, str):
            out.append(v)
    for v in args.values():
        if isinstance(v, str) and "*** " in v:
            out += PATCH_FILE_RE.findall(v)
    return out


def is_shell_tool(tool):
    n = (tool or "").lower()
    return any(k in n for k in SHELL_TOOL_HINTS) and not n.startswith(("read_", "stop_", "list_"))


def shell_command(args):
    v = args.get("command") or args.get("cmd") or args.get("script") or args.get("_raw") or ""
    return v if isinstance(v, str) else ""


_FALLBACK_REDIRECT = re.compile(r"(?<![0-9&])>{1,2}\s*(\"[^\"]+\"|'[^']+'|[^\s;&|]+)")
_FALLBACK_WRITE = re.compile(
    r"\b(?:set-content|add-content|out-file|new-item|copy-item|move-item|remove-item|tee-object)\b"
    r"(?:\s+-\w+)*\s+(\"[^\"]+\"|'[^']+'|[^\s;&|-][^\s;&|]*)", re.I)


def shell_write_targets(cmd):
    """(paths a shell command plausibly writes, base dir override or None).

    Reuses the write-target parser of ext/guards.py (redirects, copy destinations,
    write verbs) so core and the self-edit guard agree; falls back to a small
    redirect / Set-Content parser when guards is unavailable."""
    if not cmd:
        return [], None
    g = ext_module("guards")
    need = ("segments", "tokens", "REDIRECT_TARGET", "SHELL_WRITE_VERB", "_copy_dest_targets", "_path_like", "_cd_target")
    if g is not None and all(hasattr(g, a) for a in need):
        try:
            hits = []
            for seg in g.segments(cmd):
                for m in g.REDIRECT_TARGET.finditer(seg):
                    t = (m.group(1) or m.group(2) or "").strip("\"'")
                    if t and not t.startswith("&") and t.lower() not in ("$null", "nul", "/dev/null"):
                        hits.append(t)
                copy_targets = g._copy_dest_targets(g.tokens(seg))
                if copy_targets is not None:
                    hits += [t for t in copy_targets if t]
                    continue
                if g.SHELL_WRITE_VERB.search(seg):
                    hits += [t for t in g.tokens(seg) if g._path_like(t)]
            return list(dict.fromkeys(hits)), g._cd_target(cmd)
        except Exception:
            pass
    hits = [m.group(1).strip("\"'") for m in _FALLBACK_REDIRECT.finditer(cmd)]
    hits += [m.group(1).strip("\"'") for m in _FALLBACK_WRITE.finditer(cmd)]
    return [h for h in dict.fromkeys(hits) if h.lower() not in ("$null", "nul", "/dev/null")], None


def _cmp_path(p, cwd=""):
    """Comparable path: env prefixes expanded, forward slashes, absolute, lower case."""
    g = ext_module("guards")
    if g is not None and hasattr(g, "norm_path"):
        try:
            return g.norm_path(p, cwd)
        except Exception:
            pass
    s = str(p or "").strip().strip("\"'`").replace("\\", "/")
    if s.startswith("~"):
        s = str(Path.home()).replace("\\", "/") + s[1:]
    if not (s.startswith("/") or re.match(r"^[A-Za-z]:", s)) and cwd:
        s = str(cwd).replace("\\", "/").rstrip("/") + "/" + s
    return s.rstrip("/").lower()


def self_surface(p, cwd=""):
    """'doctrine' / 'machinery' when p is one of Kai's own surfaces, else None."""
    n = _cmp_path(p, cwd)
    if not n:
        return None
    rel = None
    for base, prefix in ((KAI_HOME, "kai/"), (COPILOT_HOME, "")):
        b = _cmp_path(str(base)).rstrip("/")
        if b and n.startswith(b + "/"):
            rel = prefix + n[len(b) + 1:]
            break
    if rel is None:
        i = n.rfind("/.copilot/")
        if i < 0:
            return None
        rel = n[i + len("/.copilot/"):]
    r = "/" + rel
    if r.startswith("/kai/memory/") or "/__pycache__/" in r + "/":
        return None
    for surface, keys in SELF_SURFACES.items():
        for k in keys:
            if (r.startswith(k) if k.endswith("/") else r == k):
                return surface
    return None


def _failure_text(evt):
    res = evt.get("toolResult")
    kind, body = "", evt.get("error")
    if isinstance(res, dict):
        kind = str(res.get("resultType") or "")
        body = body or res.get("error") or res.get("textResultForLlm")
    elif isinstance(res, str) and not body:
        body = res
    if isinstance(body, dict):
        body = body.get("message") or args_text(body)
    return kind, (str(body) if body else "")[:200]


def on_post_tool(evt, failed=False):
    sid = evt.get("sessionId", "")
    cwd = evt.get("cwd") or ""
    st = load_json(session_state(sid), {"tools": 0, "since_isa": 0, "last_calls": [], "isas": []})
    args = tool_args(evt)
    tool = evt.get("toolName", "")
    st["tools"] = st.get("tools", 0) + 1
    st["since_isa"] = st.get("since_isa", 0) + 1
    sig = f"{tool}:{args_text(args)[:300]}"
    calls = (st.get("last_calls") or [])[-4:] + [sig]
    st["last_calls"] = calls
    rec = {"ts": now_iso(), "event": "postToolUseFailure" if failed else "postToolUse", "session": sid, "tool": tool}
    if (tool or "").lower() == "skill":
        sk = args.get("skill") or args.get("name") or args.get("skillName")
        if isinstance(sk, str) and sk:
            rec["skill"] = sk[:80]
    if failed:
        kind, text = _failure_text(evt)
        if kind:
            rec["resultType"] = kind
        if text:
            rec["error"] = text
    append_jsonl(EVENTS, rec)

    notes = []
    seen = set()

    def surface_note(p, base):
        surface = self_surface(p, base)
        key = (surface, Path(str(p).replace("\\", "/")).name)
        if surface and key not in seen:
            seen.add(key)
            notes.append(f"⚙️ SYSTEM: {surface} changed — {key[1]}")
            try:
                (STATE / "docs-lint-due").write_text(now_iso(), encoding="utf-8")
            except Exception:
                pass

    for p in written_paths(tool, args):
        norm = p.replace("/", "\\")
        if norm.lower().endswith("isa.md"):
            info = parse_isa(p)
            if info:
                st["since_isa"] = 0
                if p not in st.setdefault("isas", []):
                    st["isas"].append(p)
                work = load_json(STATE / "work.json", {})
                work[p] = {"updated": now_iso(), "phase": info["frontmatter"].get("phase"),
                           "closed": info["closed"], "claims": info["claims"]}
                save_json(STATE / "work.json", work)
                notes.append(f"⚙️ SYSTEM: ISA {Path(p).parent.name} — {info['closed']}/{info['claims']} claims closed "
                             f"(phase: {info['frontmatter'].get('phase','?')})")
        else:
            surface_note(p, cwd)
    if not failed and is_shell_tool(tool):
        targets, cd = shell_write_targets(shell_command(args))
        base = _cmp_path(cd, cwd) if cd else cwd
        for p in targets:
            if not p.replace("\\", "/").lower().endswith("isa.md"):
                surface_note(p, base)

    # Folder scoping: touching a task ISA started in another folder gets a nudge.
    try:
        touched = list(written_paths(tool, args))
        vp = args.get("path") if isinstance(args.get("path"), str) else None
        if vp:
            touched.append(vp)
        for p in touched:
            if p.replace("/", "\\").lower().endswith("isa.md") and "work" in p.replace("/", "\\").lower():
                info = parse_isa(p)
                owner = (info or {}).get("frontmatter", {}).get("cwd", "").strip('"')
                if evt.get("cwd") and info and not _same_dir(owner or "\0", evt.get("cwd")):
                    where = owner or "an unknown folder (no cwd recorded)"
                    notes.append(f"🧭 ISA-SCOPE: {Path(p).parent.name} was started in {where}, not this folder. "
                                 "Create this task's own ISA with `kai.py isa new` and use the path it prints.")
                    break
    except Exception:
        pass
    if len(calls) >= 3 and len(set(calls[-3:])) == 1:
        notes.append("🔁 LOOP: the same tool call ran 3 times in a row. Stop and change approach.")
    if st["since_isa"] >= 25 and not st.get("nudged") and not st.get("isas"):
        st["nudged"] = True
        notes.append("🧭 ALGO-NUDGE: 25+ tool calls with no ISA. Still trivial, or does done need writing down? "
                     "If it's real work, scaffold an ISA now (`/isa`).")
    save_json(session_state(sid), st)
    if notes:
        return {"additionalContext": "\n".join(notes) +
                "\n(At the end of your final response, render only the latest ⚙️ SYSTEM line per item, verbatim, once each.)"}
    return None

# ---------------------------------------------------------------- agentStop (format gate)

BANNER = re.compile(r"^\s*═+\s*Kai\b")
CLOSER = re.compile(r"🗣️\s*Kai:")


def last_assistant_text(path):
    """Content of the last non-empty assistant.message in the Copilot events.jsonl transcript."""
    try:
        lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return None
    for line in reversed(lines):
        try:
            obj = json.loads(line)
        except Exception:
            continue
        if obj.get("type") != "assistant.message":
            continue
        content = (obj.get("data") or {}).get("content")
        if isinstance(content, str) and content.strip():
            return content
    return None


def final_reply_text(evt):
    """The final assistant reply of THIS turn.

    Copilot fires agentStop before the reply is flushed to events.jsonl, so read it
    through ext/verification_gate.load_stop_transcript (polls until the turn settles,
    shared parse with the other agentStop gates). None when it never settles.
    Falls back to the last assistant.message only when that extension is absent."""
    vg = ext_module("verification_gate")
    if vg is not None and hasattr(vg, "load_stop_transcript"):
        try:
            tx = vg.load_stop_transcript(evt)
            return (tx or {}).get("final") or None
        except Exception:
            return None
    return last_assistant_text(evt.get("transcriptPath") or "")


def spend_audit(evt):
    """Algorithm claim 15, deterministic half: a depth directive ("go heavy", "think deeply") that
    produced no skill, no subagent and no stated reason is a spend break. Logged, never blocking."""
    path = evt.get("transcriptPath")
    if not path:
        return
    try:
        lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return
    turn, prompt = [], ""
    for line in reversed(lines):
        try:
            o = json.loads(line)
        except Exception:
            continue
        if o.get("type") == "user.message":
            prompt = str((o.get("data") or {}).get("content") or "")
            break
        turn.append(o)
    cx = ext_module("context")
    phrase = cx.match_depth(prompt) if (cx and prompt and hasattr(cx, "match_depth")) else None
    if not phrase:
        return
    used = any(o.get("type") == "skill.invoked" or
               (o.get("type") == "tool.execution_start" and (o.get("data") or {}).get("toolName") in ("task", "skill"))
               for o in turn)
    final = next((str((o.get("data") or {}).get("content") or "") for o in turn
                  if o.get("type") == "assistant.message" and (o.get("data") or {}).get("content")), "")
    reasoned = bool(re.search(r"\b(inline is enough|answering inline|no need for (a )?(skill|agent)s?)\b", final, re.I))
    if not used and not reasoned:
        append_jsonl(EVENTS, {"ts": now_iso(), "event": "spend.break", "session": evt.get("sessionId"),
                              "reason": f"depth directive '{phrase}' with no skill/agent and no stated reason"})


def on_agent_stop(evt):
    sid = evt.get("sessionId", "")
    append_jsonl(EVENTS, {"ts": now_iso(), "event": "agentStop", "session": sid})
    if not child_mode():
        try:
            spend_audit(evt)
        except Exception:
            pass
    if (os.environ.get("KAI_FORMAT_GATE", "1") == "0" or child_mode()
            or evt.get("stop_hook_active") or evt.get("stopHookActive") or active_user_agent(evt)):
        return None
    st = load_json(session_state(sid), {})
    if st.get("format_blocks", 0) >= 2:
        return None
    text = final_reply_text(evt)
    if not text:
        return None
    if BANNER.search(text) and CLOSER.search(text):
        return None
    st["format_blocks"] = st.get("format_blocks", 0) + 1
    save_json(session_state(sid), st)
    append_jsonl(EVENTS, {"ts": now_iso(), "event": "agentStop.formatBlock", "session": sid})
    return {"decision": "block",
            "reason": "Kai format gate: your final message must open with the `════ Kai ════` banner and end "
                      "with a `🗣️ Kai:` closer line. Re-send the same answer in the Kai format."}

# ---------------------------------------------------------------- sessionEnd (learning capture)

def on_session_end(evt):
    sid = evt.get("sessionId", "")
    st = load_json(session_state(sid), {})
    if child_mode():  # eval / workflow-worker runs leave no learning trail
        append_jsonl(EVENTS, {"ts": now_iso(), "event": "sessionEnd", "session": sid, "child": True})
        try:
            session_state(sid).unlink()
        except Exception:
            pass
        return None
    day = _dt.datetime.now()
    folder = MEM / "LEARNING" / "sessions" / day.strftime("%Y-%m")
    folder.mkdir(parents=True, exist_ok=True)
    prompts = st.get("prompts", [])
    if prompts or st.get("tools"):
        md = [f"# Session {day.strftime('%Y-%m-%d %H:%M')}", "",
              f"- session: {sid}", f"- cwd: {st.get('cwd','')}", f"- reason: {evt.get('reason','')}",
              f"- tool calls: {st.get('tools',0)}", f"- ISAs touched: {', '.join(st.get('isas', [])) or 'none'}",
              "", "## Prompts"]
        md += [f"- {p['text'][:300].replace(chr(10), ' ')}" for p in prompts[-20:]]
        name = f"{day.strftime('%Y-%m-%d_%H%M')}_{(sid or 'x')[:8]}.md"
        (folder / name).write_text("\n".join(md) + "\n", encoding="utf-8")
    append_jsonl(MEM / "LEARNING" / "sessions.jsonl",
                 {"ts": now_iso(), "session": sid, "tools": st.get("tools", 0),
                  "prompts": len(prompts), "isas": st.get("isas", []), "reason": evt.get("reason")})
    append_jsonl(EVENTS, {"ts": now_iso(), "event": "sessionEnd", "session": sid})
    try:
        session_state(sid).unlink()
    except Exception:
        pass
    return None

# ---------------------------------------------------------------- main

HANDLERS = {
    "sessionStart": on_session_start,
    "userPromptSubmitted": on_prompt,
    "preToolUse": on_pre_tool,
    "postToolUse": on_post_tool,
    "postToolUseFailure": lambda e: on_post_tool(e, failed=True),
    "agentStop": on_agent_stop,
    "sessionEnd": on_session_end,
}


_EXT_CACHE = None


def load_extensions():
    """Each hooks/ext/*.py may define HANDLERS = {eventName: fn(evt) -> dict|None}.
    Loaded once per process; returns [(stem, handlers, module)]."""
    global _EXT_CACHE
    if _EXT_CACHE is not None:
        return _EXT_CACHE
    import importlib.util
    _EXT_CACHE = []  # set first: an extension importing this module must not recurse
    for f in sorted((Path(__file__).resolve().parent / "ext").glob("*.py")):
        if f.name.startswith("_"):
            continue
        try:
            spec = importlib.util.spec_from_file_location(f"kai_ext_{f.stem}", f)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            handlers = getattr(mod, "HANDLERS", {})
            _EXT_CACHE.append((f.stem, handlers if isinstance(handlers, dict) else {}, mod))
        except Exception as exc:
            append_jsonl(EVENTS, {"ts": now_iso(), "event": "ext.load_error", "ext": f.stem, "error": repr(exc)[:300]})
    return _EXT_CACHE


def ext_module(stem):
    """A loaded extension module by file stem (e.g. "guards"), or None."""
    try:
        for name, _h, mod in load_extensions():
            if name == stem:
                return mod
    except Exception:
        pass
    return None


# Extension handlers that write learning / ratings / session logs: skipped in child_mode().
CHILD_SKIP = {"memory_learning": ("postToolUse", "postToolUseFailure", "agentStop", "sessionEnd")}
# Per-turn context is a main-session concern; workflow workers return raw output.
WORKER_SKIP_EVENTS = ("userPromptTransformed",)


def skip_ext(name, event):
    if event in WORKER_SKIP_EVENTS and os.environ.get("KAI_WORKFLOW_CHILD") == "1":
        return True
    return child_mode() and event in CHILD_SKIP.get(name, ())



def active_user_agent(evt):
    """Name of the user's OWN custom agent driving this session (not kai-*), else None.
    Copilot writes `subagent.selected {agentName}` to the session transcript."""
    sid = str(evt.get("sessionId") or "")
    if not sid or not re.match(r"^[A-Za-z0-9_-]+$", sid):
        return None
    path = Path(evt.get("transcriptPath") or COPILOT_HOME / "session-state" / sid / "events.jsonl")
    name = None
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f:
                if '"subagent.selected"' in line:
                    try:
                        name = (json.loads(line).get("data") or {}).get("agentName") or name
                    except Exception:
                        pass
    except Exception:
        return None
    if not name:
        return None
    base = str(name).split(":")[-1]
    return None if base.lower().startswith("kai") else str(name)


def merge_transformed(evt, outs):
    """userPromptTransformed: Copilot applies only ONE transformer (last wins), so Kai emits
    exactly one modifiedTransformedPrompt = the original transformedPrompt plus every
    extension's appended text. Never an empty string: no additions means no output."""
    base = evt.get("transformedPrompt")
    if not isinstance(base, str) or not base.strip():
        base = evt.get("prompt") if isinstance(evt.get("prompt"), str) else ""
    if not base.strip():
        return None
    adds = []
    for o in outs:
        if not isinstance(o, dict):
            continue
        m = o.get("modifiedTransformedPrompt")
        if isinstance(m, str) and m.strip():
            add = m[len(base):] if m.startswith(base) else "\n\n" + m
            if add.strip():
                adds.append(add if add.startswith("\n") else "\n\n" + add)
        ctx = o.get("additionalContext")
        if isinstance(ctx, str) and ctx.strip():
            adds.append("\n\n" + ctx)
    agent = active_user_agent(evt)
    if agent:
        # The user's own agent owns format and voice; keep only Kai's safety reminder.
        adds = [f"\n\n<kai-turn-context>\nThe user selected their own agent '{agent}': follow ITS instructions "
                "for format, voice and persona (no Kai banner or closer unless it asks). Kai's verification, "
                "security and safety rules still apply.\n</kai-turn-context>"]
    if not adds:
        return None
    return {"modifiedTransformedPrompt": base + "".join(adds)}


def merge_outputs(event, outs):
    """Combine core + extension outputs. Deny beats ask beats allow (every ask reason is
    shown, joined with " | "); first block wins; contexts concatenate."""
    outs = [o for o in outs if isinstance(o, dict) and o]
    if not outs:
        return None
    if event == "preToolUse":
        for o in outs:
            if o.get("permissionDecision") == "deny":
                return o
        asks = [o for o in outs if o.get("permissionDecision") == "ask"]
        if asks:
            reasons = []
            for o in asks:
                r = str(o.get("permissionDecisionReason") or "").strip()
                if r and r not in reasons:
                    reasons.append(r)
            merged = {"permissionDecision": "ask"}
            if reasons:
                merged["permissionDecisionReason"] = " | ".join(reasons)
            return merged
        # No objection: stay silent so Copilot's own permission prompts still apply.
        # An explicit "allow" could pre-approve the call. Only speak when rewriting args.
        for o in outs:
            if "modifiedArgs" in o:
                return {"modifiedArgs": o["modifiedArgs"]}
        return None
    if event == "agentStop":
        for o in outs:
            if o.get("decision") == "block":
                return o
        return None
    merged = {}
    ctx = [o["additionalContext"] for o in outs if o.get("additionalContext")]
    if ctx:
        merged["additionalContext"] = "\n".join(ctx)
    for o in outs:
        for k, v in o.items():
            if k != "additionalContext":
                merged.setdefault(k, v)
    return merged or None


def main():
    event = sys.argv[1] if len(sys.argv) > 1 else ""
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    evt = read_stdin()
    if not isinstance(evt, dict):
        evt = {}
    if event == "preToolUse":
        try:
            if kai_self_call(evt):
                emit({"permissionDecision": "allow", "permissionDecisionReason": "Kai's own tool or file"})
                return 0
        except Exception:
            pass
    outs = []
    try:
        outs.append(HANDLERS.get(event, lambda e: None)(evt))
    except Exception as exc:  # fail open, but leave a trace
        append_jsonl(EVENTS, {"ts": now_iso(), "event": f"{event}.error", "error": repr(exc)[:500]})
    # a core deny/block is final; extensions only run otherwise
    core = outs[0] if outs else None
    final_core = isinstance(core, dict) and (core.get("permissionDecision") == "deny" or core.get("decision") == "block")
    if not final_core:
        for name, handlers, mod in load_extensions():
            if skip_ext(name, event):
                if event == "sessionEnd" and hasattr(mod, "cleanup"):
                    try:
                        mod.cleanup(evt.get("sessionId", ""))
                    except Exception:
                        pass
                continue
            fn = handlers.get(event)
            if not fn:
                continue
            try:
                outs.append(fn(evt))
            except Exception as exc:
                append_jsonl(EVENTS, {"ts": now_iso(), "event": f"{event}.ext_error", "ext": name, "error": repr(exc)[:300]})
    try:
        out = merge_transformed(evt, outs) if event == "userPromptTransformed" else merge_outputs(event, outs)
        if event == "preToolUse" and not out and kai_self_call(evt):
            out = {"permissionDecision": "allow", "permissionDecisionReason": "Kai's own tool or file"}
    except Exception as exc:
        append_jsonl(EVENTS, {"ts": now_iso(), "event": f"{event}.merge_error", "error": repr(exc)[:300]})
        out = None
    emit(out)
    return 0


if __name__ == "__main__":
    try:
        main()
    except BaseException:  # never fail: a crashed preToolUse hook is a deny in Copilot
        pass  # exit 0 with no output = no objection (Copilot keeps its own permission flow)
    sys.exit(0)
