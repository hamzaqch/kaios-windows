"""Kai extension: memory, learning and health.

Ported behaviors (each section below names what it replaces):
  postToolUse    🧠 MEMORY delta lines for writes into MEMORY/ (separate from ⚙️ SYSTEM)
  agentStop      last-response cache, satisfaction / rating / correction / standing-rule capture
                 read from the transcript, memory health check, memory-review cadence
  sessionStart   signals readback (ratings trend, recent corrections, unencoded rules), health nag
  sessionEnd     session digest, work-completion learnings, counts, state cleanup

Every handler is defensive and bounded: no network, no subprocess, no LLM call.
agentStop never blocks (it only records), so it can never loop the agent.
"""
import datetime as _dt
import hashlib
import json
import os
import re
import time
from pathlib import Path

import kai_hook as K

# ------------------------------------------------------------------ paths / state


def _mem():
    return Path(K.MEM)


def _state_dir():
    return Path(K.STATE)


def _safe(sid):
    return re.sub(r"[^A-Za-z0-9_-]", "_", sid or "unknown")[:128]


def ext_state_path(sid):
    return _state_dir() / "ext" / f"{_safe(sid)}.memory.json"


def review_flag_path(sid):
    return _state_dir() / "ext" / f"{_safe(sid)}.review-due"


def last_response_path(sid):
    return _state_dir() / "last-response" / f"{_safe(sid)}.txt"


def writes_log():
    return _mem() / "OBSERVABILITY" / "memory-writes.jsonl"


def ratings_log():
    return _mem() / "LEARNING" / "ratings.jsonl"


def directives_log():
    return _mem() / "LEARNING" / "directives.jsonl"


def health_state_path():
    return _state_dir() / "memory-health.json"


def health_log():
    return _mem() / "OBSERVABILITY" / "memory-health.jsonl"


def _load(sid):
    st = K.load_json(ext_state_path(sid), None)
    if not isinstance(st, dict):
        st = {"started": K.now_iso(), "started_epoch": time.time()}
    return st


def _save(sid, st):
    K.save_json(ext_state_path(sid), st)


def _norm(p):
    return str(p).replace("\\", "/")


def _month():
    return _dt.datetime.now().strftime("%Y-%m")


# ------------------------------------------------------------------ text safety

# Memory items can come from external content. Echoing them verbatim into the
# model's context is an injection channel, so instruction-shaped samples are withheld.
INJECTION_SHAPES = re.compile(
    r"ignore (all |any )?(previous|prior|above)|disregard (the |your )?(instructions|rules)|you must now|"
    r"new instructions:|system prompt|</?[a-z-]+>|execute the|run this command|curl\s+http|IMPORTANT:|do not tell",
    re.I)
SECRET_SHAPES = re.compile(
    r"(gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9_-]{16,}|xox[abpr]-[A-Za-z0-9-]{10,}|"
    r"AKIA[0-9A-Z]{16}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}|"
    r"(?i:(password|passwd|secret|token|api[_-]?key)\s*[:=]\s*)\S+)")


def redact(text):
    return SECRET_SHAPES.sub("[REDACTED]", text or "")


def short(text, n=56):
    t = re.sub(r"\s+", " ", text or "").strip()
    if INJECTION_SHAPES.search(t):
        return "[withheld: instruction-shaped]"
    t = redact(t)
    return t if len(t) <= n else t[: n - 1] + "…"


def age_str(seconds):
    m = int(max(0, seconds) // 60)
    if m < 1:
        return "just now"
    if m < 60:
        return f"{m}m ago"
    h = m // 60
    if h < 24:
        return f"{h}h ago"
    return f"{h // 24}d ago"


# ------------------------------------------------------------------ memory write detection

PATCH_SECTION_RE = re.compile(r"^\*\*\*\s+(Add|Update|Delete)\s+File:\s*(.+?)\s*$", re.M)
KAI_ADD_RE = re.compile(r"kai\.py[\"']?\s+memory\s+add\s+([\"'])(.+?)\1(?:\s+([\"'])(.+?)\3)?", re.I | re.S)
KAI_LEARN_RE = re.compile(r"kai\.py[\"']?\s+learn\s+([\"'])(.+?)\1", re.I | re.S)
SHELL_MEM_PATH_RE = re.compile(r"((?:[A-Za-z]:)?[^\s\"'|;>]*[\\/]kai[\\/]MEMORY[\\/][^\s\"'|;>]+)", re.I)
SHELL_WRITE_VERB = re.compile(r"(\bset-content\b|\badd-content\b|\bout-file\b|\bnew-item\b|>>|(?<![-=])>\s|\btee\b|"
                              r"\bcopy-item\b|\bmove-item\b|\bremove-item\b|\b(?:rm|del|erase|cp|mv|copy|move)\b)", re.I)
SHELL_DELETE_VERB = re.compile(r"(\bremove-item\b|\b(?:rm|del|erase)\b)", re.I)


def patch_sections(args):
    """[(op, path, added_lines, removed_lines)] from any apply_patch-shaped string argument."""
    out = []
    for v in args.values():
        if not isinstance(v, str) or "*** " not in v:
            continue
        matches = list(PATCH_SECTION_RE.finditer(v))
        for i, m in enumerate(matches):
            end = matches[i + 1].start() if i + 1 < len(matches) else len(v)
            body = v[m.end():end].splitlines()
            added = [l[1:] for l in body if l.startswith("+") and not l.startswith("+++")]
            removed = [l[1:] for l in body if l.startswith("-") and not l.startswith("---")]
            out.append((m.group(1).lower(), m.group(2), added, removed))
    return out


def memory_rel(path, cwd=None):
    """Path relative to MEMORY/ (forward slashes) when the path is inside Kai's MEMORY, else None."""
    if not path:
        return None
    raw = _norm(path).strip().strip("\"'")
    if raw.startswith("~"):
        raw = _norm(Path(raw).expanduser())
    p = Path(raw)
    # Relative paths resolve against the tool's cwd (on any host, a drive-letter path counts as absolute).
    if cwd and not p.is_absolute() and not re.match(r"^[A-Za-z]:/", raw):
        raw = _norm(cwd).rstrip("/") + "/" + raw
    low = raw.lower()
    mem = _norm(_mem()).lower().rstrip("/") + "/"
    if low.startswith(mem):
        return raw[len(mem):]
    i = low.find("/kai/memory/")
    if i >= 0:
        return raw[i + len("/kai/memory/"):]
    if low.startswith("kai/memory/"):
        return raw[len("kai/memory/"):]
    return None


def classify(rel):
    """kind of a MEMORY-relative path, or None when it is hook-owned / core-surfaced."""
    parts = [p for p in rel.split("/") if p]
    if not parts:
        return None
    top = parts[0].upper()
    if top in ("STATE", "OBSERVABILITY"):
        return None
    if top == "WORK":
        if parts[-1].lower() == "isa.md":
            return None  # core emits the ⚙️ SYSTEM ISA line
        return "work"
    if top == "KNOWLEDGE":
        return "knowledge"
    if top == "LEARNING":
        if len(parts) > 1 and parts[1].lower() == "sessions":
            return None  # hook-written session logs
        if parts[-1].lower() == "learnings.md":
            return "learning"
        return "learning-note"
    return "memory"


def sample_for(kind, rel, added):
    name = Path(rel).stem
    lines = [l.strip() for l in added if l.strip() and not l.strip().startswith(("#", "---"))]
    if kind == "learning":
        bullets = [l[2:] for l in lines if l.startswith("- ")]
        return short(bullets[-1] if bullets else (lines[-1] if lines else name))
    first = lines[0] if lines else ""
    return short(f"{name}: {first}" if first else name)


def detect_memory_writes(tool, args, cwd):
    """[{rel, kind, op, sample}] for this tool call. Read-only tools yield nothing."""
    name = (tool or "").lower()
    if any(name.startswith(r) for r in K.READ_ONLY_TOOLS):
        return []
    found = {}
    for op, path, added, _removed in patch_sections(args):
        rel = memory_rel(path, cwd)
        kind = classify(rel) if rel is not None else None
        if kind:
            found[rel] = {"rel": rel, "kind": kind, "op": "drop" if op == "delete" else "add",
                          "sample": sample_for(kind, rel, added)}
    for key in ("path", "file_path", "filePath", "target", "filename"):
        path = args.get(key)
        if not isinstance(path, str):
            continue
        rel = memory_rel(path, cwd)
        kind = classify(rel) if rel is not None else None
        if kind and rel not in found:
            content = args.get("file_text") or args.get("content") or args.get("new_str") or args.get("new_string") or ""
            found[rel] = {"rel": rel, "kind": kind, "op": "add",
                          "sample": sample_for(kind, rel, str(content).splitlines())}
    is_shell = any(k in name for k in ("shell", "powershell", "bash", "terminal", "command", "exec"))
    if is_shell:
        cmd = str(args.get("command") or args.get("cmd") or args.get("script") or args.get("_raw") or "")
        for m in KAI_ADD_RE.finditer(cmd):
            topic = m.group(2)
            rel = f"KNOWLEDGE/{re.sub(r'[^A-Za-z0-9_-]+', '-', topic).strip('-').lower() or 'note'}.md"
            found.setdefault(rel, {"rel": rel, "kind": "knowledge", "op": "add",
                                   "sample": short(f"{topic}: {m.group(4) or ''}".rstrip(": "))})
        for m in KAI_LEARN_RE.finditer(cmd):
            found.setdefault("LEARNING/learnings.md#" + hashlib.sha1(m.group(2).encode("utf-8")).hexdigest()[:6],
                             {"rel": "LEARNING/learnings.md", "kind": "learning", "op": "add", "sample": short(m.group(2))})
        if SHELL_WRITE_VERB.search(cmd):
            for m in SHELL_MEM_PATH_RE.finditer(cmd):
                rel = memory_rel(m.group(1), cwd)
                kind = classify(rel) if rel is not None else None
                if kind and not any(v["rel"] == rel for v in found.values()):
                    op = "drop" if SHELL_DELETE_VERB.search(cmd) else "add"
                    found[rel] = {"rel": rel, "kind": kind, "op": op, "sample": short(Path(rel).stem)}
    return list(found.values())


def delta_line(writes):
    adds = [w for w in writes if w["op"] == "add"]
    drops = [w for w in writes if w["op"] == "drop"]
    parts = []
    if adds:
        kinds = sorted({w["kind"] for w in adds})
        parts.append(f"+{len(adds)} {'/'.join(kinds)}")
    if drops:
        parts.append(f"−{len(drops)} dropped")
    samples = [f"\"{w['sample']}\"" for w in adds[:2]] + [f"−\"{w['sample']}\"" for w in drops[:1]]
    line = "🧠 MEMORY: " + " · ".join(parts) + (" — " + ", ".join(samples) if samples else "")
    return line if len(line) <= 180 else line[:179] + "…"


# ------------------------------------------------------------------ postToolUse


def on_post_tool(evt, failed=False):
    sid = evt.get("sessionId", "")
    tool = evt.get("toolName", "") or ""
    args = K.tool_args(evt)
    st = _load(sid)
    counts = st.setdefault("tool_counts", {})
    counts[tool or "?"] = counts.get(tool or "?", 0) + 1
    if failed:
        st["failures"] = st.get("failures", 0) + 1
        _save(sid, st)
        return None
    written = st.setdefault("files_written", [])
    for p in K.written_paths(tool, args)[:20]:
        if p not in written:
            written.append(p)
    st["files_written"] = written[-60:]
    for p in K.written_paths(tool, args):
        if _norm(p).lower().endswith("isa.md") and p not in st.setdefault("isas", []):
            st["isas"].append(p)
    writes = detect_memory_writes(tool, args, evt.get("cwd"))
    if not writes:
        _save(sid, st)
        return None
    st["memory_writes"] = st.get("memory_writes", 0) + len(writes)
    _save(sid, st)
    for w in writes:
        K.append_jsonl(writes_log(), {"ts": K.now_iso(), "epoch": time.time(), "session": sid,
                                      "file": w["rel"], "kind": w["kind"], "op": w["op"], "sample": w["sample"],
                                      "tool": tool})
    return {"additionalContext": delta_line(writes) +
            "\n(Render this 🧠 MEMORY line verbatim once in your final response, just above the 🗣️ Kai: closer.)"}


# ------------------------------------------------------------------ satisfaction capture

WORD_NUMBERS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
                "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
SENTENCE_STARTERS = re.compile(
    r"^(items?|things?|steps?|files?|lines?|bugs?|issues?|errors?|times?|minutes?|hours?|days?|seconds?|percent|%|"
    r"th\b|st\b|nd\b|rd\b|of\b|in\b|at\b|to\b|the\b|a\b|an\b)", re.I)
MAX_BARE_DIGIT_COMMENT = 80


def parse_explicit_rating(prompt):
    """{"rating": n, "comment": str|None} for an explicit 1-10 rating, else None. Precision over recall."""
    t = (prompt or "").strip()
    if not t:
        return None
    low = t.lower()
    for word, num in WORD_NUMBERS.items():
        if low == word or low.startswith(word + " ") or low.startswith(word + "!"):
            rest = re.sub(r"^[!.,]+", "", t[len(word):].strip()).strip() or None
            return {"rating": num, "comment": rest}
    fm = re.match(r"^(10|[1-9])\s*(?:/|out\s+of)\s*10\b(.*)$", t, re.I | re.S)
    if fm:
        rest = re.sub(r"^[\s!.,:;-]+", "", fm.group(2)).strip() or None
        if rest and (SENTENCE_STARTERS.match(rest) or re.match(r"^[^\x00-\x7F]", fm.group(2))):
            return None
        return {"rating": int(fm.group(1)), "comment": rest}
    m = re.match(r"^(10|[1-9])(?:\s*[-:]\s*|\s+)?(.*)$", t, re.S)
    if not m:
        return None
    after = t[len(m.group(1)):]
    if after and re.match(r"^[/.)\]\dA-Za-z]|^[^\x00-\x7F]", after):
        return None
    rest = (m.group(2) or "").strip() or None
    if rest and SENTENCE_STARTERS.match(rest):
        return None
    if rest and len(rest) > MAX_BARE_DIGIT_COMMENT:
        return None
    return {"rating": int(m.group(1)), "comment": rest}


PRAISE_WORDS = {"excellent", "amazing", "brilliant", "fantastic", "wonderful", "beautiful", "incredible", "awesome",
                "perfect", "great", "nice", "superb", "outstanding", "magnificent", "stellar", "phenomenal",
                "remarkable", "terrific", "splendid"}
PRAISE_PHRASES = {"great job", "good job", "nice work", "well done", "nice job", "good work", "love it", "nailed it",
                  "looks great", "looks good", "thats great", "that works"}


def is_praise(prompt):
    norm = re.sub(r"[.!?,'\"]", "", (prompt or "").strip().lower())
    words = norm.split()
    if not words or len(words) > 2:
        return False
    return norm in PRAISE_WORDS or norm in PRAISE_PHRASES or (len(words) == 2 and all(w in PRAISE_WORDS for w in words))


CORRECTION_PHRASES = ["that's wrong", "that's not what i", "you didn't", "you ignored", "still broken", "still not",
                      "didn't work", "not what i asked", "stop doing", "again?", "i already told you"]
WORK_REFERENCE = re.compile(r"\b(you|your|it|code|banner|test|tests|build|hook|hooks|file|page|deploy|fix|script|output|response)\b")
WORK_PROFANITY = re.compile(r"\b(fucking|wtf|what the fuck)\b")


def _fold(text):
    return text.lower().replace("‘", "'").replace("’", "'").replace("ʼ", "'").replace("`", "'")


def detect_correction(prompt):
    t = (prompt or "").strip()
    if len(t) < 10 or t.startswith("/"):
        return None
    norm = _fold(t)
    if re.match(r"^no[,.]", norm) or re.match(r"^nope\b", norm):
        return t
    if any(p in norm for p in CORRECTION_PHRASES):
        return t
    if WORK_PROFANITY.search(norm) and WORK_REFERENCE.search(norm):
        return t
    return None


DIRECTIVE_PATTERNS = [re.compile(p, re.I) for p in (
    r"\bfrom now on\b", r"\bin the future\b", r"\bgoing forward\b", r"\bnew rule\b", r"^rule:",
    r"\bkai should (always|never|not)\b",
    r"\b(always|never) (do|use|include|make|add|put|run|write|call|show|keep|remember to)\b")]


def detect_directive(prompt):
    t = (prompt or "").strip()
    if len(t) < 15 or t.startswith("/"):
        return None
    norm = _fold(t)
    return t if any(p.search(norm) for p in DIRECTIVE_PATTERNS) else None


SYSTEM_TEXT = [re.compile(p, re.I) for p in (
    r"^<task-notification>", r"^<system-reminder>", r"^<current_datetime>",
    r"^This session is being continued from a previous conversation", r"^Please continue the conversation",
    r"^Note:.*was read before")]


def is_system_text(prompt):
    t = (prompt or "").strip()
    return any(p.search(t) for p in SYSTEM_TEXT)


def learning_category(content, comment=""):
    text = f"{content} {comment}".lower()
    if re.search(r"over.?engineer|wrong approach|should have asked|didn't follow|missed the point|too complex|"
                 r"didn't understand|wrong direction|not what i wanted|approach|method|strategy|reasoning", text):
        return "ALGORITHM"
    return "SYSTEM"


def write_failure(sid, label, rating, feedback, response, source):
    now = _dt.datetime.now()
    folder = _mem() / "LEARNING" / "FAILURES" / now.strftime("%Y-%m")
    try:
        folder.mkdir(parents=True, exist_ok=True)
        name = f"{now.strftime('%Y-%m-%d_%H%M%S')}_{label}.md"
        path = folder / name
        if path.exists():
            return None
        cat = learning_category(response or "", feedback or "")
        body = [
            "---", "capture_type: FAILURE", f"timestamp: {K.now_iso()}", f"session: {sid}",
            f"rating: {rating if rating is not None else ''}", f"source: {source}", f"category: {cat}",
            "auto_captured: true", "---", "",
            f"# {'Low rating' if rating is not None else 'Correction'} captured" + (f": {rating}/10" if rating is not None else ""),
            "", "## What the user said (verbatim)", "", redact(feedback or "(no comment)")[:1500], "",
            "## The response it was about (preview)", "", "```", redact(response or "(not available)")[:1500], "```", "",
            "## Improvement notes", "",
            "Find the mechanism, not the instance: what rule, hook or skill change would have prevented this?", "",
        ]
        path.write_text("\n".join(body), encoding="utf-8")
        return path
    except Exception:
        return None


def capture_signal(sid, prompt, prev_response):
    """Classify one user prompt and write the matching learning records. Returns a label or None."""
    if not prompt or is_system_text(prompt):
        return None
    preview = (prev_response or "")[:500]
    r = parse_explicit_rating(prompt)
    if r:
        row = {"ts": K.now_iso(), "session": sid, "rating": r["rating"], "source": "explicit"}
        if r.get("comment"):
            row["comment"] = redact(r["comment"])[:300]
        if preview:
            row["response_preview"] = redact(preview)
        K.append_jsonl(ratings_log(), row)
        if r["rating"] < 5 and prev_response:
            write_failure(sid, f"low-rating-{r['rating']}", r["rating"], r.get("comment") or "", prev_response, "explicit")
        return f"rating:{r['rating']}"
    if len(prompt.strip()) < 3:
        return None
    if is_praise(prompt):
        row = {"ts": K.now_iso(), "session": sid, "rating": 8, "source": "implicit", "confidence": 0.95,
               "comment": f"Direct praise: \"{prompt.strip()[:60]}\""}
        if preview:
            row["response_preview"] = redact(preview)
        K.append_jsonl(ratings_log(), row)
        return "praise"
    label = None
    d = detect_directive(prompt)
    if d:
        h = hashlib.sha1(d.strip().lower().encode("utf-8")).hexdigest()[:12]
        seen = {row.get("hash") for row in tail_jsonl(directives_log(), 400)}
        if h not in seen:
            K.append_jsonl(directives_log(), {"ts": K.now_iso(), "session": sid, "hash": h,
                                              "text": redact(d)[:900], "status": "captured"})
        label = "directive"
    c = detect_correction(prompt)
    if c and prev_response:
        write_failure(sid, "correction", None, c, prev_response, "correction")
        K.append_jsonl(ratings_log(), {"ts": K.now_iso(), "session": sid, "rating": None, "source": "correction",
                                       "comment": redact(c)[:300], "response_preview": redact(preview)})
        label = "correction"
    return label


def tail_jsonl(path, n):
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 256 * 1024))
            lines = f.read().decode("utf-8", errors="replace").splitlines()
    except Exception:
        return []
    out = []
    for line in lines[-n:]:
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                out.append(obj)
        except Exception:
            continue
    return out


def scan_transcript(sid, path, st, max_bytes=4 * 1024 * 1024):
    """Process transcript lines added since the stored byte offset. Pairs each user.message with the
    assistant.message before it. Returns the list of capture labels."""
    labels = []
    try:
        size = os.path.getsize(path)
    except Exception:
        return labels
    offset = st.get("transcript_offset", 0)
    if st.get("transcript_path") != str(path) or offset > size:
        # First sight of this transcript. On a resumed session the file already holds earlier turns
        # whose ratings were captured before; start from the size recorded at sessionStart.
        base = st.get("transcript_base", 0)
        offset = base if isinstance(base, int) and 0 <= base <= size else 0
        st["transcript_path"] = str(path)
    if size - offset > max_bytes:  # first sight of a huge transcript: only read the tail
        offset = size - max_bytes
    try:
        with open(path, "rb") as f:
            f.seek(offset)
            chunk = f.read(size - offset)
    except Exception:
        return labels
    cut = chunk.rfind(b"\n")
    if cut < 0:
        return labels
    st["transcript_offset"] = offset + cut + 1
    last = st.get("last_assistant", "")
    for raw in chunk[:cut].decode("utf-8", errors="replace").splitlines():
        try:
            obj = json.loads(raw)
        except Exception:
            continue
        typ = obj.get("type")
        data = obj.get("data") or {}
        content = data.get("content") if isinstance(data, dict) else None
        if not isinstance(content, str):
            continue
        if typ == "assistant.message" and content.strip():
            last = content
        elif typ == "user.message" and content.strip():
            label = capture_signal(sid, content, last)
            if label:
                labels.append(label)
                if label.startswith("rating") or label == "praise":
                    st.setdefault("ratings", []).append(label)
                elif label == "correction":
                    st["corrections"] = st.get("corrections", 0) + 1
                elif label == "directive":
                    st["directives"] = st.get("directives", 0) + 1
    st["last_assistant"] = last[-2000:]
    return labels


# ------------------------------------------------------------------ health check

REQUIRED_EVENTS = ("sessionStart", "preToolUse", "postToolUse", "agentStop", "sessionEnd")
HEALTH_INTERVAL = 600


def _hook_registered(settings, event):
    hooks = settings.get("hooks") if isinstance(settings, dict) else None
    if not isinstance(hooks, dict):
        return False
    entries = hooks.get(event) or []
    try:
        return "kai_hook.py" in json.dumps(entries)
    except Exception:
        return False


def health_check(force=False):
    """Evidence-driven health report. Rate-limited; returns the latest report dict."""
    prev = K.load_json(health_state_path(), {})
    if not force and prev and time.time() - prev.get("epoch", 0) < HEALTH_INTERVAL:
        return prev
    findings = []

    def add(sev, code, msg):
        findings.append({"severity": sev, "code": code, "message": msg})

    mem = _mem()
    for d in ("WORK", "KNOWLEDGE", "LEARNING", "STATE", "OBSERVABILITY"):
        if not (mem / d).is_dir():
            add("critical", "missing-dir", f"MEMORY/{d} is missing (reinstall or run kai.py doctor)")
    events = Path(K.EVENTS)
    if events.exists() and not os.access(events, os.W_OK):
        add("critical", "events-readonly", "OBSERVABILITY/events.jsonl is not writable")
    settings_path = Path(K.COPILOT_HOME) / "settings.json"
    settings = K.load_json(settings_path, None)
    # Settings-hooks integrity: Kai's hook block must match what the installer wrote.
    try:
        import hashlib
        man = K.load_json(Path(K.KAI_HOME) / "manifest.json", {})
        want = man.get("hooks_sha256")
        if want and isinstance(settings, dict):
            mine = {ev: [e for e in arr if "kai_hook.py" in json.dumps(e)]
                    for ev, arr in (settings.get("hooks") or {}).items() if isinstance(arr, list)}
            mine = {ev: arr for ev, arr in mine.items() if arr}
            got = hashlib.sha256(json.dumps(mine, sort_keys=True, separators=(",", ":"),
                                            ensure_ascii=False).encode("utf-8")).hexdigest()
            if got != want:
                add("warn", "hooks-tampered", "Kai's hook entries in settings.json changed since install "
                    "(edited by hand or another tool); re-run the installer if that wasn't you")
    except Exception:
        pass
    due = Path(K.STATE) / "docs-lint-due"
    if due.exists():
        add("info", "docs-lint-due", "Kai's own files changed; run `python ~/.copilot/kai/bin/kai.py doctor --docs` "
            "to check cross-references")
    if settings is None:
        add("critical", "no-settings", "settings.json missing or unreadable, so no Kai hooks are registered")
    else:
        missing = [e for e in REQUIRED_EVENTS if not _hook_registered(settings, e)]
        if missing:
            add("critical", "hooks-unregistered", "Kai hooks not registered for: " + ", ".join(missing))
        if not _hook_registered(settings, "userPromptTransformed"):
            add("info", "turn-channel-off", "userPromptTransformed hook not registered; per-turn context falls back to tool calls")
        else:
            hb = _state_dir() / "turn-heartbeat"
            # Dead only if a prompt arrived >10 min ago and no heartbeat has landed since it.
            # (On the very first turn after install the heartbeat is written moments AFTER this check.)
            def _ts(s):
                try:
                    import datetime as _d
                    return _d.datetime.fromisoformat(str(s)).timestamp()
                except Exception:
                    return None
            now = time.time()
            prompt_ts = [x for x in (_ts(r.get("ts")) for r in tail_jsonl(events, 300)
                                     if r.get("event") == "userPromptSubmitted") if x and 600 < now - x < 86400]
            try:
                hb_mtime = hb.stat().st_mtime
            except Exception:
                hb_mtime = None
            if prompt_ts and (hb_mtime is None or hb_mtime < min(prompt_ts)):
                add("critical", "turn-channel-dead", "per-turn context hook is registered but has not run in 24h while prompts arrive")
    learn = mem / "LEARNING" / "learnings.md"
    try:
        n = sum(1 for l in learn.read_text(encoding="utf-8").splitlines() if l.startswith("- "))
        if n > 200:
            add("warn", "learnings-bloat", f"learnings.md holds {n} lessons; consolidate duplicates (cap 200)")
    except Exception:
        pass
    try:
        if events.exists() and events.stat().st_size > 20 * 1024 * 1024:
            add("warn", "events-retention", f"events.jsonl is {events.stat().st_size // (1024 * 1024)} MB; rotate it")
    except Exception:
        pass
    errs = sorted({r.get("ext") or r.get("event") for r in tail_jsonl(events, 400)
                   if str(r.get("event", "")).endswith(("ext_error", "ext.load_error", ".error")) and _recent(r.get("ts"), 86400)})
    if errs:
        add("warn", "hook-errors", "hook errors in the last 24h: " + ", ".join(e for e in errs if e)[:160])
    try:
        sess = list((_state_dir() / "sessions").glob("*.json"))
        if len(sess) > 500:
            add("warn", "state-bloat", f"{len(sess)} stale session-state files in STATE/sessions")
    except Exception:
        pass
    crit = sum(1 for f in findings if f["severity"] == "critical")
    warn = sum(1 for f in findings if f["severity"] == "warn")
    report = {"ts": K.now_iso(), "epoch": time.time(), "overall": "critical" if crit else ("warn" if warn else "ok"),
              "counts": {"critical": crit, "warn": warn}, "findings": findings}
    K.save_json(health_state_path(), report)
    if report["overall"] != prev.get("overall") or time.time() - prev.get("logged_epoch", 0) > 6 * 3600:
        K.append_jsonl(health_log(), {k: v for k, v in report.items() if k != "epoch"})
        report["logged_epoch"] = time.time()
        K.save_json(health_state_path(), report)
    else:
        report["logged_epoch"] = prev.get("logged_epoch", 0)
        K.save_json(health_state_path(), report)
    return report


def _recent(ts, seconds):
    try:
        t = _dt.datetime.fromisoformat(str(ts))
        if t.tzinfo is None:
            t = t.astimezone()
        return (_dt.datetime.now().astimezone() - t).total_seconds() <= seconds
    except Exception:
        return False


def health_line(report, include_warn=False):
    if not report:
        return None
    lvl = report.get("overall")
    if lvl == "critical" or (include_warn and lvl == "warn"):
        sev = "critical" if lvl == "critical" else "warn"
        msgs = [f["message"] for f in report.get("findings", []) if f.get("severity") == sev][:3]
        return (f"🩺 MEMORY HEALTH: {lvl.upper()} — " + " · ".join(msgs) +
                f". Check: python \"{Path(K.KAI_HOME) / 'bin' / 'kai.py'}\" doctor")
    return None


# ------------------------------------------------------------------ agentStop

REVIEW_TURNS = 8
REVIEW_MINUTES = 30


def on_agent_stop(evt):
    sid = evt.get("sessionId", "")
    st = _load(sid)
    path = evt.get("transcriptPath") or ""
    if path:
        scan_transcript(sid, path, st)
        if st.get("last_assistant"):
            try:
                lr = last_response_path(sid)
                lr.parent.mkdir(parents=True, exist_ok=True)
                lr.write_text(st["last_assistant"], encoding="utf-8")
            except Exception:
                pass
    if not evt.get("stop_hook_active"):
        st["turns"] = st.get("turns", 0) + 1
        st["turns_since_review"] = st.get("turns_since_review", 0) + 1
        glob = K.load_json(_state_dir() / "memory-review.json", {})
        since = time.time() - glob.get("last_review_epoch", 0)
        if st["turns_since_review"] >= REVIEW_TURNS and since >= REVIEW_MINUTES * 60:
            try:
                f = review_flag_path(sid)
                f.parent.mkdir(parents=True, exist_ok=True)
                f.write_text(str(st["turns_since_review"]), encoding="utf-8")
            except Exception:
                pass
            K.append_jsonl(_mem() / "OBSERVABILITY" / "reviewer-fires.jsonl",
                           {"ts": K.now_iso(), "session": sid, "turns": st["turns_since_review"]})
            st["turns_since_review"] = 0
            glob.update({"last_review_epoch": time.time(), "last_review": K.now_iso(), "session": sid})
            K.save_json(_state_dir() / "memory-review.json", glob)
    _save(sid, st)
    health_check()
    return None  # never blocks: recording only


# ------------------------------------------------------------------ sessionStart


def signals_readback():
    lines = []
    rows = [r for r in tail_jsonl(ratings_log(), 200) if isinstance(r.get("rating"), (int, float))]
    if rows:
        last = rows[-10:]
        avg = sum(r["rating"] for r in last) / len(last)
        trend = ""
        if len(rows) >= 20:
            prev = rows[-20:-10]
            pavg = sum(r["rating"] for r in prev) / len(prev)
            trend = " (up)" if avg > pavg + 0.5 else (" (down)" if avg < pavg - 0.5 else " (flat)")
        lines.append(f"- Satisfaction: avg {avg:.1f}/10 over the last {len(last)} ratings{trend}.")
    corr = [r for r in tail_jsonl(ratings_log(), 300)
            if (r.get("source") == "correction" or (isinstance(r.get("rating"), int) and r["rating"] < 5))
            and _recent(r.get("ts"), 14 * 86400)][-3:]
    if corr:
        lines.append("- Recent corrections and low ratings (don't repeat these):")
        for r in corr:
            what = r.get("comment") or f"rated {r.get('rating')}/10"
            lines.append(f"  - \"{short(what, 120)}\" ({str(r.get('ts', ''))[:10]})")
    dirs = [r for r in tail_jsonl(directives_log(), 200) if _recent(r.get("ts"), 30 * 86400)][-5:]
    if dirs:
        lines.append("- Standing rules the user stated recently (confirm each is encoded under `## Your rules` "
                     "in ~/.copilot/copilot-instructions.md; encode any that are missing):")
        for r in dirs:
            lines.append(f"  - \"{short(r.get('text', ''), 140)}\"")
    return lines


def on_session_start(evt):
    sid = evt.get("sessionId", "")
    st = {"started": K.now_iso(), "started_epoch": time.time(), "cwd": evt.get("cwd") or ""}
    try:  # resumed session: skip transcript lines already processed in an earlier run
        tp = Path(K.COPILOT_HOME) / "session-state" / _safe(sid) / "events.jsonl"
        if sid and tp.is_file():
            st["transcript_base"] = tp.stat().st_size
            prev = K.last_assistant_text(tp) if st["transcript_base"] <= 8 * 1024 * 1024 else None
            if prev:
                st["last_assistant"] = prev[-2000:]
    except Exception:
        pass
    _save(sid, st)
    out = []
    hl = health_line(health_check(force=True), include_warn=True)
    if hl:
        out.append(hl)
    sig = signals_readback()
    if sig:
        out.append("# Kai learning signals")
        out += sig
    return {"additionalContext": "\n".join(out)} if out else None


# ------------------------------------------------------------------ sessionEnd


def _slug(text):
    return re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")[:30] or "work"


def work_learnings(sid, st):
    """WORK -> LEARNING bridge: one note per ISA touched this session that closed at least one claim."""
    written = []
    paths = list(dict.fromkeys(st.get("isas", [])))
    work = K.load_json(_state_dir() / "work.json", {})
    started = st.get("started_epoch", 0)
    for p, row in (work.items() if isinstance(work, dict) else []):
        try:
            t = _dt.datetime.fromisoformat(str(row.get("updated"))).timestamp()
        except Exception:
            continue
        if t >= started and p not in paths:
            paths.append(p)
    now = _dt.datetime.now()
    folder = _mem() / "LEARNING" / "work" / now.strftime("%Y-%m")
    for p in paths[:10]:
        info = K.parse_isa(p)
        if not info or info["closed"] <= 0:
            continue
        fm = info["frontmatter"]
        title = fm.get("task") or fm.get("title") or fm.get("principal_stated_goal") or Path(p).parent.name
        dur = "unknown"
        try:
            begin = _dt.datetime.fromisoformat(fm.get("started") or fm.get("created") or "")
            if begin.tzinfo is None:
                begin = begin.astimezone()
            mins = int((now.astimezone() - begin).total_seconds() // 60)
            dur = f"{mins} minutes" if mins < 60 else f"{mins // 60}h {mins % 60}m"
        except Exception:
            pass
        name = f"{now.strftime('%Y-%m-%d_%H%M')}_work_{_slug(title)}.md"
        target = folder / name
        if target.exists():
            continue
        body = ["# Work completion learning", "", f"- **Title:** {redact(title)[:200]}", f"- **ISA:** {p}",
                f"- **Session:** {sid}", f"- **Phase at close:** {fm.get('phase', 'unknown')}",
                f"- **Claims closed:** {info['closed']}/{info['claims']}",
                f"- **Still open:** {', '.join(info['open_ids'][:12]) or 'none'}", f"- **Duration:** {dur}", "",
                "## What to carry forward", "",
                "Review the ISA's Decisions and Verification sections; promote any reusable lesson with "
                "`kai.py learn \"...\"`.", ""]
        try:
            folder.mkdir(parents=True, exist_ok=True)
            target.write_text("\n".join(body), encoding="utf-8")
            written.append(str(target))
        except Exception:
            pass
    return written


def session_digest(sid, st, work_notes):
    counts = st.get("tool_counts", {})
    top = sorted(counts.items(), key=lambda kv: -kv[1])[:8]
    ratings = [int(r.split(":")[1]) for r in st.get("ratings", []) if r.startswith("rating:")]
    dur = ""
    if st.get("started_epoch"):
        mins = int((time.time() - st["started_epoch"]) // 60)
        dur = f"{mins} min" if mins < 60 else f"{mins // 60}h {mins % 60}m"
    lines = ["", "## Digest", "",
             f"- duration: {dur or 'unknown'} · turns: {st.get('turns', 0)} · tool calls: {sum(counts.values())} "
             f"· failures: {st.get('failures', 0)}",
             f"- tools: {', '.join(f'{k}×{v}' for k, v in top) or 'none'}",
             f"- memory writes: {st.get('memory_writes', 0)}",
             f"- ratings: {', '.join(map(str, ratings)) or 'none'}"
             + (f" (avg {sum(ratings) / len(ratings):.1f})" if ratings else "")
             + f" · praise: {st.get('ratings', []).count('praise')} · corrections: {st.get('corrections', 0)}"
             + f" · new standing rules: {st.get('directives', 0)}"]
    files = st.get("files_written", [])
    if files:
        lines.append("- files written:")
        lines += [f"  - {f}" for f in files[-20:]]
    if work_notes:
        lines.append("- work learnings: " + ", ".join(Path(w).name for w in work_notes))
    return lines


def on_session_end(evt):
    sid = evt.get("sessionId", "")
    st = _load(sid)
    notes = work_learnings(sid, st)
    meaningful = st.get("tool_counts") or st.get("turns") or st.get("ratings")
    if meaningful:
        digest = session_digest(sid, st, notes)
        folder = _mem() / "LEARNING" / "sessions" / _month()
        try:
            folder.mkdir(parents=True, exist_ok=True)
            tag = (sid or "x")[:8]
            existing = sorted(folder.glob(f"*_{tag}.md"), key=lambda p: p.stat().st_mtime)
            target = existing[-1] if existing else folder / f"{_dt.datetime.now().strftime('%Y-%m-%d_%H%M')}_{tag}.md"
            prefix = "" if target.exists() else f"# Session {_dt.datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n- session: {sid}\n"
            with open(target, "a", encoding="utf-8") as f:
                f.write(prefix + "\n".join(digest) + "\n")
            K.append_jsonl(writes_log(), {"ts": K.now_iso(), "epoch": time.time(), "session": sid,
                                          "file": f"LEARNING/sessions/{_month()}/{target.name}", "kind": "digest",
                                          "op": "add", "sample": f"session digest ({len(notes)} work notes)",
                                          "tool": "sessionEnd"})
        except Exception:
            pass
    write_counts()
    cleanup(sid)
    return None


def write_counts():
    mem = _mem()
    home = Path(K.COPILOT_HOME)

    def n(globber):
        try:
            return sum(1 for _ in globber)
        except Exception:
            return 0

    learn = 0
    try:
        learn = sum(1 for l in (mem / "LEARNING" / "learnings.md").read_text(encoding="utf-8").splitlines() if l.startswith("- "))
    except Exception:
        pass
    K.save_json(_state_dir() / "counts.json", {
        "ts": K.now_iso(),
        "skills": n((home / "skills").glob("*/SKILL.md")),
        "agents": n((home / "agents").glob("*.agent.md")),
        "knowledge": n((mem / "KNOWLEDGE").glob("**/*.md")),
        "learnings": learn,
        "work": n((mem / "WORK").glob("*/ISA.md")),
        "ratings": _count_lines(ratings_log()),
        "failures": n((mem / "LEARNING" / "FAILURES").glob("*/*.md")),
    })


def _count_lines(path):
    try:
        n = 0
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                n += chunk.count(b"\n")
        return n
    except Exception:
        return 0


def cleanup(sid):
    for p in (ext_state_path(sid), review_flag_path(sid), last_response_path(sid)):
        try:
            p.unlink()
        except Exception:
            pass
    cutoff = time.time() - 7 * 86400
    for d in (_state_dir() / "ext", _state_dir() / "last-response"):
        try:
            for f in d.iterdir():
                try:
                    if f.stat().st_mtime < cutoff:
                        f.unlink()
                except Exception:
                    continue
        except Exception:
            continue


HANDLERS = {
    "sessionStart": on_session_start,
    "postToolUse": on_post_tool,
    "postToolUseFailure": lambda e: on_post_tool(e, failed=True),
    "agentStop": on_agent_stop,
    "sessionEnd": on_session_end,
}
