"""Kai extension: per-turn context, format drift contract, Algorithm nudges, loop and complexity watch.

Per-turn channel: Copilot drops userPromptSubmitted output, but userPromptTransformed's
{"modifiedTransformedPrompt"} reaches the model (verified live, CLI 1.0.106). Multiple
transformers do NOT chain (last one wins), so Kai must register exactly ONE
userPromptTransformed hook, and this extension is the only Kai code that answers it.
It appends one <kai-turn-context> block to the transformed prompt and never returns
an empty string. When that event is not registered, the format contract falls back to
the first tool call of each turn (postToolUse additionalContext).

Block contents (each line is computed here, deterministically):
  🩺 memory health nag (critical only)      FORMAT CONTRACT (+ what the last reply broke)
  🧠 MEMORY delta / heartbeat               memory-review-due prompt
  learnings refresh (on change / every 20)  task-scoped memory retrieval (BM25)
  🧭 ALGO-NUDGE rows: skill routing, depth directive, design-class, standing rule

postToolUse rows: 🔁 LOOP (repeat / oscillation / hammering), 📈 RATCHET (large writes,
new dependencies, session growth bands), 🧭 ALGO-NUDGE (stale ISA, execution and sweep
delegation, destructive cloud ops), 🧪 EVAL-NUDGE (ConfigEvalFire: an edit to Kai's
constitution, agents, hooks, RULES or ALGORITHM.md -> run the /evals regression suites;
advisory only, never spawns a run; KAI_CONFIG_EVAL_NUDGE=0 silences it).
subagentStart: compact Kai rules for subagents.
"""
import hashlib
import json
import math
import os
import re
import time
from pathlib import Path

import kai_hook as K

# ------------------------------------------------------------------ state


def _safe(sid):
    return re.sub(r"[^A-Za-z0-9_-]", "_", sid or "unknown")[:128]


def ext_state_path(sid):
    return Path(K.STATE) / "ext" / f"{_safe(sid)}.context.json"


def _load(sid):
    st = K.load_json(ext_state_path(sid), None)
    return st if isinstance(st, dict) else {}


def _save(sid, st):
    K.save_json(ext_state_path(sid), st)


def _cooled(st, key, seconds):
    return time.time() - st.setdefault("nudges", {}).get(key, 0) >= seconds


def _fire(st, key, text, out, prefix="🧭 ALGO-NUDGE: "):
    st.setdefault("nudges", {})[key] = time.time()
    out.append(prefix + text)
    K.append_jsonl(K.MEM / "OBSERVABILITY" / "nudges.jsonl", {"ts": K.now_iso(), "nudge": key})


INJECTION_SHAPES = re.compile(
    r"ignore (all |any )?(previous|prior|above)|disregard (the |your )?(instructions|rules)|you must now|"
    r"new instructions:|system prompt|</?[a-z-]+>|execute the|run this command|curl\s+http|IMPORTANT:|do not tell",
    re.I)


def short(text, n=90):
    t = re.sub(r"\s+", " ", text or "").strip()
    if INJECTION_SHAPES.search(t):
        return "[withheld: instruction-shaped]"
    return t if len(t) <= n else t[: n - 1] + "…"


# ------------------------------------------------------------------ format drift contract

BANNER_RE = re.compile(r"^\s*═+\s*Kai\b")
CLOSER_RE = re.compile(r"🗣️\s*Kai:")
DEFAULT_LINE_CAP = 15
DEPTH_RE = re.compile(
    r"\b(extensive|thorough|comprehensive|exhaustive|deep[\s-]?dive|in[\s-]depth|detailed|long[\s-]form|"
    r"full (?:analysis|report|breakdown|write[\s-]?up)|go deep|be verbose|everything (?:you|we) (?:know|have))\b", re.I)
BANNED_VOCAB = ["delve", "leverage", "robust", "comprehensive", "cutting-edge", "seamless", "seamlessly",
                "meticulous", "meticulously", "pivotal", "underscores", "testament to", "game-changer", "utilize",
                "tapestry", "realm", "paradigm", "embark", "beacon", "vibrant", "showcasing", "dive into",
                "intricate", "ever-evolving", "holistic", "actionable", "impactful", "synergy", "in order to",
                "due to the fact that", "unleash", "streamline", "elevate", "foster"]
BANNED_RE = re.compile(r"(?<![A-Za-z0-9])(" + "|".join(re.escape(w) for w in BANNED_VOCAB) + r")(?![A-Za-z0-9])", re.I)


def strip_code(text):
    return re.sub(r"`[^`\n]*`", "", re.sub(r"```.*?```", "", text or "", flags=re.S))


def measure(text):
    prose = strip_code(text)
    m = BANNED_RE.search(prose)
    return {"lines": sum(1 for l in prose.splitlines() if l.strip()),
            "em_dashes": prose.count("—"),
            "banner": bool(BANNER_RE.search(text or "")),
            "closer": bool(CLOSER_RE.search(text or "")),
            "banned": m.group(1).lower() if m else None}


def breaks_in(m, cap):
    out = []
    if not m["banner"]:
        out.append("no banner")
    if not m["closer"]:
        out.append("no closer")
    if m["em_dashes"] > 2:
        out.append(f"{m['em_dashes']} em-dashes")
    if m["banned"]:
        out.append(f"banned word '{m['banned']}'")
    if cap is not None and m["lines"] > cap:
        out.append(f"{m['lines']} lines (cap {cap})")
    return out


def cap_for(prompt):
    return None if DEPTH_RE.search(prompt or "") else DEFAULT_LINE_CAP


def last_response(sid):
    """Previous final reply: cache written at agentStop, else the Copilot transcript (bounded size)."""
    cache = Path(K.STATE) / "last-response" / f"{_safe(sid)}.txt"
    try:
        if time.time() - cache.stat().st_mtime <= 1800:
            return cache.read_text(encoding="utf-8")
    except Exception:
        pass
    tp = Path(K.COPILOT_HOME) / "session-state" / (sid or "_") / "events.jsonl"
    try:
        if tp.stat().st_size <= 2 * 1024 * 1024 and time.time() - tp.stat().st_mtime <= 1800:
            return K.last_assistant_text(tp)
    except Exception:
        pass
    return None


def contract_line(prompt, last):
    cap = cap_for(prompt)
    budget = "depth requested, line cap lifted" if cap is None else f"max {cap} prose lines for a plain answer"
    prev = ""
    if last:
        broke = breaks_in(measure(last), cap)
        prev = f" Last reply broke: {', '.join(broke)}." if broke else f" Last reply was clean ({measure(last)['lines']} lines)."
    return (f"FORMAT CONTRACT (check before writing, not after): {budget}; `════ Kai ════` banner first, "
            f"`🗣️ Kai:` closer last, max 2 em-dashes.{prev}")


# ------------------------------------------------------------------ 🧠 MEMORY per-turn line


def _age(seconds):
    m = int(max(0, seconds) // 60)
    return "just now" if m < 1 else (f"{m}m ago" if m < 60 else (f"{m // 60}h ago" if m < 1440 else f"{m // 1440}d ago"))


def _tail(path, n=500):
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 256 * 1024))
            lines = f.read().decode("utf-8", errors="replace").splitlines()
    except Exception:
        return []
    out = []
    for line in lines[-n:]:
        try:
            o = json.loads(line)
            if isinstance(o, dict):
                out.append(o)
        except Exception:
            continue
    return out


def memory_line(sid, st, first_turn):
    """Delta form for writes from other sessions/hooks since this session's cursor; heartbeat on turn 1."""
    rows = _tail(K.MEM / "OBSERVABILITY" / "memory-writes.jsonl")
    cursor = st.get("mem_cursor", 0)
    fresh = [r for r in rows if r.get("epoch", 0) > cursor and r.get("session") != sid]
    if rows:
        st["mem_cursor"] = max(cursor, max(r.get("epoch", 0) for r in rows))
    if fresh and not first_turn:
        adds = [r for r in fresh if r.get("op") == "add"]
        drops = [r for r in fresh if r.get("op") == "drop"]
        parts = ([f"+{len(adds)} learned elsewhere"] if adds else []) + ([f"−{len(drops)} dropped"] if drops else [])
        samples = ", ".join(f"\"{short(r.get('sample', ''), 56)}\"" for r in adds[:2])
        line = "🧠 MEMORY: " + " · ".join(parts) + (f" — {samples}" if samples else "")
        return line[:180]
    if not first_turn:
        return None
    counts = K.load_json(K.STATE / "counts.json", {})
    segs = []
    try:
        know = counts.get("knowledge")
        if know is None:
            know = sum(1 for _ in (K.MEM / "KNOWLEDGE").glob("**/*.md"))
        learn = counts.get("learnings")
        if learn is None:
            learn = sum(1 for l in (K.MEM / "LEARNING" / "learnings.md").read_text(encoding="utf-8").splitlines()
                        if l.startswith("- "))
        segs.append(f"{know} knowledge · {learn} learnings")
    except Exception:
        segs.append("memory counts unavailable")
    if rows:
        last = rows[-1]
        segs.append(f"last write {last.get('kind', '?')} {_age(time.time() - last.get('epoch', time.time()))}")
    else:
        segs.append("no memory writes yet")
    return ("🧠 MEMORY: " + " · ".join(segs))[:180]


# ------------------------------------------------------------------ learnings refresh (hot layer)

REFRESH_TURNS = 20


def learnings_refresh(st, first_turn):
    path = K.MEM / "LEARNING" / "learnings.md"
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return None
    h = hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
    if first_turn or "learn_hash" not in st:  # sessionStart already injected them
        st.update(learn_hash=h, turns_since_learn=0)
        return None
    if h == st.get("learn_hash") and st.get("turns_since_learn", 0) < REFRESH_TURNS:
        st["turns_since_learn"] = st.get("turns_since_learn", 0) + 1
        return None
    st.update(learn_hash=h, turns_since_learn=0)
    tail = [l for l in text.splitlines() if l.startswith("- ")][-5:]
    if not tail:
        return None
    return "Recent learnings (refreshed; apply them):\n" + "\n".join("  " + short(l, 200) for l in tail)


# ------------------------------------------------------------------ task-scoped retrieval (BM25)

STOP = set("""the and for that this with you your are was were have has had not but all any can could would should
will just from into onto about what when where which who whom why how its it's our out off over under then than them
they there their these those been being does did doing done also more most some such only own same very too here
please make need want like get got use using used let lets tell show give know think thing things way well yes okay
kai one two now new file files code""".split())
TOKEN_RE = re.compile(r"[A-Za-z0-9_]{3,}")
MAX_DOCS = 600


def tokens(text):
    return [t for t in (w.lower() for w in TOKEN_RE.findall(text or "")) if t not in STOP and not t.isdigit()]


def _corpus_files():
    mem = K.MEM
    files = []
    try:
        files += sorted((mem / "KNOWLEDGE").glob("**/*.md"))
    except Exception:
        pass
    try:
        files += sorted((mem / "WORK").glob("*/ISA.md"))
    except Exception:
        pass
    learn = mem / "LEARNING" / "learnings.md"
    if learn.exists():
        files.append(learn)
    return files[:MAX_DOCS]


def build_index():
    files = _corpus_files()
    sig = []
    for f in files:
        try:
            s = f.stat()
            sig.append(f"{f}|{int(s.st_mtime)}|{s.st_size}")
        except Exception:
            continue
    signature = hashlib.sha1("\n".join(sig).encode("utf-8")).hexdigest()
    cache_path = K.STATE / "ground-index.json"
    cached = K.load_json(cache_path, {})
    if cached.get("signature") == signature:
        return cached
    docs = []
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")[:6000]
        except Exception:
            continue
        if f.name == "learnings.md":
            for line in text.splitlines():
                if line.startswith("- ") and len(docs) < MAX_DOCS:
                    tf = {}
                    for t in tokens(line):
                        tf[t] = tf.get(t, 0) + 1
                    if tf:
                        docs.append({"path": str(f), "title": "learning", "snippet": line[2:160], "tf": tf,
                                     "len": sum(tf.values())})
            continue
        title = f.parent.name if f.name == "ISA.md" else f.stem
        body_lines = [l for l in text.splitlines() if l.strip() and not l.startswith(("---", "#"))]
        tf = {}
        for t in tokens(title + " " + title + " " + text):
            tf[t] = tf.get(t, 0) + 1
        if tf:
            docs.append({"path": str(f), "title": title, "snippet": (body_lines[0] if body_lines else "")[:160],
                         "tf": tf, "len": sum(tf.values())})
        if len(docs) >= MAX_DOCS:
            break
    df = {}
    for d in docs:
        for t in d["tf"]:
            df[t] = df.get(t, 0) + 1
    idx = {"signature": signature, "docs": docs, "df": df,
           "avgdl": (sum(d["len"] for d in docs) / len(docs)) if docs else 1.0}
    K.save_json(cache_path, idx)
    return idx


def retrieve(prompt, k=3, k1=1.2, b=0.75):
    q = list(dict.fromkeys(tokens(prompt)))[:24]
    if len(q) < 2:
        return []
    idx = build_index()
    docs, df, n = idx.get("docs", []), idx.get("df", {}), max(1, len(idx.get("docs", [])))
    avgdl = idx.get("avgdl") or 1.0
    scored = []
    need = 2 if len(q) >= 3 else 1
    for d in docs:
        tf = d["tf"]
        hit = [t for t in q if t in tf]
        if len(hit) < need:
            continue
        s = 0.0
        for t in hit:
            idf = math.log(1 + (n - df.get(t, 0) + 0.5) / (df.get(t, 0) + 0.5))
            s += idf * (tf[t] * (k1 + 1)) / (tf[t] + k1 * (1 - b + b * d["len"] / avgdl))
        if s >= 2.0:
            scored.append((s, d))
    scored.sort(key=lambda x: -x[0])
    return [d for _, d in scored[:k]]


def ground_block(prompt):
    if len(prompt.strip()) < 15 or prompt.strip().startswith(("/", "<")):
        return None
    try:
        hits = retrieve(prompt)
    except Exception:
        return None
    if not hits:
        return None
    lines = ["Possibly relevant Kai memory (read it if it applies; ignore if not):"]
    for d in hits:
        lines.append(f"  - {d['path']} [{d['title']}] {short(d['snippet'], 110)}")
    return "\n".join(lines)


# ------------------------------------------------------------------ prompt-time nudges

ROUTE_STOPWORDS = {"research", "analyze", "analysis", "network", "profile", "metrics", "calendar", "schedule",
                   "upgrade", "extract", "develop", "improve", "content", "monitor", "opinion", "reminder",
                   "comment", "summary", "publish", "deploy", "search", "review", "install", "update", "create",
                   "archive", "projects", "critique", "knowledge", "remember", "design", "decide", "explain"}
ROUTE_MAX_MATCHES = 6
ROUTE_COOLDOWN = 3600
NUDGE_COOLDOWN = 300


def parse_use_when(desc):
    m = re.search(r"\buse (?:it )?when\b(.*?)(?:\bnot for\b|\bdo not use\b|$)", desc, re.I | re.S)
    if not m:
        return []
    clause = re.sub(r"\b(the user|someone|they|you)\s+(says?|asks?|wants?|mentions?|needs?)( to| for)?\b", ",",
                    m.group(1), flags=re.I)
    out = []
    for part in re.split(r",|;|\bor\b|\.", clause):
        p = re.sub(r"\s+", " ", part).strip(" '\"`:()").lower()
        if 6 <= len(p) <= 60:
            out.append(p)
    return out


def skill_index():
    skills_dir = Path(K.COPILOT_HOME) / "skills"
    cache_path = K.STATE / "skill-index.json"
    cached = K.load_json(cache_path, {})
    newest = 0.0
    files = []
    try:
        for f in skills_dir.glob("*/SKILL.md"):
            files.append(f)
            newest = max(newest, f.stat().st_mtime)
    except Exception:
        return {"entries": []}
    if cached.get("built", 0) >= newest and cached.get("count") == len(files):
        return cached
    entries = []
    for f in files:
        try:
            head = f.read_text(encoding="utf-8", errors="replace")[:4096]
        except Exception:
            continue
        fm = re.match(r"^---\s*\n(.*?)\n---", head, re.S)
        if not fm:
            continue
        name = re.search(r"^name:\s*(.+)$", fm.group(1), re.M)
        desc = re.search(r"^description:\s*(.+?)(?=^\S[^:\n]*:|\Z)", fm.group(1), re.M | re.S)
        if not desc:
            continue
        phrases = parse_use_when(desc.group(1))
        if phrases:
            entries.append({"skill": (name.group(1).strip().strip("'\"") if name else f.parent.name),
                            "phrases": phrases})
    idx = {"built": time.time(), "count": len(files), "entries": entries}
    K.save_json(cache_path, idx)
    return idx


def match_skills(prompt, index):
    p = prompt.lower()
    hits = []
    for e in index.get("entries", []):
        best = None
        for ph in e.get("phrases", []):
            if " " in ph:
                ok = len(ph) >= 7 and ph in p
            else:
                ok = len(ph) >= 6 and ph not in ROUTE_STOPWORDS and re.search(
                    r"(?<![\w])" + re.escape(ph) + r"(?![\w])", p) is not None
            if ok and (best is None or len(ph) > len(best)):
                best = ph
        if best:
            hits.append((e["skill"], best))
    if not hits or len(hits) > ROUTE_MAX_MATCHES:
        return []
    return sorted(hits, key=lambda h: -len(h[1]))[:3]


DEPTH_PHRASES = ["think deeply", "think hard", "think harder", "go deep", "be thorough", "ultrathink", "dig deep",
                 "thorough analysis", "thoroughly analyze", "thoroughly analyse", "deep analysis", "deep dive",
                 "deeply look"]


def match_depth(prompt):
    if len(prompt) > 1500 or "```" in prompt:
        return None
    head = prompt[:200].lower()
    for ph in DEPTH_PHRASES:
        if re.search(r"\b" + re.escape(ph) + r"\b", head):
            return ph
    return None


DESIGN_VERBS = ["separate", "redesign", "restructure", "rearchitect", "re-architect", "architect", "rework",
                "rebuild", "from scratch", "design", "plan out", "lay out", "think through", "build out",
                "stand up", "introduce", "split"]
AUTHORITY_NOUNS = ["security", "auth", "authentication", "authorization", "permission", "access control",
                   "privilege", "admin", "rbac", "role model", "isolation", "boundary", "multi-tenant",
                   "multitenant", "tenancy", "architecture", "trust model", "threat model", "tenant",
                   "provisioning", "credential"]
DESIGN_PHRASES = ["security standpoint", "security boundary", "auth boundary", "authority model", "permission model",
                  "access control", "threat model", "trust boundary", "privilege escalation",
                  "security architecture", "tenant isolation"]


def match_design(prompt):
    if len(prompt) > 4000 or "```" in prompt:
        return None
    p = prompt.lower()
    for ph in DESIGN_PHRASES:
        if ph in p:
            return ph
    verb = next((v for v in DESIGN_VERBS if re.search(r"\b" + re.escape(v) + r"\b", p)), None)
    if not verb:
        return None
    noun = next((n for n in AUTHORITY_NOUNS if re.search(r"\b" + re.escape(n) + r"\b", p)), None)
    return f"{verb} + {noun}" if noun else None


DIRECTIVE_PATTERNS = [re.compile(p, re.I) for p in (
    r"\bfrom now on\b", r"\bin the future\b", r"\bgoing forward\b", r"\bnew rule\b", r"^rule:",
    r"\bkai should (always|never|not)\b",
    r"\b(always|never) (do|use|include|make|add|put|run|write|call|show|keep|remember to)\b")]


def match_directive(prompt):
    t = prompt.strip()
    if len(t) < 15 or t.startswith("/"):
        return None
    return t if any(p.search(t.replace("’", "'")) for p in DIRECTIVE_PATTERNS) else None


def active_isa(sid):
    core = K.load_json(K.session_state(sid), {})
    for p in reversed(core.get("isas") or []):
        info = K.parse_isa(p)
        if info and info["frontmatter"].get("phase", "") != "complete":
            return info
    return None


def prompt_nudges(sid, st, prompt):
    out = []
    p = prompt.strip()
    if not p or p.startswith("<"):
        return out
    if not p.startswith("/") and len(p) >= 15:
        try:
            matches = [m for m in match_skills(p, skill_index()) if _cooled(st, f"route:{m[0]}", ROUTE_COOLDOWN)]
        except Exception:
            matches = []
        if matches:
            for m in matches:
                st.setdefault("nudges", {})[f"route:{m[0]}"] = time.time()
            _fire(st, "route", "This prompt matches the purpose of " + ", ".join(f"/{m[0]}" for m in matches)
                  + ". If the work lands there, invoke the skill instead of improvising.", out)
    isa = active_isa(sid)
    ph = match_depth(p)
    if ph and not isa and _cooled(st, "depth", NUDGE_COOLDOWN):
        _fire(st, "depth", f"The user asked for depth (\"{ph}\"). That outranks your own estimate: treat this as "
              "Algorithm work. Write done down as an ISA and name what the task earns (skills, @kai-researcher, "
              "verification), or state why inline is enough.", out)
    dc = match_design(p)
    if dc and _cooled(st, "design", NUDGE_COOLDOWN):
        _fire(st, "design", f"This reads as design-class work ({dc}). Design it explicitly before building: state "
              "the boundary and threat model in the ISA, consider @kai-architect for the design pass, and get "
              "@kai-reviewer's independent second look before calling it done.", out)
    d = match_directive(p)
    if d and _cooled(st, "directive", 60):
        _fire(st, "directive", f"That reads as a standing rule (\"{short(d, 80)}\"). Persist it now: add it under "
              "`## Your rules` in ~/.copilot/copilot-instructions.md (or a hook/skill if it needs enforcement), "
              "and say where you put it.", out, prefix="📌 RULE: ")
    return out


# ------------------------------------------------------------------ the per-turn block

def health_nag():
    rep = K.load_json(K.STATE / "memory-health.json", {})
    if rep.get("overall") != "critical":
        return None
    msgs = [f.get("message", "") for f in rep.get("findings", []) if f.get("severity") == "critical"][:3]
    return ("🩺 MEMORY HEALTH: CRITICAL — " + " · ".join(msgs) +
            f". Surface this line verbatim in your reply. Check: python \"{Path(K.KAI_HOME) / 'bin' / 'kai.py'}\" doctor")


def review_due(sid):
    f = K.STATE / "ext" / f"{_safe(sid)}.review-due"
    if not f.exists():
        return None
    try:
        f.unlink()
    except Exception:
        pass
    return ("🧠 MEMORY REVIEW due (8+ turns since the last one): before you finish this turn, check whether this "
            "session revealed a durable fact, preference or lesson. If it did, save it (`kai.py memory add` / "
            "`kai.py learn`). Keep facts, drop task progress. Skip silently if nothing qualifies.")


BLOCK_CAP = 3500


def build_turn_block(sid, st, prompt):
    first = not st.get("turn_blocks")
    st["turn_blocks"] = st.get("turn_blocks", 0) + 1
    parts = []
    for fn in (health_nag,):
        line = fn()
        if line:
            parts.append(line)
    try:
        import datetime as _dt
        parts.append("Now: " + _dt.datetime.now().astimezone().strftime("%A %Y-%m-%d %H:%M %Z"))
    except Exception:
        pass
    parts.append(contract_line(prompt, last_response(sid)))
    ml = memory_line(sid, st, first)
    if ml:
        parts.append(ml + "\n(Render this 🧠 MEMORY line verbatim once in your reply, just above the 🗣️ Kai: closer.)")
    rv = review_due(sid)
    if rv:
        parts.append(rv)
    lr = learnings_refresh(st, first)
    if lr:
        parts.append(lr)
    gb = ground_block(prompt)
    if gb:
        parts.append(gb)
    parts += prompt_nudges(sid, st, prompt)
    body = "\n".join(parts)
    if len(body) > BLOCK_CAP:
        body = body[: BLOCK_CAP - 1] + "…"
    return "<kai-turn-context>\n" + body + "\n</kai-turn-context>"


def touch_heartbeat():
    try:
        hb = K.STATE / "turn-heartbeat"
        hb.parent.mkdir(parents=True, exist_ok=True)
        hb.write_text(K.now_iso(), encoding="utf-8")
    except Exception:
        pass


def on_prompt_submitted(evt):
    sid = evt.get("sessionId", "")
    st = _load(sid)
    st["turn"] = st.get("turn", 0) + 1
    st["prompt"] = (evt.get("prompt") or "")[:2000]
    st["fallback_pending"] = True
    _save(sid, st)
    return None


def on_prompt_transformed(evt):
    sid = evt.get("sessionId", "")
    touch_heartbeat()
    st = _load(sid)
    st["upt_seen"] = True
    st["fallback_pending"] = False
    prompt = evt.get("prompt") or st.get("prompt") or ""
    base = evt.get("transformedPrompt")
    if not isinstance(base, str) or not base.strip():
        base = prompt
    if not base.strip():
        _save(sid, st)
        return None
    try:
        block = build_turn_block(sid, st, prompt)
    finally:
        _save(sid, st)
    if not block:
        return None
    return {"modifiedTransformedPrompt": base + "\n\n" + block}


# ------------------------------------------------------------------ postToolUse observers

BUILD_TOOLS = ("apply_patch", "edit", "create", "write", "str_replace", "multiedit", "notebook")
DISPATCH_TOOLS = ("task", "agent", "subagent")
EXEC_THRESHOLD = 10
SWEEP_THRESHOLD = 20
STALE_ISA_THRESHOLD = 15
DESTRUCTIVE_CLOUD_RE = re.compile(
    r"\bterraform\s+(destroy|apply\s+[^|;&]*-destroy)\b|\bpulumi\s+destroy\b|"
    r"\baz\s+(?:[a-z][\w.-]*\s+)*?(?:delete|purge|remove-record)(?=\s|$)|\bgcloud\s+dns\s+record-sets\s+(?:transaction\s+)?remove\b|\bremove-az\w*\b|\baws\s+\S+\s+(delete-\S+|rb|terminate-instances)\b|"
    r"\bgcloud\s+[^|;&]*\bdelete\b|\bkubectl\s+delete\b|\bhelm\s+(uninstall|delete)\b|\bwrangler\s+[^|;&]*\bdelete\b|"
    r"\bgh\s+repo\s+delete\b|\bdoctl\s+[^|;&]*\bdelete\b|\b-X\s*DELETE\b", re.I)


def destructive_cloud(cmd):
    """The preToolUse guard's segment-aware detector (quoted text, heredocs and grep patterns never
    match), so the ask before and this nudge after fire on the same commands; the regex is the
    fallback when guards cannot load."""
    try:
        import guards
        return guards.destructive_infra(cmd) is not None
    except Exception:
        return bool(DESTRUCTIVE_CLOUD_RE.search(cmd or ""))


DESTRUCTIVE_NUDGE = ("A destructive cloud/infra operation just ran. Before anything closes on it: (1) what did that "
                     "resource own (DNS records, routes, domains, bindings, volumes)? (2) Re-list from the provider "
                     "after the op, not through a cache. (3) Does the flow it served still work at its baseline?")


def _is(name, kinds):
    n = (name or "").lower()
    return any(n == k or n.startswith(k) for k in kinds)


def _shell_cmd(tool, args):
    n = (tool or "").lower()
    if any(k in n for k in ("shell", "powershell", "bash", "terminal", "command", "exec")):
        return str(args.get("command") or args.get("cmd") or args.get("script") or args.get("_raw") or "")
    return ""


def loop_watch(st, tool, args, failed):
    """Repeat-in-window, a-b-a-b oscillation, hammering. Core already covers 3 identical calls in a row."""
    sig = hashlib.sha1(f"{tool}:{K.args_text(args)}".encode("utf-8")).hexdigest()[:16]
    win = (st.get("window") or [])[-19:] + [{"sig": sig, "tool": tool, "failed": bool(failed)}]
    st["window"] = win
    st["seq"] = st.get("seq", 0) + 1
    alerted = st.setdefault("alerted", [])
    found = None
    if len(win) >= 4:
        a, b = win[-4]["sig"], win[-3]["sig"]
        if a != b and [w["sig"] for w in win[-4:]] == [a, b, a, b]:
            found = (f"osc:{a}|{b}", f"🔁 LOOP: flip-flopping between {win[-4]['tool']} and {win[-3]['tool']} "
                     "(a-b-a-b) without progress. Step back and change approach.")
    if not found:
        same = [w for w in win if w["sig"] == sig]
        consecutive = len(win) >= 3 and len({w["sig"] for w in win[-3:]}) == 1
        if len(same) >= 3 and not consecutive:
            found = (f"exact:{sig}", f"🔁 LOOP: {tool} has run {len(same)} times with the same input this session "
                     "without progress. Use what you already learned or try something different.")
    if not found:
        by = {}
        for w in win[-8:]:
            by.setdefault(w["tool"], []).append(w)
        for t, ws in by.items():
            nf = sum(1 for w in ws if w["failed"])
            if len(ws) >= 5 and nf >= 3:
                found = (f"hammer:{t}:{st['seq'] // 8}", f"🔁 LOOP: {t} ran {len(ws)} times in quick succession and "
                         f"{nf} failed. Diagnose the failure before retrying.")
                break
    if not found or found[0] in alerted:
        return None
    if st.get("last_alert") and st["seq"] - st["last_alert"] < 4:
        return None
    alerted.append(found[0])
    st["alerted"] = alerted[-50:]
    st["last_alert"] = st["seq"]
    return found[1]


BIG_EDIT_LINES = 200
SESSION_BAND = 1000
DEP_JSON_LINE = re.compile(r"^\s*\"[^\"]+\"\s*:\s*\"[\^~>=<]*\d")
DEP_REQ_LINE = re.compile(r"^\s*[A-Za-z0-9_.\-\[\]]+\s*([=<>!~]=?|$)")
DEP_CSPROJ_LINE = re.compile(r"<PackageReference\s+Include=", re.I)


def count_deps(path, added, removed):
    name = Path(str(path).replace("\\", "/")).name.lower()
    if name == "package.json":
        pat = DEP_JSON_LINE
    elif name.startswith("requirements") and name.endswith(".txt"):
        added = [l for l in added if l.strip() and not l.strip().startswith(("#", "-"))]
        pat = DEP_REQ_LINE
    elif name.endswith(".csproj") or name.endswith(".fsproj"):
        pat = DEP_CSPROJ_LINE
    else:
        return 0
    old = {l.strip() for l in removed if pat.search(l)}
    return sum(1 for l in added if pat.search(l) and l.strip() not in old)


def _lines(s):
    return len(s.splitlines()) if isinstance(s, str) and s else 0


def measure_write(tool, args):
    """(net_added_lines, new_deps, biggest_file) for a write-shaped tool call."""
    net = deps = 0
    target = ""
    sections = []
    for v in args.values():
        if isinstance(v, str) and "*** " in v:
            ms = list(re.finditer(r"^\*\*\*\s+(Add|Update|Delete)\s+File:\s*(.+?)\s*$", v, re.M))
            for i, m in enumerate(ms):
                end = ms[i + 1].start() if i + 1 < len(ms) else len(v)
                body = v[m.end():end].splitlines()
                add = [l[1:] for l in body if l.startswith("+") and not l.startswith("+++")]
                rem = [l[1:] for l in body if l.startswith("-") and not l.startswith("---")]
                sections.append((m.group(2), add, rem))
    if sections:
        for path, add, rem in sections:
            net += len(add) - len(rem)
            deps += count_deps(path, add, rem)
            target = target or path
        return net, deps, target
    path = args.get("path") or args.get("file_path") or args.get("filePath") or ""
    new = args.get("new_str") if "new_str" in args else args.get("new_string")
    old = args.get("old_str") if "old_str" in args else args.get("old_string")
    if isinstance(new, str):
        net = _lines(new) - _lines(old if isinstance(old, str) else "")
        deps = count_deps(path, new.splitlines(), (old or "").splitlines() if isinstance(old, str) else [])
        return net, deps, path
    content = args.get("file_text") if "file_text" in args else args.get("content")
    if isinstance(content, str):
        return _lines(content), count_deps(path, content.splitlines(), []), path
    return 0, 0, path


def ratchet(st, tool, args):
    if not _is(tool, BUILD_TOOLS):
        return None
    net, deps, target = measure_write(tool, args)
    r = st.setdefault("ratchet", {"cumulative": 0, "deps": 0, "band": 0})
    if net > 0:
        r["cumulative"] += net
    r["deps"] += deps
    notes = []
    if deps > 0:
        notes.append(f"added {deps} new {'dependency' if deps == 1 else 'dependencies'} ({r['deps']} this session); "
                     "a dependency is the most expensive complexity to walk back, so confirm it earns its keep")
    if net > BIG_EDIT_LINES:
        notes.append(f"one write added {net} net lines{(' to ' + Path(str(target)).name) if target else ''}; "
                     "a blob that large is worth a second look for something simpler")
    band = r["cumulative"] // SESSION_BAND
    if band > r["band"]:
        r["band"] = band
        notes.append(f"net growth this session crossed ~{band * SESSION_BAND} added lines; make sure it's deliberate")
    return ("📈 RATCHET: " + "; ".join(notes) + ".") if notes else None


def algo_watch(sid, st, tool, args):
    out = []
    if _is(tool, DISPATCH_TOOLS):
        st["build_since_dispatch"] = 0
        st["calls_since_dispatch"] = 0
    else:
        st["calls_since_dispatch"] = st.get("calls_since_dispatch", 0) + 1
        if _is(tool, BUILD_TOOLS):
            st["build_since_dispatch"] = st.get("build_since_dispatch", 0) + 1
        if st.get("build_since_dispatch", 0) >= EXEC_THRESHOLD and _cooled(st, "exec", NUDGE_COOLDOWN):
            st["build_since_dispatch"] = 0
            _fire(st, "exec", f"{EXEC_THRESHOLD}+ consecutive file edits with no delegation. Is this judgment work "
                  "that belongs inline, or an execution leg for @kai-engineer or a task subagent? Make it a decision, "
                  "not a default.", out)
        elif st.get("calls_since_dispatch", 0) >= SWEEP_THRESHOLD and _cooled(st, "sweep", NUDGE_COOLDOWN):
            st["calls_since_dispatch"] = 0
            _fire(st, "sweep", f"{SWEEP_THRESHOLD}+ consecutive inline tool calls, zero delegation. If a chunk is "
                  "mechanical (bulk reads, sweeps, migrations), hand it to a subagent with a clear brief; if it needs "
                  "your judgment, carry on.", out)
    wrote_isa = any(str(p).replace("\\", "/").lower().endswith("isa.md") for p in K.written_paths(tool, args))
    st["since_isa_edit"] = 0 if wrote_isa else st.get("since_isa_edit", 0) + 1
    if st["since_isa_edit"] >= STALE_ISA_THRESHOLD and _cooled(st, "stale-isa", NUDGE_COOLDOWN):
        if active_isa(sid):
            st["since_isa_edit"] = 0
            _fire(st, "stale-isa", f"{STALE_ISA_THRESHOLD}+ tool calls with zero ISA edits. Is the ISA still the true "
                  "shape of done, or has the work learned something it hasn't?", out)
    cmd = _shell_cmd(tool, args)
    if cmd and destructive_cloud(cmd):
        key = "destructive:" + hashlib.sha1(cmd.strip().lower().encode("utf-8")).hexdigest()[:10]
        if _cooled(st, key, 600):
            _fire(st, key, DESTRUCTIVE_NUDGE, out)
    return out


# ------------------------------------------------------------------ config eval advisory (ConfigEvalFire)

# Kai's behavior-shaping config: the constitution, custom agents, hook code and RULES (plus the
# Algorithm doctrine). Paths are matched on forward-slash lowercase form; the `kai/` or `.copilot/`
# component keeps a project's own src/hooks/ or .github/agents/ from matching.
CONFIG_SURFACES = (
    ("constitution", re.compile(r"(?:^|/)(?:\.copilot|kai)/copilot-instructions\.md$")),
    ("agents", re.compile(r"(?:^|/)(?:\.copilot|kai)/agents/[^/]+\.(?:agent\.)?md$")),
    ("hooks", re.compile(r"(?:^|/)kai/hooks/(?!tests/)(?:[^/]+/)*[^/]+\.py$")),
    ("hooks", re.compile(r"(?:^|/)(?:\.copilot|kai)/hooks/[^/]+\.json$")),
    ("RULES", re.compile(r"(?:^|/)kai/rules/[^/]+\.md$")),
    ("doctrine", re.compile(r"(?:^|/)kai/algorithm\.md$")),
)
CONFIG_SHELL_WRITE = re.compile(
    r"set-content|add-content|out-file|\bsc\s|\bac\s|writealltext|write_text|copy-item|move-item|\bcp\s|\bmv\s|"
    r"\bcopy\s|\bmove\s|\btee\b|sed\s+-i|(?<![0-9&-])>{1,2}", re.I)
CONFIG_PATH_TOKEN = re.compile(r"[^\s\"'|;&<>]*(?:copilot-instructions\.md|agents[\\/][^\s\"'|;&<>]+|"
                               r"kai[\\/](?:hooks|rules)[\\/][^\s\"'|;&<>]+|algorithm\.md)", re.I)
CONFIG_EVAL_COOLDOWN = 1800


def _config_surface(path):
    p = str(path or "").replace("\\", "/").lower()
    try:
        home = str(K.COPILOT_HOME).replace("\\", "/").lower().rstrip("/")
        if home and p.startswith(home + "/"):
            p = ".copilot/" + p[len(home) + 1:]
    except Exception:
        pass
    if p.startswith("~/.copilot/") or p.startswith("$env:userprofile/.copilot/") or p.startswith("%userprofile%/.copilot/"):
        p = ".copilot/" + p.split("/.copilot/", 1)[1]
    if "/__pycache__/" in p:
        return None
    for name, rx in CONFIG_SURFACES:
        if rx.search(p):
            return name
    return None


def config_targets(tool, args):
    """(surface, filename) pairs for Kai config files this tool call wrote."""
    paths = list(K.written_paths(tool, args))
    cmd = _shell_cmd(tool, args)
    if cmd and CONFIG_SHELL_WRITE.search(cmd):
        paths += CONFIG_PATH_TOKEN.findall(cmd)
    out = []
    for p in paths:
        s = _config_surface(p)
        if s and (s, p) not in out:
            out.append((s, p))
    return out


def config_eval_watch(st, tool, args):
    if os.environ.get("KAI_CONFIG_EVAL_NUDGE", "1") == "0" or os.environ.get("KAI_EVAL") == "1":
        return []
    hits = config_targets(tool, args)
    if not hits:
        return []
    surfaces = sorted({s for s, _ in hits})
    key = "config-eval:" + ",".join(surfaces)
    if not _cooled(st, key, CONFIG_EVAL_COOLDOWN):
        return []
    names = ", ".join(sorted({Path(str(p).replace("\\", "/")).name for _, p in hits})[:4])
    out = []
    _fire(st, key, f"you edited Kai's {'/'.join(surfaces)} ({names}). That changes behavior for every session. Before "
          "calling it done, run the regression suites: /evals (`python ~/.copilot/skills/evals/tools/evals.py list`, "
          "then `evals.py run -s <suite>` for each regression suite). Advisory: Kai never spawns that run itself.",
          out, prefix="🧪 EVAL-NUDGE: ")
    return out


def on_post_tool(evt, failed=False):
    sid = evt.get("sessionId", "")
    tool = evt.get("toolName", "") or ""
    args = K.tool_args(evt)
    st = _load(sid)
    out = []
    lp = loop_watch(st, tool, args, failed)
    if lp:
        out.append(lp)
    if not failed:
        rt = ratchet(st, tool, args)
        if rt:
            out.append(rt)
        out += algo_watch(sid, st, tool, args)
        try:
            out += config_eval_watch(st, tool, args)
        except Exception:
            pass
    if st.get("fallback_pending") and not st.get("upt_seen"):
        st["fallback_pending"] = False
        out.append(contract_line(st.get("prompt", ""), last_response(sid)))
    _save(sid, st)
    if not out:
        return None
    return {"additionalContext": "\n".join(out)}


# ------------------------------------------------------------------ subagentStart

SUBAGENT_RULES = (
    "Kai subagent rules: return raw findings to the caller, with no Kai banner and no closer. Every claim needs tool "
    "evidence gathered in this run (command output, file read-back, diff, HTTP response); write \"verified\" or "
    "\"not verified\", never \"should work\". Stay inside the scope you were given and report blockers instead of "
    "widening it. Never put secrets in output; write [REDACTED].")


def on_subagent_start(evt):
    return {"additionalContext": SUBAGENT_RULES}


def on_session_end(evt):
    try:
        ext_state_path(evt.get("sessionId", "")).unlink()
    except Exception:
        pass
    return None


HANDLERS = {
    "userPromptSubmitted": on_prompt_submitted,
    "userPromptTransformed": on_prompt_transformed,
    "postToolUse": on_post_tool,
    "postToolUseFailure": lambda e: on_post_tool(e, failed=True),
    "subagentStart": on_subagent_start,
    "sessionEnd": on_session_end,
}
