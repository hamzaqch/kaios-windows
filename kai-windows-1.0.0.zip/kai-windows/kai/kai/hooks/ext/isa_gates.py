"""Kai ISA gates: keep the ISA (the run's state of record) honest and current.

Gates and notices, all fail-open and capped so they can never loop:

  preToolUse  STALE-WRITE GUARD   deny a whole-file overwrite of an ISA whose on-disk
                                  content changed since this session last saw it
                                  (another session or the user edited it; overwriting
                                  would silently revert their closed claims). Edits that
                                  patch against current disk content are never guarded.
  postToolUse VIEW RECORDING +    record what this session believes each ISA contains;
              ISC CHECKPOINT      diff claim states on every ISA write and append each
                                  claim flip ([ ]->[x], reopen, drop) to
                                  MEMORY/STATE/isc-checkpoints.jsonl. A reopen gets a
                                  visible warning, since that is how a stale write shows up.
  agentStop   CLOSE GATE          completion claim + an active ISA (phase != complete)
                                  that has gone >= N tool calls without an edit and was not
                                  touched this turn -> block once per ISA per session.
              FOLD GATE           this turn changed live state (deploy, push, publish,
                                  migration, --apply) or the reply reports a discovery
                                  (root cause, "turns out", unsupported, dead end) on an
                                  active run, and the ISA was not updated -> block (capped).
              STRUCTURE GATE      an ISA set to phase: complete this turn fails the mechanical
                                  gate (open claims, unresolved fog, plus every hard finding
                                  of `isa_tool.py check`) -> block (capped).

postToolUse notices on every ISA write (each once per transition, never per message):
  ASCENT STRIP     the derived ascent state changed -> inject
                   `════ Kai | Algorithm | <icon> <Label> ════` (derived through
                   PHASE_TO_ASCENT / derive_ascent() in isa_tool.py, never hand-listed here).
  COMPLETE CHECK   phase: complete was just written and the mechanical gate fails -> list
                   the failures now (the agentStop structure gate blocks on the same list).
  REOPEN           a body edit landed on a phase: complete ISA (frozen: true opts out) ->
                   tell the model to rewind phase: to learn and bump iteration. The model
                   writes the rewind; the hook never edits the ISA.
  QUALITY CLAIM    an open claim with behavioral/quality-shaped wording and no probe ->
                   ask whether it is the multi-sample class (an eval suite closes it) or
                   needs a direct probe. Once per claim ID per ISA.

The verification gate outranks these: if it is about to block, the ISA gates stand
down so the recovery turn gets one clear instruction.

Env: KAI_ISA_GATES=0 disables all agentStop gates; KAI_ISA_CLOSE_GATE=0,
KAI_ISA_FOLD_GATE=0, KAI_ISA_STRUCTURE_GATE=0, KAI_ISA_STALE_GUARD=0, KAI_ISC_CHECKPOINT=0,
KAI_ISA_STRIP=0, KAI_ISA_COMPLETE_CHECK=0, KAI_ISA_REOPEN=0, KAI_ISA_QUALITY_NUDGE=0
disable one. KAI_ISA_CLOSE_THRESHOLD (default 10) sets the close-gate staleness.
"""
import hashlib
import importlib.util
import os
import re
import sys
import time
from pathlib import Path

_HERE = Path(__file__).resolve().parent
for _p in (str(_HERE.parent), str(_HERE)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import kai_hook as K  # noqa: E402
import verification_gate as VG  # noqa: E402

VIEW_DIR_NAME = "isa_views"
SNAP_DIR_NAME = "isc_snapshots"
CHECKPOINT_LOG = "isc-checkpoints.jsonl"
PRUNE_AFTER_S = 7 * 24 * 3600


def _off(name):
    return os.environ.get(name, "1").strip().lower() in ("0", "off", "false", "no")


def _int_env(name, default):
    try:
        return int(os.environ.get(name, str(default)))
    except ValueError:
        return default


def _sha(text):
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def _read(path):
    try:
        return Path(path).read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None


def _safe_name(s):
    return re.sub(r"[^A-Za-z0-9_-]", "_", s or "unknown")[:120]


# ============================================================ claim parsing

CLAIM_LINE_RE = re.compile(r"^\s*-\s*\[([ xX~-])\]\s*(~~)?\s*([A-Z]+\d+)\b(~~)?[\s.:)—-]*(.*)$", re.M)


def claim_states(text):
    """{id: (state, text)} where state is open|closed|dropped."""
    out = {}
    for box, s1, cid, s2, rest in CLAIM_LINE_RE.findall(text or ""):
        if s1 or s2 or box in "~-" or re.match(r"\s*dropped\b", rest, re.I):
            state = "dropped"
        elif box in "xX":
            state = "closed"
        else:
            state = "open"
        out[cid] = (state, rest.strip()[:160])
    return out


def frontmatter(text):
    fm = {}
    m = re.match(r"^﻿?---\s*\n(.*?)\n---", text or "", re.S)
    if m:
        for line in m.group(1).splitlines():
            if ":" in line and not line.startswith((" ", "\t")):
                k, v = line.split(":", 1)
                v = re.sub(r"\s+#.*$", "", v.strip())
                fm[k.strip()] = v.strip().strip('"').strip("'")
    return fm


def section(text, heading):
    m = re.search(r"^##\s+" + re.escape(heading) + r"\b[^\n]*\n(.*?)(?=^##\s|\Z)", text or "", re.M | re.S)
    return m.group(1) if m else None


# ============================================================ view store (stale-write guard)

def _view_file(sid):
    return K.STATE / VIEW_DIR_NAME / f"{_safe_name(sid)}.json"


def _prune(folder):
    try:
        now = time.time()
        for f in folder.glob("*.json"):
            try:
                if now - f.stat().st_mtime > PRUNE_AFTER_S:
                    f.unlink()
            except Exception:
                pass
    except Exception:
        pass


def record_view(sid, path):
    """Remember the hash of an ISA as this session now knows it. Best effort."""
    try:
        if not sid or not path or not is_isa(path) or not os.path.isfile(path):
            return
        text = _read(path)
        if text is None:
            return
        vf = _view_file(sid)
        if not vf.exists():
            _prune(vf.parent)
        data = K.load_json(vf, {})
        views = data.get("views") if isinstance(data.get("views"), dict) else {}
        views[VG.norm_path(path)] = _sha(text)
        K.save_json(vf, {"sessionId": sid, "views": views, "updated": K.now_iso()})
    except Exception:
        pass


def recorded_view(sid, path):
    data = K.load_json(_view_file(sid), {})
    views = data.get("views") if isinstance(data.get("views"), dict) else {}
    return views.get(VG.norm_path(path))


def is_isa(p):
    return VG.is_isa_path(p)


# Whole-file shell writes: a redirect (not append), Set-Content / Out-File without -Append,
# WriteAllText, Python write_text / open(...,'w'), tee without -a, copy/move onto the path.
SHELL_WHOLE_WRITE_RE = re.compile(
    r"((^|[^-=2&>])>(?!>)\s*[\"']?(?P<redir>[^\s\"'|&;]+))|set-content|\bsc\s|out-file(?![^|;]*-append)|"
    r"writealltext|write_text|open\([^)]*['\"]w['\"]|\btee\b(?!\s+-a)|copy-item|move-item|\bcp\s|\bmv\s|\bcopy\s|\bmove\s",
    re.I)
COPY_MOVE_RE = re.compile(r"(copy-item|move-item|\bcp\s|\bmv\s|\bcopy\s|\bmove\s)", re.I)
SHELL_INPLACE_RE = re.compile(
    r"sed\s+-i\b|perl\s+-i\b|add-content|\bac\s|>>\s*[\"']?[^\s\"'|&;]*isa\.md|kai\.py\s+isa\s+new|git\s+add\b", re.I)
SHELL_READ_RE = re.compile(
    r"(\bcat\b|\btype\b|\bgc\b|get-content|\bmore\b|\bless\b|\bhead\b|\btail\b|\bbat\b|select-string|findstr|"
    r"\bgrep\b|\brg\b|sed\s+-n|read_text|\.read\(\))", re.I)


PIPE_WRITER_RE = re.compile(r"(set-content|\bsc(?=\s)|out-file|\btee\b|writealltext)", re.I)
PY_WRITE_TEXT_RE = re.compile(r"""([^\s"'`()]*isa\.md)["']\s*\)\s*\.write_text""", re.I)
PY_OPEN_W_RE = re.compile(r"""open\(\s*[^)]*?([^\s"'`()]*isa\.md)["']\s*,\s*(?:mode\s*=\s*)?["']w""", re.I)


def shell_whole_write_targets(cmd, cwd):
    """ISA paths a shell command would overwrite whole.

    Only the write TARGET counts: an ISA that is merely read in the same command
    (`Get-Content ISA.md | Set-Content copy.txt`, `cat ISA.md > notes.txt`,
    `cp ISA.md backup.md`) is never treated as overwritten.
    """
    out = []
    for seg in re.split(r"&&|\|\||;|\n", cmd or ""):
        if not VG.shell_isa_paths(seg) or not SHELL_WHOLE_WRITE_RE.search(seg):
            continue
        # Python one-liners: only the path the write is bound to.
        for rx in (PY_WRITE_TEXT_RE, PY_OPEN_W_RE):
            out += [p for p in rx.findall(seg) if is_isa(p)]
        for stage in seg.split("|"):
            if not VG.shell_isa_paths(stage):
                continue
            if COPY_MOVE_RE.search(stage) and not PIPE_WRITER_RE.search(stage) and ">" not in stage:
                # copy/move: only the destination (last path token) is overwritten
                toks = [t.strip("\"'") for t in re.split(r"\s+", stage.strip()) if t and not t.startswith("-")]
                if len(toks) >= 3 and is_isa(toks[-1]):
                    out.append(toks[-1])
                continue
            m = re.search(r"(^|[^-=2&>])>(?!>)\s*[\"']?([^\s\"'|&;]+)", stage)
            if m and is_isa(m.group(2)):
                out.append(m.group(2))
            w = PIPE_WRITER_RE.search(stage)
            if w:
                kw = w.group(1).lower()
                if kw == "out-file" and re.search(r"-append\b", stage, re.I):
                    continue
                if kw == "tee" and re.search(r"\btee\s+(-a\b|--append\b)", stage, re.I):
                    continue
                out += VG.shell_isa_paths(stage[w.end():])
    return list(dict.fromkeys(VG.norm_path(p, cwd) for p in out))


def whole_write_targets(evt):
    """Absolute ISA paths this tool call would replace whole (not a patch against current content)."""
    name = (evt.get("toolName") or "").lower()
    args = K.tool_args(evt)
    cwd = evt.get("cwd")
    cmd = args.get("command") if isinstance(args.get("command"), str) else None
    if cmd is not None and VG.SHELL_NAME_RE.search(name):
        return shell_whole_write_targets(cmd, cwd)
    out = []
    for p, op in VG.write_targets(name, args):
        if is_isa(p) and op in ("add", "delete", "whole"):
            out.append(VG.norm_path(p, cwd))
    return out


def deny_message(path, disk, mine):
    return ("Kai stale-write guard: BLOCKED a whole-file overwrite of an ISA that changed on disk after you last saw it.\n"
            f"  {path}\n"
            f"  on disk now: {disk[:12]}   your view: {mine[:12]}\n"
            "Overwriting it would silently discard those changes (usually someone's closed claims and evidence). "
            "Recover: (1) view the file to pick up the current content, (2) apply your change as a patch/edit against "
            "the current text, which keeps the other changes. Nothing is locked; re-reading clears this.")


def _tool_calls(evt):
    """preToolUse carries toolName/toolArgs; accept a batched toolCalls list defensively."""
    calls = evt.get("toolCalls")
    if isinstance(calls, list) and calls and not evt.get("toolName"):
        out = []
        for c in calls:
            if isinstance(c, dict):
                sub = dict(evt)
                sub["toolName"] = c.get("name") or c.get("toolName") or ""
                sub["toolArgs"] = c.get("args") if "args" in c else c.get("toolArgs")
                out.append(sub)
        return out
    return [evt]


def on_pre_tool(evt):
    try:
        if _off("KAI_ISA_STALE_GUARD"):
            return None
        sid = evt.get("sessionId", "")
        if not sid:
            return None
        targets = [p for call in _tool_calls(evt) for p in whole_write_targets(call)]
        for p in targets:
            if not os.path.isfile(p):
                continue  # creating it: nothing to lose
            mine = recorded_view(sid, p)
            if not mine:
                continue  # never observed here: fail open
            disk_text = _read(p)
            if disk_text is None:
                continue
            disk = _sha(disk_text)
            if disk != mine:
                VG.gate_log({"gate": "isa-stale-write", "session": sid, "path": p, "decision": "deny"})
                return {"permissionDecision": "deny", "permissionDecisionReason": deny_message(p, disk, mine)}
        return None
    except Exception:
        return None


# ============================================================ postToolUse: views + checkpoints

def _snap_file(path):
    return K.STATE / SNAP_DIR_NAME / (hashlib.sha256(VG.norm_path(path).encode("utf-8")).hexdigest()[:24] + ".json")


def snapshot(path, assume_new=False, sid="", source="write"):
    """Diff current claim states against the last snapshot; return flips (and record them)."""
    text = _read(path)
    if text is None:
        return []
    cur = claim_states(text)
    sf = _snap_file(path)
    prev_data = K.load_json(sf, None)
    flips = []
    if prev_data is None and not assume_new:
        K.save_json(sf, {"path": str(path), "claims": {k: v[0] for k, v in cur.items()}, "updated": K.now_iso()})
        return []
    prev = (prev_data or {}).get("claims", {}) if prev_data else {}
    for cid, (state, desc) in cur.items():
        before = prev.get(cid, "new" if prev_data else "open")
        if before == "new" and state == "open":
            continue
        if before != state:
            flips.append({"id": cid, "from": before, "to": state, "text": desc})
    for cid, before in prev.items():
        if cid not in cur:
            flips.append({"id": cid, "from": before, "to": "removed", "text": ""})
    K.save_json(sf, {"path": str(path), "claims": {k: v[0] for k, v in cur.items()}, "updated": K.now_iso()})
    if flips:
        fm = frontmatter(text)
        for f in flips:
            K.append_jsonl(K.STATE / CHECKPOINT_LOG, {
                "ts": K.now_iso(), "session": sid, "isa": str(path), "slug": fm.get("slug") or Path(path).parent.name,
                "phase": fm.get("phase"), "source": source, **f})
    return flips


# ============================================================ isa_tool (the one derivation)

_ISA_TOOL = []


def _isa_tool():
    """Load skills/isa/Tools/isa_tool.py once (repo and installed layouts). None when absent."""
    if _ISA_TOOL:
        return _ISA_TOOL[0]
    mod = None
    for base in (_HERE.parents[2] / "skills", Path(K.COPILOT_HOME) / "skills"):
        f = base / "isa" / "Tools" / "isa_tool.py"
        if not f.is_file():
            continue
        try:
            spec = importlib.util.spec_from_file_location("kai_isa_tool", str(f))
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            if all(hasattr(m, a) for a in ("load", "check", "progress", "derive_ascent", "ascent_strip")):
                mod = m
                break
        except Exception:
            continue
    _ISA_TOOL.append(mod)
    return mod


def mechanical_failures(path, text):
    """(hard, advisory) for an ISA at phase: complete: claim/fog facts plus isa_tool check's hard findings."""
    it = _isa_tool()
    hard, adv = structural_violations(text, check_progress=it is None)
    if it is not None:
        try:
            findings, _sub = it.check(it.load(path))
            for sev, label, detail in findings:
                if sev != "hard" or label in ("at least one claim", "fog is empty at phase: complete"):
                    continue  # already reported above in claim/fog terms
                hard.append(f"{label} ({detail})" if detail else label)
        except Exception:
            pass
    return hard, adv


# ============================================================ postToolUse notices (meta per ISA)

META_DIR_NAME = "isa_meta"
QUALITY_RE = re.compile(
    r"\b(quality|tone|voice|natural(ly)?|readab(le|ility)|helpful(ness)?|coheren(t|ce)|fluen(t|cy)|engaging|"
    r"persuasive|on[\s-]brand|sounds?\s+(like|human|natural)|feels?\s+(like|natural|right)|hallucinat\w*|"
    r"relevan(t|ce)|faithful(ness)?|consistent(ly)?|reliabl[ey]|accura(te|cy)|good\s+(enough|answers?|output)|"
    r"better\s+than|user[\s-]friendly|intuitive|behaves?|regress(es|ion)?\s+in\s+behaviou?r)\b", re.I)


def _meta_file(path):
    return K.STATE / META_DIR_NAME / (hashlib.sha256(VG.norm_path(path).encode("utf-8")).hexdigest()[:24] + ".json")


def _body_sha(text):
    body = re.sub(r"^﻿?---\s*\n.*?\n---[^\n]*\n?", "", text or "", count=1, flags=re.S)
    return _sha(re.sub(r"[ \t]+\n", "\n", body.replace("\r\n", "\n")).strip())


def _derive(path):
    """(ascent_state, strip) through isa_tool's one table, or (None, None) when it is unavailable."""
    it = _isa_tool()
    if it is None:
        return None, None
    try:
        isa = it.load(path)
        closed, total = it.progress(isa)
        state = it.derive_ascent(isa["frontmatter"].get("phase", ""), closed, total, tracked=True, active=True)
        return state, it.ascent_strip(state)
    except Exception:
        return None, None


def _meta_now(path, text, prev):
    fm = frontmatter(text)
    state, _ = _derive(path)
    return {"path": str(path), "phase": (fm.get("phase") or "").lower(), "iteration": fm.get("iteration", ""),
            "body": _body_sha(text), "ascent": state if state is not None else (prev or {}).get("ascent"),
            "quality_nudged": (prev or {}).get("quality_nudged", []), "updated": K.now_iso()}


def observe_meta(path):
    """A read: learn the ISA's current state silently (no notices)."""
    try:
        text = _read(path)
        if text is None:
            return
        mf = _meta_file(path)
        K.save_json(mf, _meta_now(path, text, K.load_json(mf, None)))
    except Exception:
        pass


def _int_or(v, default):
    try:
        return int(str(v).strip())
    except Exception:
        return default


def unprobed_quality_claims(path):
    it = _isa_tool()
    if it is None:
        return []
    try:
        isa = it.load(path)
    except Exception:
        return []
    rows = {r["id"] for r in isa.get("rows", []) if r.get("id")}
    out = []
    for c in isa["claims"]:
        if c["dropped"] or c["checked"] or not c["leaf"] or c["inline_probe"] or c["id"] in rows:
            continue
        if QUALITY_RE.search(it.BACKTICK_RE.sub("", c["text"])):
            out.append(c["id"])
    return out


def write_notices(path):
    """Notices for one ISA write: ascent strip, complete check, reopen, quality claim. Updates meta."""
    text = _read(path)
    if text is None:
        return []
    mf = _meta_file(path)
    prev = K.load_json(mf, None) or {}
    cur = _meta_now(path, text, prev)
    fm = frontmatter(text)
    name = fm.get("slug") or Path(path).parent.name
    notes = []
    state, strip = _derive(path)
    was_complete = prev.get("phase") == "complete"
    now_complete = cur["phase"] == "complete"
    hard = []
    if now_complete and not was_complete and not _off("KAI_ISA_COMPLETE_CHECK"):
        hard, _adv = mechanical_failures(path, text)
    if hard:
        # A failing close is not a close: no Cairn strip, and meta keeps the prior phase so the next
        # write re-runs the check; the strip fires on the write that makes the ISA pass.
        cur["ascent"] = prev.get("ascent")
        cur["phase"] = prev.get("phase", "")
    elif strip and not _off("KAI_ISA_STRIP") and state != prev.get("ascent"):
        notes.append(strip + "  (echo this strip verbatim at the head of your next status note; once per transition)")
    if hard:
        notes.append(f"⚠️ ISA CHECK: {name} says phase: complete, but the mechanical gate fails:\n"
                     + "\n".join(f"  ✗ {h}" for h in hard[:8])
                     + "\n  Fix the ISA, or set phase: back to climbing if the work isn't done.")
    if (was_complete and prev.get("body") and prev["body"] != cur["body"] and not _off("KAI_ISA_REOPEN")
            and fm.get("frozen", "").lower() != "true"):
        nxt = max(_int_or(prev.get("iteration"), 1), 1) + 1
        if now_complete:
            notes.append(f"↩️ ISA REOPEN: a body edit landed on {name}, which is phase: complete. That is a reopen: "
                         f"rewind phase: to learn, set iteration: {nxt}, stamp resumed_at: <now> and "
                         "resumed_from_phase: complete. If this edit should not reopen it, set frozen: true.")
        elif _int_or(cur["iteration"], 1) < nxt:
            notes.append(f"↩️ ISA REOPEN: {name} left phase: complete. Also set iteration: {nxt} and stamp "
                         "resumed_at / resumed_from_phase: complete.")
    if not _off("KAI_ISA_QUALITY_NUDGE") and not now_complete:
        done = set(cur.get("quality_nudged") or [])
        fresh = [c for c in unprobed_quality_claims(path) if c not in done]
        if fresh:
            cur["quality_nudged"] = sorted(done | set(fresh))[-200:]
            verb = "reads like a behavioral or quality property" if len(fresh) == 1 else "read like behavioral or quality properties"
            notes.append(f"🧭 ALGO-NUDGE: {', '.join(fresh[:6])} in {name} {verb} "
                         "with no probe. Multi-sample class (one direct probe can't close it)? Then an eval suite "
                         "with pass^k is the falsifier (/evals), scaled to blast radius. Otherwise name the direct probe.")
    K.save_json(mf, cur)
    return notes


def _mark_isa_written(sid, path):
    """Shell writes are invisible to the core; reset its staleness counter and bind the ISA."""
    sp = K.session_state(sid)
    st = K.load_json(sp, {})
    st["since_isa"] = 0
    isas = st.setdefault("isas", [])
    if path not in isas and VG.norm_path(path) not in [VG.norm_path(x) for x in isas]:
        isas.append(path)
    K.save_json(sp, st)


def on_post_tool(evt):
    try:
        sid = evt.get("sessionId", "")
        name = (evt.get("toolName") or "").lower()
        args = K.tool_args(evt)
        cwd = evt.get("cwd")
        res = evt.get("toolResult") or {}
        if isinstance(res, dict) and str(res.get("resultType", "")).lower() in ("failure", "error", "denied", "rejected"):
            return None
        written, seen, new_files = [], [], set()
        cmd = args.get("command") if isinstance(args.get("command"), str) else None
        if cmd is not None and VG.SHELL_NAME_RE.search(name):
            isas = [VG.norm_path(p, cwd) for p in VG.shell_isa_paths(cmd)]
            # Only real write targets count; an ISA that is just the source of a copy or a
            # pipe (`cp ISA.md bak`, `Get-Content ISA.md | Set-Content x`) is a read.
            whole = shell_whole_write_targets(cmd, cwd) if isas else []
            inplace = bool(isas) and bool(SHELL_INPLACE_RE.search(cmd))
            if whole or inplace:
                written += list(dict.fromkeys(whole + (isas if inplace else [])))
                if re.search(r"kai\.py\s+isa\s+new", cmd, re.I):
                    new_files.update(isas)
            elif isas and SHELL_READ_RE.search(cmd):
                seen += isas
        elif name in VG.READ_TOOL_NAMES or (name == "str_replace_editor" and args.get("command") == "view"):
            p = args.get("path") or args.get("file_path") or args.get("filePath")
            if isinstance(p, str) and is_isa(p):
                seen.append(VG.norm_path(p, cwd))
        else:
            for p, op in VG.write_targets(name, args):
                if is_isa(p):
                    np_ = VG.norm_path(p, cwd)
                    written.append(np_)
                    if op == "add":
                        new_files.add(np_)
        notes = []
        for p in seen:
            record_view(sid, p)
            observe_meta(p)
            if not _off("KAI_ISC_CHECKPOINT"):
                snapshot(p, sid=sid, source="observed")
        for p in written:
            if not os.path.isfile(p):
                continue
            record_view(sid, p)
            if cmd is not None:
                _mark_isa_written(sid, p)
            try:
                notes += write_notices(p)
            except Exception:
                pass
            if _off("KAI_ISC_CHECKPOINT"):
                continue
            flips = snapshot(p, assume_new=p in new_files, sid=sid)
            reopened = [f["id"] for f in flips if f["from"] == "closed" and f["to"] in ("open", "removed")]
            if reopened:
                notes.append(f"⚠️ ISC REOPENED: {Path(p).parent.name} — {', '.join(reopened)} went from closed to "
                             "open/removed. If that wasn't deliberate, a stale write reverted it: view the ISA and "
                             "restore the closure with its evidence.")
        if notes:
            return {"additionalContext": "\n".join(notes)}
        return None
    except Exception:
        return None


def on_session_start(evt):
    """Baseline snapshots so the first write of a session diffs against real prior state."""
    try:
        sid = evt.get("sessionId", "")
        paths = [i["path"] for i in K.active_isas(limit=5)]
        cwd = evt.get("cwd")
        if cwd and (Path(cwd) / "ISA.md").is_file():
            paths.append(str(Path(cwd) / "ISA.md"))
        for p in paths:
            if not K.load_json(_meta_file(p), None):
                observe_meta(p)
            if not _off("KAI_ISC_CHECKPOINT") and not K.load_json(_snap_file(p), None):
                snapshot(p, sid=sid, source="baseline")
        return None
    except Exception:
        return None


# ============================================================ agentStop gates

ISA_ADDRESSED_RE = re.compile(
    r"\bISA(?:'s|s)?\s+(?:is\s+|was\s+|are\s+)?(?:already\s+)?(?:current|up[\s-]?to[\s-]?date|updated|unchanged|fresh|"
    r"complete|closed|\d+\s*/\s*\d+)\b|\bno\s+ISA\s+(?:update|delta|change)s?\s+(?:needed|required)\b|"
    r"\bupdated?\s+the\s+ISA\b|\bISA\s+doesn'?t\s+need\b", re.I)
CLOSE_COMPLETION_RE = re.compile(
    r"\b(done|complete(d)?|finished|shipped|implemented|built\s+and\s+(verified|tested)|all\s+(\d+\s+)?claims?\s+closed|"
    r"all\s+(green|passing)|feature\s+(is\s+)?(live|done|complete|in)|task\s+complete|work\s+(is\s+)?(done|complete)|"
    r"good\s+to\s+go|ready\s+to\s+ship)\b", re.I)
PROD_MUTATION_RES = [
    re.compile(r"\bgit\s+push\b", re.I),
    re.compile(r"\b(npm|pnpm|yarn)\s+publish\b|\btwine\s+upload\b|\bgh\s+release\s+(create|upload|edit)\b|"
               r"\bdotnet\s+nuget\s+push\b|\bcargo\s+publish\b|\bdocker\s+push\b|publish-module\b", re.I),
    re.compile(r"\bgh\s+pr\s+merge\b", re.I),
    re.compile(r"\bwrangler\s+(secret\s+put|kv\s+key\s+(put|delete))\b|wrangler\s+d1\s+execute\b[^\n]*--remote", re.I),
    re.compile(r"\b(alembic\s+upgrade|prisma\s+migrate\s+deploy|migrate\s+(deploy|up)|flyway\s+migrate|"
               r"dotnet\s+ef\s+database\s+update)\b", re.I),
    re.compile(r"\bkubectl\s+(apply|delete|rollout|scale)\b|\bterraform\s+(apply|destroy)\b|\bhelm\s+(upgrade|install|uninstall)\b", re.I),
    re.compile(r"\s--apply\b"),
]
READ_ONLY_CMD_RE = re.compile(r"^\s*(rg|grep|egrep|fgrep|ag|ack|cat|head|tail|ls|dir|wc|type|select-string|findstr|get-content|gc)\b", re.I)
SHELL_CHAIN_RE = re.compile(r"[;&|`\n]|\$\(")
EXEC_FLAG_RE = re.compile(r"--(pre|pre-glob|hostname-bin|pager)\b")
DISCOVERY_RE = re.compile(
    r"\b(turns?\s+out|it\s+turned\s+out|(i\s+)?discovered|found\s+(out\s+)?that|root\s+cause|the\s+(real|actual|underlying)\s+"
    r"(issue|problem|cause|bug)|gotcha|doesn'?t\s+support|does\s+not\s+support|isn'?t\s+supported|not\s+supported|"
    r"contrary\s+to|unexpectedly|surprisingly|dead\s+end|had\s+to\s+(switch|change|abandon|fall\s+back)|new\s+constraint|"
    r"hard\s+limit|undocumented)\b", re.I)


def prod_mutations(ev):
    out = []
    for e in ev:
        if e["is_error"] or not e["completed"]:
            continue
        if e["kind"] == "deploy":
            out.append(e)
            continue
        if e["kind"] != "command":
            continue
        t = e["target"]
        if READ_ONLY_CMD_RE.search(t) and not SHELL_CHAIN_RE.search(t) and not EXEC_FLAG_RE.search(t):
            continue
        if any(r.search(t) for r in PROD_MUTATION_RES):
            out.append(e)
    return out


def isa_edits_this_turn(ev, cwd):
    """Normalized ISA paths written this turn (write tools, or successful shell writes naming an ISA)."""
    out = []
    for e in ev:
        if e["kind"] == "edit" and is_isa(e["target"]) and not e["is_tool_error"]:
            out.append(VG.norm_path(e["target"], cwd))
        elif e["kind"] in ("command", "deploy", "test-run") and not e["is_tool_error"] and e.get("isa_write"):
            out += [VG.norm_path(p, cwd) for p in e.get("isa_paths") or []]
    return list(dict.fromkeys(out))


def active_isas(st, cwd):
    """ISAs bound to this session (written this session) whose phase is not complete."""
    out = []
    for p in st.get("isas") or []:
        np_ = VG.norm_path(p, cwd)
        text = _read(np_)
        if text is None:
            continue
        if frontmatter(text).get("phase", "").lower() == "complete":
            continue
        if np_ not in [x[0] for x in out]:
            out.append((np_, text))
    return out


def discovery_unit(message):
    for u in VG.split_units(VG.strip_noise(message)):
        if "?" in u or VG.LEADING_INTERROGATIVE.search(u) or VG.LEADING_IMPERATIVE.search(u) or VG.ATTRIBUTION.search(u):
            continue
        if DISCOVERY_RE.search(u):
            return u
    return None


def close_completion_unit(message):
    for u in VG.claim_units(message):
        if CLOSE_COMPLETION_RE.search(u):
            return u
    return None


def structural_violations(text, check_progress=True):
    """Hard structural facts that make phase: complete false (claims and fog).

    The progress count and goal-literal rules belong to isa_tool.py check (mechanical_failures
    merges them); check_progress=True keeps a local progress check for when isa_tool is absent.
    A null principal_stated_goal is legal (fail-closed capture), so it is never a violation here."""
    hard, advisory = [], []
    fm = frontmatter(text)
    claims = claim_states(text)
    open_ids = [c for c, (s, _) in claims.items() if s == "open"]
    closed = sum(1 for s, _ in claims.values() if s == "closed")
    live = sum(1 for s, _ in claims.values() if s != "dropped")
    if not claims:
        hard.append("no claims at all: an ISA with nothing to verify cannot be complete")
    if open_ids:
        hard.append(f"{len(open_ids)} claim(s) still open at phase: complete ({', '.join(open_ids[:10])}) — close each "
                    "with evidence, or retire it as ~~ID~~ dropped: <why>")
    fog = section(text, "Not yet specified")
    if fog is not None:
        lines = [l.strip() for l in fog.splitlines()
                 if l.strip() and not l.strip().startswith("<!--") and not re.match(r"^-?\s*(none|n/a)\.?$", l.strip(), re.I)
                 and not re.match(r"^-?\s*Fog:\s*things in scope", l.strip(), re.I)]
        if lines:
            hard.append(f"{len(lines)} unresolved fog line(s) in \"## Not yet specified\" — graduate each to a claim or "
                        "kill it in Decisions")
    prog = fm.get("progress", "")
    m = re.match(r"^(\d+)\s*/\s*(\d+)$", prog)
    if check_progress and m and (int(m.group(1)), int(m.group(2))) != (closed, live):
        hard.append(f"progress: {prog} disagrees with the claims on disk ({closed}/{live} closed)")
    if claims and not any(c.startswith("A") for c in claims):
        advisory.append("no Anti-claim")
    ver = section(text, "Verification") or ""
    missing = [c for c, (s, _) in claims.items() if s == "closed" and not re.search(r"\b" + re.escape(c) + r"\b", ver)]
    if missing:
        advisory.append(f"closed without a Verification stub: {', '.join(missing[:10])}")
    return hard, advisory


def _block(gate, sid, reason, st_updates, extra=None):
    sp = K.session_state(sid)
    st = K.load_json(sp, {})
    for k, fn in st_updates.items():
        st[k] = fn(st.get(k))
    st["isa_gate_blocks"] = st.get("isa_gate_blocks", 0) + 1
    K.save_json(sp, st)
    VG.gate_log({"gate": gate, "session": sid, "decision": "block", **(extra or {})})
    K.append_jsonl(K.EVENTS, {"ts": K.now_iso(), "event": f"agentStop.{gate}Block", "session": sid})
    return {"decision": "block", "reason": reason}


def close_gate(evt, tx, st, sid, cwd, message, ev, edited):
    if _off("KAI_ISA_CLOSE_GATE"):
        return None
    act = active_isas(st, cwd)
    if not act:
        return None
    unit = close_completion_unit(message)
    if not unit or ISA_ADDRESSED_RE.search(VG.strip_noise(message)):
        return None
    if edited or VG.spawned_agent(ev):
        return None
    stale = st.get("since_isa", 0)
    if stale < _int_env("KAI_ISA_CLOSE_THRESHOLD", 10):
        return None
    done = set(st.get("isa_close_fps") or [])
    for path, _text in act:
        fp = hashlib.sha256(f"{sid}|{path}".encode("utf-8")).hexdigest()[:16]
        if fp in done:
            continue
        reason = (f"ISA CLOSE GAP [Kai ISA close gate]. You declared work complete (\"{unit[:160]}\") but the active ISA "
                  f"{path} hasn't been edited in {stale} tool calls and wasn't updated this turn. At the close the ISA "
                  "must reflect the work: close finished claims with one-line evidence stubs in ## Verification, record "
                  "decisions (dead ends included), and set phase:/progress: honestly. Update it now, then restate, or "
                  "state explicitly why no ISA delta is needed. This fires once per ISA per session.")
        return _block("isaClose", sid, reason, {"isa_close_fps": lambda v, fp=fp: ((v or []) + [fp])[-50:]},
                      {"isa": path, "stale": stale})
    return None


def fold_gate(evt, tx, st, sid, cwd, message, ev, edited):
    if _off("KAI_ISA_FOLD_GATE"):
        return None
    if st.get("isa_fold_blocks", 0) >= _int_env("KAI_ISA_FOLD_MAX", 2):
        return None
    act = active_isas(st, cwd)
    if not act or edited or VG.spawned_agent(ev):
        return None
    if ISA_ADDRESSED_RE.search(VG.strip_noise(message)):
        return None
    muts = prod_mutations(ev)
    disc = None
    if not muts:
        tool_calls = sum(1 for e in ev if e["kind"] not in ("meta",))
        if tool_calls >= 3:
            disc = discovery_unit(message)
        if not disc:
            return None
    sample = " · ".join(("deploy: " if m["kind"] == "deploy" else "") + m["target"][:60] for m in muts[:3])
    fp = hashlib.sha256(f"{sid}|{act[0][0]}|{sample or disc}".encode("utf-8")).hexdigest()[:16]
    if fp in set(st.get("isa_fold_fps") or []):
        return None
    if muts:
        what = f"this turn changed live state ({len(muts)} call(s): {sample})"
    else:
        what = f"this turn surfaced a discovery (\"{disc[:160]}\")"
    reason = (f"ISA FOLD GAP [Kai ISA fold gate]. On the active run {act[0][0]}, {what}, but the ISA was not touched and "
              "the reply doesn't address ISA state. A fact that changes a claim goes into the claim in the same turn, not "
              "into narrative: add evidence stubs to affected claims, add/split/kill claims the discovery changed, log the "
              "decision or dead end, update phase/progress. Fold it in now, then restate, or state explicitly why no ISA "
              "delta is needed.")
    return _block("isaFold", sid, reason, {
        "isa_fold_blocks": lambda v: (v or 0) + 1,
        "isa_fold_fps": lambda v, fp=fp: ((v or []) + [fp])[-50:]}, {"isa": act[0][0], "trigger": "mutation" if muts else "discovery"})


def structure_gate(evt, tx, st, sid, cwd, message, ev, edited):
    if _off("KAI_ISA_STRUCTURE_GATE") or not edited:
        return None
    if st.get("isa_struct_blocks", 0) >= _int_env("KAI_ISA_STRUCTURE_MAX", 2):
        return None
    offenders = []
    for p in edited:
        text = _read(p)
        if text is None or frontmatter(text).get("phase", "").lower() != "complete":
            continue
        hard, adv = mechanical_failures(p, text)
        if hard:
            offenders.append((p, hard, adv))
    if not offenders:
        return None
    lines = []
    for p, hard, adv in offenders:
        lines.append(f"  {p}")
        lines += [f"    ✗ {h}" for h in hard]
        lines += [f"    (advisory) {a}" for a in adv]
    reason = ("ISA STRUCTURE GATE [Kai]. An ISA set to phase: complete this turn fails the mechanical gate "
              "(isa_tool.py check semantics):\n" +
              "\n".join(lines) + "\nThese are facts, not judgment calls. Fix the ISA, or set phase: back to climbing if "
                                 "the work isn't actually done. Advisories never block.")
    return _block("isaStructure", sid, reason, {"isa_struct_blocks": lambda v: (v or 0) + 1},
                  {"isas": [o[0] for o in offenders]})


def on_agent_stop(evt):
    try:
        if _off("KAI_ISA_GATES") or VG.stop_active(evt):
            return None
        sid = evt.get("sessionId", "") or "unknown"
        st = K.load_json(K.session_state(sid), {})
        if st.get("isa_gate_blocks", 0) >= _int_env("KAI_ISA_MAX_BLOCKS", 4):
            return None
        cwd = evt.get("cwd")
        tx = VG.load_stop_transcript(evt)
        if not tx:
            return None
        message = tx.get("final") or ""
        if not message.strip():
            return None
        # Verification evidence gaps outrank ISA bookkeeping: let that gate own this stop.
        vg_out, _ = VG.evaluate(evt, tx)
        if vg_out:
            return None
        ev = tx["turn_events"]
        edited = isa_edits_this_turn(ev, cwd)
        for gate in (close_gate, fold_gate, structure_gate):
            out = gate(evt, tx, st, sid, cwd, message, ev, edited)
            if out:
                return out
        return None
    except Exception:
        return None


HANDLERS = {
    "sessionStart": on_session_start,
    "preToolUse": on_pre_tool,
    "postToolUse": on_post_tool,
    "agentStop": on_agent_stop,
}
