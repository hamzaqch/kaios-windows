"""Kai verification gate (agentStop): the message is a claim, the transcript is the evidence.

Claims are detected in the final assistant message. Evidence is detected ONLY in
the transcript's real tool calls (Copilot session-state events.jsonl), never in
the message's own wording, so rewording cannot pass the gate; verifying or
honestly downgrading ("not verified", "DEFERRED: <why>") does.

BLOCK iff all hold (any doubt => pass, fail-open):
  1. not a stop-hook recovery pass (stop_hook_active) and under the per-session cap
  2. a claim of a blocking type survives every unit guard (negation, question,
     intent/future, conditional, quote, attribution, narration, honest downgrade)
  3. act-then-claim: this turn did mutating work of the claimed kind
     (T5 publicity is the exception: its failure mode is asserting without acting)
  4. the type's required evidence is absent from the transcript
  5. no subagent ran this turn (its evidence would be invisible; T5 ignores this)
  6. this exact claim was not already blocked in this session

Types:
  TF  contradicted completion: the turn's final tool call failed, message says done
  T5  publicity: "vX.Y.Z is public/released/live" with no probe of the public surface
  T2  flow: "login/checkout works" after a change, flow never exercised
  T1  deploy: "site is live" after a deploy, nothing probed it afterwards
  T3  appearance: "the button renders/looks right" after a frontend edit, no pixels viewed
  T4  tests: "tests pass" after a code edit, no passing test run after the edit
  TC  completion: "done/fixed/implemented" after a code edit, no verification call after it
  TH  hedge: "should work" after acting this turn (forbidden phrase; say verified / not verified)

Env: KAI_VERIFY_GATE=0 disables all. KAI_VERIFY_<TYPE>=0 disables one type,
KAI_VERIFY_<TYPE>=log makes it log-only. KAI_VERIFY_MAX_BLOCKS (default 3) caps
blocks per session so the gate can never loop.
"""
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path

try:
    import kai_hook as K
except Exception:  # loaded outside the hooks dir (tests, tools)
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import kai_hook as K

GATE_LOG_NAME = "gates.jsonl"
TAIL_CAP = 8 * 1024 * 1024
RESULT_CAP = 4000

# ============================================================ transcript parsing

PATCH_OP_RE = re.compile(r"^\*\*\*\s+(Add|Update|Delete)\s+File:\s*(.+?)\s*$", re.M)
EXIT_IN_TEXT_RE = re.compile(r"completed with exit code\s+(-?\d+)", re.I)

WRITE_TOOL_NAMES = {
    "apply_patch", "edit", "create", "write", "str_replace", "str_replace_editor", "insert",
    "multi_edit", "multiedit", "notebook_edit", "write_file", "edit_file", "create_file",
    "replace_string_in_file", "insert_edit_into_file",
}
WHOLE_WRITE_TOOL_NAMES = {"create", "write", "write_file", "create_file"}
READ_TOOL_NAMES = {"view", "read", "read_file", "cat", "open_file"}
SEARCH_TOOL_NAMES = {"grep", "rg", "glob", "search", "find", "list_dir", "ls", "file_search", "codebase_search"}
WEB_TOOL_NAMES = {"web_fetch", "fetch", "webfetch", "fetch_url", "http_request", "fetch_webpage", "web_search"}
AGENT_TOOL_NAMES = {"task", "agent", "subagent", "run_subagent", "delegate", "dispatch_agent"}
META_TOOL_NAMES = {"skill", "ask_user", "report_intent", "todo", "update_todo", "think",
                   "fetch_copilot_cli_documentation"}

SHELL_NAME_RE = re.compile(r"(bash|powershell|pwsh|shell|terminal)", re.I)
BROWSER_NAME_RE = re.compile(r"(browser|playwright|puppeteer|chrome|selenium)", re.I)
BROWSER_CAPTURE_RE = re.compile(r"(screenshot|capture|take_image)", re.I)
BROWSER_INTERACT_RE = re.compile(r"(click|type|fill|press|select|submit|hover|drag|key|upload|check)", re.I)

IMG_RE = re.compile(r"\.(png|jpe?g|webp|gif|bmp)$", re.I)
DOC_PATH_RE = re.compile(r"(\.(md|markdown|txt|rst)$)|([\\/]MEMORY[\\/])", re.I)
FRONTEND_RE = re.compile(r"\.(tsx|jsx|vue|svelte|css|scss|sass|less|html?|astro|svg|png|webp|xaml|razor|cshtml)$", re.I)
FLOW_PATH_RE = re.compile(r"(auth|login|oauth|sign[\s_-]?in|callback|session|checkout|payment)", re.I)

DEPLOY_RE = re.compile(
    r"\b(wrangler(@\S+)?\s+(pages\s+)?deploy|(npm|pnpm|yarn)\s+run\s+deploy|vercel\s+(deploy|--prod)|"
    r"netlify\s+deploy|firebase\s+deploy|fly(ctl)?\s+deploy|az\s+(webapp|functionapp|staticwebapp)\s+(\S+\s+)?(deploy|up)|"
    r"gcloud\s+(app|run|functions)\s+deploy|kubectl\s+(apply|rollout)|helm\s+(upgrade|install)|terraform\s+apply|"
    r"pulumi\s+up|cdk\s+deploy|sam\s+deploy|serverless\s+deploy|sls\s+deploy|eb\s+deploy|gh-pages|docker\s+push|"
    r"deploy\.(sh|ps1|py|cmd))\b", re.I)
TEST_RE = re.compile(
    r"\b(pytest|py\.test|python[0-9.]*(\.exe)?\s+-m\s+(unittest|pytest)|go\s+test|cargo\s+test|vitest|jest|mocha|"
    r"(npm|pnpm|yarn)\s+(run\s+)?test|deno\s+test|dotnet\s+test|invoke-pester|mvn\s+(\S+\s+)*test|"
    r"gradlew?\s+test|ctest|rspec|phpunit|tox|nox|make\s+(test|check))\b", re.I)
PROBE_RE = re.compile(r"\bcurl(\.exe)?\b|\bwget\b|\bhttpie\b|invoke-webrequest|invoke-restmethod|\biwr\b|\birm\b", re.I)
SHELL_BROWSER_RE = re.compile(r"\b(playwright|puppeteer|selenium)\b", re.I)
URL_RE = re.compile(r"https?://([^\s\"'/]+)", re.I)

# Hard failure markers in tool OUTPUT (narrow on purpose: an HTTP 4xx/5xx status line
# or explicit failure words, never a bare "500" or "error").
ERROR_MARKERS = re.compile(
    r"\bHTTP[/ ]?\d(\.\d)?\s+[45]\d\d\b|\b(internal server error|traceback|connection refused|timed out|"
    r"command not found|permission denied|is not recognized as)\b|\bexit\s+(code\s+)?[1-9]\d*\b", re.I)
HTTP_SUCCESS = re.compile(r"\bHTTP[/ ]?\d(\.\d)?\s+[23]\d\d\b|set-cookie|location:\s*/|StatusCode\s*:\s*[23]\d\d", re.I)

ISA_MENTION_RE = re.compile(r"""(?:^|[\s/\\"'`=(])((?:[^\s"'`|;&<>()]*[\\/])?(?:[\w.-]+\.)?ISA\.md)\b""", re.I)
SHELL_ISA_WRITE_RE = re.compile(
    r"(write_text|writealltext|\.write\(|sed\s+-i\b|perl\s+-i\b|\btee\b|set-content|add-content|out-file|"
    r"\bsc\s|\bac\s|copy-item|move-item|\bcp\s|\bmv\s|\bcopy\s|\bmove\s|git\s+add\b|kai\.py\s+isa\s+new|"
    r"(^|[^-=2&>])>>?\s*[\"']?[^\s\"'|&;]*isa\.md)", re.I)


def norm_path(p, cwd=None):
    """Normalized absolute path for comparisons (case-folded on Windows)."""
    try:
        s = str(p).strip().strip("\"'")
        if not s:
            return ""
        path = Path(os.path.expanduser(s))
        if not path.is_absolute() and cwd:
            path = Path(cwd) / path
        return os.path.normcase(os.path.normpath(str(path)))
    except Exception:
        return str(p)


def is_isa_path(p):
    name = os.path.basename(str(p).replace("\\", "/")).lower()
    return name == "isa.md" or name.endswith(".isa.md")


def _norm_args(a):
    if isinstance(a, dict):
        return a
    if isinstance(a, str):
        try:
            v = json.loads(a)
            return v if isinstance(v, dict) else {"_raw": a}
        except Exception:
            return {"_raw": a}
    return {}


def _read_tail(path):
    p = Path(path)
    size = p.stat().st_size
    with open(p, "rb") as f:
        if size > TAIL_CAP:
            f.seek(size - TAIL_CAP)
            f.readline()
        data = f.read()
    return data.decode("utf-8", errors="replace")


def write_targets(name, args):
    """[(path, op)] a write tool touched. op: add|update|delete|whole|edit."""
    out = []
    raw_texts = [v for v in args.values() if isinstance(v, str) and "*** " in v]
    for t in raw_texts:
        for op, p in PATCH_OP_RE.findall(t):
            out.append((p, op.lower()))
    if out:
        return out
    whole = name in WHOLE_WRITE_TOOL_NAMES or (
        ("file_text" in args or "content" in args) and "old_str" not in args and "old_string" not in args)
    for key in ("path", "file_path", "filePath", "target", "filename", "notebook_path"):
        v = args.get(key)
        if isinstance(v, str) and v.strip():
            out.append((v, "whole" if whole else "edit"))
            break
    return out


def shell_isa_paths(cmd):
    return [m for m in ISA_MENTION_RE.findall(cmd or "") if is_isa_path(m)]


def _classify(name, args, cwd):
    """Yield (kind, target, extra) for one tool call."""
    lname = (name or "").lower()
    cmd = args.get("command") if isinstance(args.get("command"), str) else None
    if lname in META_TOOL_NAMES:
        return [("meta", lname, {})]
    if lname in AGENT_TOOL_NAMES or lname.startswith("kai-") or lname.startswith("kai:"):
        desc = args.get("description") or args.get("agent_type") or args.get("prompt") or lname
        return [("agent", str(desc)[:120], {})]
    if lname == "str_replace_editor" and args.get("command") == "view":
        lname, cmd = "view", None
    if BROWSER_NAME_RE.search(lname):
        blob = lname + " " + str(args.get("action") or "")
        if BROWSER_CAPTURE_RE.search(blob):
            return [("browser-capture", str(args.get("url") or ""), {})]
        if BROWSER_INTERACT_RE.search(blob):
            return [("browser-interact", str(args.get("url") or ""), {})]
        return [("browser-nav", str(args.get("url") or ""), {})]
    if cmd is not None and (SHELL_NAME_RE.search(lname) or lname in ("cmd", "exec", "execute", "run_command")):
        c = cmd[:2000]
        extra = {"isa_paths": shell_isa_paths(c), "isa_write": bool(SHELL_ISA_WRITE_RE.search(c))}
        if DEPLOY_RE.search(c):
            return [("deploy", c, extra)]
        if SHELL_BROWSER_RE.search(c):
            return [("browser-capture" if re.search(r"screenshot", c, re.I) else "browser-nav", c, extra)]
        if TEST_RE.search(c) and "--dry-run" not in c:
            return [("test-run", c, extra)]
        if PROBE_RE.search(c):
            return [("probe", c, extra)]
        return [("command", c, extra)]
    if lname in WEB_TOOL_NAMES or lname.startswith("web_"):
        return [("probe", str(args.get("url") or args.get("query") or ""), {})]
    if lname in READ_TOOL_NAMES:
        p = str(args.get("path") or args.get("file_path") or args.get("filePath") or "")
        return [("read-image" if IMG_RE.search(p) else "read", p, {})]
    if lname in SEARCH_TOOL_NAMES:
        return [("search", str(args.get("pattern") or args.get("path") or ""), {})]
    if lname in WRITE_TOOL_NAMES or any(isinstance(v, str) and "*** " in v and PATCH_OP_RE.search(v) for v in args.values()):
        outs = []
        for p, op in write_targets(lname, args):
            is_code = bool(p) and not DOC_PATH_RE.search(p) and not is_isa_path(p)
            outs.append(("edit", p, {"op": op, "is_code": is_code}))
        return outs or [("meta", lname, {})]
    return [("other", lname, {})]


def parse_transcript(path, cwd=None, stop_ts=None):
    """Parse a Copilot events.jsonl into {"events", "final", "turn_events", "settled"}.

    Every tool call becomes one or more ordered events (start order) carrying its
    completion: is_tool_error (success false / non-zero exit), is_error (that or a
    failure marker in the output), result text. `in_turn` marks events after the
    last user.message. `final` is the last non-empty assistant.message content of
    the current turn. `settled` is True when the reply that ended the turn is on
    disk: either an assistant.message with content follows the last tool completion
    / model-turn start, or this agentStop's own hook.start line (matched on
    stop_ts) has been written. Returns None when the transcript cannot be read.
    """
    try:
        raw = _read_tail(path)
    except Exception:
        return None
    starts, order, completes = {}, [], {}
    finals = []
    turn_marker = -1
    last_activity = -1
    last_final = -1
    stop_seen = False
    idx = 0
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        t = obj.get("type")
        d = obj.get("data") or {}
        if t == "user.message":
            turn_marker = idx
            finals = []
            last_final = -1
        elif t == "tool.execution_start":
            cid = d.get("toolCallId") or f"_anon{idx}"
            starts[cid] = (idx, d.get("toolName") or "", d.get("arguments"))
            order.append(cid)
        elif t == "tool.execution_complete":
            cid = d.get("toolCallId")
            if cid:
                completes[cid] = d
            last_activity = idx
        elif t == "assistant.turn_start":
            last_activity = idx
        elif t == "assistant.message":
            c = d.get("content")
            if isinstance(c, str) and c.strip():
                finals.append(c)
                last_final = idx
        elif t == "hook.start" and stop_ts is not None and d.get("hookType") == "agentStop":
            if str((d.get("input") or {}).get("timestamp")) == str(stop_ts):
                stop_seen = True
        idx += 1

    events = []
    seq = 0
    for cid in order:
        pos, name, rawargs = starts[cid]
        args = _norm_args(rawargs)
        comp = completes.get(cid) or {}
        res = comp.get("result") or {}
        text = ""
        if isinstance(res, dict):
            text = res.get("content") or res.get("detailedContent") or ""
        elif isinstance(res, str):
            text = res
        err = comp.get("error")
        if isinstance(err, dict) and err.get("message"):
            text = (text + "\n" + str(err.get("message"))).strip()
        text = str(text)[:RESULT_CAP]
        exit_code = (comp.get("shellExecution") or {}).get("exitCode")
        if exit_code is None:
            m = EXIT_IN_TEXT_RE.search(text)
            exit_code = int(m.group(1)) if m else None
        tool_error = comp.get("success") is False or (isinstance(exit_code, int) and exit_code != 0)
        completed = bool(comp)
        for kind, target, extra in _classify(name, args, cwd):
            ev = {"seq": seq, "kind": kind, "tool": name, "target": target or "", "result": text,
                  "is_tool_error": tool_error, "is_error": tool_error or bool(text and ERROR_MARKERS.search(text)),
                  "completed": completed, "in_turn": pos > turn_marker}
            ev.update(extra)
            events.append(ev)
            seq += 1
    return {"events": events, "final": finals[-1] if finals else None,
            "turn_events": [e for e in events if e["in_turn"]],
            "settled": stop_seen or (last_final > last_activity and last_final > turn_marker)}


def load_stop_transcript(evt):
    """Transcript for an agentStop, waiting briefly for Copilot to flush the final reply.

    Verified live (CLI 1.0.106): when agentStop fires, events.jsonl often ends at
    assistant.turn_start; the final assistant.message and the hook.start line land a
    moment later because the writer lags the event stream. Poll (every 50 ms, up to
    KAI_STOP_WAIT_MS, default 1500) until the turn is settled. If it never settles,
    `final` is cleared so no gate judges an older message (fail-open).
    """
    tp = evt.get("transcriptPath") or evt.get("transcript_path") or ""
    if not tp:
        return None
    try:
        wait = max(0, int(os.environ.get("KAI_STOP_WAIT_MS", "1500"))) / 1000.0
    except ValueError:
        wait = 1.5
    stop_ts = evt.get("timestamp")
    # isa_gates and this gate both need the transcript in the same hook process; share
    # one parse (and one wait) through the kai_hook module both import.
    key = (str(tp), str(stop_ts), str(evt.get("sessionId")))
    cached = getattr(K, "_kai_stop_tx_cache", None)
    if isinstance(cached, tuple) and len(cached) == 2 and cached[0] == key:
        return cached[1]
    deadline = time.monotonic() + wait
    while True:
        tx = parse_transcript(tp, evt.get("cwd"), stop_ts)
        if tx is None or tx["settled"]:
            break
        if time.monotonic() >= deadline:
            tx["final"] = None
            break
        time.sleep(0.05)
    try:
        K._kai_stop_tx_cache = (key, tx)
    except Exception:
        pass
    return tx


# ----------------------------------------------------------- evidence queries

def last_code_mutation_seq(ev):
    s = -1
    for e in ev:
        if (e["kind"] == "edit" and e.get("is_code") and not e["is_tool_error"]) or e["kind"] == "deploy":
            s = max(s, e["seq"])
    return s


def had_deploy(ev):
    return any(e["kind"] == "deploy" and not e["is_tool_error"] for e in ev)


def had_code_edit(ev):
    return any(e["kind"] == "edit" and e.get("is_code") and not e["is_tool_error"] for e in ev)


def had_frontend_edit(ev):
    return any(e["kind"] == "edit" and not e["is_tool_error"] and FRONTEND_RE.search(e["target"]) for e in ev)


def had_flow_edit(ev):
    return any(e["kind"] == "edit" and e.get("is_code") and not e["is_tool_error"] and FLOW_PATH_RE.search(e["target"])
               for e in ev)


def spawned_agent(ev):
    return any(e["kind"] == "agent" for e in ev)


def acted(ev):
    """Any mutating or executing work this turn (edits or shell commands)."""
    return any(e["kind"] in ("edit", "deploy", "command", "test-run") and e["completed"] for e in ev)


def probed_after_deploy(ev):
    deps = [e["seq"] for e in ev if e["kind"] == "deploy"]
    if not deps:
        return False
    after = max(deps)
    return any(e["seq"] > after and not e["is_error"] and
               e["kind"] in ("probe", "browser-nav", "browser-capture", "browser-interact") for e in ev)


def flow_exercised(ev):
    after = last_code_mutation_seq(ev)
    post = [e for e in ev if e["seq"] > after and not e["is_error"]]
    interacted = any(e["kind"] == "browser-interact" for e in post)
    navved = any(e["kind"] in ("browser-nav", "browser-capture") for e in post)
    if interacted and navved:
        return True
    return any(e["kind"] in ("probe", "browser-nav") and HTTP_SUCCESS.search(e["result"]) for e in post)


def pixel_viewed(ev):
    """A screenshot came back to the model (browser capture) or an image file was viewed after the last edit."""
    after = last_code_mutation_seq(ev)
    for e in ev:
        if e["seq"] <= after or e["is_error"]:
            continue
        if e["kind"] == "read-image":
            return True
        if e["kind"] == "browser-capture" and e["tool"] and not SHELL_NAME_RE.search(e["tool"]):
            return True  # browser tools return the image inline
    shell_caps = [e for e in ev if e["seq"] > after and e["kind"] == "browser-capture" and not e["is_error"]]
    return bool(shell_caps) and any(e["seq"] > shell_caps[0]["seq"] and e["kind"] == "read-image" for e in ev)


def test_result_passed(text):
    m = re.search(r"\b(\d+)\s+(failed|failures?|failing|errors?)\b", text, re.I)
    if m and int(m.group(1)) > 0:
        return False
    if re.search(r"\bFAILED\b|\bFAIL:", text):
        return False
    if re.search(r"\b0\s+passed\b", text, re.I):
        return False
    return bool(re.search(r"\b[1-9]\d*\s+(passed|pass|tests? passed)\b", text, re.I) or
                re.search(r"\bRan\s+[1-9]\d*\s+tests?\b[\s\S]*\bOK\b", text) or
                re.search(r"\ball\s+(tests?\s+)?(pass|passed|green)\b", text, re.I) or
                re.search(r"\bexit(\s+code)?\s+0\b", text, re.I) or
                re.search(r"\bPassed!\s", text) or re.search(r"\bok\s+\S+\s+[\d.]+s\b", text))


def test_passed_after_edit(ev):
    after = last_code_mutation_seq(ev)
    return any(e["seq"] > after and e["kind"] == "test-run" and not e["is_error"] and test_result_passed(e["result"])
               for e in ev)


BOOKKEEPING_SEG_RE = re.compile(
    r"^\s*(git\s+(add|commit|status|diff|log|stash|checkout|switch|branch|restore|reset)|cd|chdir|ls|dir|mkdir|md|echo|"
    r"write-host|write-output|cp|mv|copy|move|copy-item|move-item|rm|del|erase|remove-item|touch|new-item|pwd|"
    r"get-location|set-location|clear|cls|true|:)\b", re.I)


def _is_bookkeeping(cmd):
    segs = [s for s in re.split(r"&&|\|\||;|\|", cmd or "") if s.strip()]
    return bool(segs) and all(BOOKKEEPING_SEG_RE.search(s) for s in segs)


def verified_after_code_edit(ev):
    """Some verification tool call succeeded after the last code edit: a test, a probe, a browser
    check, a search, a read-back of an edited file, or any non-bookkeeping command."""
    after = last_code_mutation_seq(ev)
    edited = {os.path.basename(e["target"].replace("\\", "/")).lower()
              for e in ev if e["kind"] == "edit" and e.get("is_code")}
    for e in ev:
        if e["seq"] <= after or e["is_error"] or not e["completed"]:
            continue
        k = e["kind"]
        if k in ("test-run", "probe", "browser-nav", "browser-capture", "browser-interact", "search", "read-image"):
            return True
        if k == "read" and os.path.basename(e["target"].replace("\\", "/")).lower() in edited:
            return True
        if k == "command" and not _is_bookkeeping(e["target"]):
            return True
    return False


PUBLIC_PROBE_RE = re.compile(
    r"\bgit\s+ls-remote\b|\bgh\s+(api|release|repo|search|pr|run)\b|github\.com|\bgit\s+fetch\b|\borigin/\w+|"
    r"\bnpm\s+(view|info)\b|\bpip\s+index\b|pypi\.org|https?://", re.I)


def public_state_probed(ev):
    for e in ev:
        if e["kind"] == "probe" and not e["is_tool_error"]:
            return True
        if e["kind"] in ("command", "test-run") and PUBLIC_PROBE_RE.search(e["target"]) and not e["is_tool_error"]:
            return True
    return False


# ============================================================ claim detection

def strip_noise(msg):
    """Drop fenced code, inline code, blockquotes, and machine-echoed Kai format scaffolding."""
    s = re.sub(r"```[\s\S]*?```", " ", msg or "")
    s = re.sub(r"`[^`\n]*`", " ", s)
    s = re.sub(r"^\s*>.*$", " ", s, flags=re.M)
    s = re.sub(r"^\s*═+.*$", " ", s, flags=re.M)
    s = re.sub(r"^\s*⚙️?\s*SYSTEM:.*$", " ", s, flags=re.M)
    s = re.sub(r"^\s*(🔧\s*CHANGE|✅\s*VERIFY)\s*:\s*$", " ", s, flags=re.M)
    s = re.sub(r"🗣️\s*Kai:", " ", s)
    return s


def split_units(text):
    # Dotted numbers (versions, IPs) stay intact; newlines always split.
    return [u.strip(" \t-*•") for u in re.split(r"\n+|(?<!\d)[.!?;,]+|[.!?;,]+(?!\d)", text or "") if u and u.strip(" \t-*•")]


HONEST_DOWNGRADE = re.compile(
    r"\b(DEFERRED|not\s+(yet\s+)?(browser[\s-]?|pixel[\s-]?|end[\s-]?to[\s-]?end\s+|live\s+)?verif\w*|"
    r"haven'?t\s+(yet\s+)?(browser[\s-]?|actually\s+)?(verif\w*|exercised|tested|looked|run|checked)|"
    r"deployed\s+but\s+not\s+\w*\s*verif\w*|flow\s+not\s+exercised|not\s+(yet\s+)?(browser[\s-]?)?tested|"
    r"unverified|pending\s+(browser\s+|live\s+|your\s+)?(verif\w*|test)|verify\s+next|verifying\s+(next|now)|"
    r"checking\s+now|about\s+to\s+(verify|test|check|probe)|couldn'?t\s+(capture|verify|reach|run)|"
    r"can'?t\s+(verify|run|reach)|did(\s+not|n'?t)\s+(actually\s+|yet\s+)?(inspect|run|verify|check|test|execute|look\s+at|open)|"
    r"not\s+(yet\s+)?(run|checked|inspected|executed)|unchecked|untested)\b", re.I)
NONCLAIM = re.compile(
    r"\b(not|isn'?t|aren'?t|wasn'?t|weren'?t|doesn'?t|don'?t|didn'?t|won'?t|can'?t|cannot|couldn'?t|no\s+longer|"
    r"still\s+(not|broken|failing)|never|needs?\s+to|should\s+be|would\s+be|make\s+sure|please|let'?s|going\s+to|"
    r"will\s+be|to\s+be|want|hope|expect|if\s|once\s|when\s|after\s|assuming|would|could\s+you|can\s+you)\b", re.I)
LEADING_INTERROGATIVE = re.compile(
    r"^\s*(is|are|does|do|did|can|could|should|would|will|has|have|how|why|what|where|when|which|who|isn'?t|aren'?t)\b", re.I)
LEADING_IMPERATIVE = re.compile(
    r"^\s*(run|do|execute|try|click|open|deploy|add|set|install|go|check|make|use|call|start|restart|edit|write|"
    r"create|build|test|verify|ensure|remember\s+to)\b", re.I)
RECIPE = re.compile(r"\b(then|and\s+then|after\s+that)\b[^.\n]{0,40}\b(works?|is\s+live|verified|passes?|done)\b", re.I)
ATTRIBUTION = re.compile(
    r"\b(you\s+(said|asked|told|mentioned)|per\s+the|according\s+to|the\s+(ticket|PR|docs?|user|issue|spec)\s+"
    r"(say|says|said|claims?))\b|\"[^\"]*\"", re.I)
NARRATION = re.compile(
    r"\b(earlier|already|previously|in\s+(the\s+)?prior\s+turns?|prior\s+turns?|last\s+turn)\b|"
    r"\b(in|back\s+in|since|during)\s+(19|20)\d\d\b", re.I)
RECIPE_TAIL = re.compile(r"^\s*(then|and\s+then|after\s+that|so\s+that)\b", re.I)


def unit_is_claimable(u, allow_narration=False):
    if "?" in u:
        return False
    if LEADING_INTERROGATIVE.search(u) or LEADING_IMPERATIVE.search(u) or RECIPE.search(u):
        return False
    if NONCLAIM.search(u) or ATTRIBUTION.search(u):
        return False
    if not allow_narration and NARRATION.search(u):
        return False
    if RECIPE_TAIL.search(u):
        return False
    return True


def claim_units(message, allow_narration=False):
    return [u for u in split_units(strip_noise(message)) if unit_is_claimable(u, allow_narration)]


T1_LIVE = re.compile(r"\b((is|it'?s|site'?s|page'?s|app'?s|now)\s+live|went\s+live|live\s+(at|on)|deployed\s+(to|at|and\s+"
                     r"(live|working))|deploy(ment)?\s+(is\s+)?(complete|done|succeeded|successful))\b", re.I)
T1_WEBNOUN = re.compile(r"\b(site|page|web\s*site|web\s*app|app|url|domain|https?://|worker|function|deploy(ment|ed)?|"
                        r"production|prod|admin|dashboard|endpoint|api|service)\b", re.I)
T2_FLOW = re.compile(r"\b(log[\s-]?in|sign[\s-]?in|sign[\s-]?up|auth(entication|orization)?|oauth|sso|checkout|payment|"
                     r"purchase|the\s+(login|sign[\s-]?in|auth|checkout)\s+flow)\b", re.I)
T2_WORKS = re.compile(r"\b(works?(\s+(now|end[\s-]?to[\s-]?end|fine|correctly|great))?|working|functional|"
                      r"verified(\s+working)?|confirmed\s+working|succeeds?|can\s+(now\s+)?(log|sign)\s+in|completes?|"
                      r"goes?\s+through)\b", re.I)
T3_VISUAL = re.compile(r"\b(logo|image|icon|favicon|thumbnail|hero|banner|button|layout|header|footer|nav(bar)?|"
                       r"wordmark|graphic|background|colou?r|font|modal|sidebar|card)\b", re.I)
T3_LOOK = re.compile(r"\b(renders?|rendered|displays?|displayed|looks?\s+(right|correct|good|great|fine)|is\s+(now\s+)?"
                     r"(centered|centred|aligned|transparent|visible|positioned|the\s+(right|correct)\s+colou?r))\b", re.I)
T4_CODE = re.compile(r"\b(tests?\s+(pass|passed|green|passing)|\d+\s*/\s*\d+\s+(pass|passed|green|passing)|"
                     r"all\s+(tests\s+)?(green|passing|pass)|verified\s+(with|via)\s+a?\s*(run|test))\b", re.I)
GENERIC_FLOW = re.compile(r"\b(live\s+and\s+verified|it\s+works\b|works\s+now|works\s+end[\s-]?to[\s-]?end|"
                          r"confirmed\s+working|fully\s+working|sign[\s-]?in\s+works|login\s+works|"
                          r"working\s+(now|end[\s-]?to[\s-]?end))\b", re.I)
T5_SURFACE = re.compile(r"\b(public\s+repo(sitory)?|github|the\s+public|docs\s+site|release[ds]?|published|package|"
                        r"pypi|npm|marketplace|v?\d+\.\d+\.\d+)\b", re.I)
T5_PREDICATE = re.compile(r"\b(is|are|'s|was|were|now|already)\s+(public|live|released|shipped|published|out)\b", re.I)
T5_LOCAL = re.compile(r"\b(local(ly)?|staged?|staging|payload|private\s+repo|candidate|draft|dry[\s-]?run)\b", re.I)
COMPLETION = re.compile(r"\b(done|complete(d)?|finished|fixed|resolved|implemented|all\s+set|works?\s+(now|fine|correctly)|"
                        r"good\s+to\s+go|ready\s+to\s+(ship|use|go)|everything('?s)?\s+(fine|working|good))\b", re.I)
HARD_FAIL = re.compile(r"\btraceback\s*\(most recent call last\)|\bcommand not found\b|\bpermission denied\b|"
                       r"\bno such file or directory\b|\bexit(ed)?(\s+with)?(\s+code)?\s+[1-9]\d*\b|\bsegmentation fault\b|"
                       r"\bpanic:\s|is not recognized as|cannot find path|\bFAILED\b|\bfatal:\s|failed to apply patch", re.I)
ACKNOWLEDGES_FAILURE = re.compile(r"\b(fail(s|ed|ure|ing)?|error(s|ed)?|traceback|exception|broke|broken|"
                                  r"didn'?t\s+(work|run|parse|apply)|couldn'?t|hit\s+a\s+(snag|wall)|blocked|denied)\b", re.I)
HEDGE = re.compile(r"\b(should\s+(now\s+)?(work|be\s+working|be\s+fixed|fix\s+(it|this|the\s+\w+)|be\s+good|be\s+fine|"
                   r"pass|be\s+resolved|do\s+the\s+trick|be\s+ok(ay)?)|ought\s+to\s+work|probably\s+works?|"
                   r"(i\s+)?(think|believe)\s+(it|this|that)\s+(works|is\s+fixed|should\s+work)|in\s+theory\s+(it\s+)?works?)\b",
                   re.I)
HEDGE_GUARD = re.compile(r"^\s*(once|after|when|if|assuming|provided)\b", re.I)


def publicity_claim_unit(message):
    for u in claim_units(message, allow_narration=True):
        if T5_LOCAL.search(u):
            continue
        if T5_SURFACE.search(u) and T5_PREDICATE.search(u):
            return u
    return None


def classify_claim(message):
    """Strongest typed claim: T2 outranks T1, then T3, then T4. (type, unit) or None."""
    t1 = t3 = t4 = None
    for u in claim_units(message):
        if T2_FLOW.search(u) and T2_WORKS.search(u) and not T3_VISUAL.search(u):
            return ("T2", u)
        if not t1 and T1_LIVE.search(u) and T1_WEBNOUN.search(u):
            t1 = u
        if not t3 and T3_VISUAL.search(u) and T3_LOOK.search(u):
            t3 = u
        if not t4 and T4_CODE.search(u):
            t4 = u
    for t, u in (("T1", t1), ("T3", t3), ("T4", t4)):
        if u:
            return (t, u)
    return None


def generic_flow_unit(message):
    for u in claim_units(message):
        if GENERIC_FLOW.search(u):
            return u
    return None


def completion_unit(message):
    for u in claim_units(message):
        if COMPLETION.search(u):
            return u
    return None


def hedge_unit(message):
    for u in split_units(strip_noise(message)):
        if "?" in u or HEDGE_GUARD.search(u) or ATTRIBUTION.search(u):
            continue
        if HEDGE.search(u):
            return u
    return None


def contradicted_completion_unit(message, ev):
    """Message claims completion while the turn's final tool call hard-failed (raw failure flag
    required, so a successful grep for 'exit 1' never fires) and nothing ran after it."""
    real = [e for e in ev if e["kind"] not in ("meta",)]
    if not real:
        return None
    last = real[-1]
    if not last["is_tool_error"]:
        return None
    stripped = strip_noise(message)
    if ACKNOWLEDGES_FAILURE.search(stripped):
        return None
    for u in claim_units(message):
        if COMPLETION.search(u):
            return u
    return None


# ============================================================ state + decision

def _env(name, default="1"):
    return os.environ.get(name, default).strip().lower()


def type_mode(t):
    """'block' | 'log' | 'off' for a claim type."""
    v = _env(f"KAI_VERIFY_{t}")
    if v in ("0", "off", "false", "no"):
        return "off"
    if v in ("log", "logonly", "log-only"):
        return "log"
    return "block"


def fingerprint(sid, kind, unit):
    return hashlib.sha256(f"{sid}|{kind}|{' '.join(unit.lower().split())}".encode("utf-8")).hexdigest()[:16]


def gate_log(rec):
    rec = dict(rec)
    rec.setdefault("ts", K.now_iso())
    K.append_jsonl(K.MEM / "OBSERVABILITY" / GATE_LOG_NAME, rec)


def stop_active(evt):
    return bool(evt.get("stop_hook_active") or evt.get("stopHookActive"))


BLOCK_MSGS = {
    "TF": "CONTRADICTED COMPLETION [Kai verification gate/TF]. You claimed: \"{u}\", but the turn's final tool call "
          "failed (non-zero exit, error, or failed patch) and nothing ran after it. Fix and re-run the failed step and show "
          "it passing, or state the failure honestly instead of claiming completion. This gate reads the transcript's real "
          "tool results, so rewording won't pass it.",
    "T5": "UNPROBED PUBLICITY CLAIM [Kai verification gate/T5]. You asserted: \"{u}\", but nothing in this session probed "
          "the public surface (no git ls-remote / git fetch, no gh api|release|repo, no web fetch or curl of the public URL). "
          "A local checkout can sit ahead of its remote with commits that were never pushed. Run the probe and cite it, or "
          "downgrade the claim (\"staged\", \"local\", \"pushed to a private remote\").",
    "T1": "DEPLOY VERIFICATION GAP [Kai verification gate/T1]. You claimed: \"{u}\". {ev}. Deployed is not live. Probe the "
          "deployed URL after the deploy (curl -i / Invoke-WebRequest returning 2xx-3xx, or a real browser), then restate, "
          "or downgrade honestly (\"deployed, not verified live\").",
    "T2": "FLOW VERIFICATION GAP [Kai verification gate/T2]. You claimed: \"{u}\". {ev}. A page rendering does not prove "
          "the flow works. Drive the real flow (navigate + interact + read the resulting state in a browser, or hit the "
          "endpoint and show the 2xx/3xx plus Set-Cookie/redirect), then restate, or downgrade (\"flow not exercised\", "
          "DEFERRED: <why>).",
    "T3": "APPEARANCE VERIFICATION GAP [Kai verification gate/T3]. You claimed: \"{u}\". {ev}. A DOM read proves an element "
          "exists; only viewed pixels prove how it looks. Take a screenshot after the last frontend edit and look at it, "
          "then restate, or downgrade (\"placed, not pixel-viewed\").",
    "T4": "TEST CLAIM WITHOUT A TEST RUN [Kai verification gate/T4]. You claimed: \"{u}\", but no test run after the last "
          "code edit shows a pass in this turn's transcript. Run the tests and cite the output, or say \"tests not run\".",
    "TC": "UNVERIFIED COMPLETION [Kai verification gate/TC]. You claimed: \"{u}\" after editing code, but no verification "
          "tool call ran after the last edit (no test, run, build, probe, search, or read-back of the changed file). Check "
          "the change with a tool and cite the result, or say \"not verified\".",
    "TH": "FORBIDDEN HEDGE [Kai verification gate/TH]. You wrote: \"{u}\". \"Should work\" is not allowed: either verify it "
          "with a tool now and write \"verified\" with the evidence, or write \"not verified\" and say what would check it.",
}


def _evaluate_typed(t, ev):
    """(acted, verified, summary) for T1-T4 against this turn's events."""
    if t == "T1":
        n = sum(1 for e in ev if e["kind"] == "deploy")
        return had_deploy(ev), probed_after_deploy(ev), f"The transcript shows {n} deploy(s) and no probe of the deployed thing afterwards"
    if t == "T2":
        return (had_code_edit(ev) or had_deploy(ev)), flow_exercised(ev), \
            "The transcript shows no interaction and no successful endpoint round-trip after the last change"
    if t == "T3":
        return had_frontend_edit(ev), pixel_viewed(ev), "The transcript shows no screenshot viewed after the last frontend edit"
    return had_code_edit(ev), test_passed_after_edit(ev), ""


def evaluate(evt, tx=None):
    """Pure decision. Returns (decision|None, info). Never writes state.

    info = {"type", "unit", "fp", "decision": block|log|pass-*} for the caller to record.
    """
    info = {"decision": "skip"}
    if _env("KAI_VERIFY_GATE") in ("0", "off", "false"):
        return None, info
    if stop_active(evt):
        info["decision"] = "skip-recovery"
        return None, info
    sid = evt.get("sessionId", "") or "unknown"
    st = K.load_json(K.session_state(sid), {})
    try:
        cap = int(os.environ.get("KAI_VERIFY_MAX_BLOCKS", "3"))
    except ValueError:
        cap = 3
    if st.get("vg_blocks", 0) >= cap:
        info["decision"] = "pass-cap"
        return None, info
    if tx is None:
        tx = load_stop_transcript(evt)
    if not tx:
        info["decision"] = "pass-no-transcript"
        return None, info
    message = tx.get("final") or ""
    if not message.strip():
        info["decision"] = "pass-no-message"
        return None, info
    seen = set(st.get("vg_fps") or [])
    ev = tx["turn_events"]
    stripped = strip_noise(message)
    if HONEST_DOWNGRADE.search(stripped):
        info["decision"] = "pass-honest-downgrade"
        return None, info

    def candidate(t, unit, summary=""):
        fp = fingerprint(sid, t, unit)
        d = {"type": t, "unit": unit, "fp": fp}
        if fp in seen:
            d["decision"] = "pass-dedupe"
            return None, d
        mode = type_mode(t)
        if mode == "log":
            d["decision"] = "would-block-logonly"
            return None, d
        d["decision"] = "block"
        return {"decision": "block", "reason": BLOCK_MSGS[t].format(u=unit[:200], ev=summary)}, d

    agent = spawned_agent(ev)

    # TF: contradicted completion (more specific than any typed claim).
    if type_mode("TF") != "off" and not agent:
        u = contradicted_completion_unit(message, ev)
        if u:
            out, d = candidate("TF", u)
            if out or d["decision"] == "would-block-logonly":
                return out, d

    # T5: publicity. No act-then-claim and no subagent bypass; evidence is session-wide.
    if type_mode("T5") != "off":
        u = publicity_claim_unit(message)
        if u and not public_state_probed(tx["events"]):
            out, d = candidate("T5", u)
            if out or d["decision"] == "would-block-logonly":
                return out, d

    claim = classify_claim(message)
    if not claim or claim[0] == "T1":
        gu = generic_flow_unit(message)
        if gu and had_flow_edit(ev):
            claim = ("T2", gu)

    if agent:
        info.update({"decision": "pass-subagent", "type": claim[0] if claim else None})
        return None, info

    if claim and type_mode(claim[0]) != "off":
        did, verified, summary = _evaluate_typed(claim[0], ev)
        if did and not verified:
            out, d = candidate(claim[0], claim[1], summary)
            if out or d["decision"] == "would-block-logonly":
                return out, d

    # TC: generic completion claim over an unverified code edit.
    if type_mode("TC") != "off" and had_code_edit(ev) and not verified_after_code_edit(ev):
        u = completion_unit(message)
        if u:
            out, d = candidate("TC", u)
            if out or d["decision"] == "would-block-logonly":
                return out, d

    # TH: the forbidden "should work" hedge after doing work this turn.
    if type_mode("TH") != "off" and acted(ev):
        u = hedge_unit(message)
        if u:
            out, d = candidate("TH", u)
            if out or d["decision"] == "would-block-logonly":
                return out, d

    info["decision"] = "pass-no-gap" if claim else "no-claim"
    return None, info


def on_agent_stop(evt):
    out, info = evaluate(evt)
    sid = evt.get("sessionId", "") or "unknown"
    if info.get("decision") not in ("skip", "no-claim", "pass-no-message", "pass-no-transcript", "pass-no-gap"):
        gate_log({"gate": "verification", "session": sid, **{k: v for k, v in info.items() if k != "fp"}})
    if out:
        path = K.session_state(sid)
        st = K.load_json(path, {})
        st["vg_blocks"] = st.get("vg_blocks", 0) + 1
        st["vg_fps"] = ((st.get("vg_fps") or []) + [info["fp"]])[-100:]
        K.save_json(path, st)
        K.append_jsonl(K.EVENTS, {"ts": K.now_iso(), "event": "agentStop.verifyBlock", "session": sid,
                                  "type": info.get("type")})
    return out


HANDLERS = {"agentStop": on_agent_stop}
