# Kai as a GitHub Copilot plugin

This folder is the Kai plugin. It is also a one-plugin local marketplace named `kai-local`, so it installs with Copilot's own plugin commands. It is an alternative to `install.ps1`; pick one route, not both.

## Install

Python 3.8+ must be on PATH (`py` launcher or `python` on Windows, `python3` elsewhere). Unzip `kai-plugin-<version>.zip` somewhere permanent, then:

```
copilot plugin marketplace add C:\path\to\kai-plugin
copilot plugin install kai@kai-local
```

Copilot loads the plugin live from that folder; nothing is copied. Start a fresh session afterwards. To update, replace the folder's contents with a newer build and start a new session. To remove: `copilot plugin uninstall kai@kai-local` and `copilot plugin marketplace remove kai-local`. Your memory in `~/.copilot/kai/MEMORY` stays.

In the GitHub Copilot app, the same plugin appears under Customize -> Plugins once it is installed from the CLI. App-side plugin loading has not been verified by the Kai maintainers; the script installer is the verified route for the app.

## What the plugin route covers vs install.ps1

| Piece | install.ps1 / install.py | Plugin |
|---|---|---|
| Skills (`/algorithm`, `/isa`, ...) | `~/.copilot/skills/<name>` | Shipped in the plugin; same `/<name>` |
| Custom agents | `@kai-engineer` etc. | Namespaced by Copilot: `@kai:kai-engineer` etc. Kai is told this at session start |
| Hooks (all Kai events) | Inline in `~/.copilot/settings.json` | Plugin `hooks.json`, same events and timeouts, via `kai_plugin_hook.py` |
| Kai home (`~/.copilot/kai`: ALGORITHM, RULES, `bin/kai.py`) | Copied at install | Synced from the plugin on each new build, at the first sessionStart |
| MEMORY | Created at install, never deleted | Created on first hook run, never deleted |
| Constitution (`copilot-instructions.md`) | Merged into the file | Plugins cannot ship global instructions. The sessionStart hook injects the same Kai block as context, unless your file already carries it |
| Doctor (`kai.py doctor`) | Checks settings.json hooks, global instructions, `~/.copilot/skills` and `~/.copilot/agents` | Reports all four as missing in this route (they live in the plugin, not those files); the MEMORY and safety self-test checks still apply. Use `copilot plugin list` to confirm the plugin is enabled |
| Backups / uninstall restore | Yes | Not needed: the plugin writes only `~/.copilot/kai` |

Known limits of the plugin route:

- The constitution arrives as session-start context, not as a standing instruction file. Sessions resumed without a sessionStart event, and subagents, may not see it. If you want it always on, run the script installer instead, or paste the Kai block from `instructions/copilot-instructions.md` into `~/.copilot/copilot-instructions.md` (the plugin then stops injecting it).
- If both routes are installed, the plugin's hooks step aside (they detect Kai's inline hooks in settings.json), but skills and agents appear twice. Uninstall one.
- A Kai home created by the script installer (it has `manifest.json`) is never overwritten by the plugin.
