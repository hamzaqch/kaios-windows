"""Kai plugin hook launcher. Stdlib only, Python 3.8+.

Copilot runs this for every hook event when Kai is installed as a plugin:

    python kai_plugin_hook.py <eventName>   (event JSON on stdin)

It does four things, then hands the event to the bundled core engine
(kai/hooks/kai_hook.py) in-process:

1. Finds the Copilot home (COPILOT_HOME, else derived from COPILOT_PLUGIN_DATA
   or the plugin's install folder, else ~/.copilot).
2. Steps aside when the script installer (install.py / install.ps1) already
   registered Kai's hooks in settings.json, so no event is handled twice.
3. On sessionStart, syncs the bundled Kai runtime into <copilot home>/kai so the
   skills' `python ~/.copilot/kai/bin/kai.py ...` commands work. MEMORY is never
   touched. A Kai home owned by the script installer is never overwritten.
4. On sessionStart, injects Kai's constitution as additionalContext when the
   user's copilot-instructions.md does not carry the Kai block (plugins cannot
   ship global instructions), plus a note on the plugin's agent names.

It always exits 0: a missing or broken Kai must never deny tools (Copilot
treats a non-zero preToolUse exit as deny).
"""
import io
import json
import os
import runpy
import shutil
import sys
import time
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parent
BUNDLED = PLUGIN_ROOT / "kai"
CORE = BUNDLED / "hooks" / "kai_hook.py"
INSTRUCTIONS = PLUGIN_ROOT / "instructions" / "copilot-instructions.md"
BUILD_ID = PLUGIN_ROOT / "BUILD_ID"
MARKER = ".plugin-build"
BEGIN, END = "<!-- KAI:BEGIN", "<!-- KAI:END -->"
MEMORY_DIRS = ("WORK", "KNOWLEDGE", "LEARNING/sessions", "STATE/sessions", "OBSERVABILITY")
LOCK_STALE_SEC = 60
LOCK_WAIT_SEC = 5  # well under the 30s sessionStart timeout


def copilot_home():
    env = os.environ.get("COPILOT_HOME")
    if env:
        return Path(env).expanduser()
    data = os.environ.get("COPILOT_PLUGIN_DATA")
    if data:
        p = Path(data)
        for parent in p.parents:
            if parent.name == "plugin-data":
                return parent.parent
    for parent in PLUGIN_ROOT.parents:
        if parent.name == "installed-plugins":
            return parent.parent
    return Path.home() / ".copilot"


def installer_route_active(home):
    """True when settings.json already runs kai_hook.py inline (script-installer route)."""
    try:
        settings = json.loads((home / "settings.json").read_text(encoding="utf-8-sig"))
    except Exception:
        return False
    return "kai_hook.py" in json.dumps(settings.get("hooks") or {})


def build_id():
    try:
        return BUILD_ID.read_text(encoding="utf-8").strip()
    except Exception:
        return "unknown"


def _acquire(lock):
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
        return True
    except FileExistsError:
        try:
            if time.time() - lock.stat().st_mtime > LOCK_STALE_SEC:
                lock.unlink()
                return _acquire(lock)
        except Exception:
            pass
        return False
    except Exception:
        return False


def sync_runtime(kai_home):
    """Copy the bundled runtime into kai_home. Returns a short status string."""
    if not BUNDLED.is_dir():
        return "no-bundle"
    if (kai_home / "manifest.json").exists():
        return "installer-owned"  # the script installer manages this Kai home; leave it alone
    want = build_id()
    try:
        have = (kai_home / MARKER).read_text(encoding="utf-8").strip()
    except Exception:
        have = ""
    if have == want and (kai_home / "bin" / "kai.py").exists():
        ensure_memory(kai_home)
        return "current"
    kai_home.mkdir(parents=True, exist_ok=True)
    lock = kai_home / ".plugin-sync.lock"
    deadline = time.time() + LOCK_WAIT_SEC
    while not _acquire(lock):
        # another session is syncing; wait briefly so a first install still gets bin/kai.py
        if time.time() >= deadline:
            return "busy"
        time.sleep(0.2)
        try:
            if (kai_home / MARKER).read_text(encoding="utf-8").strip() == want:
                ensure_memory(kai_home)
                return "current"
        except Exception:
            pass
    try:
        for item in sorted(BUNDLED.iterdir()):
            if item.name in ("MEMORY", "__pycache__", "manifest.json"):
                continue
            dst = kai_home / item.name
            if item.is_dir():
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(item, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            else:
                shutil.copy2(item, dst)
        ensure_memory(kai_home)
        (kai_home / MARKER).write_text(want + "\n", encoding="utf-8")
        return "synced"
    finally:
        try:
            lock.unlink()
        except Exception:
            pass


def ensure_memory(kai_home):
    for d in MEMORY_DIRS:
        (kai_home / "MEMORY" / d).mkdir(parents=True, exist_ok=True)
    learn = kai_home / "MEMORY" / "LEARNING" / "learnings.md"
    if not learn.exists():
        learn.write_text("# Learnings\n\n", encoding="utf-8")


def constitution(home):
    """Kai block to inject, or '' when the user's instructions already carry it."""
    try:
        user = (home / "copilot-instructions.md").read_text(encoding="utf-8-sig")
    except Exception:
        user = ""
    if BEGIN in user:
        return ""
    try:
        text = INSTRUCTIONS.read_text(encoding="utf-8-sig")
    except Exception:
        return ""
    if BEGIN in text and END in text:
        text = text[text.index(BEGIN):text.index(END) + len(END)]
    return text.strip()


def agent_note():
    stems = sorted(p.name[:-len(".agent.md")] for p in (PLUGIN_ROOT / "agents").glob("*.agent.md"))
    if not stems:
        return ""
    names = ", ".join(f"kai:{s}" for s in stems)
    return ("# Kai plugin install\n\nKai is installed as a Copilot plugin, so its custom agents are "
            f"namespaced: {names}. Wherever Kai's rules or skills say @<agent>, use the namespaced "
            "name (for example @kai:kai-engineer, or `--agent kai:kai-engineer` on the command line).")


def run_core(event, kai_home, home):
    """Run kai_hook.py in-process; return what it wrote to stdout."""
    os.environ["KAI_HOME"] = str(kai_home)
    os.environ["COPILOT_HOME"] = str(home)
    hooks_dir = str(CORE.parent)
    if hooks_dir not in sys.path:
        sys.path.insert(0, hooks_dir)
    real_out, buf = sys.stdout, io.StringIO()
    old_argv = sys.argv
    sys.argv = [str(CORE), event]
    sys.stdout = buf
    try:
        runpy.run_path(str(CORE), run_name="__main__")
    except SystemExit:
        pass
    except Exception:
        pass
    finally:
        sys.stdout = real_out
        sys.argv = old_argv
    return buf.getvalue()


def write_out(text):
    if not text:
        return
    try:
        sys.stdout.buffer.write(text.encode("utf-8"))
        sys.stdout.flush()
    except Exception:
        sys.stdout.write(text)
        sys.stdout.flush()


def main(argv):
    event = argv[1] if len(argv) > 1 else ""
    home = copilot_home()
    if installer_route_active(home):
        return 0  # the inline settings.json hooks own Kai; do not double-handle
    kai_home = home / "kai"
    status = ""
    if event == "sessionStart":
        try:
            status = sync_runtime(kai_home)
        except Exception as exc:
            status = f"sync-error: {exc!r}"[:200]
    else:
        try:
            ensure_memory(kai_home)
        except Exception:
            pass
    out = run_core(event, kai_home, home) if CORE.exists() else ""
    if event == "sessionStart":
        try:
            obj = json.loads(out) if out.strip() else {}
        except Exception:
            obj = {}
        parts = [constitution(home), agent_note(), obj.get("additionalContext", "")]
        if status.startswith("sync-error"):
            parts.append(f"⚙️ SYSTEM: Kai plugin could not sync its runtime into {kai_home} ({status}).")
        ctx = "\n\n".join(p for p in parts if p)
        if ctx:
            obj["additionalContext"] = ctx
        out = json.dumps(obj, ensure_ascii=False) if obj else ""
    write_out(out)
    return 0


if __name__ == "__main__":
    try:
        main(sys.argv)
    except Exception:
        pass
    sys.exit(0)
