---
name: memory
description: Search and maintain Kai's long-term memory, which holds past sessions, task ISAs, knowledge notes and learnings. Use when the user says remember, recall, what did we do, last time, prior work, pick up where we left off, save this, note this down, or what do we know about X.
---
# Kai memory

Memory lives in `~/.copilot/kai/MEMORY/`:

| Folder | Holds |
|---|---|
| `WORK/<slug>/ISA.md` | task ISAs (the state of each piece of work) |
| `KNOWLEDGE/*.md` | durable facts, one note per topic |
| `LEARNING/learnings.md` | one-line lessons, also shown at session start |
| `LEARNING/sessions/YYYY-MM/*.md` | automatic per-session logs (prompts, tools, ISAs touched) |
| `OBSERVABILITY/events.jsonl` | hook event log |

Commands:
- Search: `python ~/.copilot/kai/bin/kai.py memory search "<terms>"` matches all terms, newest first.
- Save a fact: `python ~/.copilot/kai/bin/kai.py memory add "<topic>" "<content>"`
- Save a lesson: `python ~/.copilot/kai/bin/kai.py learn "<lesson>"`

**To recall:** search first, read the best hits, and answer with file references. If nothing matches, say so. Never invent past work.

**To save:** keep the fact, not the conversation. Never store secrets, credentials or other people's private data.
