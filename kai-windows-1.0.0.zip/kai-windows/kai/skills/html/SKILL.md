---
name: html
description: "Render the session's output (analysis, research, red team, report, plan, comparison) as one well-designed, self-contained HTML file through a deterministic renderer: Kai distills the content into typed JSON and picks a design register; the tool owns all layout, typography and color. Three registers: dossier (dark green and orange, for evidence and investigations), ledger (dark navy and gold, for reports and plans), broadsheet (light paper and red, for printable briefs). Zero external requests, opens offline. Use when the user says /html, HTML artifact, render this as HTML, make this a web page, make a shareable page of this, export this report as HTML, designed HTML output, or a printable version of this analysis. NOT FOR building websites, apps or UI components (use /webdesign), diagrams on a canvas (use /tldraw), or producing the analysis itself (run the analysis first, then /html renders it)."
argument-hint: "[register] [output path]"
---
# HTML

Turns what the session already produced into one designed HTML file. The split is deliberate: Kai's only jobs are distilling the content into the typed JSON the renderer accepts and choosing a register. `tools/render.py` decides every pixel, so outputs stay consistent and nothing is hand-styled.

**Done looks like:** one `.html` file on disk containing the session's actual content (verbatim quotes still verbatim, sources and confidence flags preserved), produced by `render.py` from a content JSON, opened for the user, with the path and a one-line description in the reply.

## Routing

| Workflow | Trigger | File |
|---|---|---|
| Render | `/html`, "HTML artifact", "render this as HTML" | `Workflows/Render.md` |

## Tool contract

```
python ~/.copilot/skills/html/tools/render.py --schema                     # complete content JSON example
python ~/.copilot/skills/html/tools/render.py --registers                  # registers and when to use each
python ~/.copilot/skills/html/tools/render.py --check content.json         # validate only
python ~/.copilot/skills/html/tools/render.py --json content.json --register ledger --out report.html [--open]
```

Block types: `prose`, `callout`, `quote` (id, badge, quote/text, note, source), `list` (bold lead-ins), `cut` (struck-through rejected claim with a stamp), `table`, `group` (era or category separator). Badges named in the register's solid list render filled; others outlined. `prose`, `callout`, `text`, `note`, `source` and table cells accept inline HTML; titles, quotes, labels and stamps are escaped.

## Gotchas

- **Never add CSS counters or `::before` labels.** Screenshot pipelines and text extraction drop pseudo-element content, so section numbers are emitted as real text. If content does not fit the block types, extend `render.py` (a new block type or register) instead of hand-writing CSS, so the next run benefits.
- **No web fonts.** A Google Fonts link breaks offline viewing and leaks a request. The renderer embeds a font as a data URI only when the file exists locally (for example Anton in `C:\Windows\Fonts`), otherwise it uses system stacks that look right on Windows (Segoe UI, Consolas, Palatino Linotype).
- **Numbered markers must mean something.** Sections are numbered in document order. Don't number list items unless they are a true sequence; use `list` blocks with bold lead-ins.
- **Write the JSON to a file, then pass the path.** PowerShell's quoting mangles inline JSON; `--json -` reads stdin if piping is easier.
- **Rotate registers.** Consecutive artifacts in the same register converge into a house style; if the last one this week was dossier, pick another unless the content clearly calls for it.
