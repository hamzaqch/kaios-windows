# Render

Turn the current session's output into a rendered, opened HTML file.

## Sufficiency check

If the session contains nothing substantive to render (no analysis, research or deliverable yet), say so and ask what to render. Never invent content to fill the page. If several outputs could be meant, pick the most recent substantial one and say so in one line (`Rendering the vendor comparison, not the earlier notes; redirect if wrong.`).

## Ideal state

- The page carries the real content: verbatim quotes kept verbatim, every source kept, confidence tags (`[HIGH]`, `VERIFIED`, ...) kept as badges.
- Structure follows the content, not a template: a verdict or bottom line goes in `summary`; evidence goes in `quote` blocks with ids; rejected or unverified claims that were disclosed go in `cut` blocks; comparisons go in `table`.
- Rendered by `render.py`. No hand-authored HTML or CSS.

## Register choice

| Content | Register |
|---|---|
| Evidence file, red team, investigation, claim testing | `dossier` |
| Report, plan, comparison, metrics, finance | `ledger` |
| Printable brief, explainer, how-to, anything that should be light | `broadsheet` |
| Same register as the previous artifact this week | pick a different one |

## Steps

1. `render.py --schema` if you need the exact shape. Write the content JSON to a file next to where the page will live.
2. `render.py --check <content.json>` and fix every reported problem.
3. Render: `render.py --json <content.json> --register <name> --out <path>.html --open`.
   - Output location: the user's named path; otherwise the active task folder (`~/.copilot/kai/MEMORY/WORK/<slug>/`) if there is one; otherwise the current working directory.
   - `--open` launches the default browser. On Windows you can also run `Start-Process "<path>.html"`.
4. Verify before handing over:
   - The renderer printed the output path and size (proof the file was written).
   - Read the HTML back with the view tool and confirm the summary, every section title and a sample of quotes are present and correctly escaped.
   - If a browser or screenshot tool is available in this session, capture the page and look at it. If not, say plainly "rendered and structurally checked; open it to eyeball the layout". Never say it looks good without having seen pixels.
5. Reply with the file path, the register used, and one line on what the page contains.

## Hosts that wrap HTML

Some viewers wrap a file in their own document skeleton and reject `<!doctype>`/`<html>` tags. For those, pass `--fragment` to emit only `<title>`, `<style>` and the body content.
