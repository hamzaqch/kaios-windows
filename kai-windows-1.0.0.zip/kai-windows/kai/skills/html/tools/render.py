"""render.py - deterministic HTML renderer: typed content JSON -> one self-contained HTML file.

The model's job ends at the JSON. Layout, typography, color, spacing and numbering
are decided here, so every artifact is consistent and nothing is hand-styled.
Output makes zero external requests: inline CSS, optional @font-face data URIs
from font files already on this machine, system font stacks otherwise.

  python render.py --json content.json [--register dossier|ledger|broadsheet] [--out artifact.html]
                   [--fragment] [--open]
  python render.py --schema         print the content JSON shape (a complete example)
  python render.py --registers      list registers
  python render.py --check content.json   validate only (exit 0 valid, 2 invalid)

--fragment  emit <title>+<style>+body content only (for hosts that wrap the file
            in their own document skeleton); default is a complete HTML document.
--open      open the result in the default browser when done.

Numbering rule: all numbers and labels are REAL DOM TEXT, never CSS counters,
because DOM-render screenshot pipelines and text extraction drop pseudo-element content.
"""
import base64
import html
import json
import os
import sys
import webbrowser
from pathlib import Path

BLOCK_TYPES = ("prose", "callout", "quote", "list", "cut", "table", "group")

REGISTERS = {
    "dossier": {
        "use": "evidence files, red teams, investigations, claim testing",
        "vars": {"ink": "#0d1712", "panel": "#121f17", "line": "#26382c", "fg": "#f2ede2", "dim": "#c6c0b1",
                 "accent": "#f58220", "accent2": "#7d9fc4", "danger": "#d0654a"},
        "display": "Anton, 'Bahnschrift Condensed', 'Arial Narrow', 'Avenir Next Condensed', sans-serif",
        "body": "'Segoe UI', 'Avenir Next', 'Helvetica Neue', system-ui, sans-serif",
        "mono": "Consolas, 'Cascadia Mono', 'Courier New', monospace",
        "embed": [("Anton", ["Anton-Regular.ttf"])],
        "solid": ["VERIFIED"],
        "upper": True,
    },
    "ledger": {
        "use": "reports, plans, comparisons, metrics, finance",
        "vars": {"ink": "#101623", "panel": "#161e30", "line": "#2a3550", "fg": "#dce6f2", "dim": "#9fb0c8",
                 "accent": "#d9a441", "accent2": "#6fbf9f", "danger": "#c96f6f"},
        "display": "'Iowan Old Style', 'Palatino Linotype', Palatino, 'Book Antiqua', Georgia, serif",
        "body": "'Segoe UI', 'Avenir Next', 'Helvetica Neue', system-ui, sans-serif",
        "mono": "'Cascadia Mono', Consolas, 'SF Mono', Menlo, monospace",
        "embed": [],
        "solid": ["VERIFIED", "CONFIRMED"],
        "upper": True,
    },
    "broadsheet": {
        "use": "light-background explainers, briefs, how-tos, anything meant to be printed",
        "vars": {"ink": "#f4efe4", "panel": "#ebe4d4", "line": "#cfc5b0", "fg": "#1d1a14", "dim": "#5a5243",
                 "accent": "#a3261c", "accent2": "#1f5f7a", "danger": "#a3261c"},
        "display": "'Georgia Pro', Georgia, 'Times New Roman', serif",
        "body": "Charter, 'Bitstream Charter', Cambria, Georgia, serif",
        "mono": "'Cascadia Mono', Consolas, Menlo, monospace",
        "embed": [],
        "solid": ["VERIFIED", "CONFIRMED", "FACT"],
        "upper": False,
    },
}


def font_dirs():
    dirs = []
    win = os.environ.get("WINDIR") or os.environ.get("SystemRoot")
    if win:
        dirs.append(Path(win) / "Fonts")
    local = os.environ.get("LOCALAPPDATA")
    if local:
        dirs.append(Path(local) / "Microsoft" / "Windows" / "Fonts")
    home = Path.home()
    dirs += [home / "Library" / "Fonts", Path("/Library/Fonts"), Path("/System/Library/Fonts/Supplemental"),
             home / ".local" / "share" / "fonts", home / ".fonts", Path("/usr/share/fonts/truetype")]
    return dirs


EXAMPLE = {
    "title": "Was the Claim True?",
    "eyebrow": "A red team of one claim · evidence brief",
    "subtitle": "The claim under test, with verbatim sourced quotes both ways.",
    "summary": {"label": "Verdict", "html": "<b>False on the letter.</b> Survives only as a definitional argument."},
    "sections": [
        {
            "title": "The evidence",
            "intro": "Optional one-paragraph framing for the section.",
            "blocks": [
                {"type": "group", "label": "Early years", "detail": "1975-1982"},
                {"type": "quote", "id": "E1", "badge": "VERIFIED", "quote": "An example verbatim quote.",
                 "text": "Optional HTML commentary.", "note": "Optional note.", "source": "Source, date"},
                {"type": "list", "items": [{"lead": "Lead-in.", "text": "Supporting sentence (HTML allowed)."}]},
                {"type": "cut", "stamp": "UNVERIFIED", "quote": "A famous quote that failed verification.",
                 "note": "Why it was cut."},
                {"type": "table", "headers": ["Option", "Cost", "Risk"], "rows": [["A", "$10", "Low"]]},
                {"type": "callout", "html": "<p>A highlighted aside.</p>"},
                {"type": "prose", "html": "<p>Free-form paragraphs.</p>"},
            ],
        }
    ],
    "footer": "Method note.",
    "accentLastWord": True,
    "numberedSections": True,
}


def esc(s):
    return html.escape(str(s if s is not None else ""), quote=True)


# ---------------------------------------------------------------- validation

def validate(doc):
    """-> list of human-readable problems (empty when valid)."""
    errs = []
    if not isinstance(doc, dict):
        return ["top level must be a JSON object"]
    if not isinstance(doc.get("title"), str) or not doc["title"].strip():
        errs.append("title: required non-empty string")
    secs = doc.get("sections")
    if not isinstance(secs, list) or not secs:
        errs.append("sections: required non-empty array")
        return errs
    if "summary" in doc and not (isinstance(doc["summary"], dict) and isinstance(doc["summary"].get("html"), str)):
        errs.append("summary: must be {label?, html}")
    for i, s in enumerate(secs):
        where = f"sections[{i}]"
        if not isinstance(s, dict) or not isinstance(s.get("title"), str):
            errs.append(f"{where}.title: required string")
            continue
        blocks = s.get("blocks")
        if not isinstance(blocks, list):
            errs.append(f"{where}.blocks: required array")
            continue
        for j, b in enumerate(blocks):
            w = f"{where}.blocks[{j}]"
            t = b.get("type") if isinstance(b, dict) else None
            if t not in BLOCK_TYPES:
                errs.append(f"{w}.type: must be one of {', '.join(BLOCK_TYPES)} (got {t!r})")
                continue
            if t in ("prose", "callout") and not isinstance(b.get("html"), str):
                errs.append(f"{w}: {t} needs html")
            if t == "group" and not isinstance(b.get("label"), str):
                errs.append(f"{w}: group needs label")
            if t == "quote" and not any(isinstance(b.get(k), str) for k in ("quote", "text")):
                errs.append(f"{w}: quote needs quote or text")
            if t == "cut" and not all(isinstance(b.get(k), str) for k in ("stamp", "quote", "note")):
                errs.append(f"{w}: cut needs stamp, quote and note")
            if t == "list":
                items = b.get("items")
                if not isinstance(items, list) or not all(
                        isinstance(it, dict) and "lead" in it and "text" in it for it in items):
                    errs.append(f"{w}: list needs items[] of {{lead, text}}")
            if t == "table":
                hs, rows = b.get("headers"), b.get("rows")
                if not isinstance(hs, list) or not isinstance(rows, list):
                    errs.append(f"{w}: table needs headers[] and rows[][]")
                elif any(not isinstance(r, list) or len(r) != len(hs) for r in rows):
                    errs.append(f"{w}: every table row needs exactly {len(hs)} cells")
    return errs


# ---------------------------------------------------------------- css

def font_face(reg):
    css = []
    for family, files in reg["embed"]:
        for fname in files:
            hit = next((d / fname for d in font_dirs() if (d / fname).is_file()), None)
            if hit:
                b64 = base64.b64encode(hit.read_bytes()).decode("ascii")
                fmt = "opentype" if fname.lower().endswith(".otf") else "truetype"
                mime = "font/otf" if fmt == "opentype" else "font/ttf"
                css.append(f"@font-face{{font-family:'{family}';src:url(data:{mime};base64,{b64}) "
                           f"format('{fmt}');font-display:swap}}")
                break
    return "\n".join(css)


def css(reg):
    v = reg["vars"]
    up = "uppercase" if reg["upper"] else "none"
    h1_size = "clamp(42px,9vw,72px)" if reg["upper"] else "clamp(38px,7vw,60px)"
    return f"""{font_face(reg)}
:root{{--ink:{v['ink']};--panel:{v['panel']};--line:{v['line']};--fg:{v['fg']};--dim:{v['dim']};--accent:{v['accent']};--accent2:{v['accent2']};--danger:{v['danger']}}}
*{{box-sizing:border-box}}
html{{background:var(--ink)}}
body{{background:var(--ink);color:var(--fg);font-family:{reg['body']};line-height:1.6;font-size:16px;margin:0}}
a{{color:var(--accent2)}}
.page{{max-width:760px;margin:0 auto;padding:64px 20px 80px}}
.eyebrow{{font-family:{reg['mono']};font-size:12px;letter-spacing:.3em;text-transform:uppercase;color:var(--accent);margin:0 0 14px}}
h1{{font-family:{reg['display']};font-weight:400;font-size:{h1_size};line-height:.98;text-transform:{up};margin:0 0 10px;text-wrap:balance}}
h1 .acc{{color:var(--accent)}}
.subtitle{{color:var(--dim);max-width:56ch;margin:0 0 40px}}
h2{{font-family:{reg['display']};font-weight:400;font-size:27px;text-transform:{up};letter-spacing:.02em;margin:54px 0 6px;text-wrap:balance}}
h2 .n{{color:var(--accent);font-family:{reg['mono']};font-size:16px;margin-right:10px}}
.rule{{height:1px;background:var(--line);border:0;margin:0 0 20px}}
.intro{{color:var(--dim);max-width:60ch;margin:0 0 22px}}
.slab{{background:var(--panel);border:1px solid var(--line);border-left:5px solid var(--accent);padding:22px 26px;margin:0 0 8px}}
.slab p{{margin:0}}
.slab b,.slab strong{{color:var(--accent)}}
.callout{{background:var(--panel);border:1px solid var(--line);border-left:5px solid var(--accent2);padding:20px 24px;margin:14px 0}}
.callout p{{margin:0 0 10px}}.callout p:last-child{{margin:0}}
.group{{font-family:{reg['mono']};font-size:12px;letter-spacing:.24em;text-transform:uppercase;color:var(--dim);margin:28px 0 6px}}
.group b{{color:var(--fg)}}
.ex{{display:grid;grid-template-columns:74px 1fr;gap:18px;border-top:1px solid var(--line);padding:17px 0}}
.ex:last-child{{border-bottom:1px solid var(--line)}}
.ex .id{{font-family:{reg['mono']};font-size:12px;letter-spacing:.08em;color:var(--accent);padding-top:3px}}
.ex .id .badge{{display:inline-block;margin-top:6px}}
.badge{{font-family:{reg['mono']};font-size:10px;letter-spacing:.12em;padding:2px 6px;color:var(--dim);border:1px solid var(--dim);border-radius:2px}}
.badge.solid{{background:var(--accent);color:var(--ink);border-color:var(--accent);font-weight:700}}
.ex p{{margin:0 0 6px}}
.ex .q{{font-family:{reg['mono']};font-size:14.5px}}
.ex .q .om{{color:var(--accent)}}
.ex .src{{font-size:12.5px;color:var(--dim)}}
ul.lead{{list-style:none;margin:0;padding:0}}
ul.lead li{{padding:13px 0;border-top:1px solid var(--line)}}
ul.lead li:last-child{{border-bottom:1px solid var(--line)}}
ul.lead p{{margin:0;font-size:15px;color:var(--dim)}}
ul.lead b{{color:var(--fg)}}
.cut{{display:grid;grid-template-columns:110px 1fr;gap:16px;padding:15px 0;border-top:1px solid var(--line)}}
.cut:last-child{{border-bottom:1px solid var(--line)}}
.cut .stamp{{font-family:{reg['mono']};color:var(--danger);border:2px solid var(--danger);font-size:11px;letter-spacing:.14em;font-weight:700;padding:4px 6px;text-align:center;align-self:start;transform:rotate(-3deg)}}
.cut .q{{font-family:{reg['mono']};font-size:14px;color:var(--dim);text-decoration:line-through;text-decoration-thickness:2px}}
.cut p{{margin:6px 0 0;font-size:13.5px;color:var(--dim)}}
.tablewrap{{overflow-x:auto;margin:14px 0}}
table{{border-collapse:collapse;width:100%;font-size:14.5px}}
th{{font-family:{reg['mono']};font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--dim);text-align:left;padding:8px 14px 8px 0;border-bottom:1px solid var(--fg)}}
td{{padding:9px 14px 9px 0;border-bottom:1px solid var(--line);vertical-align:top;font-variant-numeric:tabular-nums}}
.prose{{max-width:62ch}}.prose p{{margin:0 0 12px}}
.foot{{margin-top:52px;color:var(--dim);font-size:13px;border-top:1px solid var(--line);padding-top:16px}}
@media(max-width:560px){{.ex{{grid-template-columns:1fr;gap:6px}}.cut{{grid-template-columns:1fr}}.cut .stamp{{justify-self:start}}.slab{{padding:18px}}}}
@media print{{html,body{{background:#fff;color:#000}}.page{{padding:0}}}}""".strip()


# ---------------------------------------------------------------- blocks

def render_block(b, reg):
    t = b["type"]
    if t == "prose":
        return f'<div class="prose">{b["html"]}</div>'
    if t == "callout":
        return f'<div class="callout">{b["html"]}</div>'
    if t == "group":
        detail = f" · {esc(b['detail'])}" if b.get("detail") else ""
        return f'<p class="group"><b>{esc(b["label"])}</b>{detail}</p>'
    if t == "quote":
        badge = ""
        if b.get("badge"):
            solid = " solid" if str(b["badge"]).upper() in reg["solid"] else ""
            badge = f'<br><span class="badge{solid}">{esc(b["badge"])}</span>'
        body = (f'<p class="q"><span class="om">“</span>{esc(b["quote"])}<span class="om">”</span></p>'
                if b.get("quote") else "")
        text = f'<p>{b["text"]}</p>' if b.get("text") else ""
        note = f'<p class="src">{b["note"]}</p>' if b.get("note") else ""
        src = f'<p class="src">{b["source"]}</p>' if b.get("source") else ""
        return f'<div class="ex"><div class="id">{esc(b.get("id", ""))}{badge}</div><div>{body}{text}{note}{src}</div></div>'
    if t == "list":
        items = "".join(f'<li><p><b>{esc(i["lead"])}</b> {i["text"]}</p></li>' for i in b["items"])
        return f'<ul class="lead">{items}</ul>'
    if t == "cut":
        return (f'<div class="cut"><div class="stamp">{esc(b["stamp"])}</div><div><span class="q">'
                f'“{esc(b["quote"])}”</span><p>{b["note"]}</p></div></div>')
    if t == "table":
        head = "".join(f"<th>{esc(h)}</th>" for h in b["headers"])
        rows = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in b["rows"])
        return f'<div class="tablewrap"><table><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table></div>'
    raise ValueError(f"unknown block type {t}")


def render(doc, reg, fragment=False):
    words = doc["title"].strip().split()
    last = words.pop() if doc.get("accentLastWord", True) and len(words) > 1 else None
    h1 = esc(" ".join(words)) + (f' <span class="acc">{esc(last)}</span>' if last else "")
    numbered = doc.get("numberedSections", True)
    secs = []
    for i, s in enumerate(doc["sections"]):
        n = f'<span class="n">{i + 1:02d}</span>' if numbered else ""
        intro = f'<p class="intro">{s["intro"]}</p>' if s.get("intro") else ""
        blocks = "\n".join(render_block(b, reg) for b in s["blocks"])
        secs.append(f'<section><h2>{n}{esc(s["title"])}</h2><hr class="rule">{intro}{blocks}</section>')
    summary = ""
    if doc.get("summary"):
        lab = doc["summary"].get("label")
        lab_html = f'<p class="eyebrow" style="margin-bottom:8px">{esc(lab)}</p>' if lab else ""
        summary = f'<div class="slab">{lab_html}<p>{doc["summary"]["html"]}</p></div>'
    body = "\n".join(x for x in [
        '<div class="page">',
        f'<p class="eyebrow">{esc(doc["eyebrow"])}</p>' if doc.get("eyebrow") else "",
        f"<h1>{h1}</h1>",
        f'<p class="subtitle">{doc["subtitle"]}</p>' if doc.get("subtitle") else "",
        summary,
        "\n".join(secs),
        f'<p class="foot">{doc["footer"]}</p>' if doc.get("footer") else "",
        "</div>",
    ] if x)
    if fragment:
        return f"<title>{esc(doc['title'])}</title>\n<style>\n{css(reg)}\n</style>\n{body}\n"
    return ("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
            f"<title>{esc(doc['title'])}</title>\n<style>\n{css(reg)}\n</style>\n</head>\n<body>\n"
            f"{body}\n</body>\n</html>\n")


# ---------------------------------------------------------------- cli

def flag(args, name, default=None):
    if name in args:
        i = args.index(name)
        if i + 1 < len(args):
            return args[i + 1]
    return default


def load_doc(path):
    # stdin as bytes: a Windows console/pipe would otherwise decode with the ANSI code page
    raw = sys.stdin.buffer.read().decode("utf-8-sig") if path == "-" else Path(path).read_text(encoding="utf-8-sig")
    return json.loads(raw)


def main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    if "--schema" in argv:
        print(json.dumps(EXAMPLE, indent=2, ensure_ascii=False))
        return 0
    if "--registers" in argv:
        for name, reg in REGISTERS.items():
            print(f"{name:11} {reg['use']}")
        return 0
    src = flag(argv, "--check") or flag(argv, "--json")
    if not src:
        sys.stderr.write("usage: render.py --json <content.json> [--register NAME] [--out FILE] | --schema | --registers\n")
        return 2
    try:
        doc = load_doc(src)
    except (OSError, ValueError) as e:
        sys.stderr.write(f"cannot read content JSON: {e}\n")
        return 2
    errs = validate(doc)
    if errs:
        sys.stderr.write("invalid content JSON (run --schema for an example):\n  " + "\n  ".join(errs) + "\n")
        return 2
    if "--check" in argv:
        print("valid")
        return 0
    reg_name = flag(argv, "--register", "dossier")
    reg = REGISTERS.get(reg_name)
    if not reg:
        sys.stderr.write(f'unknown register "{reg_name}". Available: {", ".join(REGISTERS)}\n')
        return 2
    out = Path(flag(argv, "--out", "artifact.html"))
    page = render(doc, reg, fragment="--fragment" in argv)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(page, encoding="utf-8")
    fonts = "+".join(f for f, _ in reg["embed"]) if "@font-face" in page else "system"
    print(f"{out.resolve()} ({max(1, round(len(page.encode('utf-8')) / 1024))}KB, register={reg_name}, fonts={fonts})")
    if "--open" in argv:
        webbrowser.open(out.resolve().as_uri())
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
