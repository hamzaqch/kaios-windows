# Scan: discover skill gaps from work history and frustration

Read-only. Proposes only. Never creates a skill; that is /create-skill, after the user approves.

## Step 0: sufficiency check

The corpus is the context. If the tool reports the ratings store missing and few frustration markers, say the frustration signal is thin for this run rather than presenting a topic-only result as complete. If the user asked about a specific domain ("am I missing anything around deploys?"), scope the clustering to it and say so.

## Step 1: gather deterministically

```
python "$HOME/.copilot/skills/suggest-skills/tools/collect_signals.py" --days 45 > "$env:TEMP\skill-scan-corpus.json"      # PowerShell
python "$HOME/.copilot/skills/suggest-skills/tools/collect_signals.py" --days 45 > /tmp/skill-scan-corpus.json              # bash
```

| User says | Flag |
|---|---|
| (default), recently, lately | `--days 45` |
| this quarter, last few months | `--days 90` |
| all time, everything | `--days 3650` |
| only the really bad ones | `--max-rating 2` (ratings) and weight recurrence markers |
| don't read my transcripts | `--no-transcripts` |
| a skills tree somewhere else | `--skills <dir>` (repeatable) |
| a ratings file somewhere else | `--ratings <file>` |

Read `warnings` and `missing` first. Don't re-gather by hand.

## Step 2: cluster by pain

Group `work` goals, `prompts`, `frustrations`, `learnings`, `tool_failures` and `gate_events` into recurring themes. For each theme carry two numbers: **recurrence** (sessions or ISAs touching it) and **friction** (frustration markers, recurrence-class markers, low ratings, repeated tool failures). Friction outweighs raw frequency.

## Step 3: classify each cluster

- **BEHAVIOUR-FEEDBACK:** verbosity, scope misreads, reminder cadence. Not a skill; route to memory or instructions. Exclude.
- **COVERED:** an existing skill, workflow or agent genuinely handles the discipline. Confirm by reading the covering file's body (the `path` in `registries`), not its name, and map the specific failure to explicit guidance in it. If the body doesn't address the failure, it isn't covered.
- **GAP:** recurs (severity-weighted) and is uncovered, including a discipline gap under a topic a skill nominally covers.

## Step 4: verify with two independent passes, report the union

Run two parallel `task` subagents (for example `@kai-reviewer` and `@kai-deep-analyst`) that classify the clusters from the same corpus file without seeing each other's answer. Report every cluster either one flags as GAP, tagged `both` (high confidence) or `one` (needs review). Don't drop single-pass gaps; strict intersection hides the subtle discipline gaps this exists to find.

## Step 5: propose, never create

A ranked shortlist. Each proposal: a kebab-case name, a one-line description, and evidence (recurrence, friction, the specific recurring failure it would prevent, two or three redacted example prompts). Accepted proposals go to /create-skill as a separate, approved step. This workflow writes no skill.

## Output

```
## Skill-gap scan (last N days: W ISAs, S sessions, P prompts; frustration signal: strong | thin | absent)
### Gaps worth building
- <name> [confidence: both|one]: <description>. Evidence: N sessions, K frustration signals, recurring failure = "<...>". Build with /create-skill?
### Covered (verified against bodies, no action)
- <theme> -> <skill/workflow/agent>
### Behaviour feedback (route to memory, not a skill)
- <theme>
### Recommendation
<1-2 sentences; "nothing new" is valid only when the frustration signals are also clean>
```
