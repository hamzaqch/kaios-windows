"""collect_signals: deterministic, read-only signal collector for skill-gap discovery (stdlib only).

Emits one normalized JSON corpus on stdout so the model only clusters and judges;
it never gathers by hand. Over unchanged stores it is deterministic (fully
tie-broken ordering). It writes nothing.

Sources (each optional; missing stores are reported, never fatal):
  - Kai task work:      <kai>/MEMORY/WORK/<slug>/ISA.md (goal, phase, claims)
  - Kai session logs:   <kai>/MEMORY/LEARNING/sessions/YYYY-MM/*.md (prompts per session)
  - Kai learnings:      <kai>/MEMORY/LEARNING/learnings.md (one-line lessons)
  - ratings (opt-in):   <kai>/MEMORY/LEARNING/SIGNALS/ratings.jsonl  {rating, timestamp, sentiment_summary}
  - Kai hook events:    <kai>/MEMORY/OBSERVABILITY/events.jsonl (tool failures, safety-gate hits, format blocks)
  - Copilot transcripts: <copilot>/session-state/*/events.jsonl (user messages; --no-transcripts to skip)
  - registries:         skills (<copilot>/skills, ./.github/skills), their Workflows/, custom agents

Frustration is a first-class signal: prompts are scanned for frustration and
recurrence markers ("again", "still broken", "same error", "I told you").

    python collect_signals.py [--days 45] [--max-rating 4] [--kai-home DIR] [--copilot-home DIR]
                              [--skills DIR]... [--ratings FILE] [--no-transcripts] [--max-prompts 400]
Env: KAI_HOME, COPILOT_HOME, SKILLSCAN_RATINGS_FILE. Exit 0 even when stores are missing.
"""
import argparse
import datetime as _dt
import json
import os
import re
import sys
from pathlib import Path

MAX_FILE_BYTES = 8_000_000
MAX_TEXT = 400
FRUSTRATION = [
    ("again", r"\bagain\b"), ("still-broken", r"\bstill (not|broken|failing|wrong|doesn'?t|isn'?t|the same)\b"),
    ("doesnt-work", r"\b(doesn'?t|does not|didn'?t|isn'?t|not) work(ing)?\b"), ("wrong", r"\b(wrong|incorrect)\b"),
    ("not-what-i-asked", r"\b(that'?s not what|not what i (asked|meant|wanted))\b"),
    ("i-told-you", r"\b(i (said|told you|already said|asked you)|as i said)\b"), ("why-did-you", r"\bwhy did you\b"),
    ("stop", r"^\s*(stop|no[,.!]|nope)\b"), ("swear", r"\b(wtf|ffs|ugh|damn|dammit)\b"),
    ("frustrated", r"\b(frustrat\w*|annoy\w*|ridiculous|useless)\b"), ("regressed", r"\b(regress\w*|broke(n)? again)\b"),
    ("keeps", r"\bkeeps? (failing|breaking|happening|doing|crashing)\b"),
    ("same-problem", r"\b(same (error|issue|problem|bug|mistake))\b"), ("undo", r"\b(undo|revert|roll ?back) (that|this|it)\b"),
]
EVAL_MARKERS = ("[EVALUATION CONTEXT]", "You are a strict, fair evaluator", "You are a strict assertion checker",
                "You compare two AI OUTPUTS", "You are simulating a USER", "You author ONE assertion-first eval case",
                "<system_instructions>")
RECURRENCE = {"again", "still-broken", "regressed", "keeps", "same-problem", "i-told-you"}
REDACT = [
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"), "<email>"),
    (re.compile(r"(?i)\b(gh[pousr]_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9_-]{20,}|xox[abp]-[A-Za-z0-9-]{10,}|AKIA[0-9A-Z]{16})\b"), "<secret>"),
    (re.compile(r"\b[A-Fa-f0-9]{32,}\b"), "<hex>"),
    (re.compile(r"(?i)\b(password|passwd|token|api[_-]?key|secret)\s*[:=]\s*\S+"), r"\1=<redacted>"),
    (re.compile(r"(?i)[A-Z]:\\Users\\[^\\\s]+"), r"%USERPROFILE%"),
    (re.compile(r"/(home|Users)/[^/\s]+"), "~"),
]


def redact(text, n=MAX_TEXT):
    t = re.sub(r"[\u0000-\u0008\u000b-\u001f\u007f]", " ", str(text or ""))
    for rx, rep in REDACT:
        t = rx.sub(rep, t)
    t = re.sub(r"\s+", " ", t).strip()
    return t[:n]


def markers(text):
    low = (text or "").lower()
    return [name for name, rx in FRUSTRATION if re.search(rx, low, re.M)]


def parse_ts(s):
    if not isinstance(s, str) or not s:
        return None
    try:
        return _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None


def as_utc(d):
    if d.tzinfo is None:
        d = d.astimezone()
    return d.astimezone(_dt.timezone.utc)


def mtime_utc(p):
    return _dt.datetime.fromtimestamp(p.stat().st_mtime, tz=_dt.timezone.utc)


def safe_read(p, warnings, label):
    try:
        if p.stat().st_size > MAX_FILE_BYTES:
            warnings.append(f"{label}: {p.name} too large ({p.stat().st_size} bytes), skipped")
            return None
        return p.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        warnings.append(f"{label}: unreadable {p.name}: {exc}")
        return None


def frontmatter(text):
    m = re.match(r"^﻿?---\s*\n(.*?)\n---", text or "", re.S)
    out = {}
    if not m:
        return out
    lines = m.group(1).splitlines()
    for i, line in enumerate(lines):
        if ":" in line and not line.startswith((" ", "\t")):
            k, v = line.split(":", 1)
            v = v.strip()
            if re.match(r"^[>|][+-]?$", v):
                cont = []
                for nxt in lines[i + 1:]:
                    if re.match(r"^\s+\S", nxt):
                        cont.append(nxt.strip())
                    else:
                        break
                v = " ".join(cont)
            out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def collect_work(kai, since, warnings, missing):
    d = kai / "MEMORY" / "WORK"
    if not d.is_dir():
        missing.append("work")
        return []
    out = []
    for sub in sorted(d.iterdir()):
        if not sub.is_dir() or sub.name.startswith((".", "_")):
            continue
        try:
            mt = mtime_utc(sub)
            isa = sub / "ISA.md"
            if isa.exists():
                mt = max(mt, mtime_utc(isa))
        except OSError:
            continue
        if mt < since:
            continue
        row = {"slug": sub.name, "date": mt.date().isoformat(), "goal": "", "phase": "", "claims": 0, "open": 0}
        if isa.exists():
            text = safe_read(isa, warnings, "work") or ""
            fm = frontmatter(text)
            row["goal"] = redact(fm.get("principal_stated_goal", ""), 240)
            row["phase"] = fm.get("phase", "")
            claims = re.findall(r"^\s*-\s*\[( |x|X)\]\s*[A-Z]+\d+", text, re.M)
            row["claims"] = len(claims)
            row["open"] = sum(1 for c in claims if c == " ")
        out.append(row)
    return sorted(out, key=lambda r: (r["date"], r["slug"]), reverse=True)


def collect_session_logs(kai, since, warnings, missing):
    d = kai / "MEMORY" / "LEARNING" / "sessions"
    if not d.is_dir():
        missing.append("session-logs")
        return [], []
    sessions, prompts = [], []
    for f in sorted(d.rglob("*.md")):
        try:
            if mtime_utc(f) < since:
                continue
        except OSError:
            continue
        text = safe_read(f, warnings, "session-logs") or ""
        date = mtime_utc(f).date().isoformat()
        tools = re.search(r"^- tool calls:\s*(\d+)", text, re.M)
        sess_prompts = []
        in_prompts = False
        for line in text.splitlines():
            if line.startswith("## Prompts"):
                in_prompts = True
                continue
            if in_prompts and line.startswith("## "):
                break
            if in_prompts and line.startswith("- "):
                sess_prompts.append(line[2:])
        sessions.append({"id": f.stem, "date": date, "tool_calls": int(tools.group(1)) if tools else 0,
                         "prompts": len(sess_prompts)})
        for p in sess_prompts:
            prompts.append({"date": date, "session": f.stem, "source": "kai-log", "text": redact(p),
                            "markers": markers(p)})
    return sessions, prompts


def collect_transcripts(copilot, since, warnings, missing, max_files=400):
    d = copilot / "session-state"
    if not d.is_dir():
        missing.append("copilot-transcripts")
        return []
    files = []
    for f in d.glob("*/events.jsonl"):
        try:
            if mtime_utc(f) >= since:
                files.append(f)
        except OSError:
            continue
    files.sort(key=lambda p: (mtime_utc(p), str(p)), reverse=True)
    if len(files) > max_files:
        warnings.append(f"copilot-transcripts: {len(files)} sessions in window, read newest {max_files}")
        files = files[:max_files]
    prompts = []
    bad = 0
    for f in files:
        text = safe_read(f, warnings, "copilot-transcripts")
        if text is None:
            continue
        for line in text.splitlines():
            if '"user.message"' not in line:
                continue
            try:
                ev = json.loads(line)
            except ValueError:
                bad += 1
                continue
            if ev.get("type") != "user.message":
                continue
            content = (ev.get("data") or {}).get("content")
            if not isinstance(content, str) or not content.strip():
                continue
            ts = parse_ts(ev.get("timestamp")) or mtime_utc(f)
            if as_utc(ts) < since:
                continue
            prompts.append({"date": as_utc(ts).date().isoformat(), "session": f.parent.name[:8], "source": "copilot",
                            "text": redact(content), "markers": markers(content)})
    if bad:
        warnings.append(f"copilot-transcripts: skipped {bad} malformed line(s)")
    return prompts


def collect_ratings(path, since, max_rating, warnings, missing):
    if not path or not Path(path).is_file():
        missing.append("ratings")
        return []
    text = safe_read(Path(path), warnings, "ratings")
    out, bad = [], 0
    for line in (text or "").splitlines():
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except ValueError:
            bad += 1
            continue
        rating, ts = r.get("rating"), parse_ts(r.get("timestamp"))
        if not isinstance(rating, (int, float)) or ts is None:
            bad += 1
            continue
        if rating > max_rating or as_utc(ts) < since:
            continue
        out.append({"date": as_utc(ts).date().isoformat(), "rating": rating, "source": "rating",
                    "note": redact(r.get("sentiment_summary") or r.get("note") or "", 500)})
    if bad:
        warnings.append(f"ratings: skipped {bad} malformed line(s)")
    return out


def collect_learnings(kai, warnings, missing):
    f = kai / "MEMORY" / "LEARNING" / "learnings.md"
    if not f.is_file():
        missing.append("learnings")
        return []
    text = safe_read(f, warnings, "learnings") or ""
    return [redact(l[2:], 300) for l in text.splitlines() if l.startswith("- ")][-200:]


def collect_events(kai, since, warnings, missing):
    f = kai / "MEMORY" / "OBSERVABILITY" / "events.jsonl"
    if not f.is_file():
        missing.append("hook-events")
        return {}, {}
    text = safe_read(f, warnings, "hook-events") or ""
    failures, gates = {}, {}
    for line in text.splitlines():
        if "Failure" not in line and "deny" not in line and "ask" not in line and "formatBlock" not in line:
            continue
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        ts = parse_ts(ev.get("ts"))
        if ts is None or as_utc(ts) < since:
            continue
        name = ev.get("event", "")
        if name == "postToolUseFailure":
            t = str(ev.get("tool") or "?")
            failures[t] = failures.get(t, 0) + 1
        elif name in ("preToolUse.deny", "preToolUse.ask", "agentStop.formatBlock"):
            key = name if name == "agentStop.formatBlock" else f"{name}: {redact(ev.get('reason', ''), 90)}"
            gates[key] = gates.get(key, 0) + 1
    return dict(sorted(failures.items())), dict(sorted(gates.items()))


def collect_registries(skill_dirs, agent_dirs, warnings):
    out = []
    seen = set()
    for d in skill_dirs:
        if not d.is_dir():
            continue
        for sk in sorted(d.iterdir()):
            md = sk / "SKILL.md"
            if not md.is_file():
                continue
            fm = frontmatter(safe_read(md, warnings, "skills") or "")
            name = fm.get("name") or sk.name
            if ("skill", name) in seen:
                continue
            seen.add(("skill", name))
            out.append({"kind": "skill", "name": name, "description": fm.get("description", "")[:600],
                        "path": str(md)})
            wf = sk / "Workflows"
            if wf.is_dir():
                for f in sorted(wf.glob("*.md")):
                    out.append({"kind": "workflow", "name": f"{name}/{f.stem}", "description": "", "path": str(f)})
    for d in agent_dirs:
        if not d.is_dir():
            continue
        for f in sorted(d.glob("*.agent.md")):
            fm = frontmatter(safe_read(f, warnings, "agents") or "")
            name = fm.get("name") or f.name[:-len(".agent.md")]
            if ("agent", name) in seen:
                continue
            seen.add(("agent", name))
            out.append({"kind": "agent", "name": name, "description": fm.get("description", "")[:400], "path": str(f)})
    return sorted(out, key=lambda r: (r["kind"], r["name"]))


def build_corpus(a, now=None):
    warnings, missing = [], []
    kai = Path(a.kai_home or os.environ.get("KAI_HOME") or
               (Path(os.environ["COPILOT_HOME"]) / "kai" if os.environ.get("COPILOT_HOME") else Path.home() / ".copilot" / "kai"))
    copilot = Path(a.copilot_home or os.environ.get("COPILOT_HOME") or (Path.home() / ".copilot"))
    days = max(1, min(3650, a.days))
    if days != a.days:
        warnings.append(f"--days clamped to {days}")
    now = now or _dt.datetime.now(_dt.timezone.utc)
    since = now - _dt.timedelta(days=days)
    ratings_path = a.ratings or os.environ.get("SKILLSCAN_RATINGS_FILE") or str(kai / "MEMORY" / "LEARNING" / "SIGNALS" / "ratings.jsonl")
    if a.ratings and not Path(a.ratings).is_file():
        warnings.append(f"ratings: --ratings path {a.ratings} does not exist")
    work = collect_work(kai, since, warnings, missing)
    sessions, prompts = collect_session_logs(kai, since, warnings, missing)
    if not a.no_transcripts:
        prompts += collect_transcripts(copilot, since, warnings, missing)
    # Kai's session log and the Copilot transcript record the same prompts; prefer the transcript copy
    # (exact timestamp) and drop a log copy of the same text within two days. Exact repeats from one
    # source on one date collapse too.
    copilot_days = {}
    for p in prompts:
        if p["source"] == "copilot":
            copilot_days.setdefault(p["text"][:200], []).append(_dt.date.fromisoformat(p["date"]))
    uniq, seen = [], set()
    for p in sorted(prompts, key=lambda p: (p["date"], p["source"], p["session"], p["text"])):
        if p["source"] == "kai-log":
            d = _dt.date.fromisoformat(p["date"])
            if any(abs((d - cd).days) <= 2 for cd in copilot_days.get(p["text"][:200], [])):
                continue
        key = (p["date"], p["source"], p["text"][:200])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(p)
    prompts = uniq
    evals = [p for p in prompts if any(m in p["text"] for m in EVAL_MARKERS)]
    if evals:
        warnings.append(f"prompts: ignored {len(evals)} automated eval or judge prompt(s)")
        prompts = [p for p in prompts if p not in evals]
    frustrated = [p for p in prompts if p["markers"]]
    if len(prompts) > a.max_prompts:
        keep = set(id(p) for p in frustrated)
        rest = [p for p in prompts if id(p) not in keep]
        warnings.append(f"prompts: {len(prompts)} in window; kept all {len(frustrated)} with frustration markers "
                        f"and the newest {max(0, a.max_prompts - len(frustrated))} others")
        rest = sorted(rest, key=lambda p: (p["date"], p["text"]), reverse=True)[:max(0, a.max_prompts - len(frustrated))]
        prompts = sorted(frustrated + rest, key=lambda p: (p["date"], p["source"], p["session"], p["text"]))
    ratings = collect_ratings(ratings_path, since, a.max_rating, warnings, missing)
    frustrations = sorted(
        ratings + [{"date": p["date"], "rating": None, "source": p["source"], "note": p["text"],
                    "markers": p["markers"], "recurrence": bool(set(p["markers"]) & RECURRENCE)} for p in frustrated],
        key=lambda f: (f["rating"] if f["rating"] is not None else 99, f["date"], f["note"]))
    tool_failures, gate_events = collect_events(kai, since, warnings, missing)
    skill_dirs = [Path(s) for s in (a.skills or [])] or [copilot / "skills", Path(a.cwd) / ".github" / "skills"]
    agent_dirs = [copilot / "agents", Path(a.cwd) / ".github" / "agents"]
    registries = collect_registries(skill_dirs, agent_dirs, warnings)
    if not registries:
        missing.append("skills")
    return {
        "window": {"days": days, "since": since.date().isoformat()},
        "work": work,
        "sessions": sorted(sessions, key=lambda s: (s["date"], s["id"]), reverse=True),
        "prompts": prompts,
        "frustrations": frustrations,
        "learnings": collect_learnings(kai, warnings, missing),
        "tool_failures": tool_failures,
        "gate_events": gate_events,
        "registries": registries,
        "warnings": warnings,
        "missing": sorted(set(missing)),
        "sources": {"kai_home": str(kai), "copilot_home": str(copilot), "ratings": ratings_path,
                    "transcripts": "skipped" if a.no_transcripts else str(copilot / "session-state"),
                    "skills": [str(s) for s in skill_dirs]},
        "counts": {"work": len(work), "sessions": len(sessions), "prompts": len(prompts),
                   "frustrations": len(frustrations), "recurrence": sum(1 for f in frustrations if f.get("recurrence")),
                   "registries": len(registries)},
    }


def main(argv=None):
    ap = argparse.ArgumentParser(prog="collect_signals.py", description="Read-only signal collector for skill-gap discovery")
    ap.add_argument("--days", type=int, default=45)
    ap.add_argument("--max-rating", type=int, default=4)
    ap.add_argument("--kai-home")
    ap.add_argument("--copilot-home")
    ap.add_argument("--skills", action="append", help="skills folder to treat as the registry (repeatable)")
    ap.add_argument("--ratings")
    ap.add_argument("--cwd", default=os.getcwd())
    ap.add_argument("--no-transcripts", action="store_true")
    ap.add_argument("--max-prompts", type=int, default=400)
    a = ap.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    sys.stdout.write(json.dumps(build_corpus(a), indent=2, ensure_ascii=False) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
