---
name: suggest-skills
description: "Discovers WHICH new skills are worth creating, from your own work history plus frustration signals. Read-only and proposal-only: a deterministic collector gathers recent ISAs, session prompts, Copilot transcripts, learnings, tool failures and optional ratings; then recurring pain is clustered, checked against what existing skills, workflows and agents actually cover, and returned as a ranked shortlist with evidence to build with /create-skill. It never creates or edits a skill. Frustration is a first-class signal: a topic can look covered while you keep hitting the same wall inside it. Use when the user says should I create a skill, what skills do I need, suggest skills, skill gap, based on my recent work, am I missing a skill, what should I automate, I keep doing the same thing by hand, I keep hitting the same wall. NOT FOR creating, validating, testing or tuning an individual skill (use /create-skill)."
---
# Suggest skills: what should I build next?

A read-only analytics pass over your own work. It answers one question: given what you've actually been doing and where you've been frustrated, is there a recurring problem that deserves its own skill and doesn't have one yet? It proposes; you decide; /create-skill builds. It has no ability to create or edit a skill, by design.

## Workflow routing

| Request | Workflow |
|---|---|
| what skills should I build, skill gap, suggest skills, am I missing a skill | `Workflows/Scan.md` |

In short, a scan:

1. **Gathers deterministically.** `collect_signals.py` emits one normalized corpus; the model never gathers by hand, so two runs judge the same evidence.
2. **Clusters by pain**, carrying both how often a theme recurs and how much frustration it drew.
3. **Dedups against real coverage**, by reading the bodies of the skills and workflows that might cover each theme. Name matching is not coverage.
4. **Verifies with two independent passes and reports the union**, tagged by agreement.
5. **Proposes, never creates:** a ranked shortlist with evidence, handed to /create-skill only on approval.

## Tool

`python "$HOME/.copilot/skills/suggest-skills/tools/collect_signals.py" [--days 45] [--max-rating 4] [--no-transcripts] [--skills DIR] [--ratings FILE] [--max-prompts 400]`

Sources, each optional (missing ones are listed in `missing`, never fatal): Kai task ISAs (`~/.copilot/kai/MEMORY/WORK/`), Kai session logs and learnings (`MEMORY/LEARNING/`), Kai hook events (tool failures, safety-gate hits, format blocks), Copilot transcripts (`~/.copilot/session-state/*/events.jsonl`, user messages only), an optional ratings file (`MEMORY/LEARNING/SIGNALS/ratings.jsonl`, lines of `{rating, timestamp, sentiment_summary}`), and the registry of personal and repo skills, their workflows, and custom agents.

Output: `{window, work, sessions, prompts, frustrations, learnings, tool_failures, gate_events, registries, warnings, missing, sources, counts}`. Prompts carry frustration markers (again, still broken, same error, I told you, why did you, regressed, keeps failing...); markers in the recurrence class set `recurrence: true`. Emails, tokens, keys and user-profile paths are redacted at collection time.

## Why it is separate from /create-skill

Discovery is read-only; creation mutates. Keeping them apart is the permission boundary that makes "never auto-create" real rather than a promise in prose.

## The two blind spots it exists to defeat

1. **Frustration is invisible to topic matching.** A topic can be nominally covered while you keep hitting the same wall inside it. Recurring frustration markers and low ratings are the strongest signal that a skill is missing; weight them above raw topic frequency.
2. **Discipline gaps hide under covered topics.** "Deploys" maps to a deploy skill, but the recurring pain may be an unowned discipline (rollback safety, migration ordering, state modelling) the skill never addresses. Coverage means the discipline is genuinely handled, not that the topic shares a keyword.

## Gotchas

- **A clean coverage result with dirty frustration signals is a false negative.** If prompts show recurring frustration in an area you marked covered, re-open it; the discipline under that topic is the gap.
- **Recurrence is severity-weighted, not a bare count.** One long, painful, repeated migration outweighs three trivial sessions. A high-severity pain that recurs a few times qualifies even below an arbitrary threshold.
- **Behaviour is not a skill.** "Too verbose", "misread the scope", "repeated a reminder" are steering problems: route them to memory (`python "$HOME/.copilot/kai/bin/kai.py" learn "..."`) or the instructions, not to /create-skill.
- **Gathering is deterministic on purpose.** If you find yourself grepping stores by hand during a scan, use the tool instead; hand-gathering makes runs non-reproducible.
- **A wider window makes the list longer, not the analysis better.** 45 days is the default; widen it deliberately and expect clustering to cost more. Frustration-marked prompts are always kept when the prompt cap trims the rest.
- **Transcripts are the user's private history.** Read them for this analysis only; never quote secrets, client names or personal paths in the report.
