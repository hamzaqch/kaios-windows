---
name: optimize
description: "Autonomous hill-climb on any target: change it, measure it, keep only changes that measurably win, revert the rest, stop when it stops climbing. Metric mode for code with a command that prints a number (latency, bundle size, test time, a benchmark score); eval mode for skills, prompts, agents and custom instructions judged by 3-6 binary LLM-judge criteria. A deterministic ledger makes every keep/revert call with a noise-floor check so lucky runs never become the baseline. Use when the user says /optimize, optimize this, hill climb, improve this metric, make this faster, reduce latency, shrink the bundle, optimize this skill, optimize this prompt, tune this agent, eval mode. NOT FOR one-off fixes with no measurement, supervised multi-pass rework with review between passes (use /loop), or building an eval suite for its own sake (use /evals)."
argument-hint: "--measure \"<cmd>\" --files <glob> [--lower-is-better] | --target <path> [--max-experiments N]"
disable-model-invocation: true
---
# Optimize

**The ideal state:** the target ends measurably better than its baseline, every kept change beat the noise floor, no guard rail broke along the way, and the user gets a diff plus a one-line apply/reject/partial recommendation. Nothing is applied to the real target without their yes.

The model proposes and applies mutations. `tools/optimize.py` keeps the books and decides keep/revert from numbers. Never override its decision in prose.

## Modes

| | Metric mode | Eval mode |
|---|---|---|
| Target | Code files | Skills, prompts, agents, custom instructions, any text |
| Signal | A command that prints a number | Pass rate of 3-6 binary criteria over N runs |
| Score | The number (`--higher-is-better` default, or `--lower-is-better`) | `passes / (criteria x runs)` as a percentage |
| Sandbox | A git branch `optimize/<run>` (or a copy if not a repo) | A folder copy in `MEMORY/WORK/<slug>/sandbox/` |
| Guard rails | ISA claims that must hold every experiment | Same |

`--measure` given means metric mode. `--target` given means eval mode. Neither: code with a runnable benchmark is metric, everything else is eval.

## Invocation

```
/optimize --metric "bundle_kb" --lower-is-better --measure "npm run build" --pattern "dist size: ([0-9.]+) kB" --files "src/**/*.ts" --constraints "all tests pass"
/optimize --metric "p95_ms" --lower-is-better --measure "python bench.py" --files "app/*.py" --budget 120 --target 40
/optimize --target "$HOME/.copilot/skills/research" --max-experiments 15
/optimize --target prompts/summarize.md --runs 5 --criteria "Does it cite a source for each claim?" "Is it under 200 words?"
/optimize --resume <run>      /optimize --status <run>
```

| Argument | Mode | Default | Meaning |
|---|---|---|---|
| `--metric NAME` | metric | | Readable metric name (becomes the run name) |
| `--measure CMD` | metric | | Command that produces the number |
| `--extract CMD` or `--pattern REGEX` | metric | last number in output | How to read the number |
| `--files GLOB` | metric | | Files the loop may change (comma-separated) |
| `--locked GLOB` | both | | Files it must never touch |
| `--higher-is-better` / `--lower-is-better` | metric | higher | Direction |
| `--target PATH` | eval | | Skill folder, prompt file or agent file |
| `--runs N` | eval | 3 | Runs per experiment |
| `--criteria "Q1" ...` / `--inputs "I1" ...` | eval | generated | Override the generated criteria and test inputs |
| `--preset cautious\|standard\|aggressive` | both | standard | Patience, max experiments and regression tolerance |
| `--max-experiments N`, `--target-value V`, `--budget SECONDS` | both | 10, none, 300 | Stop conditions and per-experiment time box |
| `--constraints TEXT` | both | | Extra guard rails ("tests must pass") |

## Procedure

1. **Scaffold the ISA** (`python "$HOME/.copilot/kai/bin/kai.py" isa new optimize-<name> "<goal>"`). Guard rails go in as claims: tests pass, output non-empty, no secrets, locked files untouched, plus `--constraints`. Read `LoopProtocol.md` for target detection and sandbox setup.
2. **Eval mode only:** read the target, then draft 3-6 criteria and 3-5 test inputs per `EvalGuide.md` (every criterion passes the 3-question test). **Show them and wait for approval.** This is the one checkpoint.
3. **Start the ledger:**
   `python "$HOME/.copilot/skills/optimize/tools/optimize.py" init <run> --direction higher|lower --mode metric|eval [--criteria C --runs R] [--preset P] [--target V]`
4. **Baseline:** measure the untouched sandbox and `record` it.
5. **Loop** until `record` prints a stop reason:
   - Hypothesize one change from the mutation taxonomy (`EvalGuide.md`). Check `status` dead ends first and never retry one.
   - Apply it in the sandbox only, measure, check guard rails.
   - `python ".../optimize.py" record <run> --score <v>` (or `--passes <p>`) `--hypothesis "<one line>" --mutation <type>` and add `--guard-fail "<which>"` if a guard broke.
   - In a git sandbox, commit the change before measuring and pass `--ref <sha>` to `record`.
   - Obey the decision: `keep` leaves the commit as the new best; `revert` and `marginal` roll back to the best experiment (`record` prints the `git revert --no-edit <best>..HEAD` command, or restore the best copy outside git); `accept` keeps the working copy without moving the best.
6. **Recommend:** `status <run>`, a diff of best vs original, and apply / reject / partial. Apply only on a yes.
7. **Learn:** record what worked and what didn't with `python "$HOME/.copilot/kai/bin/kai.py" learn "<lesson>"`, and copy the dead ends into the ISA `## Decisions`.

Rough throughput: metric mode about 12 experiments an hour at a 5-minute budget; eval mode 6-8, since every experiment is criteria x runs judge calls.

## Running eval-mode judges

Run the target against each test input in a fresh context, then judge each output against every criterion with a reason-then-verdict prompt. Prefer the evals skill's grader, which forces a structured TRUE/FALSE answer and treats unknown as a miss:

```
python "$HOME/.copilot/skills/evals/tools/evals.py" grade --output out.txt --asserts '[{"type":"llm-assert","value":["<criterion 1 as a statement>","<criterion 2>"]}]' --judge-model <model>
```

The `llm-assert` score is the fraction judged TRUE, so passes for that output = score x criteria count. Use a different model for the judge than the one producing the output when one is available (`--judge-model`), so the target is not grading itself.

## Gotchas

- **The ledger decides, not you.** A `marginal` result looks like a win and is noise. Revert it. Raising `--runs` is the honest way to resolve a noisy signal.
- **A guard-rail failure reverts even a record score.** That is the point of guard rails.
- **Gameable criteria get gamed.** "More than 500 words" drives padding. Run every criterion through the 3-question test before the loop starts.
- **Local optima are real.** When the run stops on patience well below target, report it and suggest a different preset or fresh criteria; do not quietly extend the loop.
- **Never mutate the real target mid-loop.** Sandbox first, apply after approval. In a git repo, keep the work on the `optimize/<run>` branch.
- **Windows commands:** quote paths and use `$HOME` rather than `~` in commands, since PowerShell 5.1 does not expand `~` for native programs.

## Files

- `EvalGuide.md`: writing binary criteria, anti-criteria, the mutation taxonomy, stall recovery, scoring.
- `LoopProtocol.md`: target types, sandbox strategy, presets, decision rules, termination.
- `tools/optimize.py`: the ledger (`init`, `record`, `status`, `list`, `score`, `extract`).
