"""Kai optimize ledger: the deterministic half of the /optimize and /loop hill-climb.

The model proposes and applies mutations. This tool keeps the books and makes the
keep/revert call from numbers, so a lucky run or a noise-floor wiggle never becomes the
new baseline. Stdlib only (Python 3.8+).

    python optimize.py init <run> --direction higher|lower [--mode metric|eval]
                       [--preset cautious|standard|aggressive] [--patience N] [--max N]
                       [--tolerance F] [--target V] [--criteria N] [--runs N] [--note TEXT]
    python optimize.py record <run> (--score V | --passes P) [--hypothesis TEXT]
                       [--mutation TYPE] [--guard-fail "<which guard>"] [--ref SHA] [--json]
    python optimize.py score --passes P --criteria C --runs R      eval-mode pass rate
    python optimize.py extract [--pattern REGEX]                    last number on stdin
    python optimize.py status <run> [--json]
    python optimize.py list [--json]

Decisions printed by `record`:
    baseline  first measurement; becomes the best
    keep      improvement beyond the noise floor (or too few points to judge); new best
    marginal  improvement inside the noise floor (|delta|/MAD < 1.0): revert, best unchanged
    accept    regression within --tolerance: keep the working copy, best unchanged
    revert    regression beyond tolerance, or a guard rail failed (always revert)

Every `record` also prints whether the loop should stop (target hit, patience exhausted,
max experiments reached). Exit codes: 0 ok, 1 run missing or corrupt, 2 bad input.
Runs live in <Kai home>/MEMORY/OPTIMIZE/<run>/ledger.json.
"""
import argparse
import datetime as _dt
import json
import math
import os
import re
import statistics
import sys
from pathlib import Path

PRESETS = {
    "cautious": {"patience": 5, "max": 20, "tolerance": 0.0},
    "standard": {"patience": 3, "max": 10, "tolerance": 0.0},
    "aggressive": {"patience": 2, "max": 15, "tolerance": 0.05},
}
RUN_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
NUMBER = re.compile(r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?")
MIN_POINTS_FOR_MAD = 3


def kai_home():
    if os.environ.get("KAI_HOME"):
        return Path(os.environ["KAI_HOME"])
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"]) / "kai"
    return Path.home() / ".copilot" / "kai"


def runs_root():
    return kai_home() / "MEMORY" / "OPTIMIZE"


def now():
    return _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat()


# ---------------------------------------------------------------------------
# Pure math (unit-tested)
# ---------------------------------------------------------------------------

def pass_rate(passes, criteria, runs):
    """Eval-mode score: passes / (criteria x runs), as a 0-100 percentage."""
    if criteria <= 0 or runs <= 0:
        raise ValueError("criteria and runs must be > 0")
    if passes < 0 or passes > criteria * runs:
        raise ValueError("passes must be between 0 and criteria x runs")
    return round(100.0 * passes / (criteria * runs), 4)


def mad(values):
    """Median absolute deviation. 0.0 for fewer than two values."""
    vals = [float(v) for v in values]
    if len(vals) < 2:
        return 0.0
    med = statistics.median(vals)
    return statistics.median([abs(v - med) for v in vals])


def extract_last_number(text, pattern=None):
    """Last number in text (or in the first group of `pattern` on its last match)."""
    if pattern:
        matches = list(re.finditer(pattern, text, re.MULTILINE))
        if not matches:
            return None
        m = matches[-1]
        chunk = m.group(1) if m.groups() else m.group(0)
        nums = NUMBER.findall(chunk)
    else:
        nums = NUMBER.findall(text)
    return float(nums[-1]) if nums else None


def improvement(score, best, direction):
    """Signed improvement: positive is better in the run's direction."""
    return (score - best) if direction == "higher" else (best - score)


def decide(ledger, score, guard_fail=None):
    """Decide keep / marginal / accept / revert for a new score. Pure: does not mutate."""
    cfg = ledger["config"]
    direction = cfg["direction"]
    exps = ledger["experiments"]
    if not exps:
        return {"decision": "baseline", "delta": 0.0, "confidence": None,
                "reason": "first measurement"}
    best = ledger["best"]["score"]
    delta = improvement(score, best, direction)
    history = [e["score"] for e in exps if isinstance(e.get("score"), (int, float))
               and math.isfinite(e["score"])]
    spread = mad(history)
    if len(history) >= MIN_POINTS_FOR_MAD and spread > 0:
        confidence = abs(delta) / spread
    else:
        confidence = None
    if guard_fail:
        return {"decision": "revert", "delta": delta, "confidence": confidence,
                "reason": "guard rail failed: %s" % guard_fail}
    if delta > 0:
        if confidence is not None and confidence < 1.0:
            return {"decision": "marginal", "delta": delta, "confidence": confidence,
                    "reason": "improvement inside the noise floor (%.2fx MAD)" % confidence}
        why = "improvement" if confidence is None else "improvement (%.2fx MAD)" % confidence
        return {"decision": "keep", "delta": delta, "confidence": confidence, "reason": why}
    tol = float(cfg.get("tolerance") or 0.0)
    if delta == 0:
        return {"decision": "revert", "delta": delta, "confidence": confidence,
                "reason": "no change in score"}
    scale = abs(best) if best != 0 else 1.0
    if tol > 0 and abs(delta) / scale <= tol:
        return {"decision": "accept", "delta": delta, "confidence": confidence,
                "reason": "regression within tolerance %.0f%%" % (tol * 100)}
    return {"decision": "revert", "delta": delta, "confidence": confidence,
            "reason": "regression"}


def stop_reason(ledger):
    """Why the loop should stop now, or None to continue."""
    cfg = ledger["config"]
    exps = ledger["experiments"]
    best = ledger.get("best")
    if best and cfg.get("target") is not None:
        if improvement(best["score"], float(cfg["target"]), cfg["direction"]) >= 0:
            return "target reached (%s)" % cfg["target"]
    if cfg.get("max") and len(exps) - 1 >= int(cfg["max"]):
        return "max experiments reached (%s)" % cfg["max"]
    streak = 0
    for e in reversed(exps):
        if e["decision"] in ("keep", "baseline"):
            break
        streak += 1
    if cfg.get("patience") and streak >= int(cfg["patience"]):
        return "no improvement in %d experiments (patience %s)" % (streak, cfg["patience"])
    return None


def apply_record(ledger, score, hypothesis="", mutation="", guard_fail=None, ref=None):
    """Append an experiment and update best. Returns the decision dict."""
    d = decide(ledger, score, guard_fail)
    entry = {
        "n": len(ledger["experiments"]),
        "ts": now(),
        "score": score,
        "decision": d["decision"],
        "delta": round(d["delta"], 6),
        "confidence": None if d["confidence"] is None else round(d["confidence"], 4),
        "reason": d["reason"],
        "hypothesis": hypothesis,
        "mutation": mutation,
    }
    if guard_fail:
        entry["guard_fail"] = guard_fail
    if ref:
        entry["ref"] = ref
    ledger["experiments"].append(entry)
    if d["decision"] in ("baseline", "keep"):
        ledger["best"] = {"n": entry["n"], "score": score}
        if ref:
            ledger["best"]["ref"] = ref
    if d["decision"] in ("revert", "marginal") and hypothesis:
        ledger.setdefault("dead_ends", []).append(
            {"n": entry["n"], "hypothesis": hypothesis, "mutation": mutation,
             "reason": d["reason"]})
    d["stop"] = stop_reason(ledger)
    d["n"] = entry["n"]
    d["best"] = ledger["best"]
    return d


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------

def ledger_path(run):
    return runs_root() / run / "ledger.json"


def load(run):
    if not RUN_NAME.match(run or ""):
        raise ValueError("bad run name %r" % run)
    p = ledger_path(run)
    if not p.exists():
        raise FileNotFoundError("no run named %r (looked in %s)" % (run, p))
    return json.loads(p.read_text(encoding="utf-8-sig"))


def save(run, ledger):
    p = ledger_path(run)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(ledger, indent=2), encoding="utf-8")
    os.replace(str(tmp), str(p))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def fmt_conf(c):
    return "n/a" if c is None else "%.2fx" % c


def cmd_init(ns):
    if not RUN_NAME.match(ns.run):
        print("run name must be letters, digits, dot, dash or underscore", file=sys.stderr)
        return 2
    if ledger_path(ns.run).exists() and not ns.force:
        print("run %r already exists; use --force to overwrite or pick a new name" % ns.run,
              file=sys.stderr)
        return 2
    preset = dict(PRESETS[ns.preset])
    for key in ("patience", "max", "tolerance"):
        v = getattr(ns, key)
        if v is not None:
            preset[key] = v
    if not 0.0 <= float(preset["tolerance"]) <= 1.0:
        print("--tolerance must be between 0 and 1", file=sys.stderr)
        return 2
    ledger = {
        "run": ns.run,
        "created": now(),
        "config": {
            "direction": ns.direction,
            "mode": ns.mode,
            "preset": ns.preset,
            "patience": int(preset["patience"]),
            "max": int(preset["max"]),
            "tolerance": float(preset["tolerance"]),
            "target": ns.target,
            "criteria": ns.criteria,
            "runs": ns.runs,
            "note": ns.note or "",
        },
        "best": None,
        "experiments": [],
        "dead_ends": [],
    }
    save(ns.run, ledger)
    print("initialised run %s (%s, %s is better) at %s"
          % (ns.run, ns.mode, ns.direction, ledger_path(ns.run)))
    return 0


def cmd_record(ns):
    try:
        ledger = load(ns.run)
    except (FileNotFoundError, ValueError) as e:
        print(str(e), file=sys.stderr)
        return 1
    if ns.score is not None:
        score = ns.score
    else:
        cfg = ledger["config"]
        if not cfg.get("criteria") or not cfg.get("runs"):
            print("--passes needs the run to be initialised with --criteria and --runs",
                  file=sys.stderr)
            return 2
        try:
            score = pass_rate(ns.passes, cfg["criteria"], cfg["runs"])
        except ValueError as e:
            print(str(e), file=sys.stderr)
            return 2
    if not math.isfinite(float(score)):
        print("score must be a finite number (got %s); a failed measurement is a guard-rail "
              "failure, not a score" % score, file=sys.stderr)
        return 2
    d = apply_record(ledger, float(score), ns.hypothesis or "", ns.mutation or "",
                     ns.guard_fail, ns.ref)
    save(ns.run, ledger)
    if ns.json:
        print(json.dumps(dict(d, score=score), indent=2))
        return 0
    print("experiment %d: score %s -> %s (%s)" % (d["n"], score, d["decision"].upper(), d["reason"]))
    print("  delta %+.4f, confidence %s, best #%d = %s"
          % (d["delta"], fmt_conf(d["confidence"]), d["best"]["n"], d["best"]["score"]))
    if d["decision"] in ("revert", "marginal"):
        print("  ACTION: revert the working copy to experiment #%d" % d["best"]["n"])
        if d["best"].get("ref"):
            print("  (git sandbox: git revert --no-edit %s..HEAD)" % d["best"]["ref"])
    print("  stop: %s" % (d["stop"] or "no, continue"))
    return 0


def cmd_score(ns):
    try:
        print(pass_rate(ns.passes, ns.criteria, ns.runs))
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 2
    return 0


def cmd_extract(ns):
    text = sys.stdin.read()
    v = extract_last_number(text, ns.pattern)
    if v is None or not math.isfinite(v):
        print("no finite number found", file=sys.stderr)
        return 2
    print(v if v != int(v) else int(v))
    return 0


def summarize(ledger):
    exps = ledger["experiments"]
    counts = {}
    for e in exps:
        counts[e["decision"]] = counts.get(e["decision"], 0) + 1
    base = exps[0]["score"] if exps else None
    best = ledger.get("best")
    return {
        "run": ledger["run"],
        "config": ledger["config"],
        "experiments": max(len(exps) - 1, 0),
        "baseline": base,
        "best": best,
        "gain": None if (base is None or not best) else round(
            improvement(best["score"], base, ledger["config"]["direction"]), 6),
        "decisions": counts,
        "stop": stop_reason(ledger) if exps else None,
        "dead_ends": ledger.get("dead_ends", []),
    }


def cmd_status(ns):
    try:
        ledger = load(ns.run)
    except (FileNotFoundError, ValueError) as e:
        print(str(e), file=sys.stderr)
        return 1
    s = summarize(ledger)
    if ns.json:
        s["history"] = ledger["experiments"]
        print(json.dumps(s, indent=2))
        return 0
    cfg = s["config"]
    print("run %s: %s mode, %s is better, preset %s" % (s["run"], cfg["mode"], cfg["direction"], cfg["preset"]))
    if s["baseline"] is None:
        print("  no measurements yet; record the baseline first")
        return 0
    print("  baseline %s, best #%d = %s, gain %+.4f over %d experiments"
          % (s["baseline"], s["best"]["n"], s["best"]["score"], s["gain"], s["experiments"]))
    print("  decisions: " + ", ".join("%s %d" % kv for kv in sorted(s["decisions"].items())))
    for e in ledger["experiments"]:
        print("  #%-3d %-9s %-10s %s" % (e["n"], e["decision"], e["score"], e.get("hypothesis", "")[:70]))
    if s["dead_ends"]:
        print("  dead ends (do not retry):")
        for d in s["dead_ends"]:
            print("    - #%d %s: %s" % (d["n"], d["hypothesis"][:70], d["reason"]))
    print("  stop: %s" % (s["stop"] or "no, continue"))
    return 0


def cmd_list(ns):
    root = runs_root()
    rows = []
    if root.exists():
        for p in sorted(root.glob("*/ledger.json")):
            try:
                rows.append(summarize(json.loads(p.read_text(encoding="utf-8-sig"))))
            except (ValueError, KeyError):
                continue
    if ns.json:
        print(json.dumps(rows, indent=2))
        return 0
    if not rows:
        print("no optimize runs yet (%s)" % root)
        return 0
    for s in rows:
        best = s["best"]["score"] if s["best"] else "-"
        print("%-30s %-6s best %-10s experiments %d" % (s["run"], s["config"]["mode"], best, s["experiments"]))
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="optimize.py", description="Kai optimize ledger")
    sub = p.add_subparsers(dest="cmd")
    i = sub.add_parser("init", help="start a run")
    i.add_argument("run")
    i.add_argument("--direction", choices=["higher", "lower"], required=True)
    i.add_argument("--mode", choices=["metric", "eval"], default="metric")
    i.add_argument("--preset", choices=sorted(PRESETS), default="standard")
    i.add_argument("--patience", type=int)
    i.add_argument("--max", type=int)
    i.add_argument("--tolerance", type=float)
    i.add_argument("--target", type=float)
    i.add_argument("--criteria", type=int)
    i.add_argument("--runs", type=int)
    i.add_argument("--note")
    i.add_argument("--force", action="store_true")
    i.set_defaults(fn=cmd_init)
    r = sub.add_parser("record", help="record a measurement and get the decision")
    r.add_argument("run")
    g = r.add_mutually_exclusive_group(required=True)
    g.add_argument("--score", type=float)
    g.add_argument("--passes", type=int)
    r.add_argument("--hypothesis")
    r.add_argument("--mutation")
    r.add_argument("--guard-fail", dest="guard_fail")
    r.add_argument("--ref", help="sandbox commit id of this experiment (git sandboxes)")
    r.add_argument("--json", action="store_true")
    r.set_defaults(fn=cmd_record)
    s = sub.add_parser("score", help="eval-mode pass rate")
    s.add_argument("--passes", type=int, required=True)
    s.add_argument("--criteria", type=int, required=True)
    s.add_argument("--runs", type=int, required=True)
    s.set_defaults(fn=cmd_score)
    e = sub.add_parser("extract", help="last number on stdin")
    e.add_argument("--pattern")
    e.set_defaults(fn=cmd_extract)
    st = sub.add_parser("status", help="run summary")
    st.add_argument("run")
    st.add_argument("--json", action="store_true")
    st.set_defaults(fn=cmd_status)
    ls = sub.add_parser("list", help="all runs")
    ls.add_argument("--json", action="store_true")
    ls.set_defaults(fn=cmd_list)
    return p


def _utf8_stdio():
    """Windows consoles and pipes default to a legacy code page; never crash on a CJK name or an emoji."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            pass


def main(argv=None):
    _utf8_stdio()
    p = build_parser()
    ns = p.parse_args(argv)
    if not getattr(ns, "fn", None):
        p.print_help()
        return 2
    return ns.fn(ns)


if __name__ == "__main__":
    sys.exit(main())
