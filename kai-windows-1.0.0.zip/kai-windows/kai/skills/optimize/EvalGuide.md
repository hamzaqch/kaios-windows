# Eval guide: binary LLM-judge criteria for eval mode

How to write, check and use the binary criteria that score eval-mode experiments. The same discipline applies to `llm-assert` assertions in the evals skill: reason before the verdict, a judge model different from the one under test, and unknown counts as a miss.

## When to use eval mode

Use eval mode when "better" means higher quality rather than a smaller number: prompts, skills, agents, custom instructions, any text output. Use metric mode when a command prints a number: build time, test count, file size, latency, a benchmark score. When both matter, run metric mode for speed first, then eval mode for quality, with the metric as a guard rail.

## The 3-question test

Every criterion must pass all three before the loop starts. One that fails any of them produces a misleading signal.

**1. Would two independent judges agree?** Specific enough that two judges reach the same yes/no answer more than 85% of the time.
- Pass: "Does the output contain at least 3 specific facts with cited sources?"
- Fail: "Is the output high quality?" (judges will disagree)
- Fail: "Is the writing style good?" (no anchor)

**2. Could the target game it without improving?** If a degenerate change could pass, the loop will find that change.
- Pass: "Does the output address the user's specific question rather than the general topic?"
- Fail: "Is the output longer than 500 words?" (padding passes)
- Fail: "Does it mention every input keyword?" (keyword stuffing passes)

**3. Does the user actually care?** It measures something the end user notices and values.
- Pass: "Does the output give actionable next steps, not only analysis?"
- Fail: "Does it use exactly 3 bullet points?" (arbitrary)
- Fail: "Does it mention its own instructions?" (meta, useless)

## Writing criteria

- **Shape:** one yes/no question about an observable property, answerable from the output alone (plus the input if needed). Template: `Does the output [observable behaviour] [specific threshold or condition]?`
- **Count:** 3-6. Fewer gives too little signal; more adds noise and slows every experiment.

Examples by target:

| Target | Criteria |
|---|---|
| Prompt | Answers the question in the first paragraph. Gives concrete examples, not only principles. Doesn't repeat the same point in new words. Has clear sections or a logical flow. |
| Skill | Routes to the right workflow for the input. Produces usable content, not meta-commentary. Follows the skill's output format. Handles an edge-case input without empty output. |
| Agent | Finishes the task without help. Uses a fitting tool at each step. Final output matches the requested deliverable. Makes no redundant tool calls. |
| Code judged on quality | Handles every documented edge case. Output matches the schema. Completes without unhandled exceptions. |

## Anti-criteria

What the output must NOT do. They stop the loop drifting toward degenerate output. Same judging, inverted: a yes is a failure.

- The output must NOT contain placeholder text or TODO markers.
- The output must NOT repeat the input verbatim.
- The output must NOT exceed 2000 words for a summary task.
- The output must NOT invent citations or sources.

## Common mistakes

- **Too many criteria.** Each extra one dilutes the meaningful ones, and the loop spends cycles on low-value checks.
- **Too rigid.** "Starts with 'Here is'" boxes the loop in. "Opens with a clear topic sentence" leaves room.
- **Overlapping.** Two criteria that always agree add nothing. Keep the sharper one.
- **Unmeasurable from the output.** If judging needs a database lookup or live data, the judge can't do it.
- **Conflicting.** "Be concise" plus "be comprehensive" oscillates. Add thresholds: "under 500 words" plus "covers at least 3 key aspects".

## Mutation taxonomy

Pass the type to `optimize.py record --mutation <type>` so the ledger shows which kinds work.

Good mutations (high signal):

| Type | What it does | Example |
|---|---|---|
| `add_instruction` | Adds one targeted instruction | "Always include a concrete example for each principle" |
| `reword_ambiguity` | Makes vague wording precise | "be thorough" becomes "cover at least 3 distinct aspects" |
| `add_anti_pattern` | Forbids an observed failure | "Never open with 'In this response I will...'" |
| `reorder_priority` | Moves important instructions earlier | Output format moves from the bottom to the top |
| `add_example` | Adds a short example of the desired output | A 3-line ideal-shape sample |
| `remove_over_optimization` | Strips rules that cause rigidity | Drop "always exactly 5 bullets" |
| `simplify` | Merges redundant rules | Three formatting rules become one |
| `constrain_scope` | Narrows the focus | "Top 3 findings, not all findings" |

Bad mutations (avoid):

| Type | Why |
|---|---|
| `rewrite_from_scratch` | Throws away every accumulated gain |
| `add_10_plus_rules` | Instruction overload degrades following |
| `vague_instructions` | "Be better" adds no signal |
| `copy_from_unrelated` | Patterns from other domains rarely transfer |
| `meta_instructions` | "Think about how to think" has diminishing returns |

## Stall recovery

When the pass rate plateaus, try these in order:

1. **Check for a ceiling.** Above 95%, the criteria are saturated. Tighten them or add a harder one.
2. **Read the failures.** Which criteria fail? Aim mutations there.
3. **Try subtractive mutations.** Remove instructions that may interfere.
4. **Swap one criterion.** Replace the least discriminating one with a harder one.
5. **Vary the inputs.** The current ones may not stress the right behaviour.

A changed criterion or input set is a new measurement scale. Start a new ledger run rather than comparing across scales.

## Scoring

`score = passes / (criteria x runs)`, as a percentage. Example: 5 criteria, 3 runs, 12 passes of 15 gives 80%.

`optimize.py score --passes 12 --criteria 5 --runs 3` prints it, and `record --passes N` computes it from the run's configured criteria and runs. The ledger compares each score with the current best and applies the noise-floor check (`LoopProtocol.md`).

## Criteria versus guard rails

- **Eval criteria** are the optimisation signal. They can be rotated, tightened or graduated.
- **Guard rails** are ISA claims that hold for every experiment ("no crash", "output non-empty", "no personal data in output"). A violation reverts the change regardless of score.

Both live in the ISA: criteria in the Test Strategy for the optimisation claim, guard rails as their own claims.
