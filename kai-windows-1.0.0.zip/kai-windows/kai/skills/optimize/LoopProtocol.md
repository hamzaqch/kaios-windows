# Loop protocol: target types, sandbox, decisions, termination

## The inner loop

```
HYPOTHESIZE -> MUTATE (sandbox) -> MEASURE -> GUARD CHECK -> record -> KEEP or REVERT
     ^                                                                    |
     +---------------------- until record prints a stop reason ----------+
```

Log every experiment through `optimize.py record`. The ledger is the experiment log; the ISA carries the goal, the guard rails and the dead ends at the close.

## Target types

| Type | How to recognise it |
|---|---|
| skill | A folder containing `SKILL.md` |
| agent | A `.md` file with agent frontmatter (`name`, `description`, `tools`), e.g. `*.agent.md` |
| prompt | Any other standalone `.md` or `.txt` with instructions |
| code | Source files plus a `--measure` command |
| function | Code scoped to one named function |

A `--measure` command always means metric mode, whatever the file type.

### Skill
- **Read:** `SKILL.md`, every file in `Workflows/`, any reference `.md` in the skill root.
- **Inputs:** 3-5 drawn from the description's "Use when" phrases: one simple, one moderate, one complex, at least one edge case (minimal, ambiguous or out of scope).
- **Run:** copy the skill to `MEMORY/WORK/<slug>/sandbox/<skill>/`. For each input, run a fresh Copilot session that is told to follow the sandbox `SKILL.md`, for example `copilot -p "Follow <sandbox>/SKILL.md for this request: <input>" --allow-all-tools`, and capture the final answer.
- **Starter criteria:** relevant to the input; follows the workflow's format; no filler; specific and usable. Anti: no placeholders; does not ignore the input.

### Prompt
- **Read:** the prompt file and anything it references.
- **Inputs:** 3-5 representative inputs plus one stress input (odd format or edge-case topic).
- **Run:** copy to the sandbox; send prompt plus input as one `copilot -p` run per input.
- **Starter criteria:** addresses the input topic; follows the specified structure; concrete facts or examples; scoped right. Anti: no meta-commentary about the prompt; no padding.

### Agent
- **Read:** the agent file and any referenced tool configuration.
- **Inputs:** 3-5 tasks of varying difficulty within its stated scope, one near its boundary.
- **Run:** copy the agent file into a scratch `COPILOT_HOME` or project `.github/agents/` and invoke it per task; judge the final output, not the intermediate tool calls.
- **Starter criteria:** finishes the task; fitting tools; right deliverable; handles errors. Anti: no needless tool calls; no empty output.

### Code
- **Sandbox:** in a git repo, `git switch -c optimize/<run>` and commit every experiment there before measuring it. Pass that commit id to `record --ref <sha>` (`git rev-parse --short HEAD`). To roll back to the best experiment, `git revert --no-edit <best-sha>..HEAD`, which also undoes any `accept`ed commits since the best, keeps the dead ends in history and never discards work; `record` prints the exact command (Kai's safety hook asks before `git reset --hard`, which would stall an unattended loop). Outside git, copy the files to the sandbox folder.
- **Measure:** run `--measure` with the per-experiment `--budget` as a timeout; read the number with `--extract`, or pipe the output through `optimize.py extract [--pattern REGEX]`.
- **Guard rails:** the test suite passes; locked files are unchanged.

## Presets

| Preset | Patience | Max experiments | Regression tolerance | Use for |
|---|---|---|---|---|
| `cautious` | 5 | 20 | 0% | Production code, stability first |
| `standard` | 3 | 10 | 0% | The default |
| `aggressive` | 2 | 15 | 5% | Prototypes, escaping a local optimum |

Override any of them on `init` with `--patience`, `--max`, `--tolerance` (a fraction: 0.05 = 5%).

Mutation boldness follows the preset: cautious favours `simplify`, `reword_ambiguity` and small parameter tweaks; aggressive allows structural changes. Never `rewrite_from_scratch`.

## Decision rules (what `record` does)

1. The first measurement is the **baseline** and the first best.
2. A **guard-rail failure** is a `revert`, whatever the score.
3. An improvement over the best is a `keep` and becomes the new best, **unless** the noise check says it is `marginal`.
4. **Noise check:** once there are at least 3 measurements, confidence = |delta| / MAD (median absolute deviation of all scores so far). Below 1.0x the change is inside the noise floor: `marginal`, revert, best unchanged. Resolve a noisy target by raising `--runs`, not by keeping marginal wins.
5. A regression within `--tolerance` (relative to the best) is `accept`: keep the working copy to explore from, best unchanged. Anything worse, or no change at all, is `revert`.
6. Reverted and marginal hypotheses go on the run's dead-ends list. Read it (`status`) before every new hypothesis.

## Termination

`record` prints a stop reason when any of these holds:
- the best reaches `--target`;
- the experiment count reaches `--max`;
- `--patience` experiments in a row produced no keep.

Also stop on an explicit user halt or a guard rail that cannot be restored. On stop: `status`, the diff of best vs original, and the apply/reject/partial recommendation.

## Plateau protocol

When patience runs out well short of the target:
1. Say so plainly, with the best score and the dead ends.
2. Offer one of: switch to the `aggressive` preset, swap the weakest criterion (eval mode), vary the inputs, or stop here. Don't silently extend the run.
