---
name: lu
description: "Shortcut for /upgrade: improve Kai from what GitHub Copilot and the best practitioners are shipping, extract system improvements from a URL or piece of content, monitor the tracked sources, or mine Kai's own learnings, with every recommendation checked against Kai's current state. Use when the user types /lu, lu <url or topic>, or says Kai upgrade, check for upgrades, what's new in Copilot. NOT FOR upgrading third-party packages in a project."
argument-hint: "[url | topic | check | learnings | research <feature>]"
---
# lu: upgrade shortcut

Thin alias. Read `$HOME/.copilot/skills/upgrade/SKILL.md` and follow it with the same arguments:

- a URL or pasted content: extract techniques from it and check each against Kai's current state;
- a topic or `research <feature>`: its research route;
- no arguments or `check`: the standard source sweep;
- `learnings`: mine Kai's own learnings and failure logs.
