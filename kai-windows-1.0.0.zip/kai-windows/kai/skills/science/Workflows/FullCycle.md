# Full Cycle

Research-grade method for macro problems spanning weeks to months: product strategy, architecture decisions, long-running A/B tests or pilots, findings that must convince skeptics or be published, anything very expensive to get wrong.

Don't use it when the problem can be solved in a day, fast iteration beats rigor, or the overhead isn't justified by the stakes. Premature formalism delays learning.

It is Structured Investigation plus these safeguards: a written protocol, pre-registration, controls and power analysis, an audit trail, formal statistics, and review checkpoints.

## Phases

### 0. Protocol
Before anything else, document the method itself: owner, start date, expected duration, the research question, why it matters (which decisions hinge on the answer), methodology overview, ethical considerations, who reviews the methodology before execution, version history.

### 1. Pre-registered goal
Lock before any evidence is gathered, with a timestamp and a reviewer who saw it first:
- Primary outcome and exact success thresholds (quantitative; qualitative only with a clear rubric).
- Secondary outcomes, explicitly marked exploratory.
- Significance threshold (e.g. p < 0.05, or a Bayesian equivalent) and the **minimum effect size that matters practically**.
- Stopping rules: stop early if ___; continue until ___.

### 2. Context
- Literature and prior art: source, finding, relevance, quality; what was tried before and why it succeeded or failed. Dispatch `@kai-researcher` for this.
- Baselines with error bars and collection method.
- Stakeholder map: interest, influence, concerns.
- Constraints: time, budget, technical, organizational, ethical.

### 3. Hypotheses with devil's advocate
Minimum 5. Each: precise claim, theoretical basis, supporting evidence, **challenging evidence** (actively argued against it), falsification criterion, prior probability, and which other hypotheses it conflicts with. Have `@kai-reviewer` argue against each one.

### 4. Experiment design with controls
- Independent, dependent, control (held at stated values) and confounding variables, each confounder with a mitigation.
- Control and treatment groups with required N.
- Randomization: how cases are assigned.
- Blinding: who doesn't know which arm is which (for model-graded work, the judge never sees the variant label).
- Power analysis: minimum detectable effect, required sample, target power (e.g. 80%).
- Exact data-collection protocol.
- **Pre-registered analysis plan:** which tests, missing-data handling, multiple-comparison correction.

### 5. Execution with audit trail
Start and end times, who ran it, a protocol-deviation log (what changed, why, impact on validity), timestamped data-collection log, anomalies with impact, raw data location. Never modify raw data.

### 6. Statistical analysis
- Descriptive: N, mean, SD, median, range per group.
- Inferential: test and justification, statistic, p-value, confidence interval, effect size with interpretation.
- Assumption checks: normality, equal variance, independence, each met or violated and how handled.
- Bayesian, if used: prior, posterior, Bayes factor.
- Sensitivity: how robust are results to different assumptions?

### 7. Results vs pre-registration
Criterion table (required, achieved, met?). Per hypothesis: prior, posterior, verdict, confidence. Unexpected findings listed separately as exploratory and needing replication. Limitations, generalizability, alternative interpretations.

### 8. Iteration plan
- Goal met: document the methodology, communicate findings, implement, set up monitoring.
- Goal not met: analyze why hypotheses failed, generate new ones, design the next cycle, consider whether the whole frame is wrong.
- Knowledge transfer: generalizable learnings, process improvements for next time, follow-up questions.

## Review checkpoints

| Phase | Review | Reviewer |
|---|---|---|
| Protocol | Methodology approval | Domain expert or `@kai-architect` |
| Pre-registration | Goal lock | Stakeholder (the user) |
| Experiment design | Validity check | `@kai-reviewer` with a statistics brief |
| Analysis | Results verification | An independent `@kai-reviewer` that didn't run it |
| Conclusions | Interpretation | Several perspectives |

## Pivot or stop

Pivot when a fundamental assumption proves false, the environment shifts, a better opportunity appears, or priorities change. Stop early on clear failure with no recovery path, better use of resources elsewhere, ethical concerns, or early success. Document the decision; pivots and stops produce learnings too.

## Artifacts

Protocol, context report, hypothesis document with priors, experiment design, execution log, statistical report, findings report, iteration plan. For a persistent project, record the pre-registered criteria as ISC in the project's ISA (`~/.copilot/kai/ISA_FORMAT.md`).
