# Quick Diagnosis

Minimum viable science for problems that should take under 15 minutes. Run it the moment you've tried the obvious fix and it failed, you're about to "try random stuff," or you catch yourself saying "it's probably..." with no evidence.

Skip it when the fix is obvious and quick, you've solved this exact pattern many times, or trying costs less than thinking.

## Steps (2-3 minutes)

1. **Goal (30s).** One sentence: what does "fixed" look like? `GOAL: user can log in without a 500.`
2. **Hypotheses (60s).** At least three. If you can't think of three, you haven't thought hard enough.
   ```
   H1: [most likely cause] because [evidence]
   H2: [second] because [evidence]
   H3: [third] because [evidence]
   ```
   For each, ask what would prove it wrong.
3. **Rank and test (60s).** Order by fastest-to-verify x most-likely. `Test H2 first because it's a 30-second log check.` Run it and note what you observed.
4. **Update.** Confirmed → fix it and verify. Refuted → next hypothesis. Inconclusive → design a sharper test.

**One-liner under time pressure:** "I think [X] because [Y]. If I'm wrong, [Z] would be true. Let me check [Z]." That sentence holds a hypothesis, a rationale and a falsification test.

## Examples

```
GOAL: build passes type checking
H1: type mismatch in the file I just edited
H2: missing type definitions for the package I just added
H3: someone changed the compiler config
Test H1 (read error location) → error is on the line I touched → CONFIRMED, fix the annotation
```

```
GOAL: component shows updated data
H1: API returns stale data (caching)
H2: component doesn't re-render (state management)
H3: data transform bug (shape mismatch)
Test H1 (network tab) → API returns fresh data → REFUTED
Test H2 (devtools state) → state not updating → CONFIRMED, fix the effect dependency list
```

Random flailing ("try this... nope, restart everything... still broken") is the anti-pattern. Three hypotheses, fastest test first, eliminate systematically.

## Exit

Done when the problem is solved. Escalate to `StructuredInvestigation.md` when 15 minutes haven't solved it, you need information you don't have, or the problem is bigger than it looked.
