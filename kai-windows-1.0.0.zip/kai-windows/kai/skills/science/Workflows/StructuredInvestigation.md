# Structured Investigation

The workhorse for problems taking hours to days. Use it when Quick Diagnosis escalated, several systems or unknowns are involved, people disagree on the cause, a wrong answer is costly, or the investigation must be documented for others.

Skip it when the problem takes five minutes, the answer is obvious to a domain expert, or the process would take longer than doing the work.

Phase details and checklists are in `../Methodology.md`; write-up shapes are in `../Templates.md`.

## Phases

1. **Define the goal (~5 min).** Outcome, 2-3 measurable success criteria, constraints (time, resources, quality), anti-goals. Check: could someone else read this and know exactly when we've succeeded?

2. **Gather context (15-30 min).** What we know (each fact with its source), what we don't know (and what would help), what has been tried and with what result, baseline measurements. Check: did we look for disconfirming evidence, not just confirming? For external or broad evidence, dispatch `@kai-researcher` via the `task` tool.

3. **Generate hypotheses (~15 min).** Minimum 3, 5-10 if important. Each has: claim, rationale, evidence for, evidence against, "WRONG if ___", cost to test, confidence. Check: can you say what would prove each one wrong?

4. **Design experiments (~15 min).** Minimum viable experiment per hypothesis: method, primary and secondary metrics, pre-committed CONFIRMED / REFUTED / INCONCLUSIVE conditions, duration, resources. Order by likelihood x cheapness.

5. **Execute.** Run as designed and record raw observations and anomalies. Don't peek and stop early. Run independent experiments in parallel, for example one `@kai-engineer` per variant.

6. **Measure.** Per experiment: expected vs actual vs delta, qualitative notes, data-quality issues.

7. **Analyze against the goal.** Goal-comparison table (required, achieved, met?); verdict per hypothesis with its evidence; learnings, surprises, new questions; implications. Be honest about misses. For consequential conclusions, have `@kai-reviewer` attack them before you accept them.

8. **Iterate.** Goal achieved → document, done. Promising hypothesis → go deeper on that path. All refuted → new hypotheses, new cycle. Need more data → more experiments. Problem reframed → back to phase 1.

## Close-out

Produce the investigation summary from `../Templates.md`: goal, key finding in one sentence, verdict per hypothesis, resolution, and reusable learnings. Save reusable learnings with Kai's memory.

## Escalate to FullCycle

When the work spans weeks, several stakeholders must review the methodology, results will be shared externally, statistical rigor is required, or the problem is macro-scale (product strategy, architecture).
