---
name: science
description: "The scientific method as a general problem-solving loop: define the goal first, generate at least three falsifiable hypotheses, design the smallest experiment that could fail, measure honestly, analyze against the pre-committed goal, iterate. Scales from a 15-minute debug to a feature A/B test to a months-long product bet. Use when the user says think about, figure out, why is this happening, experiment, iterate, optimize, hypothesis, science, run a full cycle, quick diagnosis, structured investigation, how do we test this, what should we try, compare approaches, A/B test, or analyze these results. Also use when stuck on a bug for 15+ minutes or about to try random fixes."
---
# Science

Most problem-solving is guessing dressed up as work: pick the first idea, change something, call it done when it "seems better." That is confirmation bias, not progress. Without a stated definition of success you can't tell whether a change helped. With only one hypothesis you only ever test what you already believed.

## The cycle

```
GOAL ........ What does success look like? (pre-commit it)
OBSERVE ..... What is the current state? Baseline it.
HYPOTHESIZE . What might explain it or work? At least 3.
EXPERIMENT .. Smallest test that could prove a hypothesis wrong.
MEASURE ..... What actually happened? Raw data, with context.
ANALYZE ..... How does it compare to the goal, not to your hopes?
ITERATE ..... Ship, test the next hypothesis, redesign, or reframe.
     └──────► back to HYPOTHESIZE (or GOAL on a reframe)
```

The goal anchors everything. The power is in cycle speed and discipline, not any single step.

## Pick the right depth

| Situation | Workflow |
|---|---|
| Stuck 15+ min, about to flail, problem looks small | `Workflows/QuickDiagnosis.md` (2-3 min of structure) |
| Hours to days, multiple systems or unknowns, people disagree on cause, needs a write-up | `Workflows/StructuredInvestigation.md` |
| Weeks to months, expensive if wrong, needs statistical rigor, pre-registration or stakeholder review | `Workflows/FullCycle.md` |
| One phase only (define a goal, generate hypotheses, design an experiment, analyze results, decide next step) | The matching section of `Methodology.md` |

Don't over-formalize micro work. A TDD loop runs the cycle implicitly; formality grows with stakes. Escalate QuickDiagnosis to StructuredInvestigation after 15 minutes without resolution; escalate to FullCycle when the work spans weeks, needs rigor, or will be shared.

## Resources

| File | Holds |
|---|---|
| `Methodology.md` | Each phase in depth: process, quality checklist, pitfalls, decision tree for iteration |
| `Templates.md` | Goal, hypothesis, experiment, results and iteration templates, full and quick versions |
| `Examples.md` | Worked examples: quick debug, TDD, feature A/B, prompt iteration |

## Non-negotiables

- **Goal before evidence.** Write success criteria, thresholds (minimum / target / stretch), constraints and anti-goals before looking at results. Moving the goalposts afterwards is a failure, not a nuance.
- **At least three hypotheses before testing.** Include the null ("nothing is wrong" / "current approach is optimal"). One hypothesis is trial and error.
- **Every hypothesis states what would prove it wrong.** If you can't finish "this is WRONG if ___", it isn't testable.
- **Pre-commit CONFIRMED / REFUTED / INCONCLUSIVE conditions** for each experiment before running it.
- **Test in order of (likelihood x impact) / cost.** Cheap and likely first, regardless of how attached you are to a favorite.
- **Measurements are specific and reproducible.** "It seems better" is not a measurement. Keep raw data; record anomalies.
- **Compare to the goal, not to expectations.** Report negative and null results plainly.
- **Stop when the goal is met or returns diminish.** Infinite iteration is as bad as no iteration. Set a cycle limit up front.

## Anti-patterns

| Bad | Good |
|---|---|
| "Make it better" | "Reduce load time from 3s to under 1s" |
| "I think X will work" | "Three approaches: X, Y, Z. Testing the cheapest first." |
| "Prove I'm right" | "Design a test that could disprove it" |
| "Ignore the failed run" | "It failed because A, which teaches us B" |
| "One more experiment..." forever | "Goal met at 24% vs 25% target. Shipping." |

## The method in other domains

| Domain | Goal | Hypotheses | Experiment | Measure |
|---|---|---|---|---|
| Code (TDD) | Failing test defines behavior | Implementation approaches | Red-green-refactor | Test results, coverage |
| Prompts | Eval criteria and threshold, pre-committed | Prompt variants with falsifiable claims | Baseline vs variants on the same inputs | Scores per criterion |
| Product | Target metric and threshold | Feature ideas | A/B test or pilot | Conversion, retention |
| Research | Question to answer | Candidate answers | Look for supporting AND contradicting evidence | Source quality, consensus |
| Decisions | The decision and its judging criteria | Options as competing hypotheses | Structured critique of each | Strength of arguments |

## Using agents

Independent experiments run in parallel. Use the `task` tool or dispatch to a custom agent:

- `@kai-researcher`: observation and evidence gathering; run one looking for support and one looking for contradiction per hypothesis.
- `@kai-architect`: generating and categorizing hypotheses, designing experiments, framing a reframe.
- `@kai-engineer`: building variants (one per hypothesis, kept isolated, for example in separate branches) and running benchmarks or tests.
- `@kai-reviewer`: red-teaming hypotheses and conclusions, and judging model-graded comparisons blind.

When a phase produces success criteria worth keeping, write them into the task's ISA (`~/.copilot/kai/ISA_FORMAT.md`) as ISC, each with a probe.
