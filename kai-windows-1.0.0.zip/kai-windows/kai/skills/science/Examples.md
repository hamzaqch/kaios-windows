# Science Examples

Worked examples at different scales.

---

## 1. Quick debug (micro, 5 minutes)

**Problem:** login returns 500; users can't log in.
**Goal:** users log in without a 500.

Hypotheses (60 seconds):
```
H1: database connection failure (500s usually mean backend failure)
H2: yesterday's deploy broke something (worked yesterday)
H3: auth service down (only login fails)
H4: rate limiting tripped (possible traffic spike)
```
Test order by speed x likelihood: H1, H3, H4, H2.

Test H1: `psql -c "SELECT 1"` times out; `docker ps` shows the postgres container stopped. **H1 confirmed.**
Fix: restart the container. Verify: `curl -I /api/login` returns 200.

Two minutes of structure replaced 30 minutes of flailing.

---

## 2. TDD (micro, 10 minutes)

**Goal:** `isValidEmail(email)` returns the right boolean for our cases.
**Hypotheses:** H1 simple regex; H2 a validation library; H3 step-by-step parsing.

Test H1 with red-green-refactor:
```
RED:   test('valid email', () => expect(isValidEmail('user@example.com')).toBe(true))  → fails, no function
GREEN: return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)                                   → passes
       add edge-case tests one at a time...                                                → all pass
```
**Result:** 6 tests pass, full coverage. H1 confirmed for our needs; ship the simple version. The library (H2) was never needed.

---

## 3. Feature experiment (meso, 2 weeks)

**Problem:** 40% cart abandonment.
**Goal:** abandonment < 25%, with no conversion regression and no rise in complaints.

| # | Claim | Test cost |
|---|---|---|
| H1 | Security badges reduce checkout anxiety | Low |
| H2 | Cutting steps from 4 to 2 helps | High |
| H3 | Mobile optimization helps | Medium |
| H4 | A visible discount field helps | Low |

**Experiment (H1):** control = current checkout; treatment = + badges; N = 5,000 per group; 7 days.
**Result:** 40.0% → 36.0%, p = 0.0003. **H1 confirmed.**

Iterate, cheapest next, stacking on the winner:

| Iteration | Cumulative abandonment |
|---|---|
| Baseline | 40% |
| + badges (H1) | 36% |
| + discount field (H4) | 32% |
| + mobile (H3) | 24% |

**Goal met (24% < 25%). Stop and ship.** H2, the expensive one, was never needed.

---

## 4. Prompt iteration (meso, 2 hours)

**Problem:** a summarization prompt gives inconsistent output.
**Goal (pre-committed):** length 100-150 words (now 50-300); >90% of key points captured (now ~70%); 100% bullet format (now ~60%); overall score >85% (baseline 62%).

Baseline prompt: `Summarize the following document: {document}`

Hypotheses: H1 explicit length constraint; H2 exact format (3-5 bullets); H3 key-point extraction guidance; H4 few-shot examples.

Each variant run on the same fixed document set, graded by deterministic length/format checks plus a blind judge for key-point coverage:

| Variant | Length | Key points | Format | Overall |
|---|---|---|---|---|
| Baseline | 42% | 68% | 58% | 62% |
| A (H1) | 85% | 65% | 55% | 68% |
| B (H2) | 48% | 62% | 95% | 72% |
| C (H3) | 45% | 88% | 60% | 78% |
| D (H1+H2+H3) | 82% | 85% | 92% | 88% |
| E (H4 few-shot) | 78% | 80% | 88% | 85% |

D wins at 88%. Iteration 2 strengthens enforcement:
```
Summarize the following document.

Requirements:
- Length: 100-150 words
- Format: 3-5 bullet points, each 20-30 words
- You MUST use bullet points. No paragraphs.
- Content: the main argument, key evidence, conclusion
- Check: main claim, supporting evidence, implications

Document:
{document}
```
**Final score:** 93% (from 62%). **Learning:** for this task, combined explicit constraints beat few-shot examples. Each single constraint fixed only its own dimension, which is why the combination was needed.

---

## Scale summary

| Scale | Time | Example | Formality |
|---|---|---|---|
| Micro | Minutes | TDD, quick debug | Implicit |
| Meso | Hours-days | Feature A/B, prompt eval | Explicit |
| Macro | Weeks-months | Product MVP, architecture bet | Documented, pre-registered |
