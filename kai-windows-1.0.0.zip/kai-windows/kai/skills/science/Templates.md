# Science Templates

Copy and adapt. Use the quick version unless stakes or audience call for the full one.

---

## Goal

```markdown
## Goal: [Name]
**Created:** [date] | **Status:** ACTIVE / ACHIEVED / ABANDONED

### Outcome
[What will be true when we succeed: specific and observable]

### Success criteria
**Quantitative:**
- [ ] [Metric]: [target]
**Qualitative:**
- [ ] [Observable behavior]
**Leading / lagging:** [early signal] / [final confirmation]

### Thresholds
- **Minimum:** [bare win]
- **Target:** [the aim]
- **Stretch:** [outstanding]

### Constraints
- **Time:** [deadline] | **Resources:** [limits] | **Quality:** [standards] | **Technical:** [limits] | **Ethical:** [lines]

### Anti-goals
- [Out of scope]

### Pre-registration
Locked at [timestamp]; not modified after data collection begins.
```

Quick:
```markdown
### Goal: [Name]
- **Success:** [one-sentence outcome]
- **Metric:** [primary target]
- **Deadline:** [when]
- **NOT doing:** [key anti-goal]
```

---

## Hypothesis set

```markdown
# Hypotheses: [Problem]
**Goal:** [reference] | **Date:** [date]

### H1: [Name]
**Status:** UNTESTED / TESTING / CONFIRMED / REFUTED / INCONCLUSIVE
**Claim:** [precise, testable statement]
**If-then:** If [condition], then [outcome], because [mechanism]
**Evidence for:** [...]
**Evidence against:** [...]
**WRONG if:** [specific observable outcome]
**Test cost:** [time/resources] | **Confidence:** L/M/H because [...]

### H2 ... H3 ... [minimum 3, preferably 5+]

### Null hypothesis
[What if nothing needs to change?]

### Priority
| Rank | Hypothesis | Likelihood | Impact | Test cost | (L x I) / C |
|---|---|---|---|---|---|
```

Quick:
```markdown
### H[N]: [Name]
- **Claim:** [what we think]
- **Because:** [why]
- **Wrong if:** [falsification]
- **Test cost:** L/M/H
```

---

## Experiment

```markdown
## Experiment: [Name]
**ID:** EXP-[N] | **Testing:** H[N] | **Status:** DESIGNED / RUNNING / COMPLETE / ABORTED

### Outcomes (PRE-COMMITTED)
- **CONFIRMED if:** [condition]
- **REFUTED if:** [condition]
- **INCONCLUSIVE if:** [condition]

### Variables
- **Independent:** [what we change]
- **Dependent:** [what we measure]
- **Controls:** [held constant, at what value]
- **Confounders:** [risk → mitigation]

### Method
1. [step]
**Control:** [baseline] | **Treatment:** [what's tested]

### Data
| Metric | How measured | Target |
|---|---|---|
**Sample size:** [N] | **Duration:** [how long] | **Raw data kept at:** [location]

### Stopping rules
- Stop early if: [success / failure / safety condition]
- Continue until: [minimum sample or duration]
```

Quick:
```markdown
### EXP: [Name]
- **Testing:** H[N]
- **Method:** [brief]
- **Measuring:** [primary metric]
- **Confirmed if:** [condition]
- **Refuted if:** [condition]
```

---

## Results and analysis

```markdown
## Results: [Experiment]
**Experiment:** EXP-[N] | **Hypothesis:** H[N] | **Run:** [dates]

### Verdict
**[CONFIRMED / REFUTED / INCONCLUSIVE]**: [one sentence on what happened]

### Data
| Metric | Baseline | Result | Change | Target | Met? |
|---|---|---|---|---|---|

### Observations and anomalies
- [...]

### Data quality
Completeness: [...] | Accuracy: [...] | Outliers: [none / listed]

### Goal comparison
| Criterion | Required | Achieved | Met? |
|---|---|---|---|
**Overall:** ACHIEVED / PARTIALLY / NOT ACHIEVED

### Learnings
1. [key insight]
2. [surprise]
**Mental model:** before [X], now [Y]

### Limitations and alternative interpretations
- [...]

### Next steps
- [recommended action]
- [follow-up question]
```

Quick:
```markdown
### Results: [Experiment]
- **Tested:** H[N]
- **Verdict:** CONFIRMED / REFUTED / INCONCLUSIVE
- **Key metric:** [value] vs [target]
- **Learning:** [main insight]
- **Next:** [action]
```

---

## Iteration decision

```markdown
# Iteration: Cycle [N]
**Analysis summary:** [one sentence]
**Decision:** SHIP / CONTINUE / PIVOT / STOP
**Rationale:** [why]

- If continuing: next hypothesis [name], next experiment [brief]
- If shipping: implementation [brief], monitoring metric [what], rollback trigger [when]
- If pivoting: new frame [description], what changed [evidence]
- If stopping: reason [...], what we learned anyway [...]

**World-model update:** [belief]: [up/down] because [evidence]
**Next decision point:** [when]
```

---

## Investigation summary (close-out)

```markdown
## Investigation: [Problem]
**Date:** [when] | **Duration:** [how long]
**Goal:** [what we set out to achieve]
**Key finding:** [one sentence]
**Hypotheses:** H1 [verdict], H2 [verdict], H3 [verdict]
**Resolution:** [what we did / learned]
**Reusable learnings:** [generalizable insights]
```
