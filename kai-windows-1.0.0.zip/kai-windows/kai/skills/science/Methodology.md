# Science Methodology

Each phase in depth. Use a single section when only that phase is needed. Templates for writing each phase up are in `Templates.md`.

---

## Phase 0: Goal

**You cannot judge experiments without success criteria.** If you can't say precisely what success looks like, stop and define it.

1. **Outcome.** What will exist or change when we succeed? Describe it as if it already happened, concretely and observably.
   - "Make the app faster" → "Page load is under 1s for 95% of users."
   - "Fix the bug" → "Users complete checkout without the 500 error."
2. **Indicators.** Quantitative metrics, qualitative observable behaviors, leading indicators (early signals you're on track), lagging indicators (final confirmation).
3. **Thresholds.** Minimum (bare win), target (the aim), stretch (outstanding). This avoids binary thinking; partial success is information.
4. **Constraints.** Time, resources, quality standards to keep, technical limits, ethical lines.
5. **Anti-goals.** What we are explicitly NOT doing. Prevents scope creep and clarifies trade-offs.

**Quality check.** Specific (clear what success is)? Measurable (objectively decidable)? Falsifiable (could we fail? if not, too vague)? Time-bound? Constrained? Refine until all five hold.

**Pre-registration.** Write the criteria down and timestamp them before gathering evidence. Don't change them post hoc. Wanting to move goalposts after seeing data is the red flag: either the original goal was wrong (say so explicitly) or you are rationalizing.

Pitfalls: vague outcomes; no way to fail ("improve UX" vs "task completion 60% → 80%"); moving goalposts ("we missed the number but it feels better"); missing constraints ("optimize" with unlimited time?); unstated anti-goals letting scope grow.

Weak vs strong:

> Weak: "Improve the login experience."
>
> Strong: Outcome: users log in without friction. Indicators: login tickets 50/week → <10/week; time-to-login 15s → <5s; satisfaction >4.5/5. Thresholds: minimum 50% fewer tickets; target 80% fewer + <5s; stretch zero tickets + <3s. Constraints: keep OAuth and SAML; no new third-party deps without security review; two sprints. Anti-goals: not redesigning auth; not adding auth methods.

---

## Phase 1: Observe

**You cannot solve what you don't understand.** Skipping this leads to fixing symptoms, reinventing existing solutions, missing constraints and building on false assumptions.

1. **Gather existing knowledge.** What do we know, what has been tried and with what result, what do sources say?
2. **Map current state.** How does it work now, where are the pain points, what workarounds exist, what data do we have?
3. **Identify gaps.** What don't we know, what are we assuming, what would change our approach if true?
4. **Baseline.** Current metrics, what "normal" is, the trend, relevant benchmarks.

Quality check: looked broadly before focusing; grounded in data not assumption; actively sought disconfirming evidence; information is current; baseline is quantified.

---

## Phase 2: Hypothesize

**Never generate just one hypothesis.** One hypothesis breeds confirmation bias, misses better alternatives, invites sunk cost, and frames the problem narrowly. Minimum 3; 5-10 for important problems.

1. **Diverge (quantity over quality).** 10-20 raw ideas, no judgment. Techniques: brainstorm; reverse brainstorm ("how would we make it worse?"); analogy ("how do other domains solve this?"); constraint removal ("with unlimited time/money/expertise..."); orthogonal ("what if the whole frame is wrong?"). For important problems, run parallel generators from different angles (technical, user, assumption-challenging, analogous-domain) and merge.
2. **Categorize.** Root-cause hypotheses ("the problem is X because Y"); solution hypotheses ("approach A would fix it"); paradigm hypotheses ("the framing is wrong because..."); the null ("nothing is wrong" / "current state is optimal"). Note which assumption each one challenges.
3. **Refine.** Each gets: claim, rationale, testable prediction ("if correct, then ___"), falsification ("WRONG if ___"), cost to test, confidence with reason.
4. **Prioritize.** Score (likelihood x impact) / cost to test. Test cheap, high-likelihood hypotheses first. Note dependencies.

Quality check per hypothesis: specific, testable, falsifiable, distinct from the others, actionable (confirming it tells us what to do).

**Confirmation-bias countermeasures.** Pre-mortem ("imagine it failed completely; why?"); argue against your favorite; ask what evidence would make you LESS confident; have an independent reviewer attack the set; always keep the null.

Pitfalls: "I think it's the database" (one idea) vs "database, cache, API, or client rendering"; unfalsifiable ("code quality is poor" vs "module X has cyclomatic complexity > 20"); testing your 90% favorite first instead of the cheapest; assuming something must be broken.

---

## Phase 3: Design the experiment

**Minimum viable experiment: the smallest test that could prove the hypothesis wrong.** The goal is learning, not perfection. Ask: fastest way to learn? cheapest meaningful data? what result would disprove it? minimum sample for confidence?

1. **Pre-commit outcomes.** CONFIRMED if ___ / REFUTED if ___ / INCONCLUSIVE if ___. Defined before running, to block post-hoc rationalization.
2. **Variables.** Independent (what we change), dependent (what we measure), controls (held constant, at what value), confounders (what could skew results, and the mitigation for each).
3. **Method.** Steps, control/baseline vs treatment, primary metric, how and when it's measured.
4. **Data plan.** Data points, collection method, sample size, duration, where raw data is preserved.
5. **Stopping rules.** Stop early for clear success, clear failure, or safety; continue until a minimum sample or duration; a defined endpoint.

Quality check: minimal, falsifiable, measurable, controlled, reproducible, pre-committed.

**Patterns by domain.**
- **Code.** One isolated variant per approach (separate branches or worktrees) against a control. Run the same test suite and benchmarks on each; compare pass/fail, performance and complexity.
- **Prompts.** Baseline plus 3+ variants pushing in different directions, run on the same fixed input set (aim for enough cases to separate signal from noise; dozens minimum, ~100 for small effects). Pre-commit the margin that counts as a win (e.g. beats baseline by >5% with no regression on secondary criteria). Grade with deterministic checks where possible. For model-graded criteria, use a judge persona (`@kai-reviewer`) that sees outputs blind to which variant produced them, swap presentation order between runs to cancel positional bias, require reasoning before the score, and use more than one judge if stakes warrant.
- **Features.** Feature flag or A/B split (e.g. 50/50), primary and secondary metrics, minimum duration (often 2+ weeks), success as lift above threshold at a stated confidence with no secondary regression.
- **Research.** Separate investigators for supporting evidence, contradicting evidence and alternative explanations. Rate source quality, recency and consensus. Success: preponderance of high-quality evidence and no strong contradiction.
- **UI/UX.** Build several design variants in parallel and compare them on the same tasks; verify each in a real browser rather than trusting the code.

**Parallelism.** When hypotheses are independent, run their experiments at the same time and compare directly. Requires independence, available resources and comparable results.

Pitfalls: over-engineering test infrastructure for a simple question; tests that can only succeed; changing criteria after seeing results; attributing every difference to the treatment; declaring results from N=3.

---

## Phase 4: Execute

1. **Prepare.** Prerequisites met, measurement ready, criteria clear, logging on.
2. **Run as designed.** Don't change parameters mid-run except to abort. Document unexpected events.
3. **Watch without peeking.** Monitor for anomalies and clear failure, but don't look at aggregate results early and stop when they look good.

Quality check: faithful to design, complete data, documented deviations, no mid-run adjustment.

---

## Phase 5: Measure

**Principles.** Measure what relates to the goal (more data is not better data). Quantify where possible ("felt faster" < "load time down 40%"), but don't force numbers onto qualitative insight. Capture context: conditions, anomalies, environment. Preserve raw data unmodified; derived metrics can be recomputed, raw data can't.

1. **Primary metrics.** The direct measure of the success criteria: baseline, measured, delta, method.
2. **Secondary metrics.** Context, early warnings, sanity checks.
3. **Qualitative.** Observations, feedback, anomalies, surprises.
4. **Validate quality.** Complete? Methods worked? Outliers real or errors? Do the numbers make sense?

Domain shapes: code (per-branch tests, coverage, timing, benchmark deltas, complexity); prompts (per-variant N, correct, rate, 95% CI, format compliance); A/B (per-group N, conversions, rate, CI, lift and p-value); research (evidence for and against, each with source, finding, quality, date).

Pitfalls: stopping when early numbers look good; recording only supportive data; numbers with no context; keeping only summaries; measurement that changes the outcome.

---

## Phase 6: Analyze

**Did we achieve what we committed to?** Compare to the pre-registered criteria, not to expectations or hopes.

1. **Goal comparison.** Each criterion: required, actual, met or not. Overall: ACHIEVED / PARTIALLY ACHIEVED / NOT ACHIEVED.
2. **Hypothesis verdicts.** Data matches prediction → CONFIRMED. Contradicts → REFUTED. Unclear or insufficient → INCONCLUSIVE. State the evidence and confidence.
3. **Learnings.** What changed in our understanding (before we thought X; now we understand Y), what surprised us.
4. **Limitations.** Methodological weaknesses and how they affect conclusions, generalizability, alternative interpretations.
5. **New questions.** Follow-ups and hypotheses for the next cycle.

**Countermeasures.** Compare only against pre-registered criteria ("we missed, but..." is the red flag). Argue the opposite conclusion. Ask what interpretation would lower your confidence. Steel-man a failure for its lesson. Have `@kai-reviewer` attack the conclusions.

**Statistics, when warranted.** Name the test and why; report statistic, p-value, effect size, confidence interval. p < 0.05 is convention but effect size matters more; huge samples make trivial effects "significant"; small samples hide real ones; intervals say more than p-values. Note assumption violations.

Quality check: pre-committed, objective, honest about null and negative results, complete (no cherry-picking), humble about limitations, extracts learnings not just verdicts.

---

## Phase 7: Iterate

**Fast cycles beat perfect experiments.** Each cycle should be faster than the last.

```
Goal achieved? ── yes ──► SHIP: document, implement, monitor, record learnings
      │ no
Hypothesis confirmed? ── yes ──► IMPLEMENT and MONITOR (metric, cadence, rollback trigger)
      │ no
Untested hypotheses left? ── yes ──► TEST NEXT (say why that one, and what the failure taught)
      │ no
ALL REFUTED ──► find the pattern in the failures and the wrong assumptions, generate new hypotheses
                (orthogonal approaches, challenge fundamentals, analogous problems)
INCONCLUSIVE ──► redesign the experiment (bigger sample, cleaner data, control the confounder)
FRAME IS WRONG ──► state the old frame, the evidence against it, the new frame; return to GOAL
```

**World-model update.** Before: we believed / assumed. After: we now know. Confidence changes per belief, with the evidence. Prior → evidence → posterior.

**When to stop.** Goal achieved (even at the minimum threshold); diminishing returns; constraints force a decision; the problem changed; a better opportunity appeared. **Not** because you're frustrated, want to avoid a negative result, it's taking longer than hoped, or you're attached to a hypothesis.

**Signs you're stuck.** Same hypotheses cycling; scope expanding; "just one more experiment"; fear of declaring success or failure. Set an iteration limit up front ("5 cycles max, then decide").

Pitfalls: quitting after one refuted hypothesis; refusing to ship a met goal; "that didn't work, try something else" without the why; staying in a frame the evidence has broken; not recording learnings (save reusable ones with Kai's memory).

---

## Science applied to itself

The method improves itself the same way: track which experiment designs produce insight, try methodology variants on real problems, compare learning rate and success rate, keep what works.
