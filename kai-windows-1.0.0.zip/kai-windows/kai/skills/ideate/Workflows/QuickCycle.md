# QuickCycle: one compressed cycle

Fast novelty without the Loop Controller: CONSUME, STEAL, MATE, TEST, once. No perturbation phases (DREAM, DAYDREAM, CONTEMPLATE), no EVOLVE or META-LEARN. Trades depth for speed.

## Inputs

Problem statement (required), domains (optional, default 2-3 chosen from the problem), target count (default 8).

## Steps

1. `python "$HOME/.copilot/skills/ideate/tools/ideate.py" init "<problem>" --quick --time-scale hours`
2. **CONSUME:** /research in standard mode over the direct domain plus 1-2 distant ones. 10-20 atomic ideas tagged by domain; save with `--phase CONSUME`.
3. **STEAL:** `python "$HOME/.copilot/skills/ideate/tools/ideate.py" lottery <run> --count 2`; 2-3 mapped patterns per domain; save with `--phase STEAL`.
4. **MATE:** `python "$HOME/.copilot/skills/ideate/tools/ideate.py" pairs <run> --count <1.5 x target> --cross-phase 0`; per pair one crossover and one dice-rolled mutation (skip clone with drift). Save with `--phase MATE`.
5. **TEST:** 3 judge subagents score each offspring (rubric in `Test.md`); no red-team pass, no external validation. `python "$HOME/.copilot/skills/ideate/tools/ideate.py" score <run> --file scores.json`.
6. `python "$HOME/.copilot/skills/ideate/tools/ideate.py" report <run> --top <target>`; drop the bottom 25% from the presentation.

## Output

The top N candidates by composite, each with dimension scores, a supporting and a counter argument and provenance (parents and operation), plus one line on what the input pool was made of. No Historian section; one cycle has no cross-cycle pattern.

## When not to use it

When genuinely new ideas matter (no DREAM means bounded creativity) or learning across cycles matters, use FullCycle. When scoring isn't needed, use /be-creative.
