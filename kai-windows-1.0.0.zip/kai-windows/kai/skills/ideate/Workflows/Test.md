# Test: the TEST phase alone

Score a pool of candidates on the four standard dimensions with several independent judges. No breeding or selection.

## Inputs

Candidates (required), problem statement as the fitness function (required), judge count (default 3), red-team pass (default on), external validation (optional).

## Steps

1. Load candidates if they aren't in a run yet: `python "$HOME/.copilot/skills/ideate/tools/ideate.py" init "<problem>" --quick`, `python "$HOME/.copilot/skills/ideate/tools/ideate.py" add <run> --phase MATE --file candidates.json` (any phase tag works).
2. Optional adversarial pass: /red-team each candidate; record fatal flaws as `redteam_findings` so judges see them.
3. Spawn the judges as parallel `task` subagents with different personas (for example `@kai-reviewer` as a skeptical engineer, `@kai-architect` as a systems designer, a domain expert persona). Each judge scores every candidate independently, without seeing the others' scores.
4. Optional external validation: search for existing implementations or technical blockers; express each as a `modifier` from -20 to +20 with `evidence`.
5. `python "$HOME/.copilot/skills/ideate/tools/ideate.py" score <run> --file scores.json`, then present the ranking (or `python "$HOME/.copilot/skills/ideate/tools/ideate.py" report <run>`).

## Rubric (0-100 per dimension)

| Dimension | Measures | 0 | 100 |
|---|---|---|---|
| Feasibility | can this actually be built or done? | violates physics | proven technology, clear path |
| Novelty | is it genuinely new? | already exists as described | never been tried |
| Impact | if it works, how much does it matter? | marginal | paradigm shift |
| Elegance | is the solution simple and beautiful? | Rube Goldberg | obvious in retrospect |

Each judge gives, per candidate: the four scores, one supporting sentence and one counter sentence. Judge prompt output format, one row per judge per candidate:

```json
{"id": "idea-031", "judge": "skeptical-engineer", "feasibility": 68, "novelty": 84, "impact": 72, "elegance": 79,
 "supporting": "...", "counter": "...", "modifier": -5, "evidence": "partial prior art in gossip protocols"}
```

## Aggregation (done by the tool)

Per-dimension mean across judges; composite = weighted mean of the four; judge variance across per-judge averages; confidence = 1 / (1 + stdev / 10); adjusted composite = composite + summed modifiers capped at +/-20.

High variance is information: the idea is polarising and judges legitimately disagree. Low variance is consensus. Report both.
