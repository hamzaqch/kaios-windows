# Steal: the STEAL phase alone

Scavenge solutions from foreign domains and map them onto the problem. No scoring, breeding or iteration.

## Inputs

Problem statement (required), domains (optional; otherwise drawn by lottery), patterns per domain (default 3), one agent per domain (default 3-5).

## Steps

1. Domains: the user's list, or `python "$HOME/.copilot/skills/ideate/tools/ideate.py" init "<problem>" --quick` then `python "$HOME/.copilot/skills/ideate/tools/ideate.py" lottery <run> --count 4`. At least one must be distant from the problem's native field (biology for software, jazz for logistics); the lottery enforces this.
2. One parallel Thief `task` per domain (with /research for domain material). Deliverable per pattern: "In <foreign domain>, they solve <analogous problem> by <technique>. Applied to our problem: <mapping>." plus an analogy strength 1-5.
3. Save each mapping with `python "$HOME/.copilot/skills/ideate/tools/ideate.py" add <run> --phase STEAL --domains <domain> --text "..."`.

## Output

```markdown
## Borrowed patterns
### From mycology (the Thief)
1. **Mycelial network consensus** (analogy strength 5)
   - Foreign problem: distributing nutrients across a forest floor
   - Technique: chemical gradient signalling, no central coordinator
   - Mapped: gossip-based consensus with bias-vector signals
```

Never ask a model to "pick interesting domains"; the lottery exists to defeat training-distribution bias. If a pattern can't be mapped, it isn't borrowed, it's noise.
