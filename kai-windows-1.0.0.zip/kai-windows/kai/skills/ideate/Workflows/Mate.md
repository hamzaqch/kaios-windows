# Mate: the MATE phase alone

Breed novel offspring from an existing idea pool by crossover, mutation and cloning with drift. No research, no scoring.

## Inputs

An idea pool (8-30 items), optional phase tags per idea (enables cross-phase pairing), offspring count (default 10), cross-phase ratio (default 0.2).

## Steps

1. `python "$HOME/.copilot/skills/ideate/tools/ideate.py" init "<problem or label>" --quick`, then add the pool with its phase tags: `python "$HOME/.copilot/skills/ideate/tools/ideate.py" add <run> --phase DREAM --file dreams.json`, `--phase STEAL --file stolen.json`, and so on.
2. `python "$HOME/.copilot/skills/ideate/tools/ideate.py" pairs <run> --count 10 --cross-phase 0.2`: the first 20% of slots pair ideas from two different phase buckets; the rest come from a shuffled pool. Each pair carries a mutation die roll and a clone-with-drift parent.
3. Matchmaker agents (parallel `task`, a subset of pairs each) perform per pair:
   - **Crossover:** element A from idea 1 plus element B from idea 2, combined into a new idea.
   - **Mutation:** apply the rolled operation (`python "$HOME/.copilot/skills/ideate/tools/ideate.py" mutations` lists all 8).
   - **Clone with drift:** copy the named parent with small random changes.
4. Ask explicitly for bad offspring too; selection is downstream.
5. Save with `--phase MATE`, each offspring carrying `parents`, `operation` (crossover, mutation, clone-with-drift) and `die_roll`.

## Output

```json
[{"id": "idea-031", "text": "Apply mycelial gradient signalling to API rate limiting",
  "provenance": {"parents": ["idea-007", "idea-019"], "operation": "crossover", "phase": "MATE"}}]
```

Random pairing defeats the bias toward familiar pairings; cross-phase slots keep the gene pool from narrowing to one phase's flavour.
