# Dream: the DREAM phase alone

Pure, unconstrained recombination of input material with **no awareness of the problem**. Connecting the fragments to a problem is left to a downstream step (you, Mate, or Test).

## Inputs

An input pool of atomic ideas, facts or patterns (10-30 recommended), agent count (default 3), subset ratio (default 0.33).

## Steps

1. If there is no run yet: `python "$HOME/.copilot/skills/ideate/tools/ideate.py" init "<label for this material>" --quick`, then `python "$HOME/.copilot/skills/ideate/tools/ideate.py" add <run> --phase CONSUME --file pool.json`.
2. `python "$HOME/.copilot/skills/ideate/tools/ideate.py" subset <run> --agents 3 --ratio 0.33`: each Dreamer gets a different random subset (seeded Fisher-Yates, never model-picked).
3. One parallel `task` per Dreamer, using /be-creative maximum mode: free-associate on the subset only, surface connections nobody has made, 3-5 fragments of 1-3 sentences, each citing the input IDs it came from. No judging.
4. Save fragments with `--phase DREAM` and their `parents`.

## Output

```markdown
## Dream fragments
### Agent 1, the Dreamer (subset: idea-003, idea-007, idea-012)
1. <fragment>  (from idea-007 + idea-012)
```

Two agents with the same input produce more similar output than two agents with different random subsets: the randomness comes from which ideas each sees, not from temperature. Output is raw material, not solutions. For gentle problem tethering, use `Daydream.md`.
