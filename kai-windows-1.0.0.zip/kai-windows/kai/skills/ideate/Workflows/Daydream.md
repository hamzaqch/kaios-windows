# Daydream: the DAYDREAM phase alone

Tangential wandering with the problem held loosely in the background (noise 0.5). Between Dream (no problem) and Contemplate (problem front and centre).

## Inputs

The problem statement, accumulated material (an input pool and any dream fragments), agent count (default 2-3).

## Steps

1. Load the material into a run if needed (`python "$HOME/.copilot/skills/ideate/tools/ideate.py" init ... --quick`, `python "$HOME/.copilot/skills/ideate/tools/ideate.py" add ... --phase CONSUME`), then `python "$HOME/.copilot/skills/ideate/tools/ideate.py" subset <run> --agents 3 --ratio 0.5` so each agent starts from different material.
2. One parallel `task` per agent: "Here is some material. Somewhere in the back of your mind is this problem: <problem>. Don't solve it. Wander. Follow whatever catches your attention and note where it leads." 3-5 tangential insights each, citing the material that started them.
3. Save with `--phase DAYDREAM` and `parents`.

## Output

A list of tangential insights per agent with provenance. The constraint relaxation is the mechanism: an insight that "solves" the problem directly usually means the agent held it too tightly.
