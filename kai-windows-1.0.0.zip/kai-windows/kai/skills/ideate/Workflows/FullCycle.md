# FullCycle: all nine phases under the Loop Controller

The default Ideate workflow. Phases run in sequence within a cycle; agents within a phase run in parallel as separate `task` calls. Two checkpoints gate progress, and the Loop Controller decides at each cycle boundary.

## Inputs

- **Problem statement** (required).
- **time_scale** (optional, default `weeks`): hours, days, weeks, months, years, decades.
- **domains** (optional): seed domains to consume from.
- **seed ideas or URLs** (optional): starting material for cycle 1.
- **target score** (optional): stop when a candidate reaches it.

## Start

```
python "$HOME/.copilot/skills/ideate/tools/ideate.py" init "<problem>" --time-scale weeks [--domains a,b] [--target-score 80]
```

Note the run slug it prints; every later command takes it.

## Phase 1: CONSUME (ingest)

Cycle 2+ also receives survivors, the META-LEARN questions (`python "$HOME/.copilot/skills/ideate/tools/ideate.py" status <run>` shows them) and updated domain weights.

- Use /research (standard or extensive) across problem-adjacent and problem-distant domains. Use `python "$HOME/.copilot/skills/ideate/tools/ideate.py" lottery <run> --count 3` for the distant ones.
- At least 3 distinct domains per cycle, spanning 3 of: direct, adjacent, distant, historical, contrarian.
- Extract atomic ideas, one concept each, tagged with source domain. Save: `python "$HOME/.copilot/skills/ideate/tools/ideate.py" add <run> --phase CONSUME --file consume.json`.

## Phase 2: DREAM (noise 0.9)

- `python "$HOME/.copilot/skills/ideate/tools/ideate.py" subset <run> --agents 3` gives each Dreamer a different random subset of the pool.
- One parallel `task` per Dreamer, using /be-creative maximum mode, with **no problem awareness**: free-associate on the subset only and surface connections nobody has made.
- 3-5 fragments per agent, each citing the input IDs it came from (`parents`). Save with `--phase DREAM`.

## Phase 3: DAYDREAM (noise 0.5)

- 2-3 agents get the accumulated material plus a gentle mention of the problem, held loosely in the background and not being solved. Following what catches attention is the mechanism.
- 3-5 tangential insights each. Save with `--phase DAYDREAM`.

## Phase 4: CONTEMPLATE (noise 0.1, required)

- 2-4 agents analyse everything so far with the problem front and centre, through four lenses: Literal, Failure, Analogical, Constraint Inversion (/iterative-depth; /first-principles to challenge assumptions).
- 2-4 structured analyses each. Save with `--phase CONTEMPLATE`.
- **Checkpoint A:** `python "$HOME/.copilot/skills/ideate/tools/ideate.py" checkpoint-a <run> --analyses <n> --referencing <m>` (count analyses that reference the problem statement). On failure, re-run CONTEMPLATE with the problem injected more prominently.

## Phase 5: STEAL (cross-pollinate)

- `python "$HOME/.copilot/skills/ideate/tools/ideate.py" lottery <run> --count 4` picks the foreign domains (it forces at least one domain not used last cycle and one distant domain).
- One Thief agent per domain (/research inside each): find 2-3 patterns that solve analogous problems and write each as: "In <domain>, they solve <analogous problem> by <technique>. Applied to our problem: <mapping>." The mapping is the creative act; an unmappable pattern is noise.
- Save with `--phase STEAL` and `--domains <domain>`.

## Phase 6: MATE (recombination)

- `python "$HOME/.copilot/skills/ideate/tools/ideate.py" pairs <run> --count <n>` (at least 10) gives random pairs with the first 20% forced cross-phase, a mutation die roll and a clone-with-drift parent per pair.
- Matchmaker agents produce, per pair: one **crossover** (element A from one parent plus element B from the other), one **mutation** (the rolled operation), one **clone with drift** (the named parent with small random changes). Ask explicitly for bad ideas too.
- Save offspring with `--phase MATE`, each with `parents`, `operation` and `die_roll`.

## Phase 7: TEST (select)

- Optional adversarial pass: /red-team each candidate; record fatal flaws as `redteam_findings`.
- 3-5 judge agents (parallel `task`, different personas) independently score every MATE offspring 0-100 on Feasibility, Novelty, Impact and Elegance, with one supporting and one counter sentence each. See `Test.md` for the rubric.
- Optional external validation: search for prior art or blockers and add a `modifier` (-20..+20) with `evidence`.
- `python "$HOME/.copilot/skills/ideate/tools/ideate.py" score <run> --file scores.json` aggregates and runs **checkpoint B** (this cycle's average at least the previous average minus 5). If it reports `meta_learn_early`, run META-LEARN before EVOLVE to propose a pivot.

## Phase 8: EVOLVE (iterate)

`python "$HOME/.copilot/skills/ideate/tools/ideate.py" evolve <run>` kills the bottom 50%, keeps the top 10% unchanged, assigns a dice-rolled mutation to the rest, and records the diversity index. Then:

- Write each assigned mutation and save it with `--phase EVOLVE --parents <id>`.
- Write the immigrant ideas it asks for (2-3 completely new random ideas, from a fresh `lottery` domain) with `--phase IMMIGRANT`.

## Phase 9: META-LEARN (Lamarckian)

Analyse the cycle: which domains and phases parented the top scorers, which dimensions are hardest to satisfy, what was falsely attractive. Write the adjustments and 3-5 specific research questions for the next CONSUME:

```json
{"domain_weights": {"biology": 1.5, "history": 0.5}, "phase_weights": {"DREAM": 0.7, "STEAL": 1.3},
 "noise_adjustment": -0.05, "new_domains_to_explore": ["game-theory"], "kill_threshold_adjustment": 0.05,
 "breeding_strategy": "favor cross-domain over within-domain", "questions": ["...", "..."]}
```

`python "$HOME/.copilot/skills/ideate/tools/ideate.py" meta <run> --file adjustments.json` applies them within bounds.

## Loop Controller

`python "$HOME/.copilot/skills/ideate/tools/ideate.py" gate <run>`. CONTINUE or PIVOT: start the next cycle at CONSUME (on PIVOT, change domains, noise and agent personas noticeably). STOP: go to the Historian.

## The Historian (post-loop)

`python "$HOME/.copilot/skills/ideate/tools/ideate.py" report <run>` writes the ranked candidates, evolution table and meta-learning trajectory to `final-output.md`. Then add the insight sections: dominant lineages, fertile domain combinations, the fitness landscape (peaks, valleys, unexplored regions), what the process revealed about the problem itself, and recommendations for further exploration. Present the report in the format from `../SKILL.md`.
