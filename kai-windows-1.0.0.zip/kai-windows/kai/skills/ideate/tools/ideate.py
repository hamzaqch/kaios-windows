"""ideate: the deterministic half of the Ideate evolutionary engine (stdlib only).

The model and its subagents do the creative work (dream, steal, mate, judge). This
tool owns everything that must NOT be left to a model's taste: structural
randomness (Fisher-Yates subsets, weighted domain lottery, random pairing, mutation
dice), score aggregation across judges, selection, the diversity index, the
Loop Controller's continue/pivot/stop decision, state persistence and the final
ranked report with provenance.

    python ideate.py init "<problem>" [--time-scale weeks] [--domains a,b] [--target-score 80] [--seed N]
    python ideate.py status <run>
    python ideate.py add <run> --phase DREAM (--text "idea" | --file ideas.json) [--parents id1,id2] [--domains d]
    python ideate.py subset <run> [--agents 3] [--ratio 0.33] [--phases CONSUME,DREAM]
    python ideate.py lottery <run> [--count 3]
    python ideate.py pairs <run> [--count 10] [--cross-phase 0.2]
    python ideate.py checkpoint-a <run> --analyses 8 --referencing 3
    python ideate.py score <run> --file scores.json
    python ideate.py evolve <run>
    python ideate.py meta <run> --file adjustments.json
    python ideate.py gate <run>
    python ideate.py report <run> [--top 10]
    python ideate.py domains | mutations

<run> is a run folder or its slug. Runs live in ~/.copilot/kai/MEMORY/WORK/<slug>/ideate/.
All randomness is seeded from the problem hash, the cycle and a per-call counter,
so a run is reproducible; pass --seed to init to choose the seed.
"""
import argparse
import datetime as _dt
import hashlib
import itertools
import json
import math
import os
import random
import re
import sys
import time
from pathlib import Path

TIME_SCALES = {"hours": 5, "days": 12, "weeks": 25, "months": 45, "years": 90, "decades": 180}  # budget minutes
AGENTS_PER_PHASE = {"hours": 2, "days": 3, "weeks": 4, "months": 5, "years": 6, "decades": 8}
PHASES = ["CONSUME", "DREAM", "DAYDREAM", "CONTEMPLATE", "STEAL", "MATE", "TEST", "EVOLVE", "META-LEARN", "IMMIGRANT", "SEED"]
DIMENSIONS = ("feasibility", "novelty", "impact", "elegance")
MUTATIONS = {
    1: "flip one assumption",
    2: "invert the constraint",
    3: "change the scale (10x bigger or smaller)",
    4: "change the time horizon",
    5: "merge with the best element of a random killed idea",
    6: "apply a constraint from a random domain",
    7: "remove the most complex component",
    8: "add an adversarial requirement",
}
DOMAIN_POOL = {
    # distance: 1 = adjacent to most software/business problems, 3 = distant
    "biology": 3, "mycology": 3, "immunology": 3, "ecology": 3, "evolutionary-biology": 3, "neuroscience": 2,
    "epidemiology": 2, "ethology": 3, "botany": 3, "marine-biology": 3, "physics": 2, "thermodynamics": 3,
    "materials-science": 3, "fluid-dynamics": 3, "chemistry": 3, "geology": 3, "astronomy": 3, "meteorology": 3,
    "architecture": 2, "urban-planning": 2, "civil-engineering": 2, "logistics": 1, "supply-chain": 1,
    "manufacturing": 1, "aviation": 2, "military-strategy": 2, "game-theory": 1, "economics": 1,
    "behavioral-economics": 1, "auction-design": 2, "insurance": 2, "finance": 1, "law": 2, "medicine": 2,
    "emergency-medicine": 2, "nursing": 2, "sports-coaching": 2, "music-composition": 3, "jazz-improvisation": 3,
    "theater": 3, "film-editing": 3, "cooking": 3, "agriculture": 3, "fashion": 3, "religion-and-ritual": 3,
    "anthropology": 2, "linguistics": 2, "history": 2, "archaeology": 3, "cartography": 3, "typography": 3,
    "game-design": 1, "magic-and-illusion": 3, "cryptography": 1, "distributed-systems": 1, "control-theory": 1,
    "operations-research": 1, "education": 2, "psychology": 1, "sociology": 2, "ant-colony-behavior": 3,
    "beekeeping": 3, "origami": 3, "sailing": 3, "mountaineering": 3,
}
DEFAULT_CONFIG = {
    "scoring_weights": {d: 1.0 for d in DIMENSIONS},
    "convergence_prevention": {"cross_phase_breeding_min": 0.2, "immigrant_ideas_per_cycle": 3, "kill_threshold": 0.5,
                               "elite_fraction": 0.1, "forced_new_domain_per_cycle": True},
    "loop_control": {"mode": "adaptive", "target_score": None, "max_stagnation_cycles": 3, "max_strategy_pivots": 2,
                     "diversity_floor": 0.3, "max_cycles": None},
    "randomness": {"seed": None, "subset_ratio": 0.33},
}
STOPWORDS = set("a an the of to in on for and or with by from as at is are be this that it its into via using use "
                "new more less than then when which who what how not no can will would should".split())


# ----------------------------------------------------------------- state helpers

def kai_home():
    if os.environ.get("KAI_HOME"):
        return Path(os.environ["KAI_HOME"])
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"]) / "kai"
    return Path.home() / ".copilot" / "kai"


def now_iso():
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def kebab(text, n=40):
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return s[:n].rstrip("-") or "run"


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except Exception:
        return default


def resolve_run(ref):
    p = Path(ref).expanduser()
    for cand in (p, p / "ideate"):
        if (cand / "config.json").exists():
            return cand
    cand = kai_home() / "MEMORY" / "WORK" / ref / "ideate"
    if (cand / "config.json").exists():
        return cand
    raise SystemExit(f"run not found: {ref}")


class Run:
    def __init__(self, path):
        self.path = Path(path)
        self.config = read_json(self.path / "config.json", {})
        self.state = read_json(self.path / "loop-state.json", {})
        self.pool = read_json(self.path / "domain-pool.json", {})
        self.ideas = read_json(self.path / "ideas.json", [])

    def save(self):
        write_json(self.path / "config.json", self.config)
        write_json(self.path / "loop-state.json", self.state)
        write_json(self.path / "domain-pool.json", self.pool)
        write_json(self.path / "ideas.json", self.ideas)

    @property
    def cycle(self):
        return int(self.state.get("cycle_count", 1))

    def cycle_dir(self):
        d = self.path / f"cycle-{self.cycle:03d}"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def rng(self, purpose):
        """Seeded RNG: run seed + cycle + purpose + a per-call counter, so repeated calls differ but replay identically."""
        counter = self.state.setdefault("rng_calls", {})
        key = f"{self.cycle}:{purpose}"
        n = counter.get(key, 0)
        counter[key] = n + 1
        material = f"{self.config['seed']}|{self.cycle}|{purpose}|{n}"
        seed = int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)
        return random.Random(seed), material

    def alive(self, cycle=None):
        return [i for i in self.ideas if i.get("status", "alive") == "alive"
                and (cycle is None or i["provenance"]["cycle"] == cycle)]

    def by_id(self, iid):
        return next((i for i in self.ideas if i["id"] == iid), None)

    def next_id(self):
        return f"idea-{len(self.ideas) + 1:03d}"


def fisher_yates(items, rng):
    a = list(items)
    for i in range(len(a) - 1, 0, -1):
        j = rng.randint(0, i)
        a[i], a[j] = a[j], a[i]
    return a


def tokens(text):
    return {w for w in re.findall(r"[a-z0-9]+", (text or "").lower()) if w not in STOPWORDS and len(w) > 2}


def diversity_index(texts):
    """1 - mean pairwise Jaccard similarity of content-word sets (1 = all different, 0 = identical)."""
    sets = [tokens(t) for t in texts if t]
    if len(sets) < 2:
        return 1.0
    sims = []
    for a, b in itertools.combinations(sets, 2):
        u = a | b
        sims.append(len(a & b) / len(u) if u else 1.0)
    return round(1.0 - sum(sims) / len(sims), 4)


def aggregate_scores(judgements, weights=None):
    """judgements: list of {feasibility, novelty, impact, elegance, ...} from independent judges (0-100)."""
    weights = weights or {d: 1.0 for d in DIMENSIONS}
    out = {}
    for d in DIMENSIONS:
        vals = [float(j[d]) for j in judgements if isinstance(j.get(d), (int, float))]
        out[d] = round(sum(vals) / len(vals), 2) if vals else 0.0
    tw = sum(weights.get(d, 1.0) for d in DIMENSIONS) or 1.0
    out["composite"] = round(sum(out[d] * weights.get(d, 1.0) for d in DIMENSIONS) / tw, 2)
    per_judge = []
    for j in judgements:
        vals = [float(j[d]) for d in DIMENSIONS if isinstance(j.get(d), (int, float))]
        if vals:
            per_judge.append(sum(vals) / len(vals))
    if len(per_judge) > 1:
        m = sum(per_judge) / len(per_judge)
        var = sum((x - m) ** 2 for x in per_judge) / (len(per_judge) - 1)
    else:
        var = 0.0
    out["judge_variance"] = round(var, 2)
    out["confidence"] = round(1.0 / (1.0 + math.sqrt(var) / 10.0), 3) if len(per_judge) > 1 else 0.5
    out["judges"] = len(judgements)
    mods = sum(float(j.get("modifier", 0) or 0) for j in judgements)
    mods = max(-20.0, min(20.0, mods))
    out["external_modifier"] = mods
    out["adjusted_composite"] = round(max(0.0, min(100.0, out["composite"] + mods)), 2)
    return out


# ----------------------------------------------------------------- commands

def cmd_init(a):
    seed = a.seed if a.seed is not None else int(hashlib.sha256(a.problem.encode("utf-8")).hexdigest()[:8], 16)
    slug = a.slug or f"{_dt.date.today().strftime('%Y%m%d')}-ideate-{kebab(a.problem)}"
    path = Path(a.dir).expanduser() if a.dir else kai_home() / "MEMORY" / "WORK" / slug / "ideate"
    if (path / "config.json").exists() and not a.force:
        raise SystemExit(f"run exists: {path} (use --force)")
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    cfg.update({"problem": a.problem, "slug": slug, "time_scale": a.time_scale, "seed": seed, "created": now_iso(),
                "domains": [d.strip() for d in (a.domains or "").split(",") if d.strip()],
                "agents_per_phase": AGENTS_PER_PHASE[a.time_scale], "mode": "quick" if a.quick else "full"})
    cfg["loop_control"]["target_score"] = a.target_score
    cfg["loop_control"]["max_cycles"] = 1 if a.quick else a.max_cycles
    budget = TIME_SCALES[a.time_scale] * 60
    state = {"cycle_count": 1, "started_epoch": time.time(), "budget_seconds": budget,
             "budget_seconds_remaining": budget, "fitness_history": [], "stagnation_counter": 0,
             "strategy_version": 1, "strategy_pivots_used": 0, "strategy_adjustments": {}, "loop_decision_log": [],
             "domains_used": {}, "questions": [], "rng_calls": {}}
    pool = {d: {"weight": 1.0, "distance": dist} for d, dist in DOMAIN_POOL.items()}
    for d in cfg["domains"]:
        pool.setdefault(kebab(d), {"weight": 1.5, "distance": 1})
    run = Run(path)
    run.config, run.state, run.pool, run.ideas = cfg, state, pool, []
    run.save()
    print(json.dumps({"run": str(path), "slug": slug, "seed": seed, "time_scale": a.time_scale,
                      "budget_minutes": TIME_SCALES[a.time_scale], "agents_per_phase": cfg["agents_per_phase"],
                      "mode": cfg["mode"]}, indent=2))
    return 0


def cmd_status(a):
    run = Run(resolve_run(a.run))
    st = run.state
    elapsed = time.time() - st.get("started_epoch", time.time())
    by_phase = {}
    for i in run.ideas:
        if i["provenance"]["cycle"] == run.cycle:
            by_phase[i["provenance"]["phase"]] = by_phase.get(i["provenance"]["phase"], 0) + 1
    print(json.dumps({"problem": run.config.get("problem"), "cycle": run.cycle, "mode": run.config.get("mode"),
                      "elapsed_minutes": round(elapsed / 60, 1),
                      "budget_minutes": round(st.get("budget_seconds", 0) / 60, 1),
                      "ideas_total": len(run.ideas), "alive": len(run.alive()), "this_cycle_by_phase": by_phase,
                      "stagnation_counter": st.get("stagnation_counter", 0),
                      "strategy_version": st.get("strategy_version", 1),
                      "fitness_history": st.get("fitness_history", []),
                      "last_decision": (st.get("loop_decision_log") or [None])[-1],
                      "next_questions": st.get("questions", [])}, indent=2, ensure_ascii=False))
    return 0


def _load_items(a):
    if a.text:
        return [{"text": a.text}]
    data = read_json(a.file)
    if data is None:
        raise SystemExit(f"cannot read JSON from {a.file}")
    if isinstance(data, dict):
        data = data.get("ideas") or [data]
    out = []
    for x in data:
        out.append({"text": x} if isinstance(x, str) else x)
    return out


def cmd_add(a):
    run = Run(resolve_run(a.run))
    phase = a.phase.upper()
    if phase not in PHASES:
        raise SystemExit(f"phase must be one of {', '.join(PHASES)}")
    added = []
    for item in _load_items(a):
        text = (item.get("text") or "").strip()
        if not text:
            continue
        parents = item.get("parents") or [p for p in (a.parents or "").split(",") if p]
        domains = item.get("domains") or item.get("source_domains") or [d for d in (a.domains or "").split(",") if d]
        idea = {"id": run.next_id(), "text": text, "title": item.get("title") or text[:70], "status": "alive",
                "provenance": {"parents": parents, "operation": item.get("operation") or a.operation or phase.lower(),
                               "mutation_type": item.get("mutation_type"), "mutation_die_roll": item.get("die_roll"),
                               "cycle": run.cycle, "phase": phase, "source_domains": domains,
                               "randomness_seed": item.get("randomness_seed")},
                "tags": item.get("tags") or {}}
        for d in domains:
            run.state.setdefault("domains_used", {}).setdefault(str(run.cycle), [])
            if d not in run.state["domains_used"][str(run.cycle)]:
                run.state["domains_used"][str(run.cycle)].append(d)
        run.ideas.append(idea)
        added.append(idea["id"])
    run.save()
    print(json.dumps({"added": added, "cycle": run.cycle, "phase": phase}))
    return 0


def _cycle_pool(run, phases=None):
    """Alive ideas born this cycle plus survivors carried into it; falls back to every alive idea."""
    pool = [i for i in run.alive()
            if i["provenance"]["cycle"] == run.cycle or run.cycle in (i.get("carried_into") or [])] or run.alive()
    if phases:
        pool = [i for i in pool if i["provenance"]["phase"] in phases]
    return pool


def cmd_subset(a):
    run = Run(resolve_run(a.run))
    phases = [p.strip().upper() for p in a.phases.split(",")] if a.phases else None
    pool = _cycle_pool(run, phases)
    if not pool:
        raise SystemExit("input pool is empty for this cycle; add CONSUME ideas first")
    ratio = a.ratio if a.ratio is not None else run.config["randomness"]["subset_ratio"]
    k = max(1, math.floor(len(pool) * ratio))
    agents = a.agents or run.config.get("agents_per_phase", 3)
    out = []
    for n in range(agents):
        rng, material = run.rng("subset")
        chosen = fisher_yates(pool, rng)[:k]
        out.append({"agent": n + 1, "seed_material": material,
                    "items": [{"id": i["id"], "text": i["text"]} for i in chosen]})
    run.save()
    write_json(run.cycle_dir() / f"subsets-{int(time.time())}.json", out)
    print(json.dumps({"pool_size": len(pool), "subset_size": k, "agents": out}, indent=2, ensure_ascii=False))
    return 0


def cmd_lottery(a):
    run = Run(resolve_run(a.run))
    rng, material = run.rng("lottery")
    prev = set(run.state.get("domains_used", {}).get(str(run.cycle - 1), []))
    pool = run.pool
    names = sorted(pool)
    chosen = []
    weights = {n: max(0.01, float(pool[n].get("weight", 1.0))) for n in names}
    for _ in range(min(a.count, len(names))):
        cand = [n for n in names if n not in chosen]
        total = sum(weights[n] for n in cand)
        r, acc = rng.random() * total, 0.0
        for n in cand:
            acc += weights[n]
            if acc >= r:
                chosen.append(n)
                break
    forced = []
    if run.config["convergence_prevention"].get("forced_new_domain_per_cycle") and prev and all(c in prev for c in chosen):
        fresh = [n for n in names if n not in prev and n not in chosen]
        if fresh:
            pick = fresh[rng.randrange(len(fresh))]
            chosen[-1] = pick
            forced.append(f"{pick} (new vs previous cycle)")
    if not any(pool[c].get("distance", 1) >= 3 for c in chosen):
        distant = [n for n in names if pool[n].get("distance", 1) >= 3 and n not in chosen]
        if distant:
            pick = distant[rng.randrange(len(distant))]
            chosen[0] = pick
            forced.append(f"{pick} (distant domain)")
    run.save()
    print(json.dumps({"cycle": run.cycle, "domains": chosen, "forced": forced, "seed_material": material,
                      "previous_cycle_domains": sorted(prev)}, indent=2))
    return 0


def cmd_pairs(a):
    run = Run(resolve_run(a.run))
    pool = _cycle_pool(run)
    if len(pool) < 2:
        raise SystemExit("need at least 2 ideas in the pool to pair")
    count = a.count or max(10, len(pool) // 2)
    ratio = a.cross_phase if a.cross_phase is not None else run.config["convergence_prevention"]["cross_phase_breeding_min"]
    rng, material = run.rng("pairs")
    buckets = {}
    for i in pool:
        buckets.setdefault(i["provenance"]["phase"], []).append(i)
    pairs = []
    n_cross = math.ceil(ratio * count) if len(buckets) > 1 else 0
    bucket_names = sorted(buckets)
    for _ in range(n_cross):
        b1, b2 = fisher_yates(bucket_names, rng)[:2]
        pairs.append((buckets[b1][rng.randrange(len(buckets[b1]))], buckets[b2][rng.randrange(len(buckets[b2]))], True))
    shuffled = []
    while len(pairs) + len(shuffled) // 2 < count:
        shuffled += fisher_yates(pool, rng)
    for x, y in zip(shuffled[0::2], shuffled[1::2]):
        if len(pairs) >= count:
            break
        if x["id"] == y["id"]:
            continue
        pairs.append((x, y, x["provenance"]["phase"] != y["provenance"]["phase"]))
    out = []
    for n, (x, y, cross) in enumerate(pairs, 1):
        roll = rng.randint(1, 8)
        drift_parent = x if rng.random() < 0.5 else y
        out.append({"pair": n, "parents": [x["id"], y["id"]], "texts": [x["text"], y["text"]],
                    "parent_phases": [x["provenance"]["phase"], y["provenance"]["phase"]], "is_cross_phase": cross,
                    "mutation_die_roll": roll, "mutation": MUTATIONS[roll], "clone_with_drift_parent": drift_parent["id"]})
    run.save()
    write_json(run.cycle_dir() / "pairs.json", out)
    print(json.dumps({"seed_material": material, "pairs": out,
                      "instructions": "For each pair: one crossover, one mutation using the rolled operation, "
                                      "one clone-with-drift of the named parent (FullCycle). Produce bad ideas too; "
                                      "selection happens in TEST. Add offspring with: add <run> --phase MATE --file "
                                      "offspring.json (each with parents, operation, die_roll)."},
                     indent=2, ensure_ascii=False))
    return 0


def cmd_checkpoint_a(a):
    run = Run(resolve_run(a.run))
    ratio = a.referencing / a.analyses if a.analyses else 0.0
    ok = ratio >= 0.3
    entry = {"cycle": run.cycle, "checkpoint": "A", "analyses": a.analyses, "referencing": a.referencing,
             "ratio": round(ratio, 3), "pass": ok, "ts": now_iso()}
    run.state.setdefault("checkpoints", []).append(entry)
    run.save()
    print(json.dumps(entry))
    if not ok:
        print("Checkpoint A failed: re-run CONTEMPLATE with the problem statement more prominent.", file=sys.stderr)
    return 0 if ok else 1


def cmd_score(a):
    run = Run(resolve_run(a.run))
    data = read_json(a.file)
    if not isinstance(data, list):
        raise SystemExit("scores file must be a JSON list of {id, judge, feasibility, novelty, impact, elegance, "
                         "supporting, counter, modifier?, evidence?}")
    grouped = {}
    for row in data:
        if not isinstance(row, dict) or "id" not in row:
            continue
        for d in DIMENSIONS:
            v = row.get(d)
            if v is not None and not (isinstance(v, (int, float)) and 0 <= v <= 100):
                raise SystemExit(f"{row.get('id')}: {d} must be a number 0-100")
        grouped.setdefault(row["id"], []).append(row)
    weights = run.config.get("scoring_weights")
    scored = []
    for iid, rows in grouped.items():
        idea = run.by_id(iid)
        if not idea:
            print(f"warning: unknown idea {iid}", file=sys.stderr)
            continue
        idea["scores"] = aggregate_scores(rows, weights)
        idea["scores"]["cycle"] = run.cycle
        idea["arguments"] = {"supporting": [r.get("supporting") for r in rows if r.get("supporting")],
                             "counter": [r.get("counter") for r in rows if r.get("counter")]}
        ev = [r.get("evidence") for r in rows if r.get("evidence")]
        if ev:
            idea["external_validation"] = ev
        if any(r.get("redteam_findings") for r in rows):
            idea["redteam_findings"] = sorted({f for r in rows for f in (r.get("redteam_findings") or [])})
        scored.append(idea)
    comps = [i["scores"]["adjusted_composite"] for i in scored]
    avg = round(sum(comps) / len(comps), 2) if comps else 0.0
    hist = run.state.get("fitness_history", [])
    prev_avg = hist[-1]["avg_score"] if hist else None
    ok = prev_avg is None or avg >= prev_avg - 5
    if not ok:
        run.state["stagnation_counter"] = run.state.get("stagnation_counter", 0) + 1
    entry = {"cycle": run.cycle, "checkpoint": "B", "avg": avg, "prev_avg": prev_avg, "pass": ok, "ts": now_iso()}
    run.state.setdefault("checkpoints", []).append(entry)
    run.save()
    write_json(run.cycle_dir() / "scores.json", [{"id": i["id"], **i["scores"]} for i in scored])
    print(json.dumps({"scored": len(scored), "avg_adjusted_composite": avg, "checkpoint_b": entry,
                      "meta_learn_early": (not ok) and run.state["stagnation_counter"] >= 2,
                      "top": sorted(({"id": i["id"], "score": i["scores"]["adjusted_composite"],
                                      "confidence": i["scores"]["confidence"]} for i in scored),
                                    key=lambda r: -r["score"])[:5]}, indent=2))
    return 0


def cmd_evolve(a):
    run = Run(resolve_run(a.run))
    cand = [i for i in run.alive() if (i.get("scores") or {}).get("cycle") == run.cycle]
    if not cand:
        raise SystemExit("no scored ideas this cycle; run score first")
    cp = run.config["convergence_prevention"]
    ranked = sorted(cand, key=lambda i: (-i["scores"]["adjusted_composite"], i["id"]))
    n = len(ranked)
    n_kill = int(math.floor(n * cp.get("kill_threshold", 0.5)))
    n_elite = max(1, int(math.ceil(n * cp.get("elite_fraction", 0.1))))
    keep = ranked[:n - n_kill] if n_kill < n else ranked[:1]
    killed = [i for i in ranked if i not in keep]
    rng, material = run.rng("evolve")
    survivors = []
    for rank, idea in enumerate(keep):
        if rank < n_elite:
            idea["evolve"] = {"cycle": run.cycle, "fate": "elite"}
        else:
            roll = rng.randint(1, 8)
            idea["evolve"] = {"cycle": run.cycle, "fate": "mutate", "mutation_die_roll": roll, "mutation": MUTATIONS[roll]}
        survivors.append(idea)
    for idea in killed:
        idea["status"] = "killed"
        idea["evolve"] = {"cycle": run.cycle, "fate": "killed"}
    texts = [i["text"] for i in survivors]
    div = diversity_index(texts)
    hist_entry = {"cycle": run.cycle, "ideas_in": n, "survived": len(survivors),
                  "avg_score": round(sum(i["scores"]["adjusted_composite"] for i in cand) / n, 2),
                  "top_score": ranked[0]["scores"]["adjusted_composite"], "diversity_index": div,
                  "strategy_version": run.state.get("strategy_version", 1)}
    hist = run.state.setdefault("fitness_history", [])
    hist[:] = [h for h in hist if h["cycle"] != run.cycle] + [hist_entry]
    run.save()
    out = {"seed_material": material, "fitness": hist_entry,
           "elite": [i["id"] for i in survivors if i["evolve"]["fate"] == "elite"],
           "mutate": [{"id": i["id"], "text": i["text"], "die_roll": i["evolve"]["mutation_die_roll"],
                       "mutation": i["evolve"]["mutation"]} for i in survivors if i["evolve"]["fate"] == "mutate"],
           "killed": [i["id"] for i in killed],
           "immigrants_needed": cp.get("immigrant_ideas_per_cycle", 3),
           "killed_elements_for_mutation_5": [{"id": i["id"], "text": i["text"]} for i in killed[:5]],
           "top3": [{"id": i["id"], "score": i["scores"]["adjusted_composite"], "text": i["text"]} for i in ranked[:3]]}
    write_json(run.cycle_dir() / "survivors.json", out)
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0


def _bounded(x, lo, hi):
    return max(lo, min(hi, x))


def cmd_meta(a):
    run = Run(resolve_run(a.run))
    adj = read_json(a.file)
    if not isinstance(adj, dict):
        raise SystemExit("adjustments file must be a JSON object")
    applied = {}
    for d, w in (adj.get("domain_weights") or {}).items():
        key = kebab(d)
        ent = run.pool.setdefault(key, {"weight": 1.0, "distance": 2})
        ent["weight"] = round(_bounded(float(w), 0.2, 3.0), 3)
        applied.setdefault("domain_weights", {})[key] = ent["weight"]
    for d in adj.get("new_domains_to_explore") or []:
        key = kebab(d)
        if key not in run.pool:
            run.pool[key] = {"weight": 1.5, "distance": 2}
            applied.setdefault("new_domains", []).append(key)
    cp = run.config["convergence_prevention"]
    if "kill_threshold_adjustment" in adj:
        cp["kill_threshold"] = round(_bounded(cp["kill_threshold"] + float(adj["kill_threshold_adjustment"]), 0.3, 0.7), 3)
        applied["kill_threshold"] = cp["kill_threshold"]
    if "noise_adjustment" in adj:
        r = run.config["randomness"]
        r["subset_ratio"] = round(_bounded(r["subset_ratio"] + float(adj["noise_adjustment"]), 0.15, 0.6), 3)
        applied["subset_ratio"] = r["subset_ratio"]
    for k in ("phase_weights", "breeding_strategy"):
        if k in adj:
            run.state.setdefault("strategy_adjustments", {})[k] = adj[k]
            applied[k] = adj[k]
    if adj.get("questions"):
        run.state["questions"] = [str(q) for q in adj["questions"]][:5]
        applied["questions"] = run.state["questions"]
    if applied:
        run.state["strategy_version"] = run.state.get("strategy_version", 1) + 1
    run.state.setdefault("meta_log", []).append({"cycle": run.cycle, "applied": applied, "ts": now_iso()})
    run.save()
    write_json(run.cycle_dir() / "meta-learning.json", {"input": adj, "applied": applied})
    print(json.dumps({"strategy_version": run.state["strategy_version"], "applied": applied}, indent=2))
    return 0


def decide(state, config, now=None):
    """Loop Controller gate. Returns (decision, reason)."""
    lc = config.get("loop_control", {})
    hist = state.get("fitness_history") or []
    now = now or time.time()
    elapsed = now - state.get("started_epoch", now)
    remaining = state.get("budget_seconds", 0) - elapsed
    if lc.get("max_cycles") and state.get("cycle_count", 1) >= lc["max_cycles"]:
        return "STOP", f"max_cycles {lc['max_cycles']} reached"
    if remaining <= 0:
        return "STOP", "budget exhausted"
    if not hist:
        return "CONTINUE", "no completed cycle yet"
    last = hist[-1]
    if state.get("stagnation_counter", 0) >= lc.get("max_stagnation_cycles", 3):
        if state.get("strategy_pivots_used", 0) < lc.get("max_strategy_pivots", 2):
            return "PIVOT", f"stagnation {state['stagnation_counter']} cycles; shift domains, noise and agents"
        return "STOP", "stagnated with every strategy pivot used"
    if last.get("diversity_index", 1.0) < lc.get("diversity_floor", 0.3):
        return "PIVOT", f"diversity collapse ({last['diversity_index']} < {lc.get('diversity_floor', 0.3)}); inject immigrants, widen search"
    ts = lc.get("target_score")
    if ts is not None and last.get("top_score", 0) >= ts:
        return "STOP", f"target score {ts} reached ({last['top_score']})"
    return "CONTINUE", f"{round(remaining / 60, 1)} min budget left; top {last.get('top_score')}, diversity {last.get('diversity_index')}"


def cmd_gate(a):
    run = Run(resolve_run(a.run))
    if a.elapsed_seconds is not None:
        run.state["started_epoch"] = time.time() - a.elapsed_seconds
    decision, reason = decide(run.state, run.config)
    entry = {"cycle": run.cycle, "decision": decision, "reason": reason, "ts": now_iso()}
    run.state.setdefault("loop_decision_log", []).append(entry)
    if decision == "PIVOT":
        run.state["strategy_pivots_used"] = run.state.get("strategy_pivots_used", 0) + 1
        run.state["stagnation_counter"] = 0
    if decision in ("CONTINUE", "PIVOT"):
        run.state["cycle_count"] = run.cycle + 1
        for i in run.alive():
            if (i.get("evolve") or {}).get("cycle") == run.cycle and i["evolve"]["fate"] in ("elite", "mutate"):
                i.setdefault("carried_into", []).append(run.cycle + 1)
    run.save()
    print(json.dumps({**entry, "next_cycle": run.cycle if decision != "STOP" else None,
                      "next_questions": run.state.get("questions", [])}, indent=2))
    return 0


def cmd_report(a):
    run = Run(resolve_run(a.run))
    scored = [i for i in run.ideas if i.get("scores")]
    ranked = sorted(scored, key=lambda i: (-i["scores"]["adjusted_composite"], i["id"]))
    alive_ranked = [i for i in ranked if i.get("status", "alive") == "alive"] or ranked
    st = run.state
    elapsed = (time.time() - st.get("started_epoch", time.time())) / 60
    total = len(run.ideas)
    killed = sum(1 for i in run.ideas if i.get("status") == "killed")
    pivots = st.get("strategy_pivots_used", 0)
    L = [f"# Ideate results: {run.config.get('problem')}", "",
         f"**Time scale:** {run.config.get('time_scale')} | **Budget used:** {elapsed:.0f} of "
         f"{st.get('budget_seconds', 0) / 60:.0f} min | **Cycles:** {len(st.get('fitness_history', []))} (adaptive)",
         f"**Strategy pivots:** {pivots} | **Total ideas:** {total} | **Survived:** {total - killed} | "
         f"**Kill rate:** {100 * killed / total if total else 0:.0f}%", "",
         "## Top candidates (ranked by adjusted composite)", ""]
    for n, i in enumerate(alive_ranked[:a.top], 1):
        s, p = i["scores"], i["provenance"]
        L.append(f"### {n}. {i.get('title') or i['text'][:70]} ({i['id']}): {s['adjusted_composite']:.1f}/100 "
                 f"(confidence {s['confidence']:.2f})")
        L.append("")
        L.append(f"**The idea:** {i['text']}")
        L.append(f"**Scores:** Feasibility {s['feasibility']:.0f} | Novelty {s['novelty']:.0f} | Impact {s['impact']:.0f} | "
                 f"Elegance {s['elegance']:.0f} (judges: {s['judges']}, variance {s['judge_variance']})")
        if s.get("external_modifier"):
            L.append(f"**External validation:** modifier {s['external_modifier']:+.0f}; " +
                     "; ".join(str(e) for e in i.get("external_validation", [])))
        parents = ", ".join(p.get("parents") or []) or "none"
        mut = f" Mutation: {p['mutation_type'] or ''} (die {p['mutation_die_roll']})." if p.get("mutation_die_roll") else ""
        L.append(f"**Provenance:** born in cycle {p['cycle']} ({p['phase']}) by {p['operation']} of {parents}."
                 f"{mut} Domains: {', '.join(p.get('source_domains') or []) or 'n/a'}.")
        args = i.get("arguments") or {}
        if args.get("supporting"):
            L.append(f"**For it:** {args['supporting'][0]}")
        if args.get("counter"):
            L.append(f"**Against it:** {args['counter'][0]}")
        if i.get("redteam_findings"):
            L.append(f"**Red-team findings:** {'; '.join(i['redteam_findings'])}")
        L.append("")
    L += ["## Evolution summary", "", "| Cycle | Ideas in | Survived | Avg | Top | Diversity | Strategy | Decision |",
          "|---|---|---|---|---|---|---|---|"]
    decisions = {d["cycle"]: d["decision"] for d in st.get("loop_decision_log", [])}
    for h in st.get("fitness_history", []):
        L.append(f"| {h['cycle']} | {h['ideas_in']} | {h['survived']} | {h['avg_score']} | {h['top_score']} | "
                 f"{h['diversity_index']} | v{h.get('strategy_version', 1)} | {decisions.get(h['cycle'], '-')} |")
    L += ["", "## Meta-learning trajectory", ""]
    for m in st.get("meta_log", []):
        L.append(f"- cycle {m['cycle']}: {json.dumps(m['applied'], ensure_ascii=False)}")
    if not st.get("meta_log"):
        L.append("- (no strategy adjustments recorded)")
    lineage = {}
    for i in alive_ranked[:a.top]:
        for par in i["provenance"].get("parents") or []:
            lineage[par] = lineage.get(par, 0) + 1
    if lineage:
        L += ["", "## Lineage signals", ""]
        for par, k in sorted(lineage.items(), key=lambda kv: -kv[1])[:5]:
            pi = run.by_id(par)
            L.append(f"- {par} parented {k} top candidate(s): {(pi or {}).get('text', '')[:100]}")
    L += ["", "## Evolutionary insights", "", "_The Historian's analysis goes here: dominant lineages, fertile domain "
          "combinations, fitness landscape, what the run revealed about the problem, where to explore next._"]
    md = "\n".join(L) + "\n"
    (run.path / "final-output.md").write_text(md, encoding="utf-8")
    print(md)
    print(f"(saved {run.path / 'final-output.md'})", file=sys.stderr)
    return 0


def cmd_domains(a):
    for d, dist in sorted(DOMAIN_POOL.items(), key=lambda kv: (kv[1], kv[0])):
        print(f"{dist}  {d}")
    print(f"\n{len(DOMAIN_POOL)} domains (distance 1 = adjacent, 3 = distant)")
    return 0


def cmd_mutations(a):
    for k, v in MUTATIONS.items():
        print(f"{k}. {v}")
    return 0


def build_parser():
    ap = argparse.ArgumentParser(prog="ideate.py", description="Ideate engine: structural randomness, selection, loop control")
    sp = ap.add_subparsers(dest="cmd")
    p = sp.add_parser("init")
    p.add_argument("problem")
    p.add_argument("--time-scale", choices=list(TIME_SCALES), default="weeks")
    p.add_argument("--domains")
    p.add_argument("--target-score", type=float)
    p.add_argument("--max-cycles", type=int)
    p.add_argument("--seed", type=int)
    p.add_argument("--slug")
    p.add_argument("--dir")
    p.add_argument("--quick", action="store_true", help="single-cycle QuickCycle run")
    p.add_argument("--force", action="store_true")
    for name in ("status", "evolve", "domains", "mutations"):
        x = sp.add_parser(name)
        if name in ("status", "evolve"):
            x.add_argument("run")
    p = sp.add_parser("add")
    p.add_argument("run")
    p.add_argument("--phase", required=True)
    p.add_argument("--text")
    p.add_argument("--file")
    p.add_argument("--parents")
    p.add_argument("--domains")
    p.add_argument("--operation")
    p = sp.add_parser("subset")
    p.add_argument("run")
    p.add_argument("--agents", type=int)
    p.add_argument("--ratio", type=float)
    p.add_argument("--phases")
    p = sp.add_parser("lottery")
    p.add_argument("run")
    p.add_argument("--count", type=int, default=3)
    p = sp.add_parser("pairs")
    p.add_argument("run")
    p.add_argument("--count", type=int)
    p.add_argument("--cross-phase", type=float)
    p = sp.add_parser("checkpoint-a")
    p.add_argument("run")
    p.add_argument("--analyses", type=int, required=True)
    p.add_argument("--referencing", type=int, required=True)
    for name in ("score", "meta"):
        x = sp.add_parser(name)
        x.add_argument("run")
        x.add_argument("--file", required=True)
    p = sp.add_parser("gate")
    p.add_argument("run")
    p.add_argument("--elapsed-seconds", type=float, help="override elapsed time (testing or resumed runs)")
    p = sp.add_parser("report")
    p.add_argument("run")
    p.add_argument("--top", type=int, default=10)
    return ap


COMMANDS = {"init": cmd_init, "status": cmd_status, "add": cmd_add, "subset": cmd_subset, "lottery": cmd_lottery,
            "pairs": cmd_pairs, "checkpoint-a": cmd_checkpoint_a, "score": cmd_score, "evolve": cmd_evolve,
            "meta": cmd_meta, "gate": cmd_gate, "report": cmd_report, "domains": cmd_domains, "mutations": cmd_mutations}


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = build_parser()
    a = ap.parse_args(argv)
    if not a.cmd:
        ap.print_help()
        return 2
    if a.cmd == "add" and not (a.text or a.file):
        ap.error("add needs --text or --file")
    return COMMANDS[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
