---
name: ideate
description: "Evolutionary ideation engine: loop-controlled, multi-cycle idea generation through dreaming, cross-domain stealing, recombination, multi-judge fitness testing, selection and Lamarckian meta-learning, with a deterministic tool for the structural randomness, scoring and loop decisions. Produces ranked novel candidates with full provenance. Use when the user says ideate, id8, novel ideas, evolve ideas, dream up solutions, innovate, breakthrough ideas, idea evolution, multi-cycle creativity, I need genuinely new approaches, everything we come up with is obvious, steal ideas from another field, breed these ideas, score these ideas. NOT FOR a quick single-pass brainstorm (use /be-creative) or explaining an unexplained phenomenon with a causal theory (use /novelty)."
---
# Ideate: the cognitive progress engine

A single-pass brainstorm collapses fast: the model converges on the obvious handful, and temperature only reshuffles the same probability mass. Hard problems need ideas from somewhere else (a foreign domain, an unexpected recombination, a flipped constraint) and a way to kill the weak and breed the strong over many rounds. Ideate runs that loop. The creative phases are yours and your subagents'; the tool owns everything that must not be left to model taste.

## The core insight

Human creativity reduces to five irreducible functions:

| Function | Does | Human analog |
|---|---|---|
| INGEST | gather diverse raw material | reading, conversations |
| PERTURB | recombine with controlled noise | dreaming, shower thoughts |
| CROSS-POLLINATE | map patterns from foreign domains | stealing from unrelated fields |
| SELECT | score against a fitness function | critique, peer review |
| ITERATE | feed survivors back in | sleep cycles, years of work |

## The nine phases

| # | Phase | Noise | Does |
|---|---|---|---|
| 1 | CONSUME | - | multi-domain research, atomic idea extraction (3+ domains per cycle) |
| 2 | DREAM | 0.9 | free association on random input subsets, no problem awareness |
| 3 | DAYDREAM | 0.5 | tangential wandering with the problem held loosely |
| 4 | CONTEMPLATE | 0.1 | structured analysis through 4 lenses; checkpoint A gates it |
| 5 | STEAL | - | cross-domain pattern transfer from a weighted random domain lottery |
| 6 | MATE | - | random pairing, crossover, dice-rolled mutation, clone with drift |
| 7 | TEST | - | 3+ independent judges on Feasibility, Novelty, Impact, Elegance; checkpoint B gates it |
| 8 | EVOLVE | - | kill the bottom 50%, keep the top 10% unchanged, mutate the rest, inject immigrants |
| 9 | META-LEARN | - | adjust strategy (domain weights, noise, kill threshold) and write next-cycle questions |

After the loop stops, the Historian writes cross-cycle insights. Phase mechanics: `Workflows/FullCycle.md`.

## Workflow routing

| Request | Workflow |
|---|---|
| ideate, id8, novel ideas for X, evolve ideas (default) | `Workflows/FullCycle.md` |
| quick novelty pass, fast brainstorm with scoring | `Workflows/QuickCycle.md` |
| dream on these, free-associate, wild recombinations | `Workflows/Dream.md` |
| daydream, wander around this problem | `Workflows/Daydream.md` |
| steal ideas from biology for X, cross-pollinate | `Workflows/Steal.md` |
| breed these ideas, recombine X and Y | `Workflows/Mate.md` |
| score these candidates, test these ideas | `Workflows/Test.md` |

## The engine tool

`python "$HOME/.copilot/skills/ideate/tools/ideate.py" <command>`; state lives in `~/.copilot/kai/MEMORY/WORK/<slug>/ideate/`.

| Command | Owns |
|---|---|
| `init "<problem>" [--time-scale weeks] [--domains a,b] [--target-score 80] [--quick]` | run folder, seed, budget, domain pool |
| `add <run> --phase P (--text "..." \| --file ideas.json)` | ideas with provenance (parents, operation, die roll, domains) |
| `subset <run> --agents N --ratio 0.33` | Fisher-Yates input subsets, one per Dreamer |
| `lottery <run> --count N` | weighted domain draw; forces a domain not used last cycle and at least one distant domain |
| `pairs <run> --count N --cross-phase 0.2` | random pairs, forced cross-phase slots, a mutation die roll per pair |
| `checkpoint-a <run> --analyses N --referencing M` | passes when at least 30% of analyses reference the problem |
| `score <run> --file scores.json` | judge aggregation: means, composite, variance, confidence, capped external modifiers; checkpoint B |
| `evolve <run>` | selection, elitism, mutation assignments, diversity index, fitness history |
| `meta <run> --file adjustments.json` | bounded strategy changes and next-cycle questions |
| `gate <run>` | Loop Controller: CONTINUE, PIVOT or STOP, with the reason logged |
| `report <run>` | ranked final output with provenance, written to `final-output.md` |
| `status`, `domains`, `mutations` | where the run stands; the 65-domain pool; the 8 mutation operations |

The ideas file for `add` is a JSON list of `{text, title?, parents?, operation?, die_roll?, mutation_type?, domains?}`. The scores file is a JSON list of `{id, judge, feasibility, novelty, impact, elegance, supporting, counter, modifier?, evidence?, redteam_findings?}` with dimensions 0-100, one row per judge per idea.

## Loop Controller

```
budget exhausted (or max cycles)              -> STOP
stagnation >= 3 cycles and pivots remain      -> PIVOT (shift domains, noise, agents)
stagnation >= 3 cycles and no pivots left     -> STOP
diversity index < 0.3                         -> PIVOT (inject immigrants, widen search)
top score >= target                           -> STOP
otherwise                                     -> CONTINUE
```

Time scales set the budget: hours 5 min, days 12, weeks 25 (default), months 45, years 90, decades 180, with 2 to 8 agents per phase. The controller decides the actual number of cycles.

## Mutation operations (the 8-sided die)

1 flip one assumption · 2 invert the constraint · 3 change the scale 10x · 4 change the time horizon · 5 merge with the best element of a killed idea · 6 apply a constraint from a random domain · 7 remove the most complex component · 8 add an adversarial requirement

## Skills and agents it composes

| Phase | Uses |
|---|---|
| CONSUME, STEAL | `/research` (parallel `@kai-researcher` subagents) |
| DREAM, DAYDREAM | `/be-creative` maximum mode inside each Dreamer |
| CONTEMPLATE | `/iterative-depth` lenses; `/first-principles` to challenge assumptions |
| TEST | `/red-team` for the adversarial pass; judges as parallel `task` subagents (`@kai-reviewer`, `@kai-architect`) |
| MATE (optional) | `/council` to debate ideas before breeding |

Agents in one phase run in parallel as separate `task` calls; phases run in sequence. Give each subagent a one-line persona (name, role, stance) so the cognitive styles differ.

## Final output format

```markdown
# Ideate results: <problem>
Time scale, budget used, cycles, pivots, total ideas, survivors, kill rate
## Top candidates (ranked by adjusted composite)
### 1. <title>: <score>/100 (confidence <c>)
The idea · Scores per dimension · External validation · Provenance · For it · Against it
## Evolution summary (cycle table)
## Meta-learning trajectory
## Evolutionary insights (the Historian: dominant lineages, fertile combinations, fitness landscape, what the run revealed about the problem, where to explore next)
```

`ideate.py report` writes everything except the Historian's insights, which you write from the run state.

## Gotchas

- **This is multi-cycle evolution, not a brainstorm.** For fast divergent ideas, use /be-creative.
- **Don't override the Loop Controller.** Run `gate` after every cycle and follow it; the budget sets the depth.
- **CONTEMPLATE is not optional.** Without it, STEAL and MATE work on disconnected material. Checkpoint A must pass before STEAL.
- **Structural randomness is the point.** Never replace `subset`, `lottery` or `pairs` with "interesting pairs" a model picks; that bias is exactly what the tool defeats.
- **Meta-learning adjustments stay inside bounds** (domain weights 0.2-3.0, kill threshold 0.3-0.7, subset ratio 0.15-0.6). Explicit user settings win; don't tune mid-cycle by hand.
- **Ask for bad ideas in MATE.** Selection happens in TEST; filtering early collapses diversity.
- **Persist as you go.** Add every phase's output with `add` before moving on, so provenance and resumption work.

## Lineage

The nine-phase decomposition follows a widely shared essay on the cognitive progress workflow as a possible path to superhuman ideation; the Lamarckian meta-learning step borrows from auto-research loops in agent systems.
