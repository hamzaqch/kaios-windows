---
name: aperture-oscillation
description: "Three-pass scope oscillation that holds one question constant while shifting zoom: a narrow/tactical pass, a wide/strategic pass, then a synthesis pass that names where the two disagree. Surfaces design tensions, scope recommendations and a coherence verdict that no single zoom level shows. Use when the user says aperture oscillation, oscillate scope, zoom in and out, tactical vs strategic, scope framing, design tension, system coherence check, local vs global design, is this the wrong scope, scope negotiation, or should this be a service, a library or inline. Not for rotating analytical lenses over one problem (failure, stakeholder, temporal angles); that is a different method."
---
# Aperture Oscillation

Answer one question at two scope levels, then report where the answers diverge. The divergence is the deliverable.

A component designed in isolation gets its own clean logic. The same component designed inside a system vision inherits different constraints. Pick one zoom and you miss the other: you ship something that works on its own but fights the system, or something that serves the system but ignores the component's natural shape. That mismatch, found mid-build, is the most expensive rework there is. Holding the question constant while varying the scope surfaces it before you commit.

## Inputs

- **Tactical target**: the specific thing being built, designed or decided. The narrow, concrete question.
- **Strategic context**: the bigger goal, system vision or purpose the target serves.
- **Current state** (optional): existing ISC criteria, approach decisions or constraints already set.

If no explicit inputs are given, extract them from the conversation. Tactical is the specific ask being worked on. Strategic is the project's ISA (format in `~/.copilot/kai/ISA_FORMAT.md`; read its Goal and Vision) or the broader goal or vision the user has already stated.

If the tactical target and strategic context are essentially the same thing, stop. There is no scope difference to exploit; say so and suggest a multi-angle analysis instead.

## The three passes

1. **Narrow aperture (component-first).** The specific thing is primary; the big picture is background. Capture what the component naturally wants to be: its own logic, patterns, conventions, interfaces, and what a good implementation looks like in isolation.
2. **Wide aperture (system-first).** The vision or system goal is primary; the component is derived from it. Capture what the system needs the component to be: coherence with adjacent pieces, alignment demands, and constraints the bigger picture imposes that local thinking misses.
3. **Synthesis.** Put both answers side by side. Name every point where they diverge, give each divergence a resolution, and end on a coherence verdict: ALIGNED or DIVERGENT. If they agree, "no divergence" is itself the finding. It means tactical and strategic are already coherent, and you can build with conviction.

The two passes must genuinely differ in what they treat as primary. A wide answer that restates the narrow one means the scope shift didn't happen. Push each framing until it produces something the other wouldn't.

Three passes is complete. Adding more turns this into lens rotation, which is a different method. Passes 1 and 2 are setup; the value lives in pass 3.

## Output

```
APERTURE OSCILLATION
 Tactical target: [the specific thing, 1-2 sentences]
 Strategic context: [the bigger picture, 1-2 sentences]

-- Narrow (component-first) --
[what the component wants to be, on its own logic]

-- Wide (system-first) --
[what the system needs the component to be]

-- Synthesis --
Divergences: [each point where narrow and wide disagree]

DESIGN TENSIONS:
[each tension + recommended resolution]

ISC IMPLICATIONS:
[new / refined / anti- criteria the oscillation surfaced]

Coherence: [ALIGNED | DIVERGENT, one-line verdict]
Key insight: [the most important thing single-scope analysis would have missed]
```

## When it earns its place

- **Architecture decisions.** "Service, library or inline?" depends entirely on which zoom you are at.
- **Feature design.** The feature the user asks for and the feature the product needs are often subtly different.
- **Coherence checks.** A new piece added to existing infrastructure must serve its own purpose and the system's.
- **Design reviews.** Before committing, check that the tactical plan and the strategic vision agree.
- **Scope negotiation.** When "build X" could be simple or complex depending on context, oscillation shows which scope fits.

## Where it fits in a run

- **Before writing ISC criteria**: tactical = the user's request, strategic = the project ISA or stated goals. The criteria then carry the tensions the oscillation found.
- **Before committing to an approach**: tactical = the proposed approach, strategic = the broader system goals. Confirms the approach serves both local and system needs.

If the problem itself is still unclear, explore it from several analytical angles first, then oscillate to check where the solution fits.

## Delegating it

To run it in a subagent, use the `task` tool or dispatch to `@kai-architect` with this brief:

```
Perform Aperture Oscillation: answer one question at two scope levels to
surface tensions between local component logic and system-level coherence.

TACTICAL TARGET: {specific thing being built}
STRATEGIC CONTEXT: {bigger-picture goal or system vision}

DELIVERABLE: a narrow (component-first) answer, a wide (system-first) answer
to the same question, and a synthesis naming every divergence with a
resolution and a coherence verdict (ALIGNED | DIVERGENT). Report design
tensions and ISC implications.
```

## Examples

```
Tactical target: "Build a caching layer for session data"
Strategic context: "The app is an assistant that must stay responsive and remember context across sessions"

Narrow: key-value store with TTL, standard session-cache patterns.
Wide: cached state must survive session boundaries and feed the long-term memory store.
Synthesis: DIVERGENT. A standard session cache expires exactly the data the product needs to keep.
  Resolution: a hybrid, with a session-scoped fast layer over a persistent memory-backed layer.
```

```
Tactical target: "Add webhook support to the ingest service"
Strategic context: "Ingest is one stage in a pipeline where every stage is a queued job with shared retry and observability"

Narrow: standalone webhook receiver with its own queue and retry logic.
Wide: webhooks must enter through the pipeline's job pattern and reuse its queue and retries.
Synthesis: DIVERGENT. Standalone service vs pipeline job.
  Resolution: implement as a pipeline job, because the system demands pipeline coherence over component independence.
```
