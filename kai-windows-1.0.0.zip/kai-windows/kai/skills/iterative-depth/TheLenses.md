# The Eight Lenses

Each lens forces exploration from a fundamentally different angle. They run from most concrete to most abstract, and from most commonly useful to most specialized. Draw whichever the problem calls for, in any order.

---

## 1. LITERAL: surface requirements

**Question:** What did they explicitly say? What are the concrete, stated requirements?
**Grounded in:** requirements elicitation fundamentals.
**Focus:** parse the exact words. Every stated requirement, constraint, and preference. No interpretation, only what was said.
**ISC output:** a criterion for every explicitly stated requirement.
**Prompt:** "List every concrete, testable requirement explicitly stated in this request. Do not infer; only extract."

## 2. STAKEHOLDER: who else cares?

**Question:** Who are all the people, systems, and entities affected? What does each need?
**Grounded in:** Viewpoint-Oriented Requirements Engineering (Finkelstein & Nuseibeh); triangulation (Denzin).
**Focus:** every stakeholder beyond the requester: end users, maintainers, administrators, downstream systems, future developers. What does each need that wasn't stated?
**ISC output:** criteria for stakeholder needs absent from the original request.
**Prompt:** "Identify every stakeholder affected by this work. For each, what requirement would THEY add that the requester didn't mention?"

## 3. FAILURE: what goes wrong?

**Question:** What could fail? What would an adversary exploit? What are the edge cases?
**Grounded in:** misuse cases (Sindre & Opdahl); pre-mortem (Klein); STRIDE threat modeling.
**Focus:** assume the solution exists, then break it. Error states, race conditions, security holes, data corruption, user confusion, performance under load.
**ISC output:** anti-criteria (what must NOT happen) and defensive criteria.
**Prompt:** "This solution ships tomorrow. List every way it fails in the first week. Be adversarial."

## 4. TEMPORAL: past, present, future

**Question:** How does this change over time? What's the history? What happens in 6 months?
**Grounded in:** Causal Layered Analysis (Inayatullah); progressive elaboration (PMBOK).
**Focus:** why this problem exists now, what was tried before, what future change would break the solution. Migration paths, backwards compatibility, scale changes.
**ISC output:** criteria for durability, migration, and future-proofing.
**Prompt:** "What context created this request? What will change in 3-12 months that could invalidate this solution?"

## 5. EXPERIENTIAL: how should it feel?

**Question:** When this works perfectly, how does the user feel? What's the experience?
**Grounded in:** Appreciative Inquiry (Cooperrider); de Bono's Red Hat (emotions).
**Focus:** beyond functional correctness to qualitative experience: speed, elegance, surprise, delight, confidence, trust. The difference between "works" and "works beautifully."
**ISC output:** quality-of-experience criteria that lift the result from functional to excellent.
**Prompt:** "Describe the perfect user experience of this solution. What makes someone say 'this is exactly what I wanted' rather than 'this technically works'?"

## 6. CONSTRAINT INVERSION: what if?

**Question:** What if we removed all constraints? What if we added extreme ones?
**Grounded in:** TRIZ (Altshuller); lateral thinking (de Bono); reframing (Dorst).
**Focus:** remove assumed constraints: what would we build with infinite time and resources? Then add extreme ones: offline-only, 100ms budget, zero dependencies. Both directions expose hidden assumptions.
**ISC output:** criteria that challenge assumptions and isolate what's truly essential.
**Prompt:** "What constraints are we assuming that weren't stated? Remove them: what changes? Now impose extreme constraints: what's truly essential?"

## 7. ANALOGICAL: what patterns apply?

**Question:** What similar problems have been solved before? What patterns from other domains apply?
**Grounded in:** Cognitive Flexibility Theory (Spiro); cross-domain transfer.
**Focus:** this problem isn't unique. What analogues exist in other codebases, industries, fields? What patterns emerged, and what mistakes were made?
**ISC output:** criteria derived from proven patterns and lessons from analogous solutions.
**Prompt:** "What are 3-5 analogous problems in other domains? What solutions worked there? What criteria would those solutions imply here?"

## 8. META: is this the right question?

**Question:** Are we solving the right problem? Is the framing itself correct?
**Grounded in:** hermeneutic circle (Gadamer); double-loop learning (Argyris); Soft Systems Methodology (Checkland).
**Focus:** step outside the problem. Is the request a symptom of a deeper issue? Is there a reframing that dissolves the problem instead of solving it?
**ISC output:** criteria that reframe or expand the problem definition itself.
**Prompt:** "Forget the specific request. What is the UNDERLYING need? Is there a reframing that produces a better outcome than what was asked for?"

---

## Picking lenses by problem type

| Problem leans... | Reach for |
|------------------|-----------|
| Vague or underspecified | Literal, Meta, Stakeholder |
| Security or reliability | Failure, Constraint Inversion, Temporal |
| User-facing / UX | Experiential, Stakeholder, Failure |
| Long-lived system or migration | Temporal, Stakeholder, Analogical |
| Novel or stuck | Analogical, Constraint Inversion, Meta |

These are starting points, not rules. The stopping condition decides how many you actually run.
