---
name: iterative-depth
description: "Structured multi-angle exploration: run 2-8 sequential passes over the same problem, each through a structurally different lens (literal, stakeholder, failure, temporal, experiential, constraint inversion, analogical, meta), carrying findings forward so each pass builds on the last. Surfaces hidden requirements, edge cases, and anti-criteria invisible from one angle, and returns a deduplicated set of binary-testable Ideal State Criteria (ISC). Use when the user says iterative depth, explore deeper, look at this from every angle, multi-angle analysis, surface hidden requirements, blind spot check, what am I missing, what haven't I thought of, stress the requirements, or before writing ISC for a fuzzy or high-stakes request. Not for zooming scope in and out on a single question."
---

# Iterative Depth

Examine one problem through several structurally different lenses and merge what each surfaces into criteria a single pass misses. The pattern (examine the same thing N times, each from a systematically different angle) appears independently across cognitive science, AI research, requirements engineering, and design thinking; see `ScientificFoundation.md`.

## The deliverable

A done run produces:

- **A deduplicated ISC set.** Each criterion is binary-testable, 8-12 words, phrased as a state not an action. No two criteria restate each other.
- **Refinements** to existing criteria, each noting what changed and why.
- **Anti-criteria:** failure modes that must NOT happen.
- **At least one surprising cross-angle finding:** a requirement that appeared only because two lenses collided. A run that surfaces nothing a single pass would have missed added no value; say so.

ISC follow the Kai ISA format at `~/.copilot/kai/ISA_FORMAT.md` (Windows: `%USERPROFILE%\.copilot\kai\ISA_FORMAT.md`). When an ISA exists for the work, write criteria into it in that format.

## The lenses

`TheLenses.md` catalogs eight angles: Literal, Stakeholder, Failure, Temporal, Experiential, Constraint Inversion, Analogical, Meta.

**Let the problem select the lenses.** No fixed count, no prescribed sequence. A security problem leans on Failure and Constraint Inversion; a UX problem on Experiential and Stakeholder; a vague request on Literal and Meta. The catalog is ordered concrete-to-abstract and common-to-specialized, so a short run that reaches for the earlier lenses covers the most universally useful ground.

**Stopping condition:** stop when a new lens only repeats what earlier lenses already found. Non-redundant angles are what matter; more angles for their own sake are not. Expect diminishing returns after about five passes on most topics, and never more than eight.

## Workflow

| Workflow | Trigger | File |
|----------|---------|------|
| Explore | "iterative depth", "explore deeper", "multi-angle", "what am I missing" | `Workflows/Explore.md` |

## Gotchas

- **Each pass must surface genuinely new criteria.** If passes start repeating, stop early.
- **Lenses must be structurally different, not re-runs.** Too-similar angles waste passes; too-different ones lose coherence with the problem.
- **This is a scaffold a strong model may not need.** If a single careful pass already yields everything, skip the ceremony and say the problem didn't warrant it.
