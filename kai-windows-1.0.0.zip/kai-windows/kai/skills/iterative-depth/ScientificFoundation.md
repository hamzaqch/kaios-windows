# Scientific Foundation

Iterative depth isn't one named technique. It's a meta-pattern that serious fields converged on independently: **examining the same phenomenon N times, each from a systematically different angle, yields understanding no single examination can.** That independent convergence is itself evidence the pattern is real.

## Sources by domain

### Cognitive science and epistemology

| Technique | Source | What it contributes here |
|-----------|--------|--------------------------|
| **Hermeneutic circle** | Gadamer, *Truth and Method* (1960) | Understanding forms in cycles between parts and whole; each pass refines the pre-understanding that shapes the next. |
| **Triangulation** | Denzin, *The Research Act* (1970) | Multiple methods, investigators, theories, or data sources overcome single-method bias. Each lens is a different method on the same problem. |
| **Cognitive Flexibility Theory** | Spiro et al., *Cognition and Instruction* (1988) | "Criss-crossing the landscape" of a concept from different directions improves transfer and depth. |
| **Dialectical thinking** | Hegel and successors | Thesis, antithesis, synthesis. Failure and Constraint Inversion lenses act as structured antithesis. |
| **Reflective equilibrium** | Goodman (1955); Rawls (1971) | Work back and forth between particular judgments and general principles until they cohere. Each pass tests the emerging criteria against a new angle. |
| **Equilibration** | Piaget (1975) | Conflicting information forces schema restructuring. Each new lens creates productive disequilibrium. |
| **Abductive reasoning** | Peirce (1903) | Hypotheses generated to explain surprises, held provisionally. Varied outputs are competing hypotheses, a feature rather than noise. |
| **Progressive refinement of mental models** | Gentner & Stevens; Johnson-Laird (1983) | Early passes set rough structure; later passes add precision and catch edge cases. The mechanism for why successive passes go deeper. |
| **Multiple external representations (DeFT)** | Ainsworth, *Learning and Instruction* 16(3) (2006) | Representations complement, constrain, and construct, but must be sufficiently different: too similar wastes cycles, too different loses coherence. Supports a bounded pass count and structurally distinct lenses. |
| **Perspectivism** | Nietzsche (1887); Giere, *Scientific Perspectivism* (2006) | "The more eyes, different eyes, we train on the same matter, the more complete our concept of it." Objectivity accumulates from partial views. |

### AI/ML and prompting

| Technique | Source | Contribution |
|-----------|--------|--------------|
| **Self-consistency** | Wang et al. (2022), arXiv:2203.11171 | Sampling diverse reasoning paths and taking the consistent answer beat single-path chain-of-thought (+17.9% GSM8K, +11.0% SVAMP, +12.2% AQuA). |
| **Multi-agent debate** | Du et al. (2023), arXiv:2305.14325 | Agents examining the same problem and debating converge on better answers. |
| **Ensemble methods** | Breiman; Schapire & Freund | Combining diverse models beats any single one. Merged lens passes are an ensemble of requirements. |
| **DiVeRSe** | Li et al. (2023) | Structurally diverse prompts plus step verification improve coverage. |

### Requirements engineering

| Technique | Source | Contribution |
|-----------|--------|--------------|
| **Viewpoint-oriented RE** | Finkelstein & Nuseibeh (1992) | Each stakeholder viewpoint holds partial knowledge; inconsistencies between viewpoints reveal hidden requirements. |
| **Misuse cases** | Sindre & Opdahl (2005) | The adversary's view uncovers security and safety requirements invisible from the user's. |
| **Progressive elaboration** | PMBOK (PMI) | Requirements gain detail and precision with each pass. |

### Design thinking and problem solving

| Technique | Source | Contribution |
|-----------|--------|--------------|
| **Six Thinking Hats** | de Bono (1985) | Structured perspectives applied in turn to one problem; the direct inspiration for the lens catalog. |
| **Causal Layered Analysis** | Inayatullah (1998) | Four depth layers: litany, systemic causes, worldview, myth/metaphor. Depth, not just breadth. |
| **Soft Systems Methodology** | Checkland (1981) | Multiple "root definitions" of one situation from different worldviews; CATWOE forces perspective shifts. |

## Not the same as iterative deepening search

| | Iterative deepening (IDDFS, Korf 1985) | Iterative depth (this skill) |
|-|-----------------------------------------|------------------------------|
| Domain | Graph/tree search | Problem understanding, requirements |
| What iterates | Depth limit | Perspective |
| Same path each time? | Yes, revisits the same nodes | No, structurally different angle each time |
| Output | One solution path | An enriched set of criteria |

## Why it works

1. **Perspective-blindness compensation.** Every viewpoint has blind spots; rotating through structured viewpoints covers gaps no single pass catches.
2. **Productive non-determinism.** Even under one lens, each pass surfaces slightly different aspects. Combined with structural variation, that variance becomes coverage.
3. **Progressive pre-understanding.** Each pass updates what the analyst knows to look for, so pass 5 sees what pass 1 couldn't.
