# Explore

Run structured exploration passes over the same problem, each through a different lens, to extract richer Ideal State Criteria (ISC) than a single pass produces.

**Invoked:** directly by the user ("use iterative depth on this"); while articulating ideal state for an ISA, before criteria are written, so they're informed by multi-angle exploration instead of corrected after the fact; or by other skills that need deeper requirement extraction.

## Inputs

- **Problem/request:** the original request or problem statement.
- **Context:** conversation history, codebase state, prior work, any existing ISA and its criteria.
- **Lenses:** chosen from `../TheLenses.md` to fit the problem.

## Execute

1. Read `../TheLenses.md` and pick the lenses this problem calls for, in the order that makes sense.
2. Run each pass in turn, **carrying the criteria found so far into the next lens** so later passes build on earlier ones and look for what's still missing.
3. After each pass, check: did it surface genuinely new criteria? If it only restated earlier findings, stop adding lenses.

Passes can run inline, or, for heavy problems, as parallel `task` calls (for example to `@kai-researcher` for the Analogical or Temporal lens, `@kai-reviewer` for Failure, `@kai-architect` for Meta). Parallel passes lose the carry-forward, so follow them with one inline pass that reconciles their results and probes the gaps.

## Synthesize

1. **Deduplicate:** remove criteria that are semantically identical across lenses.
2. **Merge refinements:** when several lenses refined the same criterion, keep the most specific version.
3. **Prioritize:** a criterion surfaced by several lenses ranks higher.
4. **Format:** every criterion in ISC form per `~/.copilot/kai/ISA_FORMAT.md`: 8-12 words, a state not an action, binary testable.
5. **Find the collision:** name the finding that appeared only because two lenses met.

When called while building an ISA, write the criteria into it. When called standalone, present the set to the user.

## Output

```
ITERATIVE DEPTH COMPLETE ({N} lenses applied)

Coverage:
- Lenses used: {lens names}
- New criteria: {count}
- Refined criteria: {count}
- Anti-criteria: {count}

NEW ISC CRITERIA:
- ISC-1: {criterion}  [lenses: Stakeholder, Failure]
- ...

REFINED ISC CRITERIA:
- ISC-n: {old} -> {new}  (why: {what the lens revealed})

NEW ANTI-CRITERIA:
- ISC-A1: {what must NOT happen}
- ...

Key insight: {the most surprising cross-lens finding, the thing a single pass would have missed}
```
