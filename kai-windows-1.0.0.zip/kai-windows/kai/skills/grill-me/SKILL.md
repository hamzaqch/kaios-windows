---
name: grill-me
description: "Relentless, checkpointed discovery interview that interrogates a half-formed idea, plan or decision one question at a time (each question leads with Kai's recommended answer), explores the codebase instead of asking when it can, checkpoints every answer to a grill.md file, runs a pre-mortem that turns failure modes into draft criteria, and hands off to an ISA. Use when the user says /grill-me, grill me, interview me about this idea, poke at my plan, help me figure out the shape of this, I have a rough idea, brainstorm before we spec it, or what am I missing before I build this. NOT FOR filling gaps in an ISA that already exists (use /isa) or adversarial critique of a finished plan (use /red-team)."
argument-hint: "<topic> [slug]"
---
# grill-me

Discovers a structure that doesn't exist yet. Where `/isa` fills a known structure, grill walks the design tree of a half-formed idea until its shape is clear enough to write down as falsifiable claims. Human-invoked and exploratory; never run it automatically.

If no topic was given, ask what idea, plan or decision to grill, then proceed.

**Done looks like:** `~/.copilot/kai/MEMORY/WORK/<slug>/grill.md` holds every question and answer, the settled decisions with their rationale, the open flags, and draft criteria from a pre-mortem; and the user has been offered the ISA handoff.

## Procedure

1. **Work folder.** Slug = `YYYYMMDD-<kebab topic>` unless the user gave one. Create `~/.copilot/kai/MEMORY/WORK/<slug>/grill.md` with the three sections below. Use this folder even when the session's working directory is some other repo, so the ISA that follows lands beside it.
2. **Shape check (only when ambiguous).** If it's unclear what kind of thing this is (a skill, a script, a service, a document, a process), propose 2-3 candidate shapes and ask the one question that prunes to a single shape. Skip when the shape is obvious.
3. **Walk the tree.** Resolve parents before leaves. Per decision:
   - Ask exactly one question per turn with the `ask_user` tool. Put your recommended answer first, labelled "(Recommended)", with the real alternatives after it; the user can always type their own. Use a free-text question only when the answer space genuinely won't fit options.
   - Never ask a bare open question: lead with where you'd land and why.
   - If the codebase or existing files can answer it, look (view, search) instead of asking.
   - On a low-confidence or high-stakes call, add a one-line strongest objection to your own recommendation.
4. **Checkpoint after every answer.** Append the Q&A pair to the log, promote settled decisions into Shape & Key Decisions, and put anything needing outside input under Open Flags. Long sessions lose context; the file is the memory.
5. **Pre-mortem.** Before closing, ask: "imagine this shipped and failed; what went wrong?" Turn each failure mode into a draft binary criterion and add it under Shape & Key Decisions as `- ISC: ...`.
6. **Stop** when the shape is clear enough to specify, after 12 questions (or the user's limit), or after two consecutive low-signal answers ("don't know", "skip"). If the topic arrived already well-formed, say so and go straight to the handoff rather than manufacturing questions.
7. **Handoff.** Offer, in order:
   1. Create the ISA in the same folder: `python ~/.copilot/kai/bin/kai.py isa new <slug> "<the user's original goal, verbatim>"`, then fill its Goal, Vision, Out of Scope and Criteria from Shape & Key Decisions and the draft ISCs (each criterion with a probe, per `~/.copilot/kai/ISA_FORMAT.md`), then `kai.py isa check <path>`.
   2. List each Open Flag as a follow-up the user owns.

## grill.md format

```markdown
# Grill: <topic>

## Shape & Key Decisions
- <settled decision> - <rationale>
- ISC: <binary criterion from the pre-mortem>

## Q&A Log
### Q1: <question>
**Recommended:** <recommendation>  **Answer:** <user's answer>

## Open Flags
- [ ] <unknown> - needs <who or what>
```

## Failure modes

- **User abandons mid-grill:** the partial grill.md still has value; add an Open Flag noting where it paused.
- **Answers stay aspirational:** push for the concrete ("what would prove that?"). If they can't say, log an Open Flag, not a settled decision.

Adapted from the open-source "grill-me" interviewing skill pattern (MIT); this version checkpoints each turn to the Kai work folder and adds the pre-mortem-to-criteria pass before the ISA handoff.
