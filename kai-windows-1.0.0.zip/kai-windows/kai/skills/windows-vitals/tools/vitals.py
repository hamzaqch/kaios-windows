"""windows-vitals: read-only Windows 11 performance diagnostics. Stdlib Python 3.8+ driving
Windows PowerShell 5.1 (Get-CimInstance, Get-Process); every metric comes back as raw JSON and
all math and judgement happens here, so the logic is testable off Windows.

    python vitals.py check  [--top N] [--json]   fast snapshot: CPU, memory, disk space, thermal limit, uptime
    python vitals.py hogs   [--top N] [--seconds S] [--json]   live per-process CPU over S seconds (default 2)
    python vitals.py memory [--json]             commit charge, available RAM, paging, compression, top RSS
    python vitals.py disk   [--json]             free space per fixed drive plus live disk activity
    python vitals.py gpu    [--json]             GPU engine utilisation by process (WDDM counters)
    python vitals.py thermal [--json]            firmware performance limit, CPU frequency, ACPI zones, power plan
    python vitals.py startup [--json]            Run-key / Startup-folder items, logon tasks, stopped auto services
    python vitals.py full   [--top N] [--json]   everything

Read-only by contract: nothing here kills, stops, disables or changes any setting.
Exit codes: 0 ok, 1 collection failed (not Windows, PowerShell missing or timed out), 2 usage.
"""
import argparse
import base64
import json
import re
import shutil
import subprocess
import sys

GREEN, YELLOW, RED, INFO = "ok", "warn", "bad", "info"
ICON = {GREEN: "[ok]  ", YELLOW: "[warn]", RED: "[BAD] ", INFO: "[info]"}

# Known Windows processes: what high usage usually means. Lowercase, no .exe.
KNOWN = {
    "system": "Kernel and driver work. Sustained high CPU usually means a misbehaving driver (storage, network, GPU) or heavy I/O; check Device Manager and driver updates, never try to end it.",
    "memory compression": "The memory manager compressing pages instead of paging to disk. A large working set here is normal under memory pressure; it is a symptom, not a culprit.",
    "msmpeng": "Microsoft Defender Antivirus scanning. Spikes after updates, installs and big file copies; a scheduled full scan can take an hour. Exclude only trusted dev folders, never disable protection.",
    "mpdefendercoreservice": "Defender core service; same story as MsMpEng.",
    "searchindexer": "Windows Search indexing. Heavy after big file changes or updates and finishes on its own; check Settings > Privacy & security > Searching Windows if chronic.",
    "searchprotocolhost": "Windows Search reading file contents for the index. Transient.",
    "tiworker": "Windows Modules Installer Worker: installing updates or servicing components. Let it finish; a reboot is usually pending.",
    "trustedinstaller": "Windows servicing (updates, features). Let it finish.",
    "wuauserv": "Windows Update. Transient.",
    "svchost": "A host for Windows services. The services listed next to it are the real culprits; look them up by name.",
    "dwm": "Desktop Window Manager: compositing every window. High with many windows, high-refresh or multiple monitors, screen capture, or a GPU driver issue.",
    "explorer": "The shell. Sustained CPU usually means a shell extension, a huge folder thumbnail pass, or a stuck network drive.",
    "wmiprvse": "WMI provider host: something is querying system info heavily (monitoring tools, OEM utilities, sometimes this very skill). Transient unless chronic.",
    "compattelrunner": "Compatibility telemetry appraiser. Runs on a schedule and finishes on its own.",
    "onedrive": "OneDrive sync. Heavy only during large syncs or first sign-in.",
    "runtimebroker": "Permission broker for Store apps. Sustained use points at one misbehaving Store app.",
    "msedgewebview2": "Embedded browser engine used by many apps (Teams, widgets, Outlook). Find the parent app by PID in Task Manager.",
    "audiodg": "Audio engine. Elevated with audio effects/enhancements or pro-audio software; try disabling enhancements if chronic.",
    "registry": "The registry's in-memory store. Large working set is normal.",
    "lsass": "Local security authority. Sustained high CPU is unusual; can indicate authentication storms or security software interaction.",
    "csrss": "Client/server runtime. Normally near idle.",
    "smss": "Session manager. Normally near idle.",
    "spoolsv": "Print spooler. High CPU usually means a stuck print job or a bad printer driver.",
    "vmmem": "The memory and CPU of WSL 2 or Hyper-V virtual machines. Look inside the VM; cap WSL memory in .wslconfig if needed.",
    "vmmemwsl": "WSL 2 virtual machine; same as vmmem.",
    "antimalware service executable": "Defender; same as MsMpEng.",
    "sihost": "Shell infrastructure host. Normally light.",
    "ctfmon": "Text input and IME framework. Normally light.",
}

# PowerShell fragments. Each sets $out.<key>; failures leave an error string, never throw.
PS_HEADER = r"""
$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false } catch {}
$out = [ordered]@{}
$cores = [Environment]::ProcessorCount
$out.cores = $cores
"""

PS = {
    "base": r"""
try {
  $os = Get-CimInstance Win32_OperatingSystem
  $cs = Get-CimInstance Win32_ComputerSystem
  $cpuName = (@(Get-CimInstance Win32_Processor) | Select-Object -First 1).Name
  $out.base = [ordered]@{
    os = $os.Caption; build = $os.BuildNumber; cpu = $cpuName
    uptime_hours = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalHours, 1)
    total_mb = [math]::Round($cs.TotalPhysicalMemory / 1MB)
  }
} catch { $out.base = @{ error = $_.Exception.Message } }
""",
    "cpu": r"""
try {
  $q = "Name='_Total'"
  $null = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter $q
  Start-Sleep -Milliseconds 1000
  $p = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter $q
  $s = Get-CimInstance Win32_PerfFormattedData_PerfOS_System
  $lp = (@(Get-CimInstance Win32_Processor) | Measure-Object -Property LoadPercentage -Average).Average
  $out.cpu = [ordered]@{
    percent = $p.PercentProcessorTime; privileged = $p.PercentPrivilegedTime
    interrupt = $p.PercentInterruptTime; dpc = $p.PercentDPCTime
    queue = $s.ProcessorQueueLength; load_percentage = $lp
    processes = $s.Processes; threads = $s.Threads
  }
} catch { $out.cpu = @{ error = $_.Exception.Message } }
""",
    "memory": r"""
try {
  $os = Get-CimInstance Win32_OperatingSystem
  $m = Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
  $comp = Get-Process -Name 'Memory Compression'
  $pf = @(Get-CimInstance Win32_PageFileUsage | ForEach-Object { [ordered]@{ name = $_.Name; allocated_mb = $_.AllocatedBaseSize; used_mb = $_.CurrentUsage; peak_mb = $_.PeakUsage } })
  $out.memory = [ordered]@{
    total_mb = [math]::Round($os.TotalVisibleMemorySize / 1KB); available_mb = $m.AvailableMBytes
    committed_mb = [math]::Round($m.CommittedBytes / 1MB); commit_limit_mb = [math]::Round($m.CommitLimit / 1MB)
    pages_input_per_sec = $m.PagesInputPersec; page_faults_per_sec = $m.PageFaultsPersec
    modified_mb = [math]::Round($m.ModifiedPageListBytes / 1MB); cache_mb = [math]::Round($m.CacheBytes / 1MB)
    compressed_ws_mb = $(if ($comp) { [math]::Round($comp.WorkingSet64 / 1MB) } else { $null })
    pagefiles = $pf
  }
} catch { $out.memory = @{ error = $_.Exception.Message } }
""",
    "procs": r"""
try {
  $out.procs = @(Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First __TOP__ | ForEach-Object {
    [ordered]@{ pid = $_.Id; name = $_.ProcessName; ws_mb = [math]::Round($_.WorkingSet64 / 1MB, 1); private_mb = [math]::Round($_.PrivateMemorySize64 / 1MB, 1); cpu_s = $(if ($_.CPU -ne $null) { [math]::Round($_.CPU, 1) } else { $null }) }
  })
} catch { $out.procs = @() }
""",
    "hogs": r"""
try {
  $a = @{}
  foreach ($p in Get-Process) { try { $t = $p.TotalProcessorTime; if ($t -ne $null) { $a[[string]$p.Id] = $t.TotalSeconds } } catch {} }
  $sw = [Diagnostics.Stopwatch]::StartNew()
  Start-Sleep -Milliseconds __MS__
  $rows = @()
  foreach ($p in Get-Process) {
    $t2 = $null
    try { $t = $p.TotalProcessorTime; if ($t -ne $null) { $t2 = $t.TotalSeconds } } catch {}
    $rows += ,([ordered]@{ pid = $p.Id; name = $p.ProcessName; cpu0 = $a[[string]$p.Id]; cpu1 = $t2; ws_mb = [math]::Round($p.WorkingSet64 / 1MB, 1) })
  }
  $elapsed = $sw.Elapsed.TotalSeconds
  $svc = @{}
  foreach ($s in Get-CimInstance Win32_Service -Filter "State='Running'") { $k = [string]$s.ProcessId; if (-not $svc.ContainsKey($k)) { $svc[$k] = @() }; $svc[$k] += $s.Name }
  $out.hogs = [ordered]@{ elapsed_s = $elapsed; rows = $rows; services = $svc }
} catch { $out.hogs = @{ error = $_.Exception.Message } }
""",
    "disk": r"""
try {
  $vols = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { [ordered]@{ drive = $_.DeviceID; label = $_.VolumeName; fs = $_.FileSystem; size_gb = [math]::Round($_.Size / 1GB, 1); free_gb = [math]::Round($_.FreeSpace / 1GB, 1) } })
  $q = "Name='_Total'"
  $null = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter $q
  Start-Sleep -Milliseconds 1000
  $d = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter $q
  $out.disk = [ordered]@{ volumes = $vols; busy_percent = $d.PercentDiskTime; idle_percent = $d.PercentIdleTime; queue = $d.CurrentDiskQueueLength; read_mb_s = [math]::Round($d.DiskReadBytesPersec / 1MB, 2); write_mb_s = [math]::Round($d.DiskWriteBytesPersec / 1MB, 2) }
} catch { $out.disk = @{ error = $_.Exception.Message } }
""",
    "thermal": r"""
try {
  $pi = Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation -Filter "Name='_Total'"
  $zones = @()
  try { $zones = @(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop | ForEach-Object { [ordered]@{ zone = $_.InstanceName; celsius = [math]::Round($_.CurrentTemperature / 10 - 273.15, 1) } }) } catch { $zones = @() }
  $plan = ((powercfg /getactivescheme) -join ' ')
  $battery = @(Get-CimInstance Win32_Battery | ForEach-Object { [ordered]@{ charge = $_.EstimatedChargeRemaining; status = $_.BatteryStatus } })
  $out.thermal = [ordered]@{
    performance_limit = $pi.PercentPerformanceLimit; processor_performance = $pi.PercentProcessorPerformance
    percent_of_max_frequency = $pi.PercentofMaximumFrequency; frequency_mhz = $pi.ProcessorFrequency
    limit_flags = $pi.PerformanceLimitFlags; zones = $zones; power_plan = $plan; battery = $battery
  }
} catch { $out.thermal = @{ error = $_.Exception.Message } }
""",
    "gpu": r"""
try {
  # -ErrorAction Stop: a missing class (old or non-WDDM driver) must land in catch as
  # "unavailable", not fall through as an empty list that reads as "GPU idle".
  $null = Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine -ErrorAction Stop
  Start-Sleep -Milliseconds 1000
  $eng = @(Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine | Where-Object { $_.UtilizationPercentage -gt 0 } | ForEach-Object { [ordered]@{ name = $_.Name; util = $_.UtilizationPercentage } })
  $names = @{}
  foreach ($p in Get-Process) { $names[[string]$p.Id] = $p.ProcessName }
  $adapters = @(Get-CimInstance Win32_VideoController | ForEach-Object { [ordered]@{ name = $_.Name; driver = $_.DriverVersion } })
  $out.gpu = [ordered]@{ engines = $eng; names = $names; adapters = $adapters; available = $true }
} catch { $out.gpu = @{ error = $_.Exception.Message; available = $false } }
""",
    "startup": r"""
try {
  $items = @(Get-CimInstance Win32_StartupCommand | ForEach-Object { [ordered]@{ name = $_.Name; command = $_.Command; location = $_.Location; user = $_.User } })
  $tasks = @()
  try {
    $tasks = @(Get-ScheduledTask | Where-Object { $_.State -ne 'Disabled' -and ($_.Triggers | Where-Object { $_.CimClass.CimClassName -match 'Logon|Boot' }) } | ForEach-Object {
      $info = $_ | Get-ScheduledTaskInfo
      [ordered]@{ name = $_.TaskName; path = $_.TaskPath; last_result = $info.LastTaskResult; state = [string]$_.State }
    })
  } catch { $tasks = @() }
  $stopped = @(Get-CimInstance Win32_Service -Filter "StartMode='Auto' AND State<>'Running'" | ForEach-Object { [ordered]@{ name = $_.Name; display = $_.DisplayName; exit_code = $_.ExitCode } })
  $out.startup = [ordered]@{ items = $items; tasks = $tasks; stopped_auto_services = $stopped }
} catch { $out.startup = @{ error = $_.Exception.Message } }
""",
}

PS_FOOTER = r"""
ConvertTo-Json -InputObject $out -Depth 6 -Compress
"""

COMMAND_SECTIONS = {
    "check": ["base", "cpu", "memory", "disk", "thermal", "procs"],
    "hogs": ["base", "cpu", "hogs"],
    "memory": ["base", "memory", "procs"],
    "disk": ["disk"],
    "gpu": ["gpu"],
    "thermal": ["base", "cpu", "thermal"],
    "startup": ["startup"],
    "full": ["base", "cpu", "memory", "disk", "thermal", "procs", "hogs", "gpu", "startup"],
}


class CollectError(Exception):
    pass


# ---------------------------------------------------------------------------
# Collection
# ---------------------------------------------------------------------------

def build_script(sections, top=10, seconds=2.0):
    body = [PS_HEADER]
    for s in sections:
        frag = PS[s].replace("__TOP__", str(int(top))).replace("__MS__", str(int(seconds * 1000)))
        body.append(frag)
    body.append(PS_FOOTER)
    return "\n".join(body)


def powershell_exe():
    for name in ("powershell", "powershell.exe", "pwsh"):
        path = shutil.which(name)
        if path:
            return path
    return None


def run_ps(script, timeout=60):
    exe = powershell_exe()
    if not exe:
        raise CollectError("Windows PowerShell not found; this skill runs on Windows (PowerShell 5.1)")
    try:
        # -EncodedCommand sidesteps Windows command-line quoting of the embedded double quotes.
        encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
        r = subprocess.run([exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-EncodedCommand", encoded], capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise CollectError("PowerShell timed out after %ss" % timeout)
    except OSError as e:
        raise CollectError("could not start PowerShell: %s" % e)
    raw = r.stdout.decode("utf-8", errors="replace").strip()
    start = raw.find("{")
    if start < 0:
        err = r.stderr.decode("utf-8", errors="replace").strip()
        raise CollectError("PowerShell returned no JSON (exit %s): %s" % (r.returncode, err[:300]))
    try:
        return json.loads(raw[start:])
    except ValueError as e:
        raise CollectError("could not parse PowerShell output: %s" % e)


def collect(command, top=10, seconds=2.0, runner=None):
    runner = runner or run_ps
    sections = COMMAND_SECTIONS[command]
    timeout = 60 + int(seconds) + (30 if "startup" in sections else 0)
    return runner(build_script(sections, top, seconds), timeout)


# ---------------------------------------------------------------------------
# Interpretation (pure)
# ---------------------------------------------------------------------------

def as_list(x):
    if x is None:
        return []
    if isinstance(x, list):
        return x
    return [x]


def num(x):
    try:
        if x is None or isinstance(x, bool):
            return None
        return float(x)
    except (TypeError, ValueError):
        return None


def note_for(name):
    return KNOWN.get((name or "").lower().replace(".exe", ""))


def compute_hogs(hogs, cores, top=10):
    """Per-process CPU% over the sample window from two TotalProcessorTime snapshots."""
    if not hogs or hogs.get("error"):
        return []
    elapsed = num(hogs.get("elapsed_s")) or 0.0
    cores = max(int(num(cores) or 1), 1)
    services = hogs.get("services") or {}
    rows = []
    for r in as_list(hogs.get("rows")):
        c0, c1 = num(r.get("cpu0")), num(r.get("cpu1"))
        if r.get("pid") in (0, None) or c0 is None or c1 is None or elapsed <= 0:
            continue
        pct = max(c1 - c0, 0.0) / (elapsed * cores) * 100.0
        row = {"pid": r["pid"], "name": r.get("name"), "cpu_pct": round(pct, 1),
               "ws_mb": r.get("ws_mb"), "note": note_for(r.get("name"))}
        svc = as_list(services.get(str(r["pid"])))
        if svc:
            row["services"] = svc
        rows.append(row)
    rows.sort(key=lambda x: -x["cpu_pct"])
    return rows[:top]


ENGINE = re.compile(r"pid_(\d+)_.*?engtype_([A-Za-z0-9 ]+)", re.IGNORECASE)


def compute_gpu(gpu, top=10):
    if not gpu or gpu.get("error"):
        return {"available": False, "reason": (gpu or {}).get("error") or "GPU counters unavailable",
                "by_engine": {}, "by_process": [], "adapters": []}
    names = gpu.get("names") or {}
    by_engine, by_proc = {}, {}
    for e in as_list(gpu.get("engines")):
        m = ENGINE.search(e.get("name") or "")
        util = num(e.get("util")) or 0.0
        if not m:
            continue
        pid, eng = m.group(1), m.group(2).strip()
        by_engine[eng] = by_engine.get(eng, 0.0) + util
        key = (pid, eng)
        by_proc[key] = by_proc.get(key, 0.0) + util
    procs = {}
    for (pid, eng), util in by_proc.items():
        p = procs.setdefault(pid, {"pid": int(pid), "name": names.get(pid, "?"), "engines": {}})
        p["engines"][eng] = round(min(util, 100.0), 1)
    rows = sorted(procs.values(), key=lambda p: -max(p["engines"].values()))
    return {"available": True,
            "by_engine": {k: round(min(v, 100.0), 1) for k, v in sorted(by_engine.items(), key=lambda kv: -kv[1])},
            "by_process": rows[:top], "adapters": as_list(gpu.get("adapters"))}


def finding(area, level, msg):
    return {"area": area, "level": level, "msg": msg}


def judge_cpu(cpu, cores):
    out = []
    if not cpu or cpu.get("error"):
        return [finding("cpu", INFO, "CPU counters unavailable")]
    pct = num(cpu.get("percent"))
    if pct is None:
        pct = num(cpu.get("load_percentage"))
    q = num(cpu.get("queue"))
    cores = max(int(num(cores) or 1), 1)
    if pct is not None:
        lvl = RED if pct >= 90 else (YELLOW if pct >= 70 else GREEN)
        out.append(finding("cpu", lvl, "CPU %.0f%% across %d logical cores" % (pct, cores)))
    if q is not None and q / cores > 2:
        out.append(finding("cpu", YELLOW, "processor queue %d (%.1f per core): threads are waiting for CPU" % (q, q / cores)))
    intr = (num(cpu.get("interrupt")) or 0) + (num(cpu.get("dpc")) or 0)
    if intr >= 15:
        out.append(finding("cpu", YELLOW, "interrupt + DPC time %.0f%%: a driver is busy (often network, storage, audio or GPU)" % intr))
    return out


def judge_memory(mem):
    if not mem or mem.get("error"):
        return [finding("memory", INFO, "memory counters unavailable")]
    out = []
    total, avail = num(mem.get("total_mb")), num(mem.get("available_mb"))
    committed, limit = num(mem.get("committed_mb")), num(mem.get("commit_limit_mb"))
    if committed is not None and limit:
        c = committed / limit * 100
        lvl = RED if c >= 90 else (YELLOW if c >= 80 else GREEN)
        out.append(finding("memory", lvl, "commit charge %.0f%% (%.1f of %.1f GB): the real pressure signal"
                           % (c, committed / 1024, limit / 1024)))
    if total and avail is not None:
        a = avail / total * 100
        lvl = RED if a < 5 else (YELLOW if a < 10 else GREEN)
        out.append(finding("memory", lvl, "available %.1f of %.1f GB (%.0f%%)" % (avail / 1024, total / 1024, a)))
    pin = num(mem.get("pages_input_per_sec"))
    if pin is not None and pin > 300:
        out.append(finding("memory", YELLOW, "%.0f pages/s read back from disk: active paging (one sample; confirm with a second run)" % pin))
    comp = num(mem.get("compressed_ws_mb"))
    if comp is not None and total and comp / total > 0.15:
        out.append(finding("memory", YELLOW, "Memory Compression holds %.1f GB: RAM is being squeezed" % (comp / 1024)))
    return out


def judge_disk(disk):
    if not disk or disk.get("error"):
        return [finding("disk", INFO, "disk counters unavailable")]
    out = []
    for v in as_list(disk.get("volumes")):
        size, free = num(v.get("size_gb")), num(v.get("free_gb"))
        if not size or free is None:
            continue
        f = free / size * 100
        lvl = RED if f < 10 else (YELLOW if f < 15 else GREEN)
        out.append(finding("disk", lvl, "%s %.0f GB free of %.0f GB (%.0f%%)" % (v.get("drive"), free, size, f)))
    busy, q = num(disk.get("busy_percent")), num(disk.get("queue"))
    if busy is not None:
        lvl = YELLOW if busy >= 90 and (q or 0) >= 2 else GREEN
        out.append(finding("disk", lvl, "disk busy %.0f%%, queue %s, read %s MB/s, write %s MB/s"
                           % (min(busy, 100), int(q or 0), disk.get("read_mb_s"), disk.get("write_mb_s"))))
    return out


def judge_thermal(th, cpu=None):
    if not th or th.get("error"):
        return [finding("thermal", INFO, "processor performance counters unavailable")]
    out = []
    lim = num(th.get("performance_limit"))
    if lim is not None:
        if lim < 80:
            out.append(finding("thermal", RED, "firmware is limiting the CPU to %.0f%% of nominal performance (thermal or power cap)" % lim))
        elif lim < 100:
            out.append(finding("thermal", YELLOW, "CPU performance limited to %.0f%% (thermal or power cap)" % lim))
        else:
            out.append(finding("thermal", GREEN, "no firmware performance limit"))
    pmax = num(th.get("percent_of_max_frequency"))
    load = num((cpu or {}).get("percent"))
    if pmax is not None and load is not None and load >= 60 and pmax < 60:
        out.append(finding("thermal", YELLOW, "CPU at %.0f%% of max frequency while %.0f%% busy: power plan or throttling" % (pmax, load)))
    for z in as_list(th.get("zones")):
        c = num(z.get("celsius"))
        if c is None or c <= 0:
            continue
        lvl = RED if c >= 90 else (YELLOW if c >= 80 else GREEN)
        out.append(finding("thermal", lvl, "ACPI zone %.0f C (zone sensors are coarse and often not the CPU die)" % c))
    plan = th.get("power_plan") or ""
    m = re.search(r"\(([^)]+)\)\s*$", plan.strip())
    if m:
        name = m.group(1)
        lvl = YELLOW if re.search(r"saver|power saving", name, re.I) else INFO
        out.append(finding("thermal", lvl, "power plan: %s" % name))
    for b in as_list(th.get("battery")):
        status = num(b.get("status"))
        if status == 1:
            out.append(finding("thermal", INFO, "on battery (%s%%): Windows may lower performance" % b.get("charge")))
    return out


def judge_uptime(base):
    hrs = num((base or {}).get("uptime_hours"))
    if hrs is None:
        return []
    days = hrs / 24
    lvl = INFO if days < 14 else YELLOW
    msg = "up %.1f days" % days
    if days >= 14:
        msg += ": long uptimes accumulate leaks and pending updates; a restart (not shut down, which Fast Startup turns into hibernate) is a cheap test"
    return [finding("system", lvl, msg)]


def judge_hogs(rows):
    out = []
    for r in rows[:3]:
        if r["cpu_pct"] >= 25:
            extra = (" (services: %s)" % ", ".join(r["services"][:5])) if r.get("services") else ""
            out.append(finding("hogs", YELLOW if r["cpu_pct"] < 60 else RED,
                               "%s (pid %s) %.0f%% CPU%s" % (r["name"], r["pid"], r["cpu_pct"], extra)))
    return out


def judge_gpu(g):
    if not g.get("available"):
        return [finding("gpu", INFO, "GPU counters unavailable: %s" % g.get("reason"))]
    if not g["by_engine"]:
        return [finding("gpu", GREEN, "GPU idle")]
    eng, val = next(iter(g["by_engine"].items()))
    lvl = YELLOW if val >= 90 else GREEN
    return [finding("gpu", lvl, "busiest GPU engine %s at %.0f%%" % (eng, val))]


def judge_startup(st):
    if not st or st.get("error"):
        return [finding("startup", INFO, "startup inventory unavailable")]
    out = []
    items, tasks = as_list(st.get("items")), as_list(st.get("tasks"))
    failed = [t for t in tasks if num(t.get("last_result")) not in (None, 0, 267009, 267011, 267014)]
    out.append(finding("startup", YELLOW if len(items) > 15 else INFO,
                       "%d Run-key / Startup-folder items, %d enabled logon/boot tasks" % (len(items), len(tasks))))
    if failed:
        out.append(finding("startup", YELLOW, "%d logon/boot task(s) last failed: %s"
                           % (len(failed), ", ".join(t.get("name", "?") for t in failed[:6]))))
    stopped = [s for s in as_list(st.get("stopped_auto_services")) if num(s.get("exit_code")) not in (None, 0, 1077)]
    if stopped:
        out.append(finding("startup", YELLOW, "%d automatic service(s) stopped with an error: %s"
                           % (len(stopped), ", ".join(s.get("name", "?") for s in stopped[:6]))))
    return out


def analyze(command, data, top=10):
    cores = data.get("cores")
    report = {"command": command, "findings": [], "data": {}}
    f = report["findings"]
    if "base" in data:
        report["data"]["system"] = data["base"]
        f += judge_uptime(data["base"])
    if "cpu" in data:
        report["data"]["cpu"] = data["cpu"]
        f += judge_cpu(data["cpu"], cores)
    if "memory" in data:
        report["data"]["memory"] = data["memory"]
        f += judge_memory(data["memory"])
    if "disk" in data:
        report["data"]["disk"] = data["disk"]
        f += judge_disk(data["disk"])
    if "thermal" in data:
        report["data"]["thermal"] = data["thermal"]
        f += judge_thermal(data["thermal"], data.get("cpu"))
    if "procs" in data:
        procs = as_list(data["procs"])
        for p in procs:
            p["note"] = note_for(p.get("name"))
        report["data"]["top_memory"] = procs[:top]
    if "hogs" in data:
        rows = compute_hogs(data["hogs"], cores, top)
        report["data"]["top_cpu"] = rows
        f += judge_hogs(rows)
    if "gpu" in data:
        g = compute_gpu(data["gpu"], top)
        report["data"]["gpu"] = g
        f += judge_gpu(g)
    if "startup" in data:
        report["data"]["startup"] = data["startup"]
        f += judge_startup(data["startup"])
    levels = [x["level"] for x in f]
    report["verdict"] = "degraded" if RED in levels else ("working hard" if YELLOW in levels else "healthy")
    return report


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def render(report):
    lines = []
    sysd = report["data"].get("system") or {}
    if sysd.get("os"):
        lines.append("%s (build %s), %s" % (sysd.get("os"), sysd.get("build"), sysd.get("cpu")))
    lines.append("VERDICT: %s" % report["verdict"].upper())
    for x in report["findings"]:
        lines.append("  %s %-8s %s" % (ICON[x["level"]], x["area"], x["msg"]))
    if report["data"].get("top_cpu"):
        lines.append("TOP CPU (live sample):")
        for r in report["data"]["top_cpu"]:
            svc = (" [%s]" % ", ".join(r["services"][:4])) if r.get("services") else ""
            lines.append("  %6.1f%%  %-28s pid %-6s %8s MB%s" % (r["cpu_pct"], r["name"], r["pid"], r.get("ws_mb"), svc))
            if r.get("note") and r["cpu_pct"] >= 10:
                lines.append("           known: %s" % r["note"])
    if report["data"].get("top_memory"):
        lines.append("TOP MEMORY (working set):")
        for p in report["data"]["top_memory"]:
            lines.append("  %8s MB  %-28s pid %s" % (p.get("ws_mb"), p.get("name"), p.get("pid")))
    g = report["data"].get("gpu")
    if g and g.get("available") and g.get("by_process"):
        lines.append("GPU BY PROCESS:")
        for p in g["by_process"]:
            lines.append("  %-28s pid %-6s %s" % (p["name"], p["pid"], ", ".join("%s %.0f%%" % kv for kv in p["engines"].items())))
    st = report["data"].get("startup")
    if st and not st.get("error"):
        lines.append("STARTUP ITEMS:")
        for i in as_list(st.get("items"))[:25]:
            lines.append("  %-30s %s" % ((i.get("name") or "?")[:30], i.get("location")))
    return "\n".join(lines)


def _utf8_stdio():
    """Windows consoles and pipes default to a legacy code page; never crash on a CJK name or an emoji."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            pass


def main(argv=None):
    _utf8_stdio()
    p = argparse.ArgumentParser(prog="vitals.py", description="Windows performance diagnostics (read-only)")
    p.add_argument("command", choices=sorted(COMMAND_SECTIONS))
    p.add_argument("--top", type=int, default=10)
    p.add_argument("--seconds", type=float, default=2.0)
    p.add_argument("--json", action="store_true")
    ns = p.parse_args(argv)
    if not 1 <= ns.top <= 50 or not 0.5 <= ns.seconds <= 30:
        print("--top must be 1-50 and --seconds 0.5-30", file=sys.stderr)
        return 2
    try:
        data = collect(ns.command, ns.top, ns.seconds)
    except CollectError as e:
        print("vitals: %s" % e, file=sys.stderr)
        return 1
    report = analyze(ns.command, data, ns.top)
    if ns.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print(render(report))
    return 0


if __name__ == "__main__":
    sys.exit(main())
