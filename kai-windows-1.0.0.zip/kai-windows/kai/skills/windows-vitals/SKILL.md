---
name: windows-vitals
description: "Windows 11 performance diagnostics: see how the PC is running and what is slowing it down. CPU, memory and GPU hogs, commit charge and paging, Memory Compression, disk space and disk activity, firmware performance limits and power plan, startup apps, logon tasks and failing auto-start services, via a read-only Python plus PowerShell 5.1 CLI with known-process interpretation (System, MsMpEng, SearchIndexer, svchost with its services, dwm, vmmem). Use when the user says PC slow, laptop slow, computer is slow, what's slowing down my PC, what's eating my CPU, CPU usage, GPU usage, RAM usage, memory pressure, disk at 100%, fans loud, laptop running hot, throttling, system health, check my PC, how's my system running, top processes, task manager, startup apps. NOT FOR network or wifi problems, crashes and blue screens (use /diagnose-crash-windows), website health, or security scanning."
argument-hint: "[check | hogs | memory | disk | gpu | thermal | startup | full]"
---
# Windows vitals

Read-only performance inspection for Windows 11. `tools/vitals.py` gathers the numbers through Windows PowerShell 5.1 (CIM performance classes and `Get-Process`); `Interpretation.md` turns them into a diagnosis instead of a data dump.

## Workflow routing

| Request | Workflow |
|---|---|
| "how's my system", "check my PC", "system health" | `Workflows/HealthCheck.md` |
| "PC is slow", "what's eating CPU/RAM/GPU", "disk at 100%", "fans loud" | `Workflows/FindCulprit.md` |
| "full diagnosis", "deep check", chronic or recurring slowness | `Workflows/DeepDiagnosis.md` |

Load `Interpretation.md` with any workflow: thresholds, the known-process table, the diagnosis shape.

## Quick reference

```
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" check     # snapshot: CPU, memory, disk, thermal, uptime, top memory
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" hogs      # live per-process CPU over 2 s (--seconds N)
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" full      # everything (about 10 s)
# also: memory | disk | gpu | thermal | startup, plus --json and --top N
```

The tool is read-only by contract: it never ends a process, stops a service, disables a startup item or changes a power setting. Remediation is a recommendation the user approves and carries out.

## Gotchas

- **Commit charge is the memory signal, not "in use".** Windows fills idle RAM with standby cache on purpose. Judge pressure by commit charge against the commit limit, available RAM and pages read from disk.
- **Rate counters need two samples.** The tool waits a second and reads the second sample. Never remove that wait to make it faster.
- **Don't use `Get-Counter` paths.** They are translated on non-English Windows (`\Processor(_Total)\% Processor Time` doesn't exist in a German install). The CIM `Win32_PerfFormattedData_*` classes keep English names everywhere.
- **`svchost` is a container.** The culprit is the service inside it; `hogs` lists the services per PID.
- **`System` and `Memory Compression` are symptoms.** High System CPU points at drivers or I/O (check interrupt/DPC time); a big Memory Compression working set points at memory pressure. Never suggest ending either.
- **Defender scanning is normal after updates and big copies.** For chronic scanning of trusted build folders, suggest an exclusion or a Dev Drive; never suggest turning protection off.
- **Protected processes drop out of `hogs` without elevation**, because their CPU time isn't readable. Say so if a culprit seems to be missing.
- **ACPI thermal zones are coarse, need elevation on many machines, and are often absent.** "% Performance Limit" below 100 is the reliable throttling signal.
- **Shut down is not a restart.** With Fast Startup, shutdown hibernates the kernel and uptime keeps counting. Recommend Restart when a reboot is the test.
- **Not verified on every OEM.** GPU engine counters need a WDDM 2.x driver; when a class is missing the tool reports it unavailable rather than inventing a value.

## Examples

- "My laptop is crawling, what's going on?" FindCulprit: `hogs` + `check` + `gpu`, cross-checked against the known-process table, then a named culprit with two kinds of evidence and one recommended action.
- "How's my PC doing?" HealthCheck: `check`, one screen, verdict first.
- "Why are the fans so loud?" `thermal` + `hogs`: if the performance limit is below 100 the answer is cooling or power, not a process.
