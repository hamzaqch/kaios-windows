# HealthCheck workflow

Quick pass: how is the machine running right now? One screen, verdict first.

## Ideal state

A one-screen report the user can absorb in ten seconds: an overall verdict (healthy / working hard / degraded), then one line per subsystem (CPU, memory, disk, thermal, uptime) with anything abnormal called out against `../Interpretation.md`. Normal-but-scary readings (high "in use" memory, a big Memory Compression process, Defender busy after an update) are explicitly de-flagged, not reported as problems.

## Tool

```
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" check            # readable
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" check --json     # structured
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" check --top 15   # longer process list
```

Takes a few seconds, no elevation. If anything looks off, offer FindCulprit rather than padding this report.
