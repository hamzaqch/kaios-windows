# DeepDiagnosis workflow

Full sweep when a quick check isn't enough: chronic slowness, recurring fan noise, a machine that feels worse than it used to.

## Ideal state

A complete picture across CPU, memory, disk, GPU, thermal and startup load, each reading judged against `../Interpretation.md`; a ranked list of findings (worst first, each with its evidence); and a remediation plan the user approves item by item. Startup findings separate failed items (a logon task whose last result is an error, an automatic service stopped with an error) from merely numerous ones; a long startup list alone is not a finding.

## Tools

```
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" full --top 15    # everything, no elevation
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" startup          # startup inventory alone
```

## Optional deeper probes (ask first, skip cleanly if declined)

These are read-only but either need elevation or take a while:

```
powercfg /energy /duration 60 /output "$env:TEMP\energy.html"     # elevated; power and driver problems report
powercfg /batteryreport /output "$env:TEMP\battery.html"         # laptops; battery wear and usage
Get-WinEvent -FilterHashtable @{LogName='System'; Level=1,2; StartTime=(Get-Date).AddDays(-7)} -MaxEvents 50 |
  Select-Object TimeCreated, ProviderName, Id, Message                 # recent critical and error events
```

For crashes, freezes that end in a restart, or apps that keep closing, hand off to `/diagnose-crash-windows`.

## Gotchas

- `powercfg /energy` must run elevated and samples for the full duration; tell the user it takes a minute.
- Reliability problems (crashes, failed updates) and performance problems overlap: a driver that crashes may also burn DPC time. Mention the overlap when both show up.
