# FindCulprit workflow

"Why is my PC slow right now?" Name the specific thing taxing the system, with evidence.

## Ideal state

A named culprit (or an explicit "nothing is actually wrong; here is what you noticed and why it's normal"), where every culprit claim carries two kinds of evidence per `../Interpretation.md` § Diagnosis shape: the process's live numbers and a corroborating system signal. Known Windows processes are identified as such (§ Known processes), so the user never ends Defender or the System process thinking it is malware. For `svchost`, the report names the services inside it. The report ends with one specific recommended action per culprit, offered for approval, never carried out by the skill.

## Tools

```
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" hogs             # live per-process CPU over 2 s
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" hogs --seconds 5 # longer, steadier sample
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" check            # system context
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" gpu              # GPU engines by process
python "$HOME/.copilot/skills/windows-vitals/tools/vitals.py" disk             # space and live disk activity
```

## Intent to command

| User says | Run |
|---|---|
| "what's eating my CPU" | `hogs` |
| "what's using my RAM", "memory" | `memory` |
| "GPU", "graphics", "fans spin up on video calls" | `gpu` + `hogs` |
| "disk at 100%", "everything freezes when I open files" | `disk` + `hogs` |
| "fans loud", "laptop hot" | `thermal` + `hogs` |
| "slow and I don't know why" | `check` + `hogs` + `gpu` |
| scripted use | append `--json` |

## Gotchas

- A browser helper hog is one tab or extension: point the user at the browser's own task manager (Shift+Esc) with the PID.
- `WmiPrvSE` may spike while this tool itself runs. Discount a WMI spike that only appears during collection.
