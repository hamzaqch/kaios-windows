# Interpreting Windows vitals

Reference for turning `tools/vitals.py` output into a diagnosis. Load it with any workflow.

## Thresholds that matter (and ones that don't)

| Signal | Healthy | Investigate | Why |
|---|---|---|---|
| CPU % (all cores) | < 70% | > 90% sustained | One sample is a moment; `hogs` samples over seconds |
| Processor queue per core | < 2 | > 2 sustained | Threads waiting for a core: real CPU starvation |
| Interrupt + DPC time | < 5% | > 15% | A driver (network, storage, audio, GPU) is eating CPU; shows as "System" or "Interrupts" in Task Manager |
| Commit charge (committed / limit) | < 80% | > 90% | THE memory pressure signal on Windows. Near the limit, allocations fail and apps crash with out-of-memory |
| Available RAM | > 10% | < 5% | "In use" being high is normal: Windows spends idle RAM on standby cache |
| Pages input/sec | near 0 | > 300 sustained | Pages read back from disk: genuine paging. One sample can be a file read; confirm with a second run |
| Memory Compression working set | small | > 15% of RAM | Windows compresses before paging; a big one is a symptom of pressure, not the cause |
| % Performance Limit | 100 | < 100 | Firmware is capping the CPU (thermal or power). Slowness while capped is a cooling or power problem, not software |
| % of max frequency while busy | high | < 60% at > 60% load | Power plan or throttling holding clocks down |
| Free disk space | > 15% | < 10% | Updates fail, the page file can't grow, SSD write performance drops when nearly full |
| Disk busy with queue | < 90% | > 90% with queue >= 2 | Storage is the bottleneck; find the reader/writer in Resource Monitor's Disk tab |
| GPU engine utilisation | < 60% on a quiet desktop | > 90% with no game or render running | A runaway GPU consumer or compositor pressure |
| Uptime | days | > 14 days | Leaks and pending updates pile up |

## Known processes: don't chase ghosts

| Process | What high usage means | Action |
|---|---|---|
| `System` | Kernel and driver work, or heavy I/O | Check interrupt/DPC time, update storage, network and GPU drivers. Never end it |
| `Memory Compression` | Pages being compressed under pressure | Look at commit charge and the top memory users instead |
| `MsMpEng` (Antimalware Service Executable) | Defender scanning after updates, installs, large copies, or a scheduled full scan | Let it finish. For chronic dev-folder scanning, suggest a Defender exclusion or Dev Drive for trusted build folders; never suggest disabling protection |
| `SearchIndexer`, `SearchProtocolHost` | Windows Search indexing after big file changes | Finishes on its own; adjust indexed locations only if chronic |
| `TiWorker`, `TrustedInstaller` | Windows Update servicing | Let it finish; a restart is usually pending |
| `svchost` | A shared host for services | Read the services list `hogs` prints next to it; the service is the culprit |
| `dwm` | Compositing every window | Many windows, high-refresh or multiple monitors, screen capture, or a GPU driver issue |
| `explorer` | The shell | Shell extensions, a huge thumbnail pass, or a stuck network drive |
| `WmiPrvSE` | Something querying WMI heavily | Often monitoring or OEM utilities; transient unless chronic |
| `CompatTelRunner` | Scheduled telemetry appraisal | Finishes on its own |
| `OneDrive` | Sync | Heavy only during large syncs |
| `msedgewebview2` | Embedded browser engine used by many apps | Find the parent app by PID in Task Manager's process tree |
| `vmmem`, `vmmemWSL` | WSL 2 or Hyper-V virtual machines | Look inside the VM; cap WSL memory in `%UserProfile%\.wslconfig` |
| `audiodg` | Audio engine | Audio enhancements or pro-audio software |
| `spoolsv` | Print spooler | A stuck job or a bad printer driver |
| Browser helper processes | One tab or extension, not "the browser" | The browser's own task manager (Shift+Esc in Edge and Chrome) names it |

## Diagnosis shape

A culprit claim needs two kinds of evidence: the process's own numbers (CPU% from `hogs`, working set from `check`) and a corroborating system signal (queue length, commit charge, paging, performance limit, disk busy). One snapshot over-indexes on a spike; `hogs` (a timed sample) is the confirming probe.

Remediation is always a recommendation the user carries out: ending a process in Task Manager, disabling a startup app in Settings > Apps > Startup, a driver update, a Defender exclusion for a trusted folder, a power plan change. The skill never runs any of these.

## Platform notes

- Counters come from CIM performance classes (`Win32_PerfFormattedData_*`), which keep English property names on every display language. `Get-Counter` paths are translated on non-English Windows, which is why the tool avoids them.
- Rate counters need two samples; the tool takes the second one after a one-second wait. Never "optimise" that away.
- Per-process CPU of protected processes (antivirus, some system processes) is not readable without elevation; they drop out of `hogs` rather than showing 0.
- `MSAcpi_ThermalZoneTemperature` needs elevation on many machines and is absent on many others; zone readings are coarse and often not the CPU die. Vendor tools are better for real die temperatures.
- Shut down with Fast Startup enabled is a hibernate of the kernel; uptime keeps counting. Restart actually resets it.
