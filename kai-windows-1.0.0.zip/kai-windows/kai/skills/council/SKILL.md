---
name: council
description: "Multi-agent collaborative debate with a visible round-by-round transcript and real intellectual friction. Composes 4-6 topic-briefed council members with distinct roles and stances, runs them as parallel tasks, and has them respond to each other's actual points: a 3-round DEBATE (positions, challenges, synthesis) for important decisions, or a 1-round QUICK check for sanity checks. Ends with convergence, remaining disagreements, and a recommended path. Use when the user says council, convene a council, debate this, multiple perspectives, weigh options, deliberate, get different views, what would experts say, pros and cons, help me decide between X and Y, or quick council check. Not for pure adversarial attack on an idea (use the red-team skill)."
---

# Council

Ask one model for an opinion and you get one frame and one set of blind spots. Ask for "pros and cons" and you get a flat list with nobody pushing back. Real deliberation needs distinct experts who disagree on the merits and argue it out, so weak parts of an idea get exposed before you commit. Generic agents all sound alike and produce bland agreement; this skill composes topic-specific members who create genuine friction.

**Council vs. red-team:** council is collaborative-adversarial (debate to find the best path) and produces a visible conversation transcript. Red-team is purely adversarial (attack the idea) and produces a steelman plus counter-argument. Run council first, red-team the winner after.

## Workflows

| Workflow | Use for | Rounds | Output | File |
|----------|---------|--------|--------|------|
| **DEBATE** | Important decisions | 3 | Full transcript + council synthesis | `Workflows/Debate.md` |
| **QUICK** | Sanity checks, fast feedback | 1 | Initial positions + quick summary | `Workflows/Quick.md` |

Pure adversarial analysis is not a council workflow; redirect to the red-team skill.

## Members are topic briefs

Each member is a short brief you write for this topic: name, role/expertise, stance, and what they'll push on. See `CouncilMembers.md` for the default slots and an example brief. Four different briefs; never four identical agents.

## Running on Copilot

Every member call is a `task` whose prompt is the member's brief + the round instructions + the topic context. When a member's role matches a Kai custom agent, dispatch it there: evidence/precedent members to `@kai-researcher`, builder/implementation members to `@kai-engineer`, skeptic/critic members to `@kai-reviewer`, design/strategy members to `@kai-architect`. Otherwise use a plain `task` with the persona brief. The brief, not the agent, is what gives the member a stance.

**Parallel within rounds, sequential between rounds.** All members of a round run as parallel `task` calls issued together; the next round starts only after every member's previous-round response is in, because each round's prompt includes the prior transcript. A 3-round debate of 4 members is 12 calls but only 3 sequential waits.

## Round structure

1. **Round 1, initial positions.** Each member states their take from their perspective. No interaction yet. Goal: surface diverse viewpoints before they influence each other.
2. **Round 2, responses and challenges.** Each member reads the Round 1 transcript and responds to specific points ("I disagree with [Name]'s point about X because...", "Building on [Name]'s concern about Y..."). Goal: genuine friction through direct engagement.
3. **Round 3, synthesis and convergence.** Each member states where the council agrees, where they still disagree, and their final recommendation given the full discussion. Goal: surface convergence and remaining tension honestly.

Then the orchestrator writes the **Council Synthesis**. QUICK runs Round 1 only, with shorter answers, then a quick summary.

The value is in the interaction: domain experts pushing back on each other's actual points, not a pile of opinions.

## Output contract

- The transcript is visible, round by round, with each member's name and one-line role.
- **Length:** 100-150 words per member per round (DEBATE); 30-50 words (QUICK).
- **Tone:** professional but direct; genuine challenges.
- **Round 2+ must reference other members' specific points.** Restating your Round 1 position without engagement is a failure.
- **Names** come from the briefs and stay consistent across all rounds and the synthesis.
- **No forced consensus.** Acknowledged tension beats fake agreement.

Templates for both formats live in the workflow files.

## Examples

- "Council: should we use WebSockets or SSE?" → briefs for a real-time systems architect, frontend-DX advocate, ops/reliability skeptic, industry researcher → DEBATE.
- "Quick council check: is this API design reasonable?" → four API-relevant briefs → QUICK.
- "Council: is AI overhyped?" → AI builder, security skeptic, pragmatic engineer, evidence analyst → DEBATE.

## Gotchas

- **Debates need genuine disagreement.** If every member agrees in Round 1, the topic may not warrant a council; say so.
- **More members is not better.** 4-6 well-briefed members beat 12 generic ones.
- **Brief for the topic, not a generic role.** "Skeptic" is a slot; "ops engineer who has been paged by long-lived connection leaks" is a member.
- Gather context first (invoke the `/research` skill) when members need facts to argue from; include it in every member's topic context.
