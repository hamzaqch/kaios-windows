# Quick

Single-round perspective check for sanity checks and fast feedback.

**Inputs:** the topic or question; optionally, member descriptions from the user.

## Step 1: write and announce

Write 4 member briefs tailored to the topic (see `../CouncilMembers.md`), then:

```markdown
## Quick Council: [Topic]

**Council Members:** [Name, one-line role] for each member
**Mode:** Single round (fast perspectives)
```

## Step 2: gather perspectives

Dispatch all members as parallel `task` calls (to the matching `@kai-*` agent where the role fits). Each prompt is the member's brief plus:

```
QUICK COUNCIL CHECK

Topic: [topic]

[Relevant context]

Give your immediate take from your specialized perspective:
- Key concern, insight, or recommendation
- 30-50 words max
- Be direct and specific

This is a quick sanity check, not a full debate.
```

## Step 3: output

```markdown
### Perspectives

**[Name] ([role]):**
[Brief take]

(one block per member)

### Quick Summary

**Consensus:** [Do they generally agree? On what?]
**Concerns:** [Red flags raised]
**Recommendation:** [Proceed / Reconsider / Need full debate]
```

## When to escalate

If the check reveals significant disagreement or complex trade-offs, recommend the full debate:

```
This topic has enough complexity for a full council debate.
Run: "Council: [topic]" for a 3-round structured discussion.
```
