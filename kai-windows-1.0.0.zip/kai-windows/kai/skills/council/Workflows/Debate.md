# Debate

Full structured debate: 3 rounds, visible transcript, council synthesis.

**Inputs:** the topic or question; optionally, member descriptions from the user (otherwise compose them).

## Step 0: write the members

Analyze the topic, choose the 4 perspectives that create the most productive friction, and write a brief for each (name, role/expertise, stance, what they'll push on). No tool call; you write these directly. See `../CouncilMembers.md`.

## Step 1: announce the council

```markdown
## Council Debate: [Topic]

**Council Members:** [Name, one-line role] for each member
**Rounds:** 3 (Positions -> Responses -> Synthesis)
```

## Step 2: Round 1, initial positions

Dispatch all members as parallel `task` calls (to the matching `@kai-*` agent where the role fits). Each prompt is the member's brief plus:

```
COUNCIL DEBATE - ROUND 1: INITIAL POSITIONS

Topic: [topic]

[Full topic context: background, data, quotes, constraints the member needs to form
an informed opinion]

Give your initial position from your specialized perspective.
- Speak in first person as your character
- Be specific and substantive (100-150 words)
- State your key concern, recommendation, or insight
- You will respond to the other council members in Round 2
```

Output:

```markdown
### Round 1: Initial Positions

**[Name] ([role]):**
[Response]

(one block per member)
```

## Step 3: Round 2, responses and challenges

After every Round 1 response is in, dispatch all members again in parallel. Each prompt is the brief plus:

```
COUNCIL DEBATE - ROUND 2: RESPONSES & CHALLENGES

Topic: [topic]

What the council said in Round 1:
[Full Round 1 transcript]

Respond to the other council members:
- Reference specific points they made ("I disagree with [Name]'s point about X...")
- Challenge assumptions or add nuance
- Build on points you agree with
- Keep your specialized perspective
- 100-150 words

The value is genuine intellectual friction. Engage with their actual arguments.
```

Output as `### Round 2: Responses & Challenges`, one block per member.

## Step 4: Round 3, synthesis

Dispatch all members in parallel with the Round 1 + Round 2 transcripts. Each prompt is the brief plus:

```
COUNCIL DEBATE - ROUND 3: SYNTHESIS

Topic: [topic]

Full debate transcript so far:
[Round 1 + Round 2 transcripts]

Final synthesis from your perspective:
- Where does the council agree?
- Where do you still disagree with others?
- What is your final recommendation given the full discussion?
- 100-150 words

Be honest about remaining disagreements. Forced consensus is worse than acknowledged
tension.
```

Output as `### Round 3: Synthesis`, one block per member.

## Step 5: council synthesis

You write this, from the full transcript:

```markdown
### Council Synthesis

**Areas of Convergence:**
- [Points where 3+ members agreed]
- [Shared concerns or recommendations]

**Remaining Disagreements:**
- [Points still contested, and between whom]
- [Trade-offs that couldn't be resolved]

**Recommended Path:**
[Based on convergence and the weight of the arguments, the recommended approach is...]
```

The finished transcript shows the full journey from initial positions through challenges to synthesis.
