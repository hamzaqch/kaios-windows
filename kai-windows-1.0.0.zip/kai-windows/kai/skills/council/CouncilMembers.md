# Council Members

Members are briefs you write for the topic. There is no composition tool and no trait matrix: a capable model writes a sharper, more topic-specific persona than any generic lookup.

## Why briefs, not bare agents

A bare agent with no persona has no stake in the topic and produces bland agreement. Council needs members who disagree on the merits. The friction comes from each member having a distinct role, expertise, and stance, which you supply in the brief.

## Step 1: analyze the topic

Decide which perspectives create the most productive friction for this specific debate. Design the roles around the topic.

**"Should we use WebSockets or SSE?"**
- Real-time systems architect who defends push-first bidirectional transport
- Frontend-DX advocate who wants the simplest thing that ships
- Ops/reliability skeptic who distrusts long-lived connections
- Industry researcher who weighs precedent and adoption data

**"Is AI overhyped?"**
- AI infrastructure builder who ships with these tools daily
- Security practitioner skeptic who has seen the failure modes
- Pragmatic engineer focused on real-world trade-offs
- Evidence-based researcher who wants the numbers

## Step 2: write each brief

2-4 sentences per member: a **name**, their **role/expertise**, the **stance** they hold, and **what they'll push on and attack**. That paragraph is the persona.

> **Mara, real-time systems architect.** Believes in push-first. Will defend WebSocket bidirectionality and attack SSE's connection-count limits and reconnection story. Speaks precisely, cites protocol behavior.

## Step 3: dispatch

Each member is one `task` call per round. Prompt = member brief + round instructions + full topic context. Route to the matching Kai agent when the role fits:

| Member role | Dispatch to |
|-------------|-------------|
| Evidence, precedent, data, adoption research | `@kai-researcher` |
| Builder, implementer, "what actually ships" | `@kai-engineer` |
| Skeptic, critic, failure-mode hunter | `@kai-reviewer` |
| Strategist, system designer, long-term trade-offs | `@kai-architect` |
| Anything else (user advocate, domain specialist, ethicist...) | plain `task` with the persona brief |

Two members may share an agent type; their briefs keep them distinct.

## Default perspective slots

When the user doesn't specify members, cover these four, each written for the topic:

| Slot | Purpose | Typical dispatch |
|------|---------|------------------|
| **Builder** | Has built things in this domain; argues from what actually ships | `@kai-engineer` |
| **Skeptic** | Challenges assumptions, finds flaws and failure modes | `@kai-reviewer` |
| **Pragmatist** | Implementation reality, cost, trade-offs | `@kai-architect` |
| **Analyst** | Data, precedent, external evidence | `@kai-researcher` |

The slots are a starting guide. Adjust the mix to the topic: a pure design question may want two builders and a user advocate instead. Go to 5-6 members only when a distinct, necessary perspective would otherwise be missing.
