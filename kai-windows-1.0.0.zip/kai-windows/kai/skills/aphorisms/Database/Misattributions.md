# Common misattributions

Check here before adding a famous quote. Each of these circulates under a big name, and none has a verified source in that person's work. When one comes up, offer the user the honest options: add it as `Unknown` (or under the real author) with a note, skip it, or find an authentic quote from the named person instead.

| Quote (as it circulates) | Usually credited to | What the record shows |
|---|---|---|
| "We are what we repeatedly do. Excellence, then, is not an act, but a habit." | Aristotle | Will Durant's summary of Aristotle in *The Story of Philosophy* (1926). Authentic Aristotle on habit: *Nicomachean Ethics* II.1. |
| "Be the change you wish to see in the world." | Gandhi | No verified source. The closest authentic passage (1913) is about changing oneself as the world changes, in different words. |
| "Insanity is doing the same thing over and over again and expecting different results." | Einstein | Not found in Einstein's writings; it appears in 1980s recovery-program literature. |
| "Everybody is a genius. But if you judge a fish by its ability to climb a tree..." | Einstein | No source in Einstein's papers or letters. |
| "Not everything that can be counted counts, and not everything that counts can be counted." | Einstein | Sociologist William Bruce Cameron, *Informal Sociology* (1963). |
| "Luck is what happens when preparation meets opportunity." | Seneca | No source in Seneca's works. |
| "No man ever steps in the same river twice." | Heraclitus | A modern paraphrase. The ancient reports (Plato, *Cratylus* 402a; fragments) word it differently. |
| "The definition of success is..." variants | various | Treat any "definition of X" quote as unverified until a primary source turns up. |

## How to check a quote

1. Search the exact wording in quotes, plus the author's name.
2. Look for a primary source: the book, chapter or section, letter, speech or interview, with a date.
3. Search "misattributed" plus the author's name.
4. No primary source after one honest round → record it as `Unknown (often attributed to X)` with status `disputed`, or skip it. Never store an unverified attribution as fact.
