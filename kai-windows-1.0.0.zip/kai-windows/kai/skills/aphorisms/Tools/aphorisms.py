#!/usr/bin/env python3
"""aphorisms.py - deterministic store for the aphorisms skill.

Code lives in the skill folder; data lives in Kai memory so reinstalls never
touch it:
  default  <KAI_HOME>/MEMORY/KNOWLEDGE/aphorisms/
  override APHORISMS_DATA_DIR
KAI_HOME resolves from the KAI_HOME env var, else <COPILOT_HOME>/kai, else
~/.copilot/kai.

Store: aphorisms.json (system of record). aphorisms.md is a generated view;
edit through this CLI, never by hand.

Commands:
  init                         create the store from the public-domain seed (idempotent)
  list   [--theme T] [--author A] [--json]
  search <terms...> [--theme T] [--author A] [--exclude-author A] [--max-chars N]
                     [--fresh-days N] [--limit N] [--json]
  add    --text T --author A --themes "x,y" [--source S] [--context C]
         [--status verified|disputed|unknown] [--force] [--json]
  update <id> [--text T] [--author A] [--themes "x,y"] [--source S] [--context C] [--status S]
  use    <id> --where W [--placement P] [--date YYYY-MM-DD]
  show   <id> [--json]
  themes [--json]
  stats  [--json]
  export                       regenerate aphorisms.md

Python 3.8+ standard library only.
"""
import argparse
import datetime as dt
import difflib
import json
import os
import re
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SEED = HERE.parent / "Database" / "seed.json"
STATUSES = ("verified", "disputed", "unknown")
NEAR_DUP = 0.82


# ---------------------------------------------------------------- paths

def kai_home():
    env = os.environ.get("KAI_HOME")
    if env:
        return Path(env).expanduser()
    ch = os.environ.get("COPILOT_HOME")
    if ch:
        return Path(ch).expanduser() / "kai"
    return Path.home() / ".copilot" / "kai"


def data_dir():
    env = os.environ.get("APHORISMS_DATA_DIR")
    d = Path(env).expanduser() if env else kai_home() / "MEMORY" / "KNOWLEDGE" / "aphorisms"
    d = d.resolve()
    if any(part.lower() == "skills" for part in d.parts):
        raise SystemExit("error: data dir {} is inside a skills folder; code and data stay separate. "
                         "Set APHORISMS_DATA_DIR elsewhere.".format(d))
    return d


def store_path(d):
    return d / "aphorisms.json"


# ---------------------------------------------------------------- store

def now_iso():
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def today():
    return dt.date.today().isoformat()


def normalize(text):
    t = text.lower().replace("’", "'").replace("‘", "'")
    t = re.sub(r"[^\w\s']", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def empty_store():
    return {"version": 1, "updated": now_iso(), "aphorisms": []}


def load(d):
    p = store_path(d)
    if not p.exists():
        return None
    try:
        with p.open("r", encoding="utf-8-sig") as fh:
            store = json.load(fh)
    except ValueError as exc:
        raise SystemExit("error: {} is not valid JSON ({}). Fix or restore it; never hand-edit the store."
                         .format(p, exc))
    if not isinstance(store, dict) or store.get("version") != 1:
        raise SystemExit("error: unsupported store version {}".format(
            store.get("version") if isinstance(store, dict) else "?"))
    return store


def require(d):
    store = load(d)
    if store is None:
        raise SystemExit("error: no store at {}. Run: aphorisms.py init".format(store_path(d)))
    return store


def save(d, store):
    d.mkdir(parents=True, exist_ok=True)
    store["updated"] = now_iso()
    fd, tmp = tempfile.mkstemp(prefix=".aphorisms-", suffix=".json", dir=str(d))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(store, fh, indent=2, ensure_ascii=False)
            fh.write("\n")
        os.replace(tmp, str(store_path(d)))
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    export(d, store)


def next_id(store):
    mx = 0
    for a in store["aphorisms"]:
        try:
            mx = max(mx, int(a["id"].split("-")[1]))
        except (IndexError, ValueError):
            pass
    return "A-{:03d}".format(mx + 1)


def find(store, aid):
    for a in store["aphorisms"]:
        if a["id"].lower() == aid.lower():
            return a
    raise SystemExit("error: no aphorism {}".format(aid))


def split_list(value):
    return [s.strip() for s in (value or "").split(",") if s.strip()]


def make_entry(store, text, author, themes, source="", context="", status="verified", origin="user"):
    if status not in STATUSES:
        raise SystemExit("error: --status must be one of {}".format("|".join(STATUSES)))
    return {
        "id": next_id(store), "text": text.strip(), "author": author.strip(), "themes": themes,
        "source": source.strip(), "context": context.strip(), "status": status, "origin": origin,
        "added": today(), "usage": [],
    }


def duplicates(store, text, skip_id=None):
    """Return (exact, near) lists of existing entries matching text."""
    n = normalize(text)
    exact, near = [], []
    for a in store["aphorisms"]:
        if a["id"] == skip_id:
            continue
        m = normalize(a["text"])
        if m == n:
            exact.append(a)
        else:
            ratio = difflib.SequenceMatcher(None, n, m).ratio()
            if ratio >= NEAR_DUP or (len(n) > 20 and (n in m or m in n)):
                near.append((round(ratio, 2), a))
    near.sort(key=lambda x: -x[0])
    return exact, near


def last_used(a):
    dates = [u.get("date", "") for u in a.get("usage", [])]
    return max(dates) if dates else ""


# ---------------------------------------------------------------- search

def tokens(text):
    return [t for t in normalize(text).split() if len(t) > 2]


def score(a, terms, theme=None):
    """Keyword relevance (0-10): quote text weighs most, then themes, author, context."""
    if not terms and not theme:
        return 5.0
    hay_text = set(tokens(a["text"]))
    hay_theme = set(tokens(" ".join(a["themes"])))
    hay_author = set(tokens(a["author"]))
    hay_ctx = set(tokens(a.get("context", "") + " " + a.get("source", "")))
    s = 0.0
    for t in terms:
        stem = t[:5]

        def hit(bag):
            return any(w == t or w.startswith(stem) for w in bag)
        if hit(hay_text):
            s += 3
        if hit(hay_theme):
            s += 2.5
        if hit(hay_author):
            s += 2
        if hit(hay_ctx):
            s += 1
    if theme and any(theme.lower() in th.lower() for th in a["themes"]):
        s += 4
    denom = max(1, len(terms)) * 3 + (4 if theme else 0)
    return round(min(10.0, 10.0 * s / denom), 1)


def freshness(a, ref=None):
    """0-10, 10 = never used. Mirrors the skill's freshness rubric."""
    lu = last_used(a)
    if not lu:
        return 10
    ref = ref or dt.date.today()
    try:
        days = (ref - dt.date.fromisoformat(lu[:10])).days
    except ValueError:
        return 10
    if days > 180:
        return 8
    if days > 90:
        return 5
    return 1


def do_search(store, terms, theme=None, author=None, exclude_author=None, max_chars=None,
              fresh_days=None, limit=10):
    terms = [t for t in (normalize(" ".join(terms)).split()) if len(t) > 2]
    out = []
    for a in store["aphorisms"]:
        if author and author.lower() not in a["author"].lower():
            continue
        if exclude_author and exclude_author.lower() in a["author"].lower():
            continue
        if theme and not any(theme.lower() in th.lower() for th in a["themes"]):
            continue
        if max_chars and len(a["text"]) > max_chars:
            continue
        if fresh_days is not None and last_used(a):
            try:
                if (dt.date.today() - dt.date.fromisoformat(last_used(a)[:10])).days < fresh_days:
                    continue
            except ValueError:
                pass
        rel = score(a, terms, theme)
        if terms and rel == 0:
            continue
        out.append({"relevance": rel, "freshness": freshness(a), "aphorism": a})
    out.sort(key=lambda r: (-(r["relevance"] + r["freshness"] / 2.0), len(r["aphorism"]["text"])))
    return out[:limit] if limit else out


# ---------------------------------------------------------------- rendering

def line(a):
    lu = last_used(a)
    return '{}  "{}" - {}  [{}]{}'.format(a["id"], a["text"], a["author"], ", ".join(a["themes"]),
                                          "  (last used {})".format(lu) if lu else "")


def detail(a):
    rows = [
        "{}: \"{}\"".format(a["id"], a["text"]),
        "  author: {}".format(a["author"]),
        "  themes: {}".format(", ".join(a["themes"]) or "-"),
        "  source: {}".format(a.get("source") or "-"),
        "  context: {}".format(a.get("context") or "-"),
        "  status: {}   origin: {}   added: {}".format(a.get("status"), a.get("origin"), a.get("added")),
    ]
    if a.get("usage"):
        rows.append("  usage:")
        rows.extend("    - {} | {} | {}".format(u.get("date"), u.get("where"), u.get("placement") or "-")
                    for u in a["usage"])
    else:
        rows.append("  usage: never used")
    return "\n".join(rows)


def theme_index(store):
    idx = {}
    for a in store["aphorisms"]:
        for th in a["themes"]:
            idx.setdefault(th, []).append(a)
    return dict(sorted(idx.items()))


def export(d, store):
    lines = ["# Aphorism Collection", "",
             "> GENERATED by aphorisms.py from aphorisms.json - edit through the CLI, not here. "
             "Updated: {}".format(store["updated"]), ""]
    for th, items in theme_index(store).items():
        lines.append("## {}".format(th))
        lines.append("")
        for a in items:
            lines.append('**"{}"**'.format(a["text"]))
            lines.append("- ID: {} | Author: {} | Status: {}".format(a["id"], a["author"], a.get("status")))
            if a.get("source"):
                lines.append("- Source: {}".format(a["source"]))
            if a.get("context"):
                lines.append("- Context: {}".format(a["context"]))
            lines.append("")
    lines.append("## Usage History")
    lines.append("")
    used = [(u, a) for a in store["aphorisms"] for u in a.get("usage", [])]
    used.sort(key=lambda x: x[0].get("date", ""), reverse=True)
    if not used:
        lines.append("_No usage recorded yet._")
    for u, a in used:
        lines.append("- {} | {} | {} | {} - {}".format(u.get("date"), u.get("where"), u.get("placement") or "-",
                                                      a["id"], a["author"]))
    lines.append("")
    (d / "aphorisms.md").write_text("\n".join(lines), encoding="utf-8")


def stats(store):
    authors = {a["author"] for a in store["aphorisms"]}
    return {
        "total": len(store["aphorisms"]),
        "authors": len(authors),
        "themes": len(theme_index(store)),
        "used": sum(1 for a in store["aphorisms"] if a.get("usage")),
        "disputed": sum(1 for a in store["aphorisms"] if a.get("status") == "disputed"),
        "updated": store["updated"],
    }


# ---------------------------------------------------------------- commands

def cmd_init(d, args):
    store = load(d)
    created = store is None
    if created:
        store = empty_store()
    with SEED.open("r", encoding="utf-8-sig") as fh:
        seed = json.load(fh)
    added = 0
    for s in seed["aphorisms"]:
        exact, _ = duplicates(store, s["text"])
        if exact:
            continue
        store["aphorisms"].append(make_entry(store, s["text"], s["author"], s["themes"], s.get("source", ""),
                                             s.get("context", ""), "verified", "seed"))
        added += 1
    save(d, store)
    print("{} {} ({} seed entries added, {} total)".format("Created" if created else "Updated", d, added,
                                                         len(store["aphorisms"])))
    return 0


def emit(obj, as_json, text):
    print(json.dumps(obj, indent=2, ensure_ascii=False) if as_json else text)


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description="Aphorism store (data in Kai memory).")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("init")
    p = sub.add_parser("list")
    p.add_argument("--theme")
    p.add_argument("--author")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("search")
    p.add_argument("terms", nargs="*")
    p.add_argument("--theme")
    p.add_argument("--author")
    p.add_argument("--exclude-author")
    p.add_argument("--max-chars", type=int)
    p.add_argument("--fresh-days", type=int, help="skip quotes used within N days")
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("add")
    p.add_argument("--text", required=True)
    p.add_argument("--author", required=True)
    p.add_argument("--themes", required=True)
    p.add_argument("--source", default="")
    p.add_argument("--context", default="")
    p.add_argument("--status", default="verified")
    p.add_argument("--force", action="store_true", help="add despite a near-duplicate (never despite an exact one)")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("update")
    p.add_argument("id")
    for f in ("text", "author", "themes", "source", "context", "status"):
        p.add_argument("--" + f)
    p = sub.add_parser("use")
    p.add_argument("id")
    p.add_argument("--where", required=True)
    p.add_argument("--placement", default="")
    p.add_argument("--date", default="")
    p = sub.add_parser("show")
    p.add_argument("id")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("themes")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("stats")
    p.add_argument("--json", action="store_true")
    sub.add_parser("export")
    args = ap.parse_args(argv)

    d = data_dir()
    if args.cmd == "init":
        return cmd_init(d, args)
    if args.cmd is None:
        ap.print_help()
        print("\ndata dir: {}".format(d))
        return 0
    store = require(d)

    if args.cmd == "list":
        items = [a for a in store["aphorisms"]
                 if (not args.theme or any(args.theme.lower() in t.lower() for t in a["themes"]))
                 and (not args.author or args.author.lower() in a["author"].lower())]
        emit(items, args.json, "\n".join(line(a) for a in items) or "(no aphorisms)")
    elif args.cmd == "search":
        res = do_search(store, args.terms, args.theme, args.author, args.exclude_author, args.max_chars,
                        args.fresh_days, args.limit)
        emit(res, args.json, "\n".join("[rel {:>4} fresh {:>2}] {}".format(r["relevance"], r["freshness"],
                                                                           line(r["aphorism"])) for r in res)
             or "(no matches; try a broader term, a theme from `themes`, or ResearchThinker)")
    elif args.cmd == "add":
        themes = split_list(args.themes)
        if not themes:
            raise SystemExit("error: --themes needs at least one theme")
        exact, near = duplicates(store, args.text)
        if exact:
            print("DUPLICATE: already stored as {}".format(exact[0]["id"]), file=sys.stderr)
            print(line(exact[0]), file=sys.stderr)
            return 3
        if near and not args.force:
            print("NEAR-DUPLICATE (re-run with --force to add anyway):", file=sys.stderr)
            for ratio, a in near[:3]:
                print("  {:.2f}  {}".format(ratio, line(a)), file=sys.stderr)
            return 4
        entry = make_entry(store, args.text, args.author, themes, args.source, args.context, args.status)
        store["aphorisms"].append(entry)
        save(d, store)
        emit(entry, args.json, "added " + line(entry))
    elif args.cmd == "update":
        a = find(store, args.id)
        if args.text:
            exact, _ = duplicates(store, args.text, skip_id=a["id"])
            if exact:
                raise SystemExit("error: that text is already stored as {}".format(exact[0]["id"]))
            a["text"] = args.text.strip()
        if args.author:
            a["author"] = args.author.strip()
        if args.themes:
            a["themes"] = split_list(args.themes)
        if args.source is not None:
            a["source"] = args.source.strip()
        if args.context is not None:
            a["context"] = args.context.strip()
        if args.status:
            if args.status not in STATUSES:
                raise SystemExit("error: --status must be one of {}".format("|".join(STATUSES)))
            a["status"] = args.status
        save(d, store)
        print("updated " + line(a))
    elif args.cmd == "use":
        a = find(store, args.id)
        date = args.date or today()
        try:
            dt.date.fromisoformat(date)
        except ValueError:
            raise SystemExit("error: --date must be YYYY-MM-DD")
        a.setdefault("usage", []).append({"date": date, "where": args.where, "placement": args.placement})
        save(d, store)
        print("recorded use of {} on {} in {}".format(a["id"], date, args.where))
    elif args.cmd == "show":
        a = find(store, args.id)
        emit(a, args.json, detail(a))
    elif args.cmd == "themes":
        idx = {th: len(items) for th, items in theme_index(store).items()}
        emit(idx, args.json, "\n".join("{:>3}  {}".format(n, th) for th, n in idx.items()))
    elif args.cmd == "stats":
        st = stats(store)
        st["data_dir"] = str(d)
        emit(st, args.json, "\n".join("{}: {}".format(k, v) for k, v in st.items()))
    elif args.cmd == "export":
        export(d, store)
        print("wrote {}".format(d / "aphorisms.md"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
