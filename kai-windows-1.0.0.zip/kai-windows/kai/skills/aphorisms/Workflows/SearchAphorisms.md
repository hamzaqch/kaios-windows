# Search aphorisms

**Purpose:** search the store by theme, keyword, author or topic to discover relevant quotes.

**When to use:**
- "search aphorisms about <topic>", "find quotes on <theme>", "show me <keyword> quotes"
- Browsing for inspiration before the content's theme is settled
- Discovering what the collection holds

**Prerequisites:** the store exists. `$A` is `"$HOME/.copilot/skills/aphorisms/Tools/aphorisms.py"`.

---

## Step 1: Parse the query

| Search type | Examples | Command |
|---|---|---|
| **Theme** | "aphorisms about resilience", "stoicism quotes" | `python $A search --theme "<theme>"` (see `python $A themes` for names) |
| **Keyword** | "quotes with 'curiosity'", "aphorisms mentioning fear" | `python $A search <keyword>` |
| **Author** | "all Seneca quotes", "what do we have from Emerson?" | `python $A list --author "<name>"` |
| **Topic (semantic)** | "quotes about overcoming setbacks", "wisdom on decision-making" | map the topic to 2-3 themes and keywords, run a search for each, merge |
| **Combination** | "Seneca on learning", "short stoic quotes on control" | combine flags: `--author`, `--theme`, `--max-chars` |

Matching is case-insensitive and stem-based ("learn" finds "learning" and "learns").

## Step 2: Run the search

```powershell
python $A search <keywords> [--theme T] [--author A] [--exclude-author A] [--max-chars N] [--fresh-days N] [--limit N] [--json]
```

Use `--json` when you need the full entries (source, context, usage) to write results. For a topic search, run one search per mapped theme or keyword and merge the results yourself.

## Step 3: Rank

The CLI orders by relevance plus freshness. Re-rank for the final answer on three criteria, 0-10 each (max 30):

1. **Relevance**: exact theme match 10 · keyword in the quote 8-10 · keyword in the context 5-7 · related theme 4-6 · tangential 1-3
2. **Quotability**: clear and concise 8-10 · needs some context 5-7 · long or complex 3-4
3. **Freshness**: never used 10 · used over 6 months ago 7-9 · recently 3-6 · very recently 0-2

Sort by total; break ties by quotability, then author diversity.

## Step 4: Format the results

```markdown
## Search results: "[query]"

**Found [N] matching aphorisms**

### 1. [first few words]
**"[full quote]"**
**Author:** [author] — *[source]*
**Themes:** [theme 1], [theme 2]
**Context:** [brief context]
**Why it matches:** [specific relevance to the query]
**Usage:** [last used: date / never]  ·  **Score:** [X/30]

### 2. ...

## Summary
**Total:** [N]  ·  **By theme:** [theme: n, ...]  ·  **By author:** [author: n, ...]
**Top recommendation:** #1

## You might also like
- [related theme]
- quotes from [related author]
```

## Advanced filters

| Ask | How |
|---|---|
| "resilience quotes but not Seneca" | `--theme Resilience --exclude-author Seneca` |
| "unused quotes about learning" | `--theme Learning --fresh-days 180` (also drops anything used in the last 180 days) |
| "short quotes about action" | `--theme "Risk & Action" --max-chars 150` |
| "quotes from books, not speeches" | `--json`, then filter on the `source` field |

## Search by use case

- **Content topic** ("I'm writing about AI safety"): map the topic to themes (careful thinking → Wisdom & Truth, Humility & Doubt, Stoicism & Control), search each, rank by relevance to the specific message.
- **Mood** ("I need an inspiring quote"): pick themes that match the mood (Resilience, Excellence, Risk & Action) and filter out cautionary or dark quotes.
- **Audience** ("for a technical audience"): favor scientists, philosophers of knowledge and rigorous thinkers (Darwin, Bacon, Spinoza, Montaigne in the seed); avoid pop-culture lines.

## Edge cases

- **No results:** say so plainly, list the available themes (`python $A themes`), suggest broader or adjacent terms, and offer **ResearchThinker** to grow the collection.
- **Too many results:** show the top 10, summarize the rest by theme and author, and offer narrowing filters.
- **Ambiguous query** ("quotes about power"): ask which sense (personal power, political power, knowledge as power) or show the top hit for each sense.
- **Contradictory request** ("calm but urgent"): show the best quote for each side and one that holds both, if the store has it.

## After the search

- **Using one in content:** record it with `python $A use <id> --where "<publication + date>" --placement <opening|closing|divider>`.
- **Gap found:** run **ResearchThinker** for a fitting thinker.
- **User supplies a new quote:** run **AddAphorism**.

## Quality checks

- [ ] Every result genuinely matches the query
- [ ] Scores reflect match quality; results ranked
- [ ] Author variety where possible
- [ ] Each result says why it matches
- [ ] Usage history shown
- [ ] Related suggestions are actually related
