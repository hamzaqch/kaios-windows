# Find an aphorism for content

**Purpose:** analyze a newsletter, article or draft and recommend the best thematically aligned aphorism from the store.

**When to use:**
- The user provides a draft or URL and asks for a quote
- The user describes a theme and wants a recommendation
- "find an aphorism for this", "what quote fits this", "suggest a quote"
- An opening or closing quote is needed

**Prerequisites:**
- The store exists (`python "$HOME/.copilot/skills/aphorisms/Tools/aphorisms.py" stats`; if it says there is no store, run `init`)
- Content, a URL, or a clear theme description

---

## Step 1: Get the content

- **URL:** web fetch it and extract the main content, title and key themes.
- **Pasted content:** use the full text.
- **Theme described:** work from the description (for example "a newsletter about overcoming setbacks").

## Step 2: Analyze the content's themes

Identify:

1. **Core topic**: what is it fundamentally about? (AI safety, personal productivity, a security incident, market analysis)
2. **Emotional tone**: optimistic, cautionary, reflective, urgent, inspirational
3. **Key messages**: the 2-3 main takeaways ("persistence beats talent", "question assumptions", "fundamentals first")
4. **Philosophical alignment**: which value themes are present (wisdom & truth-seeking, rationality & evidence, human flourishing & progress, resilience & growth, learning & curiosity, stoicism & control, risk & action, excellence & mastery). Use the user's stated values when known (see SKILL.md, Alignment).
5. **Audience**: newsletter readers, blog readers, social audience, technical readers

```markdown
### Content analysis
- **Core topic**: [topic]
- **Emotional tone**: [tone]
- **Key messages**:
  1. [message 1]
  2. [message 2]
  3. [message 3]
- **Value themes**: [theme 1], [theme 2], [theme 3]
- **Audience**: [context]
```

## Step 3: Pull candidates from the store

Run 2-4 searches covering the core topic, the key messages and the matching themes, so you see the whole relevant slice:

```powershell
$A = "$HOME/.copilot/skills/aphorisms/Tools/aphorisms.py"
python $A search <topic words> --limit 15 --json
python $A search --theme "<matching theme>" --limit 15 --json
python $A themes
```

Read the usage history in each result (`usage`, and the `freshness` score) to avoid recently used quotes. If nothing fits, go to the edge cases below.

## Step 4: Score each candidate

Score on five criteria, 0-10 each (max 50):

1. **Thematic relevance**: directly addresses the core themes (8-10), tangential (4-7), weak (0-3)
2. **Tonal alignment**: mood matches (8-10), compatible (5-7), mismatched (0-4)
3. **Message reinforcement**: strongly reinforces a key message (8-10), somewhat (4-7), neutral or contradictory (0-3)
4. **Philosophical alignment**: embodies the user's values deeply (8-10), somewhat (5-7), misaligned (0-4)
5. **Freshness**: never used = 10, used 6+ months ago = 7-9, within 6 months = 3-6, within 3 months = 0-2 (the CLI's `freshness` field follows this rubric)

**Select the top 3-5.** All should score 35+ (70%). Prefer variety in authors. Balance well-known and lesser-known quotes.

## Step 5: Write the recommendations

```markdown
### Recommendation [N]: [quote summary]

**Quote:** "[full quote text]"
**Author:** [author] — *[source]*

**Why this fits:**
- **Thematic relevance**: [specific connection to the content's themes]
- **Tonal alignment**: [how the mood matches]
- **Message support**: [which key message it reinforces]
- **Value alignment**: [which value themes it embodies]

**Placement:** [opening quote / closing quote / section divider] — [reasoning]
**Context (if needed):** [brief background readers might need]
**Score:** [X/50] · **Last used:** [date / never]
```

Provide 3-5:
- **#1 Best overall match**: highest total
- **#2 Alternative strong match**: second-best, or a different tone
- **#3 Safe classic**: well-known, universally resonant
- **#4 (optional) Unexpected choice**: high relevance, lesser-known author or quote
- **#5 (optional) Philosophical depth**: for readers who want the deeper cut

## Step 6: Present

```markdown
## Aphorism recommendations for "[title or theme]"

### Content analysis
[2-3 sentences on themes and tone]

### Top recommendations
[recommendations from Step 5]

### Quick decision guide
- **Maximum impact**: #1
- **Variety** (if #1's author was used recently): #2
- **Broad appeal**: #3
- **Surprise**: #4
- **Depth**: #5
```

## Step 7: Record the choice

When the user picks one, record it so it isn't repeated:

```powershell
python $A use <id> --where "<publication + date + title>" --placement <opening|closing|divider>
```

---

## Advanced techniques

- **Several drafts at once:** analyze all, find through-lines, recommend quotes that span themes, keep variety across drafts.
- **Seasonal and temporal context:** time of year (new year = fresh starts), current events (avoid tone-deaf picks), recent themes (ensure variety).
- **Author diversity:** check `usage` across recent picks; rotate classical and modern; balance well-known and obscure.

## Common patterns

| Content type | Themes | Tone |
|---|---|---|
| Resilience / adversity | setbacks, persistence, growth through difficulty | inspirational, realistic about difficulty |
| Learning / curiosity | knowledge, improvement, intellectual honesty | encouraging, thoughtful |
| Action / risk | taking chances, overcoming fear, experimenting | bold, courage-focused |
| Excellence / mastery | standards, craft, dedication, results | demanding, outcome-focused |
| Stoicism / control | focus on what you control, acceptance | calm, centered |
| Progress / self-competition | internal benchmarks, growth | encouraging, non-comparative |

## Quality checks

- [ ] Every quote's wording and attribution checked (store status `verified`, or flagged)
- [ ] Thematic relevance is clear and specific
- [ ] Tone fits (no jarring mismatch)
- [ ] Value alignment is genuine
- [ ] Usage history checked (nothing recently used unless the user wants it)
- [ ] Context given where a quote needs background
- [ ] Placement suggestion fits
- [ ] Author diversity maintained
- [ ] At least 3 recommendations, ranked and explained

## Edge cases

- **No good match:** widen to adjacent themes (resilience → strength → adversity); recommend complementary rather than identical matches; or run **ResearchThinker** for a fitting thinker, add the finds via **AddAphorism**, then recommend.
- **User rejects all:** ask what didn't land (tone? author? message?), then search again with that constraint, or offer research on a specific thinker or theme.
- **Multi-themed content:** pick the dominant theme, or find one quote that unifies several.

## Success criteria

The user gets 3-5 relevant, explained options, can pick one confidently, the top pick scores 35+, and the chosen quote's use is recorded.
