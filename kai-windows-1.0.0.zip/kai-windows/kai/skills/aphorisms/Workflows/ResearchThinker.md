# Research a thinker's quotes

**Purpose:** research a specific philosopher, writer or thinker, find their most authentic and useful aphorisms, and add the best to the store.

**When to use:**
- "research <thinker> quotes", "find <author> aphorisms", "what did <thinker> say about <topic>"
- The store has no good match for a theme and a particular thinker would cover it
- Building out an author's presence in the collection

**Prerequisites:** the store exists. `$A` is `"$HOME/.copilot/skills/aphorisms/Tools/aphorisms.py"`.

---

## Step 1: Identify the target

**Required:** the thinker's name.
**Optional:** a theme focus ("Seneca on time", "Montaigne on doubt") and a quote count (default: the best 10-15).

Write a short profile before searching, so the search has direction:

```
**[Thinker] ([dates])**
- Focus: [what they're known for]
- Key works: [2-4 primary works]
- Value alignment: [which of the user's value themes their work speaks to]
```

Check what's already stored: `python $A list --author "<thinker>"`.

## Step 2: Research

Cover several source types. For a deep pass, issue parallel `task` calls to `@kai-researcher`, one per angle below, each returning candidate quotes with a primary-source citation (work, chapter or section, translator, year) and a link:

1. **Primary sources**: the works themselves (for older authors, public-domain texts are often online in full).
2. **Quote collections** (Wikiquote and similar): useful for leads, never as proof. Wikiquote's "Misattributed" and "Disputed" sections are especially useful.
3. **Biographical and scholarly sources**: context for when and why something was said.
4. **Talks and interviews** (modern thinkers): transcripts; get the transcript text, never guess from a title.

Search queries that work:

```
"<thinker> most famous quotes"
"<thinker> on <theme>"
"<thinker> <work title> quotes"
"<thinker> misattributed quotes"
```

## Step 3: Filter and verify

Gather 30-50 candidates, then filter on:

1. **Authenticity (critical):** traceable to a primary source; not on the misattribution lists (`Database/Misattributions.md`, Wikiquote's sections). When in doubt, mark `disputed` or skip.
2. **Value alignment (high):** embodies wisdom, truth-seeking or the user's stated values; offers a real insight.
3. **Quotability (high):** concise, memorable, stands alone without extensive context.
4. **Thematic relevance (medium):** fits existing themes and the topics the user writes about.
5. **Uniqueness (medium):** adds an angle the store doesn't already cover (search before adding).

Keep the top 10-15: all must pass authenticity; most should score high on alignment and quotability; spread them across themes so they represent the thinker's range.

## Step 4: Context for each quote

For each selection, write:
- **Source:** work, chapter or section, page if known, translator and year
- **Background:** what the thinker was addressing; why it's significant; how it represents their philosophy
- **Relevance:** why it matters to the user's audience now

## Step 5: Organize by theme

Group the selections by primary theme (existing themes first; propose new ones to the user if needed). Within a theme, order by impact.

## Step 6: Add them

One `add` per quote (see **AddAphorism** Step 6 for the command). The CLI rejects duplicates; when it flags a near-duplicate, decide with the user.

## Step 7: Report

```markdown
## [Thinker] research complete

**Quotes added:** [N]  ·  **Skipped as unverifiable:** [N]

**By theme:**
- [Theme 1]: [N]
- [Theme 2]: [N]

**Top 3**
1. "[quote]" — *[source]* — why notable: [reason]
2. ...
3. ...

**Philosophy summary:** [2-3 sentences on the thinker's core ideas as these quotes show them]
**Value alignment:** [how this thinker connects to the user's values]

**Best uses:**
- Writing about [topic] → [ID]
- Writing about [topic] → [ID]

**Store:** [N] total · [N] from [thinker]
```

---

## Research tips by kind of thinker

- **Ancient and classical (Stoics, Confucius, Laozi, Plato):** wording depends on the translation. Prefer one named translation per quote, cite it, and don't mix translations inside one quote. Public-domain translations (pre-1929) are safest to store verbatim.
- **Early modern (Bacon, Montaigne, Pascal, Spinoza):** dense or archaic prose; extract the clearest single sentences and keep the original wording.
- **Prolific modern writers and debaters:** debates and interviews are rich but full of paraphrase; insist on a transcript or a page reference.
- **Scientists:** famous lines are the most misattributed of all; verify every one.

## Edge cases

- **No good quotes:** the thinker's style isn't quotable, the works aren't accessible, or their ideas don't fit the user's values. Try interviews and speeches, extract the clearest statements, or suggest a better-suited thinker.
- **Too many great quotes:** add the top 10-15 now, keep the research notes (in the conversation or a note in `~/.copilot/kai/MEMORY/KNOWLEDGE/`), and add more in a later pass.
- **Quotes that need heavy context:** keep minimal context when the quote stands alone; extend it only when understanding requires background.

## Quality checks

- [ ] Every quote traced to a primary or reliable source
- [ ] No misattributions
- [ ] 10-15 strong quotes (or fewer with the reason stated)
- [ ] Each has source, background and relevance
- [ ] Themes assigned; store updated through the CLI
- [ ] Report delivered with highlights
