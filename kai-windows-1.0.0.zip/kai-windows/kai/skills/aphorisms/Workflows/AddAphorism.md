# Add an aphorism

**Purpose:** add a new aphorism to the store with verified wording and attribution, themes, source, context, and no duplicates.

**When to use:**
- The user provides a quote to add ("add this quote", "save this aphorism")
- A great quote turned up during research and should be kept
- After **ResearchThinker** finds quotes worth adding

**Prerequisites:** the store exists (run `init` if a command reports no store). `$A` below is `"$HOME/.copilot/skills/aphorisms/Tools/aphorisms.py"`.

---

## Step 1: Parse the input

**Required:** quote text (exact wording) and author.
**Optional (research if missing):** themes, context, source.

```
"Add this quote: 'The cure for boredom is curiosity. There is no cure for curiosity.' - Dorothy Parker"
"Save this: Quote: <text>  Author: Unknown"
"Add Seneca's line about time being the only thing that's ours"   (needs the exact wording found first)
```

## Step 2: Verify wording and attribution

1. Check `Database/Misattributions.md` (in this skill's folder) for known false attributions.
2. Web search the exact wording in quotes plus the author: `"<quote text>" <author>`.
3. Find a primary source: book and chapter or section, speech, letter or interview, with a date. For translations, name the translator and year.
4. Web search `misattributed <author>` when the quote is famous or suspiciously neat.
5. If the user only remembered the gist, find the exact wording and show it to them before adding.

Outcome, one of:
- ✅ Verified text, confirmed attribution, source identified → `--status verified`
- ⚠️ Commonly attributed but no primary source → author `Unknown (often attributed to X)`, `--status disputed`, and say so to the user
- ❌ Misattributed → offer: add under the real author or as Unknown with a note, skip it, or find an authentic quote from the named person

## Step 3: Check for duplicates

Search the key words first, so you catch paraphrases the CLI can't:

```powershell
python $A search <two or three distinctive words> --limit 10
python $A list --author "<author>"
```

- **Exact duplicate:** tell the user where it is; offer to update its context or themes instead (`update`).
- **Same author, similar message, or a paraphrase:** show it and ask: add anyway?
- **Unique:** continue.

`add` also refuses exact duplicates (exit 3) and flags near-identical wording (exit 4, re-run with `--force` only after the user confirms).

## Step 4: Assign themes

Use the established themes (see `python $A themes`): Learning & Education · Wisdom & Truth · Stoicism & Control · Mindset & Perspective · Resilience & Strength · Work Ethic & Excellence · Risk & Action · Curiosity & Intelligence · Humility & Doubt · Time & Mortality · Present Moment · Self-Reliance.

- Assign 1-3 themes, primary first. Fewer accurate themes beat many vague ones.
- Think about what topics this quote would actually be used for.
- If nothing fits, propose a new theme to the user (closest existing theme, a new theme, or none) before creating it.

Example: "The cure for boredom is curiosity. There is no cure for curiosity." → Curiosity & Intelligence (primary).

## Step 5: Write the context

1-3 sentences covering: **source** (work, section, year), **background** (what was happening, the original meaning), and **relevance** (why it's useful now, what it's good for). Research it if unknown (web search `<author> "<snippet>" source context`).

Example: "Meditations V.16 (George Long translation, 1862). Written as private notes during military campaigns. A compact statement that habitual thinking shapes character."

## Step 6: Add it

```powershell
python $A add --text "<exact quote>" --author "<author>" --themes "<Primary>,<Secondary>" --source "<work, section, translator, year>" --context "<context>" --status verified
```

Batch additions: run one `add` per quote, then report all IDs together.

## Step 7: Confirm

```markdown
✅ **Aphorism added**

**Quote:** "[quote text]"
**Author:** [author] — *[source]*
**Themes:** [theme 1], [theme 2]
**ID:** [A-0NN] · **Status:** [verified/disputed]

**Store:** [N] aphorisms · [N] authors · [N] themes  (from `python $A stats`)
```

---

## Other cases

- **Update an existing quote:** `python $A update <id> --context "<better context>"` (also `--source`, `--themes`, `--status`, `--author`, `--text`). Preserve the attribution unless research proved it wrong, and say what changed.
- **Multiple versions of one quote:** store the version from the best primary source and note the variants in the context.
- **Usage tracking:** when a stored quote gets used, record it: `python $A use <id> --where "<publication + date + title>" --placement <opening|closing|divider>`.

## Quality checks

- [ ] Wording verified against a source (or status `disputed` with a note)
- [ ] Attribution verified; misattributions list checked
- [ ] No duplicates (search done, CLI accepted)
- [ ] 1-3 accurate themes
- [ ] Context gives source, background and relevance
- [ ] Addition confirmed to the user with its ID
