---
name: aphorisms
description: "Curated aphorism collection with full CRUD: matches a quote to a piece of content, searches by theme, keyword or author, researches a thinker's authentic quotes, and adds new ones with verified attribution, sources and duplicate detection. Tracks usage so quotes don't repeat. Ships a public-domain seed collection (Stoics, Confucius, Laozi, Bacon, Emerson, Thoreau, Spinoza and others) and keeps the user's additions in Kai memory. Use when the user says aphorism, quote, find a quote, quote for my newsletter, what quote fits this, quotes about X, what did X say about Y, research a thinker, add this quote, save this aphorism, or quote bank. Not for creative writing or social posts."
argument-hint: "find <content|url> | search <theme|keyword|author> | add \"<quote>\" - <author> | research <thinker>"
---

# Aphorisms

Curated aphorism store with full CRUD. **Deliverable: a ranked, non-repeated, attributed quote matched to the content's themes**, with a one-line reason per option. Adding parses text + author, verifies attribution, assigns themes, records the source, and dedupes. Research pulls a thinker's authentic quotes and files them by theme with sources.

## Workflow routing

| Workflow | Trigger | File |
|----------|---------|------|
| **FindAphorism** | find an aphorism, quote for my newsletter, match a quote, suggest a quote, what quote fits this | `Workflows/FindAphorism.md` |
| **AddAphorism** | add a quote, add an aphorism, save this quote, store this quote | `Workflows/AddAphorism.md` |
| **ResearchThinker** | research a thinker, find quotes from X, what did X say about Y, X's quotes on Z | `Workflows/ResearchThinker.md` |
| **SearchAphorisms** | search aphorisms, quotes on X, quotes about X, quotes matching, what aphorisms do we have | `Workflows/SearchAphorisms.md` |

## The store

The collection is data, so it lives in Kai memory, never in this skill folder (a reinstall replaces the skill folder):

```
~/.copilot/kai/MEMORY/KNOWLEDGE/aphorisms/
  aphorisms.json   system of record (edit only through the CLI)
  aphorisms.md     generated, readable view by theme + usage history
```

Override the location with the `APHORISMS_DATA_DIR` environment variable.

All reads and writes go through the deterministic CLI (Python 3.8+ standard library):

```powershell
$A = "$HOME/.copilot/skills/aphorisms/Tools/aphorisms.py"
python $A init                                   # first run: create the store from the public-domain seed (safe to re-run)
python $A search resilience adversity --limit 8  # keyword search, ranked by relevance + freshness
python $A search --theme "Stoicism" --max-chars 120 --fresh-days 90
python $A list --author Seneca
python $A themes                                 # theme index with counts
python $A show A-004
python $A add --text "<exact wording>" --author "<name>" --themes "Theme A,Theme B" --source "<work, section, year>" --context "<one or two sentences>"
python $A update A-004 --context "<better context>"
python $A use A-004 --where "newsletter 2026-11-06: <title>" --placement opening
python $A stats
```

In bash, use `A="$HOME/.copilot/skills/aphorisms/Tools/aphorisms.py"` and `python3 "$A" ...`.

`add` exits 3 on an exact duplicate (never added) and 4 on a near-duplicate (shown; re-run with `--force` only after the user confirms it's a genuinely different quote). If any command says there is no store, run `init` first.

## Seed collection

`Database/seed.json` holds 27 public-domain aphorisms, each from a work or translation published before 1929, with a section-level source (for example "Meditations V.16, trans. George Long (1862)") so wording can be checked. `init` copies it into the store once; later inits only add seed entries that are missing.

`Database/Misattributions.md` lists famous quotes that circulate under the wrong name. Check it before adding anything famous.

## Taxonomy

**Themes** (extend freely; a theme exists once any quote carries it): Learning & Education · Wisdom & Truth · Stoicism & Control · Mindset & Perspective · Resilience & Strength · Work Ethic & Excellence · Risk & Action · Curiosity & Intelligence · Humility & Doubt · Time & Mortality · Present Moment · Self-Reliance.

**Alignment.** Quotes are matched to the user's values, not a fixed list of favorite thinkers. If the user's rules section of `~/.copilot/copilot-instructions.md` (or Kai memory) states what they care about, use that. Otherwise default to: wisdom, intellectual honesty, truth-seeking, curiosity, resilience, human flourishing.

## Running on Copilot

- Content from a URL: web fetch it. A file: `view` it.
- Verification and thinker research: web search and web fetch. For a deep thinker pass, run parallel `task` calls to `@kai-researcher`, one per source angle (primary works, interviews, quote-verification sites), each returning candidate quotes with a primary-source citation.
- All store changes go through `aphorisms.py`. Never edit `aphorisms.json` or `aphorisms.md` by hand.

## Gotchas

- **Search by theme, not exact text.** The collection is organized by concept; `search` matches word stems across quote, themes, author and context, and `--theme` filters by theme.
- **Always include attribution and source when adding.** Unattributed quotes are useless. Unverifiable ones are stored as `Unknown (often attributed to X)` with `--status disputed`, or skipped.
- **Duplicate detection:** same idea, different wording, still counts as a duplicate. The CLI catches near-identical wording; you catch paraphrases by searching the key words before adding.
- **Copyright:** the seed is public domain. Short quotations the user adds from modern authors are their own collection; keep each to the quote itself plus a citation, never long excerpts.
