---
name: loop
description: "Iterative improvement across several full Kai Algorithm passes on the same target, each pass starting from what the last one learned and what it already rejected, with the user reviewing and redirecting between passes (or, opt-in, running autonomously with a dead-ends ledger and a noise-floor check on the score). Use when the user says /loop, loop on this, iterate on this, refine this over several passes, keep improving it, another pass, revisit, rework this until it is right. NOT FOR one-pass work (just run the Algorithm), an autonomous measure-keep-revert hill-climb (use /optimize), or a recurring scheduled job."
argument-hint: "--target <path> [--goal \"<what better means>\"] [--iterations N] [--autoresearch] | --resume | --status"
disable-model-invocation: true
---
# Loop

**The ideal state:** the target got meaningfully better on every pass, no pass re-explored an approach an earlier pass rejected, the user steered between passes, and the ISA shows the iteration count, what each pass changed and why the loop stopped.

Unlike `/optimize` (an autonomous mutation loop that keeps or reverts single changes), each `/loop` iteration is a complete Algorithm run: articulate done, climb, verify, learn. The learn step of one pass feeds the next pass's articulation.

## Invocation

```
/loop --target "<path>" --iterations 5
/loop --target "$HOME/.copilot/skills/research/Workflows/QuickResearch.md" --goal "more consistent structure"
/loop --target prompts/summarize.md --goal "more concise, less filler" --iterations 20 --autoresearch
/loop --resume        /loop --status
```

| Argument | Default | Meaning |
|---|---|---|
| `--target PATH` | required | File, folder or skill to improve |
| `--goal TEXT` | inferred, then confirmed | What "better" means. Captured verbatim as the ISA's stated goal |
| `--iterations N` | 3 | Maximum passes |
| `--autoresearch` | off | No review between passes; see below |
| `--resume` / `--status` | | Continue the most recent loop ISA, or show its iteration history |

## Procedure

1. **Scaffold one ISA for the whole loop:** `python "$HOME/.copilot/kai/bin/kai.py" isa new loop-<name> "<goal>"`. Put the verbatim goal in `## Goal` and an exit condition as a claim ("<measurable condition> holds" or "N passes done"). Without an exit condition the loop has no end; ask for one if the goal doesn't give it.
2. **Each pass:**
   - Read the ISA: current claims, `## Decisions` (including every `dead-end:` row) and `## Learning`.
   - Run the Algorithm on the target. Claims may be added, sharpened or retired between passes, and each change is a `refined:` row in `## Decisions`.
   - Close the pass: append a `## Decisions` row `pass <n>: <what changed> -> <result>` and, for every rejected approach, a row `dead-end: <approach> - <why>`. Write `## Learning` only when understanding changed.
   - Bump `iteration:` in the frontmatter (omitted on pass 1, `2` on the second pass, and so on).
3. **Between passes (default):** show a short diff summary and the open claims, then stop and ask: continue, redirect (new emphasis), or stop. The review is the feedback mechanism. Don't skip it.
4. **Stop** when the exit claim holds, `--iterations` is reached, or the user says stop. Set `phase: complete` and summarize the passes in one table: pass, change, result.

## Autoresearch mode (opt-in)

`--autoresearch` runs the passes without review, for overnight work where waiting for a human each pass is too slow:

1. **No human review between passes.** Each pass's learning flows straight into the next. Runs until `--iterations`, the exit claim holds, or an interrupt.
2. **Dead-ends ledger.** Every failed pass appends `dead-end:` rows to `## Decisions`. A resumed loop reads them first and never retries one.
3. **Noise-floor check on the score.** If the target has a score (a metric command or an eval pass rate per `../optimize/EvalGuide.md`), record each pass in an optimize ledger and obey its decision:
   ```
   python "$HOME/.copilot/skills/optimize/tools/optimize.py" init loop-<name> --direction higher --preset cautious --max <iterations>
   python "$HOME/.copilot/skills/optimize/tools/optimize.py" record loop-<name> --score <v> --hypothesis "<pass summary>"
   ```
   A `marginal` pass (|delta| / MAD under 1.0x) is noise: log it as `marginal` in the ISA and don't treat it as the new baseline.
4. **Fresh context per pass (optional).** For long runs, each pass can be a separate worker so context doesn't pile up: write a `/workflow` spec with one step per pass that reads the ISA first, and run it with `python "$HOME/.copilot/kai/bin/kai_workflow.py" run <spec>`.

## Gotchas

- **Every pass is a full Algorithm run.** That costs time and tokens. Three good passes beat ten shallow ones.
- **Set the exit condition up front.** A loop without one runs until the iteration cap, whether or not it is still improving.
- **Don't re-litigate dead ends.** If a new pass wants to retry a rejected approach, it needs new evidence, written as a `refined:` row explaining what changed.
- **One ISA, many passes.** Don't scaffold a new ISA per pass; iteration on the target IS iteration on its ISA.
