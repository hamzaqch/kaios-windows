---
name: research
description: "Multi-source web research with mandatory URL verification, confidence-tagged findings ([HIGH]/[MED]/[LOW]/[CONFLICT]) and four depth tiers, from a quick single-pass lookup to an iterative deep investigation that builds a persistent research vault. Also extracts the highest-signal ideas from content, retrieves hard-to-fetch pages, maps markets and threat landscapes, and preps interview questions. Use when the user says research, do research, quick research, extensive research, deep research, deep investigation, investigate X, map the X landscape, competitive analysis, market research, threat landscape, find information, find this, identify this, what is this thing, track down, help me find, I can't find X online, source this, fact-check, verify these findings, extract alpha, extract knowledge, analyze this article or video, AI trends, interview prep, or can't fetch this page. Not for academic paper lookup or deep background checks on private individuals."
---
# Kai research

Research a question across several independent passes, cross-check them, verify every URL, and deliver confidence-tagged findings. Two failure modes wreck a single-pass answer: hallucinated URLs (one broken link destroys trust in the whole report) and one-angle answers that parrot the first results and miss conflicts, gaps and what real people actually said. Every tier below is built to beat both.

## Non-negotiables

1. **Source routing first (Step 0 of every tier).** Read `SourceRoutingProtocol.md`. Web search answers "what was published about X"; community sources answer "what people said about X". Sentiment questions go to community sources before web search.
2. **Verify every URL before delivery.** Read `UrlVerificationProtocol.md`. Unverified URL = drop it.
3. **Tag every finding** `[HIGH]` `[MED]` `[LOW]` `[CONFLICT]`. Missing confidence = `[LOW]`. Never resolve a conflict by silently picking a side.
4. **Sufficiency check.** If the question and target sources are clear, proceed. If you would be speculating, state the ambiguity in one line and ship best effort. If clearly insufficient, ask at most 3 questions and offer "proceed anyway".
5. **Don't re-research what's already in context.** If the session already covers it, answer from that.

## Depth tiers

"Research" with no qualifier = **Standard**. Never default down to Quick.

| Tier | Trigger | Passes | Verification | File |
|---|---|---|---|---|
| Quick | "quick research", "minor research", simple factual lookup | 1 pass, 1 query | self-verify only | `Workflows/QuickResearch.md` |
| Standard | "research", "research this" (default) | 3 parallel passes, distinct angles (+1 technical) | self-verify + cross-check synthesis | `Workflows/StandardResearch.md` |
| Extensive | "extensive research", "deep research", "thorough" | 7 explorers + 2 independent verifiers, all parallel | + verifier cross-reference | `Workflows/ExtensiveResearch.md` |
| Deep investigation | "deep investigation", "investigate X", "map the X landscape" | landscape -> entity catalog -> scored deep dives, iterative | + per-entity spot-check of numbers | `Workflows/DeepInvestigation.md` |

How to run passes: dispatch parallel `task` calls, or dispatch to custom agents. Research passes go to `@kai-researcher`; independent verifiers and contrarian/red-team passes go to `@kai-reviewer`; landscape synthesis and investigation planning can go to `@kai-architect`. Brief each pass with exactly one angle, the confidence-tag requirement, and "verify your own URLs before returning". Then cross-check and synthesize yourself.

## Other workflows

| Workflow | Trigger | File |
|---|---|---|
| Verify | "verify these findings", "fact-check", confidence scoring of existing claims | `Workflows/Verify.md` |
| ExtractAlpha | "extract alpha", highest-signal / most surprising ideas from content | `Workflows/ExtractAlpha.md` |
| ExtractKnowledge | "extract knowledge", structured insights + recommendations from a URL, video, PDF or text | `Workflows/ExtractKnowledge.md` |
| Retrieve | page blocked, CAPTCHA, rate-limited, "can't get this", web scraping, YouTube transcripts | `Workflows/Retrieve.md` |
| InterviewResearch | interview prep, questions for a founder/company | `Workflows/InterviewResearch.md` |
| AnalyzeAiTrends | trend analysis across accumulated research (AI by default) | `Workflows/AnalyzeAiTrends.md` |

**Enhance (inline):** to add links to a draft, identify key terms, tools, products and concepts; find the official or authoritative page for each; link in body text only, never headings; keep existing links; verify every link per `UrlVerificationProtocol.md`; never guess internal site URLs, confirm the target exists first.

**Domain templates** for deep investigations: `Templates/MarketResearch.md` (companies, products, people, technologies, trends, investors) and `Templates/ThreatLandscape.md` (threat actors, campaigns, TTPs, vulnerabilities, tools, defenders). No match: derive categories from the landscape pass.

## Query decomposition

A single query answers from one angle. For Standard and above, split the question into 4-8 targeted sub-queries and spread them across passes:

- the question as asked
- background / what-is context
- latest news and recent developments (include the current year)
- technical details, how it actually works
- comparisons and alternatives
- expert analysis and opinion
- implications, impact, second-order effects
- contrarian: what people get wrong, counter-consensus evidence

## Confidence tags

| Tag | Meaning |
|---|---|
| `[HIGH]` | Independently confirmed: two passes agree, or a verifier/tool call confirmed it against a primary source |
| `[MED]` | Single source, plausible, not independently confirmed |
| `[LOW]` | Unconfirmed, weakly sourced, or contradicted |
| `[CONFLICT]` | Passes disagree; show both sides with sources |

A failed URL downgrades the finding it supported (a `[HIGH]` resting on it drops to `[MED]`).

## Output shape

```markdown
## Answer
[2-4 sentences: the direct answer]

## Findings
### [Theme]
- [HIGH] finding (confirmed by: pass A + verifier) [source]
- [MED] finding (single source) [source]

## Conflicts and low-confidence items
CONFLICT on [topic]:
  Pass A: [claim] - [source]
  Pass B: [claim] - [source]
  Status: unresolved | resolved by [source priority / follow-up query]

## Sources
[verified URLs only]

## Next
[e.g. "Run extensive research to resolve the 2 conflicts"]
```

Quick tier can collapse this to an answer plus sources. Skip empty sections.

## Gotchas

- **X/Twitter URLs:** X blocks automated reads. Try one web fetch; if it fails, say so plainly and ask the user to paste the post text, then research the substance normally. One unreadable URL never cancels the task.
- **Recap journalism is not sentiment.** Press recaps invent consensus and timestamps and parrot promoter copy. For "what did people think", community sources are primary; recaps only scaffold dates and facts.
- **The inverse signal is signal.** When pulling sentiment, always include what people disliked.
- **"Extract alpha" is not a summary.** It is the ExtractAlpha workflow: novelty over coverage.
- **Background checks on private individuals** are out of scope; decline or route elsewhere.

## Saving artifacts

Research worth keeping goes in `~/.copilot/kai/MEMORY/RESEARCH/YYYY-MM/YYYY-MM-DD_<topic-slug>/` (Windows: `%USERPROFILE%\.copilot\kai\MEMORY\RESEARCH\...`). Deep investigations always save there, since the vault is their state. Other tiers save when the user asks or the result is clearly reusable: the final report plus a short source list (URLs, date retrieved).
