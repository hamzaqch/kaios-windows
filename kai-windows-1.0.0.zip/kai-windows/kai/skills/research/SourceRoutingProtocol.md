# Source routing protocol

Read before dispatching any pass. The right source has the answer; the pass only fetches it. A mismatched source is the most common cause of bad research.

## Core rule

**Web search answers "what was published about X." Community sources answer "what people said about X."** Press articles invent consensus, fabricate timestamps and miss the loudest reactions. For sentiment, ratings, reactions or opinions, go to the platforms where those people actually posted.

## Step 0: classify the question

Run both checks on every request.

**Sentiment signal** fires on any of:
- "what did fans / people / the community / users / players / viewers think (of|about)"
- "ratings of", "rated", "fan ratings", "user ratings"
- "best / worst / favorite / most disappointing / standout (episodes|moments|features|sets|games)"
- "reactions to", "what people are saying about"
- "is X any good", "is X worth it" (a purchase or consumption decision driven by social proof)
- "consensus on", "popular opinion of"
- event name + "last night" / "last weekend" / "yesterday" / a recent date

**Technical signal** fires when the question is about code, APIs, frameworks, libraries, runtimes, protocols, tooling, versions, migration paths, or how a system works under the hood.

- Sentiment fires -> sentiment-mode routing (below).
- Technical fires -> add a technical pass briefed to prefer primary sources only: official docs, source code, changelogs, release notes, RFCs. Wrong API contracts, invented flags and stale version numbers are exactly what secondary sources get confidently wrong.
- Neither -> standard routing (the tier's normal web-search passes).

## Cascade priority (never invert)

Inside each platform, walk the tiers in order and drop down only when the upper one is unavailable or fails:

1. **Free public API / structured endpoint.** Highest signal, stable schema, no key needed at research volume.
2. **Web fetch of the platform pages themselves.**
3. **Web search** (`site:` queries). Discovery and context only (dates, lineups, version numbers), never the answer to "what did people think".

If a platform needs a paid key or login you don't have, skip it, say so in the output, and offer: "paste the thread/post and I'll include it".

## Sentiment-mode platform priority

Spend passes across platforms in this order:

1. **Reddit (always first).** Where most English-language communities post raw reactions.
2. **Bluesky.** Free public search API, no auth for reads.
3. **YouTube.** Reactor videos and their comments, especially for events and launches. Use web fetch for discovery; transcripts per `Workflows/Retrieve.md`.
4. **X/Twitter.** Fastest reaction window (first ~6 hours after an event), but it blocks automated reads. Use web search for discovery; ask the user to paste key posts if they matter.
5. **Platform-native communities:** Steam reviews, Discord (only if the user shares content), subject forums.
6. **Web search, last, for context only.**

Inside each platform, finish the cascade before moving to the next.

## Reddit: JSON endpoints (Tier 1)

Free, unauthenticated, public. Append `.json` to any Reddit URL.

- Subreddit top this week: `https://www.reddit.com/r/{sub}/top.json?t=week&limit=50`
- Subreddit top this month: `https://www.reddit.com/r/{sub}/top.json?t=month&limit=50`
- Subreddit search: `https://www.reddit.com/r/{sub}/search.json?q={query}&restrict_sr=1&sort=top&t=month`
- Site-wide search: `https://www.reddit.com/search.json?q={query}&sort=top&t=month`
- Thread + comments: `https://www.reddit.com/r/{sub}/comments/{id}.json`

Send a descriptive User-Agent (e.g. `curl -A "Kai-Research/1.0" -s <url>`); Reddit rate-limits the default one.

- **Subreddit discovery:** unknown sub -> site-wide search first, read the `subreddit` field on results. Check 2-3 subs; communities span several (the main sub, the general-genre sub, the contrarian/circlejerk sub).
- **What to pull:** megathreads first (broad sample), top posts by score (the upvote is the rating), top comments sorted by score, dedicated single-subject threads.
- **Quote verbatim** with the thread URL and score. Paraphrasing fan quotes launders the signal. A score without the text it endorses means nothing.

## Bluesky (Tier 1)

`https://api.bsky.app/xrpc/app.bsky.feed.searchPosts?q={query}&limit=50` returns public posts with like/repost counts. No auth for reads.

## Output when sentiment-routed

Organize by **tier of agreement**, not by source:

```markdown
## Tier S - multiple people called this their #1
| # | Subject | Evidence |
|---|---------|----------|
| 1 | [name] | "[verbatim quote]" - [thread URL, score] / "[quote]" - [URL, score] |

## Tier A - repeated standouts
...

## Tier C - disappointments (the inverse signal, equally valuable)
...

## Sources
- Reddit threads pulled (count): URLs + scores
- Other platforms (count): URLs
- Platforms skipped and why (e.g. "X: automated reads blocked")
```

## Anti-patterns

- **Cascade inversion:** running generic web search on a sentiment question before pulling Reddit. One JSON fetch would have answered it.
- **Recap-only answers:** if a recap-article claim has zero corroboration in the community corpus, drop it.
- **One subreddit only** when the topic spans several.
- **Filtering out negative reactions to "balance" the review.** Report the actual signal; Tier C is often the truest part.

## Quick reference

| Question shape | First call |
|---|---|
| "what did people think of X" | Reddit JSON: `r/{topic}/top.json?t=week` |
| "best moments of {event}" | Reddit site-wide search: `search.json?q={event}&sort=top` |
| "is {product} any good" | Reddit JSON: `r/{product}/top.json?t=month` + site-wide search |
| "reactions to {event}" | Reddit JSON + web-fetch discovery of top reactor videos |
| "what's the consensus on X" | Reddit JSON + Bluesky search |
| "what are people saying right now" | Bluesky search + Reddit `new`/`top?t=day` |
| technical "how does X work / which version" | primary sources: official docs, changelog, source |
