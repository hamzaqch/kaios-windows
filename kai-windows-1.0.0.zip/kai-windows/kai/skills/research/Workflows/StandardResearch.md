# Standard research (default)

**Shape:** three parallel passes, each with one distinct angle and one query, then a cross-check synthesis. Fourth pass when the question is technical.

Use for "research", "research this", "do research", and anything that needs multiple perspectives quickly.

## Step 0: source routing

Classify per `../SourceRoutingProtocol.md`.

- **Sentiment fires:** add a community pass. Brief: Reddit JSON against 2-3 relevant subreddits, plus Bluesky search; return verbatim quotes with URLs and scores. If time allows, add a pass that finds top reactor videos and their comment themes. The web-search passes then do context only (dates, facts, lineup), not sentiment.
- **Technical fires:** add the primary-sources pass (official docs, source, changelogs, RFCs only).
- **Neither:** Step 1 as written.

## Step 1: one query per angle

Decompose the question (see SKILL.md, query decomposition) and write one focused query per pass:

| Pass | Angle |
|---|---|
| A | Depth: detailed analysis, authoritative and scholarly sources, how and why |
| B | Breadth: multiple perspectives, cross-domain connections, comparisons and alternatives |
| C | Current state: latest news and developments, dated and cited |
| D (technical only) | Primary sources: docs, changelogs, source, specs |

## Step 2: dispatch in parallel

Send all passes at once as parallel `task` calls to `@kai-researcher`. Brief each:

> Do ONE search for: [angle-specific query]. Tag each finding [HIGH], [MED] or [LOW]. Verify your own URLs before returning. Return findings immediately.

Each pass gets one query, does one search, returns.

## Step 3: cross-check synthesis

1. **Agreement:** same fact reported by two or more passes -> `[HIGH]`.
2. **Single-source:** reported by only one pass -> `[MED]`.
3. **Contradiction:** passes disagree -> `[CONFLICT]`, show both sides with sources. Don't pick one silently.
4. **Numbers:** for every figure one pass cites, did another pass's sources confirm it? If not, it can't be `[HIGH]`.

## Step 4: URL verification

Batch-check any URL not already verified, per `../UrlVerificationProtocol.md`. A failed URL is removed; a `[HIGH]` that rested on it drops to `[MED]`.

## Step 5: return

Use the output shape in SKILL.md. Under **Next**, recommend extensive research if `[CONFLICT]` items need resolution.

## Degradation

Only one pass returned -> skip cross-check, rely on self-verification, and say so.
