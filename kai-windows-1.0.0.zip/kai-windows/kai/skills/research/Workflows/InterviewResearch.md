# Interview research

Prepare for an interview with a company, founder or executive: research them, then write questions in the style of Tyler Cowen, driven by Shannon's idea of surprise. Questions and answers should maximize information content and never be boring.

## Research

Run **Standard research** (or Extensive for a high-stakes interview) on {company / person}, with passes covering:

1. **Recent activity (last ~6 months):** launches, funding and milestones, press, conference talks.
2. **Technical innovation:** core technology and approach, patents or papers, technical blog posts, open-source work.
3. **Thought leadership:** founder/executive public posts, company blog, podcast appearances, industry commentary.
4. **Competitive landscape:** direct competitors and alternatives, positioning, real differentiators, trends they're reacting to.
5. **Future direction:** roadmap hints, job postings (what they're hiring for reveals what's next), partnerships, expansion signals.

Explicitly look for anything contrarian or surprising about their approach. Verify URLs as usual.

## Output

### Company summary (2-3 paragraphs)
What they build and why it matters; recent momentum; what they seem most excited about; key differentiators.

### 10 interview questions

For each:
- **Q[n]:** the question
- **Why:** the surprising insight it could reveal
- **Follow-up angle:** one follow-up based on the likely answer

Required themes, reframed in novel ways: problem definition and origin story; competitive differentiation and strategy; future vision and how the industry evolves. Draw the rest from: counterintuitive things they've learned; failed experiments and pivots; hiring philosophy; customer surprises and unexpected uses; technical trade-offs; market timing and "why now"; contrarian beliefs about their industry.

## Cowen techniques

- **Oblique approach:** ask about adjacent topics to reveal the core
- **Production function:** "What inputs create your outputs?"
- **Marginal thinking:** "What's the next bottleneck?"
- **Status quo challenge:** "What does everyone else get wrong?"
- **Personal history:** "What experience shaped this decision?"
- **Taste:** "What do you find beautiful about your solution?"
- **Edge cases:** "When does your approach fail?"
- **Second-order effects:** "What happens when you succeed?"

## Shannon surprise

Avoid questions with predictable answers. Seek answers that contradict conventional wisdom, find the least likely but most important aspects, expose hidden complexity in apparently simple systems, and surface assumptions nobody is questioning.

## Transformations

| Boring | Interesting |
|---|---|
| "What problem are you solving?" | "What problem did you initially *think* you were solving, and when did you realize it was something else entirely?" |
| "How are you different from competitors?" | "If your top competitor called you for advice on what to build next, what would you tell them, and what would you deliberately leave out?" |
| "What's your vision for the future?" | "If it's five years from now and the company failed, what's the most likely reason, and what would make that failure look obvious in hindsight?" |
