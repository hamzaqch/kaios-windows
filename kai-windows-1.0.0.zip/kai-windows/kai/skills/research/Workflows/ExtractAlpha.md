# Extract alpha

Pull the highest-alpha ideas from content: podcasts, videos, interviews, essays, articles. Based on Shannon's information theory: **real information is what's different, not what's the same.** Standard extraction collapses to the obvious main points and misses subtle implications, unstated frameworks, counterintuitive asides and surprising reframings. This workflow is built to catch those.

## Step 1: get the content

- Article/URL: web fetch (hard pages: `Retrieve.md`).
- YouTube/podcast: transcript per `Retrieve.md`.
- File or pasted text: read directly.

## Step 2: think before extracting

Work through all ten dimensions before writing a single bullet:

1. **Surface scan:** what are the obvious main points? (Know them so you can go past them.)
2. **Depth probe:** what implications aren't stated?
3. **Connection map:** what unusual links exist between ideas? What makes you think "wait, how does that work?" What seemingly different things (human/AI, biology/ML, physics/economics) share one underlying principle? What makes a familiar thing look different?
4. **Assumption challenge:** what conventional wisdom is being questioned?
5. **Novelty detection:** what's genuinely new here?
6. **Framework extraction:** what mental models emerge, even if never named?
7. **Subtle insights:** what quiet observations carry outsized weight?
8. **Contrarian angles:** what runs against common thinking?
9. **Future implications:** what does this suggest is coming?
10. **Synthesis:** across all of the above, what are the highest-alpha ideas?

Let the thinking wander. Question what counts as "important". Prioritize surprise over coverage.

## Step 3: extract

Write **24-30 insights** (fewer if the content doesn't support it; 15 brilliant beats 30 padded).

- 8-12 words each, flexible for clarity; plain, approachable essayist style
- Specific details only when they sharpen the surprise
- Favor ideas that make the reader stop and reconsider, reveal cross-domain patterns, reframe something familiar, or that someone would want to repeat to a friend

**High-alpha signals:** forces reconsidering something you thought you knew; connects domains unexpectedly; challenges consensus; reframes a familiar concept; carries unstated second-order implications; counterintuitive but holds up on reflection; a novel mental model; a quiet observation with real weight.

**Low-alpha (cut):** common knowledge; restated main points or direct quotes without insight; generic advice that fits anything; surface observations; things heard many times; bare facts with no insight.

Calibration: a summary of a talk on AI would say "the speaker discussed training methods". Alpha sounds like "We're building ghosts, not animals", "Pre-training is a crappy version of evolution", "Context window is working memory; weights are hazy recollection".

## Output

```markdown
# EXTRACT ALPHA

- First insight

- Second insight

[... blank line between items, 24-30 total ...]
```

Optionally spot-check any insight that rests on a number via `Verify.md` level 2.

## Failure modes

- **Mode collapse:** only the high-probability obvious ideas.
- **Surface skimming:** breadth without depth.
- **Quote collecting:** restating instead of extracting the insight.
- **Comprehensiveness trap:** covering everything instead of the highest alpha.
- **Rigid formatting:** forcing 8 words when 11 is clearer.

## Saving (optional)

If the user wants it kept: `~/.copilot/kai/MEMORY/RESEARCH/YYYY-MM/YYYY-MM-DD_<slug>/` with `extract_alpha.md` (the list), `analysis.md` (the ten-dimension notes), and source metadata (URL/title, content type, date analyzed).
