# Extensive research

**Shape:** explorer-verifier pattern. Seven explorers for breadth plus two independent verifiers for trust, all launched at once. Verifiers never see the explorers' reasoning, so they carry no confirmation bias from exploration.

Use for "extensive research", "deep research", "thorough research", comprehensive multi-domain coverage.

## Step 0a: source routing

Classify per `../SourceRoutingProtocol.md`.

- **Sentiment fires:** reallocate at least 2 explorer slots to community passes:
  - **Slot A (Reddit, mandatory):** enumerate 2-4 likely subreddits, pull `top.json?t=week`, find megathreads and single-subject threads, extract verbatim quotes with thread URLs and scores.
  - **Slot B (Bluesky + other open communities):** public search API, forums, review sections.
  - **Slot C (optional, YouTube):** top reactor videos, comment themes, transcripts per `Retrieve.md`.
  - Remaining explorers do context scaffolding (dates, facts, schedule), not sentiment. Keep both verifiers; they still catch hallucinated URLs across community passes.
- **Technical fires:** make one explorer the primary-sources pass (docs, changelogs, source, specs).

## Step 0b: generate angles

Think hard about the topic before writing angles: unusual perspectives and adjacent domains, assumptions about what's relevant, unexpected connections, edge cases, controversies, emerging trends.

Produce **7 explorer angles**, including **2 contrarian / counter-consensus angles** that prefer durable facts over trending narrative, plus **2 verifier angles**:
- V1: independently verify the most commonly cited facts, statistics and claims about [topic] against primary sources. Focus on numbers and dates; they're most often wrong.
- V2: find contradictory evidence, debunked claims and common misconceptions about [topic]. What do people get wrong?

Verifier briefs are topic-level, not claim-level, so they can run in parallel with the explorers instead of waiting for them.

## Step 1: launch all 9 at once

- 7 parallel `task` calls to `@kai-researcher`, one angle each: "Search for: [angle]. Tag each finding [HIGH]/[MED]/[LOW]. Verify your own URLs. Return findings."
- 2 parallel `task` calls to `@kai-reviewer` with the verifier briefs. V1 tags: `[HIGH]` confirmed, `[MED]` plausible, `[LOW]` unconfirmed.

## Step 2: collect

Most passes return quickly. Set a hard time budget; when it expires, proceed with what has returned and note which passes didn't.

## Step 3: verified synthesis

1. **Match claims:** for each explorer finding, did a verifier confirm, contradict, or not cover it?
2. **Adjust confidence:** explorer `[MED]` + verifier confirmed -> `[HIGH]`. Explorer `[HIGH]` + verifier contradicted -> `[CONFLICT]`.
3. **Conflicts:** explorers disagreeing with each other or with verifiers -> show both sides with sources.
4. **Batch URL check** for anything unverified, per `../UrlVerificationProtocol.md`.

```markdown
## Executive summary
[2-3 sentences]

## Verified findings
### [Theme]
- [HIGH] finding (confirmed by: explorer + verifier)
- [MED] finding (single source, not independently verified)
- [CONFLICT] A vs B (see conflicts)

## Unique insights by angle
- Contrarian passes: [...]
- Cross-domain passes: [...]
- Verifiers: [what was confirmed / refuted]

## Conflicts and low-confidence items
CONFLICT on [topic]:
  Explorer: [claim] - [source]
  Verifier: [contradicting claim] - [source]
  Status: unresolved
LOW CONFIDENCE:
- [claim] - could not independently verify

## Sources
[verified URLs]

## Metrics
Passes: 9 (7 explorers + 2 verifiers), N returned | Findings: N HIGH / N MED / N LOW / N CONFLICT | URLs verified: N/N
```

Under **Next**, give follow-ups, especially for `[CONFLICT]` items. For claims that must be bulletproof, run the claim-level check in `Verify.md`.

## Degradation

- Verifiers time out -> findings keep explorer-assigned confidence (no upgrade, no downgrade).
- Only one explorer returns -> skip cross-check, self-verification only, say so.
- Parallel URL sweep fails -> sequential.
