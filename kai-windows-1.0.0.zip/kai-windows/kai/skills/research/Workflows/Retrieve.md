# Retrieve

Content retrieval when a page is hard to get, plus scraping and transcript extraction. **Use only when there's difficulty** ("can't get this", "site is blocking me", CAPTCHA, rate-limited, "fetch failed") or an explicit scraping/transcript job. A plain "read this page" is just a web fetch. A research question goes to a research tier, not here.

## Escalation ladder

Always start at the simplest layer and escalate only on failure.

### Layer 1: markdown negotiation, then web fetch

1. **Markdown probe.** Many sites behind modern CDNs serve server-side markdown when asked. Non-supporting sites ignore the header, so it costs nothing:
   - bash: `curl -sL -H "Accept: text/markdown" "<url>" | head -5`
   - PowerShell: `curl.exe -sL -H "Accept: text/markdown" "<url>"`
   If the body starts with `---` or `# ` rather than `<!DOCTYPE`/`<html`, use it directly (far fewer tokens, cleaner conversion). Check the body, not just the Content-Type header, which may still say `text/html`.
2. **Web fetch** with a specific extraction goal ("extract the article body, title, author, date").
3. **Web search** when you have keywords but no URL; restrict to the right domain where possible.

Escalate on: 403, 429, 503, empty or broken content, CAPTCHA, bot-detection page.

### Layer 2: alternate routes to the same content

- Retry with a normal browser User-Agent via `curl`, once, politely (respect 429 back-off).
- The site's own structured routes: RSS/Atom feed, public JSON endpoint (e.g. Reddit `.json`), print view, AMP page, official API docs pages.
- An archived copy: `https://web.archive.org/web/<url>`. Say in the output that it's an archive snapshot and give its date.
- Syndicated or mirrored copies of the same piece (author's own site, press-release wire, conference page). Confirm it's the same text.

### Layer 3: hand off

Report which layers you tried and why each failed, then ask the user to paste the content, save the page to a file you can read, or share an export. Stop there; don't defeat logins, paywalls or bot protection.

## YouTube and podcast transcripts

- Web fetch the video page for title, channel, date and description.
- Look for a published transcript: the creator's show-notes page, podcast transcript page, or an accompanying article.
- If the user has a local transcript tool installed, use it.
- Otherwise ask the user to paste the transcript (YouTube: "...more" -> "Show transcript" -> copy). Don't guess content from the title.

## Scraping jobs

| Task | Method |
|---|---|
| All links on a page | fetch HTML, parse `<a>` elements, collect `href`, resolve relative URLs |
| Product or listing data | fetch, identify the repeating container, extract fields (title, price, image, URL) |
| Multi-page crawl | start at the index/listing page, collect detail-page links, fetch each, extract the same fields |

Rules: check `robots.txt` first; add delays between requests (about 1s) and honor rate limits; cache what you've fetched; handle errors without hammering retries; don't collect personal data without permission; never bypass security controls.

## Retrieval record

When the retrieval is part of research worth keeping, record:

```markdown
# Retrieval: <site / topic>
Date: YYYY-MM-DD
Target: <URLs>
Layers tried: L1 markdown probe (ok/failed), L1 web fetch (ok/failed), L2 <route> (ok/failed), L3 handoff (y/n)
Obstacles: bot detection y/n | CAPTCHA y/n | JS rendering y/n | rate limiting y/n
Output: <where the extracted content is>
Notes: <limitations, archive dates, follow-up needed>
```
