# Extract knowledge

Turn any source (URL, YouTube video, PDF, slides, paper, or pasted text) into structured insights, signal points and actionable recommendations, adapted to the content's domain. Optional focus: `security`, `business`, `research`, `wisdom`, `general` (auto-detected if not given).

## Step 1: fetch

| Source | Method |
|---|---|
| Web URL | web fetch; if blocked, `Retrieve.md` |
| YouTube | transcript per `Retrieve.md` |
| PDF / local file | read it directly |
| arXiv / DOI | fetch as web content, treat as research domain |
| Pasted text | use as-is |

## Step 2: detect domain

Unless a focus was given:
- **Security:** vulnerability, exploit, attack, defense, breach, malware
- **Business:** revenue, market, pricing, growth, strategy, customers
- **Research:** study, experiment, methodology, findings, dataset
- **Wisdom:** principles, philosophy, life lessons, experience
- **General:** everything else

## Step 3: extract per domain

Read and extract directly:

- **Security:** the primary problem and the primary solution; attack vectors, vulnerabilities, defensive measures, tools and frameworks named; technical recommendations.
- **Business:** primary problem and solution; revenue opportunities, market insights, strategies, growth tactics; action items.
- **Research:** key findings, methodology, contributions, limitations, future work; rate quality and reproducibility.
- **Wisdom:** principles, philosophical insights, practical wisdom; the most quotable lines verbatim.
- **General:** expanded summary, key concepts, important facts, what's worth learning.

## Output

```
KNOWLEDGE EXTRACTION
Source:     <source>
Type:       <article | video | pdf | paper | text>
Domain:     <detected>
Quality:    <1-10>/10
Confidence: <1-10>/10

SUMMARY
<2-3 sentences>

KEY INSIGHTS
- ...

SIGNAL POINTS
- ...

RECOMMENDATIONS
- ...

RELATED CONCEPTS
<comma-separated key terms>

[domain extras]
EXTRACTED WISDOM   (wisdom): verbatim quotes and principles
TECHNICAL DETAILS  (security/research): specifics, versions, methods
```

## Quality rating

| Score | Meaning |
|---|---|
| 9-10 | Comprehensive, actionable, high-value |
| 7-8 | Good insights, clear recommendations |
| 5-6 | Moderate value, some useful information |
| 3-4 | Limited, basic information |
| 1-2 | Poor or insufficient content |

Confidence reflects how complete the fetched content was (full transcript vs partial page) and how well claims are supported.
