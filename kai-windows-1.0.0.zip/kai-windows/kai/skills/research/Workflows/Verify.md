# Verify

Reusable verification layer. Embedded in the research tiers, or run standalone on "verify these findings", "fact-check this", "how confident should I be in this".

## Core principle

The verifier works independently of the explorer: it gets only the final claims, never the reasoning that produced them. Decompose findings into atomic sub-claims and validate each one. This catches what self-verification misses, because the verifier has no confirmation bias from exploration.

## What to verify first

Spend effort where claims are most likely wrong:

1. **Quantitative:** numbers, percentages, dates (the most common hallucination target)
2. **Causal:** "X causes Y", often asserted without evidence
3. **Recency:** "as of this year", where training data may be stale
4. **Specificity:** exact product names, version numbers, API parameters (easily fabricated)

Skip general statements and widely known facts.

## Confidence scoring

| Tag | Criteria |
|---|---|
| `[HIGH]` | Sub-claim confirmed by a tool call (web search, web fetch, or a document) against a primary source |
| `[MED]` | Some sub-claims confirmed; others unverifiable but plausible |
| `[LOW]` | No independent confirmation, or contradicted |
| `[CONFLICT]` | Two or more sources/passes make contradictory claims |

Missing confidence metadata = `[LOW]`.

## Conflict detection

1. Collect claims per topic across all passes.
2. Flag pairs asserting opposite conclusions on the same topic.
3. Present both sides with sources; don't resolve by preference.
4. Optionally run one targeted follow-up query per conflict.

```
CONFLICT on [topic]:
  Source A: [claim] - [url]
  Source B: [claim] - [url]
  Resolution: unresolved | resolved by follow-up | resolved by source priority
```

Source priority when resolving: primary (official docs, filings, the original study, vendor advisory) beats secondary reporting, which beats aggregators and recaps.

## Verification depth

| Level | Method | Cost |
|---|---|---|
| 1. URL/source | Parallel status sweep + content match, per `../UrlVerificationProtocol.md` | seconds |
| 2. Claim spot-check | Pick the highest-impact quantitative/causal sub-claims, confirm each with an independent search | per claim |
| 3. Independent verifier | `task` call to `@kai-reviewer` with the claims only (no reasoning); it researches each sub-claim from scratch | runs in parallel |
| 4. Claim-level adversarial (max rigor) | Extract atomic claims; each is attacked by 3 `@kai-reviewer` skeptics with different lenses: **quote support** (does the cited source actually say this?), **contradiction** (is there credible evidence against it?), **source strength** (is the source primary, reputable, current?). A claim survives only on a quorum of valid non-refuting votes; if all skeptics abstain, it does **not** survive. Report refuted claims transparently. | slowest; one extra serial hop |

| Tier | Levels used |
|---|---|
| Quick | 1 (self-verify) |
| Standard | 1 + synthesis cross-check |
| Extensive | 1 + 3 (two verifiers) |
| Deep investigation | 1 + 2 + 3 |
| "Bulletproof" / fact-checked request | add 4 |

Level 4 multiplies passes; confirm with the user before running it on a large claim set.

## Degradation

- Verifier times out -> its claims stay `[MED]` (neither verified nor refuted).
- Parallel URL check fails -> sequential.
- No conflicts -> omit the conflict section; no empty sections.
- Only one pass returned -> skip cross-check, self-verification only.
