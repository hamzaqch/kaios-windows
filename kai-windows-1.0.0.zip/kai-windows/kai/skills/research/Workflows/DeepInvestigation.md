# Deep investigation

**Shape:** a progressive narrowing funnel that builds a persistent research vault. Broad landscape -> discover entities -> score value and effort -> deep-dive one entity at a time -> repeat until coverage gates pass.

Use for "deep investigation", "investigate X", "map the X landscape", competitive analysis, market mapping, threat landscapes, technology surveys.

```
Iteration 1:  landscape -> entity catalog -> score -> deep-dive the top entity
Iteration 2+: read the vault -> pick the next highest-value entity -> deep-dive
Final:        both gates pass -> SUMMARY.md
```

The workflow is stateless; **all state lives in the vault on disk**, so it resumes across sessions. "Continue the investigation" re-enters at Step 0.

**Vault:** `~/.copilot/kai/MEMORY/RESEARCH/YYYY-MM/YYYY-MM-DD_<topic-slug>/`

URL verification per `../UrlVerificationProtocol.md` applies to every artifact.

## Step 0: detect state

- No `LANDSCAPE.md` / `ENTITIES.md` -> first iteration, go to Step 1.
- Continuation: read `ENTITIES.md`.
  - PENDING entities at CRITICAL/HIGH -> Step 4.
  - All CRITICAL/HIGH done but some category thin -> Step 3.
  - Both gates pass -> Step 5 (finish).

## Step 1: landscape (first iteration only)

The expensive phase; do it once and reference it cheaply afterward.

Pick a domain template from `../Templates/` (market, threat landscape) or derive entity categories from what you find. Run the **Extensive** pattern (7 explorers + 2 verifiers) with angles covering: domain overview and structure; key players and competitive dynamics; recent developments and trends; historical context; adjacent domains and cross-cutting themes; contrarian views and underappreciated dynamics. `@kai-architect` can draft the angle plan and the landscape synthesis.

Write three files:

**LANDSCAPE.md**: overview (2-3 paragraphs), domain structure (segments, size if applicable), key dynamics (forces, what's changing), entity categories with estimated counts, initial entity discoveries, verified sources.

**ENTITIES.md**:
```markdown
Status: PENDING (found, not researched) | RESEARCHED (profile exists) | SKIP (not worth it)
Value:  CRITICAL (defines the domain) | HIGH (major player) | MEDIUM (notable) | LOW (minor)
Effort: EASY (abundant public info) | MODERATE (some digging) | HARD (little public info)

| Entity | Category | Status | Value | Effort | Profile |
|--------|----------|--------|-------|--------|---------|
```

**INDEX.md**: created date, template used, status, links to landscape/catalog/profiles, coverage counts (categories complete, entities researched / total, CRITICAL+HIGH researched / pending).

## Step 2: evaluate

Score every PENDING entity lacking scores on **value** (domain impact, using the template's criteria) and **effort** (information accessibility). Investigation order:

1. CRITICAL + EASY (highest return)
2. CRITICAL + HARD (must-have despite difficulty)
3. HIGH + EASY
4. HIGH + HARD
5. MEDIUM and below only after all CRITICAL/HIGH are done

## Step 3: discover (fill thin categories)

For each category with fewer than 3 entities, dispatch 2-3 `@kai-researcher` passes:

> Find 3-5 notable {category} in the {domain} space. For each: name, one-line description, why they matter. Already known: {list}. Find NEW ones only.

Add results as PENDING and score them (Step 2).

## Step 4: investigate one entity

Quality over quantity: one comprehensive profile per iteration. Take the top PENDING entity (value first, then effort). Load the category's profile template and dispatch 3 parallel `@kai-researcher` passes (4 if the entity is technical: add the primary-sources pass):

- **Profile depth:** "Deep research on {entity} in the context of {domain}. Cover: {template fields}. Context: {paragraph from LANDSCAPE.md}. Tag findings [HIGH]/[MED]/[LOW]. Organize by template field."
- **Recent activity:** "Latest on {entity} in the last 12 months: news, funding, launches, key hires, partnerships. Tag findings."
- **Competitive position:** "{entity}'s strengths, weaknesses, and how it compares to {2-3 related entities from ENTITIES.md}. What makes it distinctive? Tag findings."

Write the profile to `<vault>/<Category>/<entity-slug>.md`, cross-link related entities, mark it RESEARCHED in `ENTITIES.md`, add it to `INDEX.md`.

## Step 4.5: verify the profile (iterative runs)

Before the gate check, scan the profile for numbers, dates and percentages. Pick the 2-3 most important, confirm each with a quick web search or fetch, tag `[HIGH]` if verified and `[LOW]` if not, and record any `[CONFLICT]`. This catches errors before they spread into cross-linked profiles. In a single run, do this once over the whole vault at the end instead.

## Step 5: coverage gates

Both must pass to finish:

- **Breadth gate:** every category has at least 3 entities not marked SKIP.
- **Depth gate:** every CRITICAL and HIGH entity is RESEARCHED or SKIP.

Both pass -> write `SUMMARY.md` (executive synthesis across the vault), update `INDEX.md` with final stats, report completion. Either fails -> report "coverage incomplete: [what remains]" and stop. The next run picks up from the vault.

## Single run vs iterative

| | Single run | Iterative |
|---|---|---|
| Covers | landscape + first deep dive | full breadth + depth gates |
| Ends | after Step 4 | when Step 5 gates pass |
| Best for | overview + top entity | comprehensive investigation |

A single run ends by listing what remains PENDING so a later run can continue.

## Final vault layout

```
<vault>/
  INDEX.md       navigation + coverage stats
  LANDSCAPE.md   broad analysis (written once)
  ENTITIES.md    catalog with status/value/effort
  SUMMARY.md     executive synthesis (on completion)
  <Category>/<entity-slug>.md   cross-linked profiles
```
