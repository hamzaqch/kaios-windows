# Analyze AI trends

Trend analysis across accumulated research over time. Default topic is the AI industry; works for any topic with a series of dated digests. The point is what's **changing over time**, not what's happening in any one entry.

## Step 1: gather the corpus

- Saved research under `~/.copilot/kai/MEMORY/RESEARCH/` on the topic (news digests, prior reports), or digests the user provides.
- Sort chronologically. Record the date range and the number of sources.
- Fewer than 3 dated sources: say trend analysis is limited, and offer to run Standard research for current state to extend the series.

## Step 2: analyze across all entries

Read everything in order (for a large corpus, split it across parallel `task` calls to `@kai-researcher` by period, then synthesize; `@kai-architect` suits the synthesis). Look for patterns across multiple entries, both obvious and subtle:

- **Evolving trends:** what's emerging, strengthening, weakening
- **Recurring themes:** topics, companies, technologies that keep appearing
- **Trajectory:** where the field is heading given the progression
- **Paradigm shifts:** inflection points, what changed and when
- **Competitive landscape:** how companies, models and approaches compete
- **Innovation velocity:** accelerating, steady or slowing
- **Emerging winners:** what's gaining momentum, and why
- **Declining areas:** what's being abandoned, and why
- **Surprising patterns:** unexpected trends or correlations
- **Predictions:** what's likely next, each tied to the trends supporting it

## Output

```
TREND ANALYSIS: <topic>
Period: <first date> to <latest date> | Sources: <n>

EVOLVING TRENDS
RECURRING THEMES        - theme: frequency and significance
TRAJECTORY
PARADIGM SHIFTS         - shift: what changed and when
COMPETITIVE LANDSCAPE
INNOVATION VELOCITY
EMERGING WINNERS        - winner: why it's succeeding
DECLINING AREAS         - area: why it's declining
SURPRISING PATTERNS     - pattern: why it's unexpected
PREDICTIONS             - prediction: based on which trends
KEY INSIGHTS            1-3, most important first
RECOMMENDATIONS         - action: based on which trend
```

Claims about the present that rest on old entries should be checked against current sources and tagged per SKILL.md.
