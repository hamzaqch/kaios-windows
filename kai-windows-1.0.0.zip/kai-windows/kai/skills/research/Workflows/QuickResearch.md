# Quick research

**Shape:** one pass, one well-crafted query, return immediately. Speed first.

Use for "quick research", "minor research", simple factual lookups, time-sensitive "just tell me what's current".

## Step 0: source routing

Classify per `../SourceRoutingProtocol.md`.

- **Sentiment signal fires:** skip web search. Make one Reddit JSON call at the most relevant subreddit (`/r/{sub}/top.json?t=week&limit=25`, or site-wide `search.json` if the sub is unknown). Read the top ~10 posts, pull comments on the highest-signal thread, return verbatim quotes with thread URLs and scores. Quick mode returning recap-only on a sentiment question is a known failure; pull the community source directly.
- **No signal:** Step 1.

## Step 1: one pass

Run a single web search yourself, or one `task` call to `@kai-researcher` with this brief:

> Do ONE web search for: [query]. Tag each finding [HIGH], [MED] or [LOW]. Verify any URL you return. Return the key findings immediately; brief and factual.

No multi-query exploration.

## Step 2: return

Direct answer, the confidence-tagged key facts, verified sources. Verification is self-verification only at this tier, but URLs still get checked per `../UrlVerificationProtocol.md`. If the answer is thin or contested, end with: "Run standard research for cross-checked depth."
