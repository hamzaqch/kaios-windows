# URL verification protocol

Mandatory for every research output. **Every URL is verified before it ships. An unverifiable URL is removed, not caveated.**

## Why

Research passes hallucinate URLs that look plausible:
- right domain, wrong path
- plausible article titles that were never published
- real domains joined to fabricated paths
- articles that were deleted or moved

One broken link destroys credibility for the whole report.

## Procedure

For each URL:

1. **Fetch it** (web fetch) and confirm it returns real content, not 404/403/5xx, a login wall or an empty shell.
2. **Confirm the content supports the claim** it is cited for. A live page that says something else is a failed citation.
3. **Status check as backup** when web fetch is ambiguous:
   - bash: `curl -s -o /dev/null -w "%{http_code}" -L "<url>"`
   - PowerShell: `curl.exe -s -o NUL -w "%{http_code}" -L "<url>"`
4. **Include only if both the status and the content check pass.**

| Acceptable | Unacceptable |
|---|---|
| Fetched, returns content, content supports the claim | Taken from a pass's output without checking |
| 200 and matching content | 403 / 404 / 500 |
| | Live page whose content doesn't match the citation |

If a removed URL was the only support for a finding, downgrade the finding (`[HIGH]` -> `[MED]`, `[MED]` -> `[LOW]`) or drop it.

## Batch verification (Extensive and Deep)

These tiers can produce 10-20+ URLs. Check them in parallel, not one at a time: issue several web fetches at once, or run a parallel status sweep and then content-check the survivors.

```bash
for url in "${urls[@]}"; do curl -s -o /dev/null -w "%{http_code} $url\n" -L "$url" & done; wait
```

```powershell
# PowerShell 7+; on Windows PowerShell 5.1 drop -Parallel and run sequentially
$urls | ForEach-Object -Parallel { "$(curl.exe -s -o NUL -w '%{http_code}' -L $_) $_" }
```

Any non-200 -> remove. If the parallel sweep fails (too many connections), fall back to sequential.

## Pass self-verification

Brief every research pass to verify its own URLs before returning. That makes most URLs pre-checked; the orchestrator's batch check is the safety net, not the primary layer. Still run it.
