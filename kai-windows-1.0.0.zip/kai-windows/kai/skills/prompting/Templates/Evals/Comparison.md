# Comparison Template: A/B test of prompt variants

Use to decide between two prompt variants (or models, or parameter settings) with evidence instead of impressions.

Design rules:
- **Same test cases for both variants** (from `TestCase.md`).
- **Position swapping:** when a judge sees both outputs side by side, run each pair twice with the order reversed and average the scores.
- **Multiple runs per case** when outputs vary, so a difference is not noise.
- **Judges independent of the generator:** `@kai-reviewer` or `task` subagents that wrote neither variant. Several judges with different focuses beat one.
- **State the hypothesis first**, so the result can confirm or reject it.

**Slots**
- `comparison.name`, `comparison.hypothesis`.
- Per variant (A, B): `name`, `description` (what differs and why it might win), `prompt`.
- `test_cases`: case IDs, or "all cases in suite X".
- Per judge: `name`, `focus`, `dimensions`.
- Settings: `position_swap` (yes/no), `runs_per_case`, `confidence_level` (default 0.95).

---

```markdown
# {{comparison.name}}

## Hypothesis

{{comparison.hypothesis}}

## Variants

### Variant A: {{a.name}}
{{a.description}}

**Prompt:**
~~~
{{a.prompt}}
~~~

### Variant B: {{b.name}}
{{b.description}}

**Prompt:**
~~~
{{b.prompt}}
~~~

## Setup

**Test cases:** {{test_cases}}

| Judge | Focus | Dimensions |
|---|---|---|
<!-- repeat: one row per judge -->
| {{judge.name}} | {{judge.focus}} | {{judge.dimensions}} |

| Setting | Value |
|---|---|
| Position swapping | {{position_swap}} |
| Runs per case | {{runs_per_case}} |
| Confidence level | {{confidence_level}} |

## Protocol

1. For each test case, generate output from both variants ({{runs_per_case}} runs each).
2. For each judge, score both outputs. With position swapping, judge each pair as (A, B) and as (B, A), and average.
3. Aggregate: win rate per variant, mean and standard deviation of scores, per-dimension wins, and significance at the stated confidence level.

## Results

| Metric | Variant A | Variant B |
|---|---|---|
| Win rate | {{a.win_rate}} | {{b.win_rate}} |
| Mean score | {{a.mean}} | {{b.mean}} |
| Std dev | {{a.sd}} | {{b.sd}} |

**p-value:** {{p_value}}  **Confidence interval of the difference:** [{{ci_low}}, {{ci_high}}]  **Significant:** yes/no

| Dimension | A wins | B wins | Tie |
|---|---|---|---|
<!-- repeat: one row per dimension -->
| {{dimension}} | {{a_wins}} | {{b_wins}} | {{ties}} |

## Conclusion

- **Winner:** Variant A / Variant B / no clear winner
- **Confidence:** high / medium / low
- **Hypothesis:** accepted / rejected / inconclusive
- **Recommendation:** {{recommendation}}

## Notes (optional)

{{comparison.notes}}
```

With few cases, report "no clear winner" rather than declaring one on a small, non-significant margin.
