# Results Template: eval results write-up

Use to write up an eval run: a one-off result, a regression check between versions, or a stakeholder summary.

Rules:
- Give the **standard error of the mean (SEM = std dev / sqrt(n))** and a **95% confidence interval (mean +/- 1.96 x SEM)**, not just the mean. A difference inside overlapping intervals is not a finding.
- Show pass and fail counts, not only the rate.
- For regressions, compare against the previous version and say whether the change is statistically significant.

**Verdict bands** for the executive summary, by pass rate:

| Pass rate | Verdict |
|---|---|
| above 90% | EXCELLENT |
| above 75% | GOOD |
| above 50% | NEEDS IMPROVEMENT |
| 50% or below | CRITICAL |

**Slots**
- `run.title`, `run.id`, `run.timestamp`, `run.use_case`, `run.version` (optional).
- `summary.*`: total, passed, failed, pass rate, mean score, std dev, SEM, confidence interval.
- Per dimension: name, weight, mean, std dev.
- Per failure: test ID, score, reason.
- `comparison.*` (optional): previous version, previous score, delta, significant (yes/no).

---

```markdown
# {{run.title}}

**Run ID:** `{{run.id}}`
**Timestamp:** {{run.timestamp}}
**Use case:** {{run.use_case}}
**Version (optional):** {{run.version}}

## Executive summary

**{{verdict}}**: {{summary.pass_rate}}% pass rate

| Metric | Value |
|---|---|
| Total test cases | {{summary.total}} |
| Passed | {{summary.passed}} |
| Failed | {{summary.failed}} |
| **Pass rate** | **{{summary.pass_rate}}%** |

## Score statistics

| Metric | Value |
|---|---|
| Mean score | {{summary.mean}} |
| Standard deviation | {{summary.sd}} |
| Standard error (SEM) | {{summary.sem}} |
| 95% confidence interval | [{{summary.ci_low}}, {{summary.ci_high}}] |

### Version comparison (optional)

| Metric | Previous ({{comparison.previous_version}}) | Current ({{run.version}}) | Delta |
|---|---|---|---|
| Mean score | {{comparison.previous_score}} | {{summary.mean}} | {{comparison.delta}} |

{{"Statistically significant change detected." or "No statistically significant change."}}

## Dimension breakdown

| Dimension | Weight | Mean | Std dev |
|---|---|---|---|
<!-- repeat: one row per dimension -->
| {{dimension.name}} | {{dimension.weight}}% | {{dimension.mean}} | {{dimension.sd}} |

## Failure analysis (optional)

{{failure_count}} test cases failed:

| Test ID | Score | Reason |
|---|---|---|
<!-- repeat: one row per failure -->
| `{{failure.id}}` | {{failure.score}} | {{failure.reason}} |

### Common failure patterns

{{group the failure reasons and name what they share}}

## Recommendations

<!-- include when pass rate is 75% or below -->
### Immediate actions
1. Review the failing cases for the common patterns above.
2. Identify the lowest-scoring dimensions.
3. Adjust the prompt for those dimensions, then re-run the same suite.

<!-- include when the version change is significant -->
### Regression alert
Performance has {{decreased / improved}} since {{comparison.previous_version}}.
{{Investigate recent changes. / Record what changed so it is kept.}}

## Appendix: raw data

~~~yaml
summary:
  total: {{summary.total}}
  passed: {{summary.passed}}
  failed: {{summary.failed}}
  pass_rate: {{summary.pass_rate}}
  mean: {{summary.mean}}
  sd: {{summary.sd}}
  sem: {{summary.sem}}
  ci: [{{summary.ci_low}}, {{summary.ci_high}}]
dimensions:
  - name: {{dimension.name}}
    weight: {{dimension.weight}}
    mean: {{dimension.mean}}
    sd: {{dimension.sd}}
~~~
```
