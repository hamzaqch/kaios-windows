# Rubric Template: evaluation criteria

Use to define what "good" means for a class of outputs, for human or AI graders. A filled rubric supplies the criteria for `Judge.md`.

**Slots**
- `rubric.name`, `rubric.version` (optional), `rubric.purpose`, `rubric.use_case` (optional).
- Per dimension: `name`, `description`, `weight` (all weights sum to 100%), and a level table, highest score first. Each level has a score, a label, and a description concrete enough that two graders would pick the same level.
- `indicators`: observable signs of the top and bottom levels. Optional but strongly recommended; they are what make a rubric reproducible.
- `pass_threshold`: weighted score required to pass. Omit for score-only rubrics.
- `examples`: scored sample outputs. Optional; they calibrate graders.

---

```markdown
# {{rubric.name}}

**Version (optional):** {{rubric.version}}

## Purpose

{{rubric.purpose}}

**Use case (optional):** {{rubric.use_case}}

## Dimensions

<!-- repeat: one block per dimension -->
### {{n}}. {{dimension.name}} ({{dimension.weight}}% weight)

{{dimension.description}}

| Score | Level | Description |
|---|---|---|
<!-- repeat: one row per level, highest first -->
| **{{level.score}}** | {{level.label}} | {{level.description}} |

**Top-score indicators:**
- {{indicator}}

**Lowest-score indicators:**
- {{indicator}}

## Summary

| Dimension | Weight | Score range |
|---|---|---|
<!-- repeat: one row per dimension -->
| {{dimension.name}} | {{dimension.weight}}% | {{lowest}} - {{highest}} |
| **Total** | **100%** | |

## Pass/fail threshold

Passing score: **{{pass_threshold}}** or higher, as the weighted average of all
dimension scores. (For score-only rubrics: "No pass/fail threshold.")

## How to use

1. For each dimension, compare the output to the level descriptions and pick the best-fitting level.
2. Multiply each dimension score by its weight and sum.
3. Compare the sum to the threshold.

## Examples (optional)

<!-- repeat: one per example -->
### Example {{n}}: {{example.title}}
**Output:** {{example.output}}
**Scores:** {{dimension}}: {{score}}, ...
**Overall:** {{example.overall}}
```

## Example dimension

```markdown
### 1. Factual accuracy (40% weight)

Every claim in the output is correct and supported by the provided source.

| Score | Level | Description |
|---|---|---|
| **5** | Exact | Every claim correct and traceable to the source |
| **4** | Minor slip | One minor imprecision, no wrong claims |
| **3** | Mixed | One wrong claim that does not change the conclusion |
| **2** | Misleading | A wrong claim that changes the conclusion |
| **1** | Fabricated | Claims not present in the source |

**Top-score indicators:** every number matches the source; hedges where the source hedges.
**Lowest-score indicators:** invented figures, quotes or citations.
```
