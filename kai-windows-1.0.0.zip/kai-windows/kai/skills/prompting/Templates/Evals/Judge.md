# Judge Template: LLM-as-judge prompt

Use to grade an output against criteria. Research-backed design choices built into this template:

- **Reasoning before score.** Requiring evidence-backed reasoning before any score measurably improves judge accuracy.
- **A 1-5 scale** (or binary pass/fail) is more reliable than 0-100.
- **A different model or agent than the generator.** A model grading its own output is biased toward it. Dispatch judging to `@kai-reviewer` or a `task` subagent that did not produce the output.
- **Position swapping** for A/B judging: run twice with the order reversed and average, to cancel position bias.

**Slots**
- `judge.name`, `judge.focus` (accuracy, style, completeness, safety, or custom).
- `context.task_description`: the original task the output was answering.
- `context.golden_output`: a reference answer. Optional.
- `output_to_evaluate`: the output under test.
- Per criterion: `name`, `description` (what a top score looks like, concretely), `weight` (weights sum to 100%).
- `judge.scale`: 1-5, binary, or custom labels.
- `pass_threshold`: weighted score needed to pass.
- `output.format`: json or structured.

---

```markdown
# {{judge.name}}

You are an expert evaluator of {{judge.focus}}.

## Task

Evaluate the output below against the criteria. Give your reasoning for each
criterion before giving any score.

### Original task

{{context.task_description}}

### Reference output (optional)

{{context.golden_output}}

### Output to evaluate

~~~
{{output_to_evaluate}}
~~~

## Criteria

<!-- repeat: one per criterion -->
### {{n}}. {{criterion.name}} (weight {{criterion.weight}}%)

{{criterion.description}}

## Scale

<!-- keep the one table that applies -->
| Score | Meaning |
|---|---|
| 5 | Excellent: exceeds the requirement |
| 4 | Good: meets every requirement |
| 3 | Acceptable: meets most requirements |
| 2 | Poor: significant issues |
| 1 | Unacceptable: fails the requirement |

| Score | Meaning |
|---|---|
| PASS | Meets the criterion |
| FAIL | Does not meet the criterion |

## How to judge

For each criterion: quote the specific parts of the output that bear on it,
explain how well they meet it, name any gaps, and only then assign the score.

(For A/B runs) This evaluation may be repeated with the content in a different
position. Judge on merit only.

## Output format

<!-- json variant -->
Respond with only this JSON:

{
  "reasoning": { "{{criterion.name}}": "<reasoning>", ... },
  "scores": { "{{criterion.name}}": <score>, ... },
  "overall_score": <weighted average>,
  "passed": <true if overall_score >= {{pass_threshold}}>,
  "summary": "<one or two sentences>"
}

<!-- structured variant -->
## Reasoning
### {{criterion.name}}
<reasoning>
**Score:** <score>
(repeat per criterion)

## Overall
**Weighted score:** <weighted average>
**Result:** PASS or FAIL (threshold {{pass_threshold}})
**Summary:** <one or two sentences>
```

Delete whichever scale table and output variant you are not using.
