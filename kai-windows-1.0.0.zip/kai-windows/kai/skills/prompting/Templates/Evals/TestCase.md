# Test Case Template: eval test suite

Use to define input and expected-output pairs for evaluating a prompt: golden sets, regression suites, eval datasets. For a larger suite grown from a few hand-written cases, expand them with the `/be-creative` skill's synthetic data expansion workflow.

**Slots**
- `suite.name`, `suite.version` (optional), `suite.description`, `suite.target_prompt` (the prompt under test, by name or location).
- Per case: `id`, `name`, `category`, `difficulty` (easy, medium, hard), `tags`, input `content` plus any `variables` the prompt template takes, and expectations.
- Expectations: any of a golden `output`, `must_contain` strings, `must_not_contain` strings, an expected `format`. Prefer deterministic checks (contains, not-contains, format) where they capture the requirement; use a judge (`Judge.md`) only for what they cannot.

Cover the distribution, not just the happy path: typical cases, edge cases, adversarial inputs, and at least one case per known past failure (a regression case).

---

```markdown
# {{suite.name}}

**Version (optional):** {{suite.version}}
{{suite.description}}

**Target prompt:** `{{suite.target_prompt}}`

## Test cases ({{count}} total)

<!-- repeat: one block per case -->
### {{case.id}}: {{case.name}}

**Category:** `{{case.category}}`  **Difficulty:** {{case.difficulty}}  **Tags:** {{case.tags}}

#### Input

**Variables (optional):**
~~~yaml
{{variable}}: {{value}}
~~~

**Content:**
~~~
{{case.input}}
~~~

#### Expected

**Golden output (optional):**
~~~
{{case.expected_output}}
~~~

**Must contain (optional):**
- `{{string}}`

**Must not contain (optional):**
- `{{string}}`

**Format (optional):** {{case.expected_format}}

**Notes (optional):** {{case.notes}}

---

## Summary

| Category | Count |
|---|---|
<!-- repeat: one row per category -->
| {{category}} | {{count}} |
| **Total** | {{count}} |
```

## Running the suite

Run the target prompt on every case. Score deterministic expectations directly, and send remaining judgments to `@kai-reviewer` with a filled `Judge.md`. Because model output varies, run each case several times when reliability matters: *pass@k* (passed at least once in k tries) measures capability; *pass^k* (passed all k tries) measures consistency. Write up the run with `Results.md`.
