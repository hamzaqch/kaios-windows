# Gate Template: validation checklist

Use for reusable quality or completion checks: code review, feature completion, content publication, research source verification, deployment, security review. A gate is a safety-gate or output-format-contract in checklist form, so it survives the delete-test.

**Slots**
- `gate.name`, `gate.category` (development, content, security, deployment, research), `gate.description`.
- `gate.action_on_fail`: what happens when any mandatory item fails (request changes, continue development, block deploy, revise). Required when there are mandatory items.
- `gate.mandatory`: items that must all pass. Each is a name plus a checkable description.
- `gate.recommended`: items that should pass; failures are noted, not blocking.

Write each item as a state that can be observed true or false ("All existing tests pass"), never as an activity ("Run the tests") or a quality ("Code is good").

---

```markdown
## {{gate.name}} checklist

**Category:** `{{gate.category}}`
{{gate.description}}

### Mandatory

If any item below fails: **{{gate.action_on_fail}}**.

<!-- repeat: one per mandatory item -->
- [ ] **{{item.name}}**: {{item.description}}

### Recommended (optional)

<!-- repeat: one per recommended item -->
- [ ] {{item.name}}: {{item.description}}
```

For a set of several gates, repeat the block above under a `# Validation gates` heading, separated by `---`.

---

## Example: code review gate

```markdown
## Code review checklist

**Category:** `development`
Pre-merge code quality check.

### Mandatory

If any item below fails: **request changes**.

- [ ] **Tests pass**: all existing tests pass with the change applied.
- [ ] **Types clean**: no type errors; public functions carry type annotations.
- [ ] **No secrets**: no API keys, passwords or tokens in the diff.

### Recommended

- [ ] Style: follows the project's formatting conventions.
- [ ] Docs: public APIs documented.
- [ ] Performance: no obvious regressions on hot paths.
```

Other gates worth having: development complete (feature works, tests added, no regressions), research verified (every claim sourced, sources reachable, conflicting sources noted), deploy ready (build passes, rollback path exists, config reviewed).
