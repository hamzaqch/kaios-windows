# Structure Template: multi-phase workflow

Use for workflows with genuine phases: phased analysis (discover, attack, steelman, report), round-based debate (opening, rebuttal, synthesis), or a gated pipeline. A phase is genuine when it ends at a real boundary: a hand-off to another agent, a gate that must pass, a human checkpoint, or a point where later output depends on earlier output.

Phases are not reasoning choreography. If a phase only tells a capable model how to think ("first consider, then analyze"), delete it and fold its outcome into a done-criterion. Each phase states what it must produce; how is left to the agent.

**Slots**
- `workflow.name`, `workflow.description`, `workflow.timing` (optional).
- Per phase: `name`, `purpose`, `produces` (the phase's completion criterion), optional `agent` (who runs it: the `task` tool, `@kai-researcher`, `@kai-reviewer`, and so on), optional `tools`, optional `gate` (a checklist from `Gate.md` that must pass before the next phase).
- `workflow.completion_criteria`: done for the whole workflow.

---

```markdown
# {{workflow.name}}

{{workflow.description}}

**Estimated timing (optional):** {{workflow.timing}}

<!-- repeat: one block per phase -->
## Phase {{n}}: {{phase.name}}

**Purpose:** {{phase.purpose}}
**Run by (optional):** {{phase.agent}}
**Tools (optional):** {{phase.tools}}

**Produces:** {{phase.produces}}

**Gate before next phase (optional):** {{phase.gate}}

---

## Completion criteria

<!-- repeat: one checkable criterion each -->
- [ ] {{workflow.completion_criterion}}

## Notes (optional)

{{workflow.notes}}
```

## Example

```markdown
# Red-team review

Stress-test a plan by attacking it in parallel, then steelmanning it.

## Phase 1: Decompose
**Purpose:** Turn the plan into atomic claims that can be attacked one at a time.
**Produces:** A numbered list of claims; every sentence of the plan maps to at least one.

## Phase 2: Attack
**Purpose:** Find how each claim fails.
**Run by:** one `@kai-reviewer` per roster member, each with a Briefing.
**Produces:** For each claim, the strongest objection with a severity rating.

## Phase 3: Steelman and report
**Purpose:** Separate fatal objections from survivable ones.
**Run by:** `@kai-architect`.
**Produces:** Severity-ranked findings, each with a remediation.

## Completion criteria
- [ ] Every claim has been attacked by at least two perspectives.
- [ ] Every critical finding has a remediation or an explicit "accept the risk".
```
