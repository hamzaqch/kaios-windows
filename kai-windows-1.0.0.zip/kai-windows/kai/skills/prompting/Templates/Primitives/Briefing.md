# Briefing Template: subagent context handoff

Use to brief a subagent dispatched with the `task` tool or a custom agent (`@kai-researcher`, `@kai-engineer`, `@kai-reviewer`, `@kai-architect`). The subagent starts with no context, so the briefing must carry everything it needs and nothing it doesn't.

**Slots**
- `briefing.type`: research, analysis, debate, review, or build.
- `agent.name`, `agent.role`: who the subagent is playing (a persona from a Roster, or a plain role).
- `agent.perspective`, `agent.traits`: the lens that makes this agent's output different from a generic one. Optional.
- `context.*`: the minimum background, plus hard constraints.
- `task.*`: the job, the questions it must answer, and the deliverables.
- `done_when`: checkable completion criteria. Required; this is the ideal state.
- `output_format`: the exact return shape. When the parent will merge several briefings' results, make every briefing's format identical.

---

```markdown
# {{briefing.type}} briefing: {{agent.name}}

**Role:** {{agent.role}}

## Your identity (optional)

You are {{agent.name}}. Your perspective: "{{agent.perspective}}"

<!-- repeat: one line per trait -->
- {{agent.trait}}

## Context

{{context.summary}}

### Background (optional)

{{context.background}}

### Constraints (optional)

<!-- repeat: one line per constraint -->
- {{context.constraint}}

## Your task

{{task.description}}

### Questions to answer (optional)

<!-- repeat: numbered, one per question -->
1. {{task.question}}

### Deliverables (optional)

<!-- repeat: one per deliverable -->
- {{task.deliverable}}

## Done when

<!-- repeat: one checkable criterion each -->
- {{done_when}}

## Output format

{{output_format}}

## Notes (optional)

{{briefing.notes}}
```

**Default output formats** when the caller specifies nothing beyond a type:
- markdown: headed sections, findings first, evidence and sources under each.
- json: valid JSON matching the schema given in `output_format`; no prose around it.
- structured: the exact headings listed in `output_format`, in order.
