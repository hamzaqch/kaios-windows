---
name: prompting
description: "Meta-prompting library: writes, optimizes and composes prompts, system prompts, agent briefings, skill files, validation checklists, and eval prompts (LLM judges, rubrics, test cases, A/B comparisons, reports) from fill-in templates and an ideal-state prompting standard. The output is always a prompt to be used elsewhere, never the final content. Use when the user says write a prompt, improve this prompt, optimize a prompt, prompt engineering, meta-prompting, create a system prompt, brief an agent, write a skill, judge prompt, eval prompt, rubric, test cases, or compare two prompts. Not for generating the final deliverable itself."
---
# Prompting

The output of this skill is a prompt: a system prompt, an agent briefing, a skill file, a checklist, or an eval artifact. Never the final content the prompt will produce.

## The standard: ideal-state prompting

Every prompt this skill writes or optimizes states **what done looks like** (as testable outcomes), the **constraints** that bound the solution space, and the **tools** available, then trusts a capable model to find how. Reasoning choreography ("first analyze, then consider, then decide") caps a capable model and rots as models improve. Ideal-state prompting is more precise, not vaguer: the specificity moves to the outcome.

The test for every procedural line: **would a smarter model make this rule unnecessary?** Yes means cut it. No means it belongs to one of four keep-classes, which survive:

| Keep-class | What it is |
|---|---|
| Safety-gate | Confirmation, destructive-op guard, approval boundary |
| Verified-gotcha | A documented, non-obvious failure, with provenance (incident, failing test, reproduction) |
| Tool-contract | Exact command syntax, API parameters, file paths |
| Output-format-contract | The required shape, schema or template of the deliverable |

The full doctrine (no-op hunting, positive framing, leading words, context management, section templates, agentic and finder patterns, skill-writing structure) is in `Standards.md`. Read it before optimizing an existing prompt or writing anything long-lived, such as a system prompt or skill.

## Routing

| Request | Do this |
|---|---|
| Write a new prompt or system prompt | Pick a skeleton from `Standards.md` (section selection matrix), fill it, apply the delete-test |
| Improve or optimize an existing prompt | Audit it line by line against `Standards.md`: cut no-ops and choreography, keep the four classes, convert prohibitions to positive targets, sharpen the done-criterion |
| Brief a subagent | Fill `Templates/Primitives/Briefing.md` |
| Render a template with data | `python ~/.copilot/skills/prompting/tools/render_template.py -t <template> -d <data.json> [--strict]` ({{var}}, {{#each}}, {{#if}}, {{join}}, {{upper}}) |
| Define a panel of personas | Fill `Templates/Primitives/Roster.md`, then one Briefing per member |
| Set tone or persona voice | Fill `Templates/Primitives/Voice.md` |
| Multi-phase workflow with real hand-offs | Fill `Templates/Primitives/Structure.md` |
| Quality or completion checklist | Fill `Templates/Primitives/Gate.md` |
| LLM-as-judge prompt | Fill `Templates/Evals/Judge.md` |
| Scoring rubric | Fill `Templates/Evals/Rubric.md` |
| Test cases for a prompt | Fill `Templates/Evals/TestCase.md` |
| A/B test of two prompt variants | Fill `Templates/Evals/Comparison.md` |
| Summarize eval results | Fill `Templates/Evals/Results.md` |
| Write or audit a skill file | `Standards.md` section "Writing skills and long-lived prompts" |

## Using the templates

The templates are plain markdown skeletons that you fill in by hand. No renderer is involved.

- `{{slot}}` means replace it with real content. `{{a.b}}` names a field of a larger thing; it is just a label.
- A block introduced by `<!-- repeat: ... -->` is copied once per item, then the comment is deleted.
- A section marked `(optional)` is deleted entirely when it has no content. Never ship an empty heading or an unfilled `{{slot}}`.
- Each template opens with a short note on what to put in each slot; strip that note from the finished prompt.

Structure is fixed; content varies. When the same template serves many runs (say, a judge prompt across a test suite), keep the filled values in one place and change only them between runs.

## Delegation

Filled briefings are the prompt you pass to the `task` tool or to a custom agent: `@kai-researcher` for investigation, `@kai-engineer` for building, `@kai-reviewer` for critique and judging, `@kai-architect` for planning and synthesis. Judges should run on a different agent or model than the one that produced the output under evaluation; `@kai-reviewer` is the default judge.

## Before calling a prompt done

- Every line passes the delete-test, or is one of the four keep-classes.
- The done-criterion is checkable (the reader can tell done from not-done) and demanding enough to force the legwork you want.
- Examples, if any, match the desired output exactly; the model copies their details.
- For any prompt that matters, test it on two or three real inputs before declaring it ready. A prompt that reads well can perform poorly. For anything reused, build a small test set with `Templates/Evals/TestCase.md`.

## Gotchas

- Keep prompts model-agnostic. Avoid depending on one model's quirks; when a quirk is unavoidable, record it as a verified-gotcha with its provenance.
- Prompt formatting leaks into output formatting. A prompt full of bullets gets bullets back.
