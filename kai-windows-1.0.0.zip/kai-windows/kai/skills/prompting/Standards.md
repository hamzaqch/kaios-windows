# Prompting Standards

**Context engineering** is curating the smallest set of high-signal tokens that maximizes the likelihood of the desired outcome. Context is a finite attention budget: every token you add dilutes the rest, and performance degrades as context grows. Everything below serves that goal and the ideal-state standard.

---

## 1. Ideal-state prompting

A prompt states WHAT done looks like as testable outcomes, the CONSTRAINTS, and the TOOLS available. The model finds HOW.

**Procedural (rots):**
```
To threat-model this: 1. First enumerate the components. 2. Then think about
trust boundaries. 3. Consider each STRIDE category carefully. 4. For each,
brainstorm attacks. 5. Finally, write up your findings.
```

**Ideal-state (survives model upgrades):**
```
Produce a threat model that names every trust boundary in the system and,
for each, a concrete attack that crosses it and the control that stops it.
Tools: [STRIDE reference], [the architecture doc]. Done = no boundary
unlisted, every listed boundary has at least one attack+control pair.
```

The second is shorter and more demanding. Its precision lives in the outcome.

**The test for every procedural line:** would a smarter model make this rule unnecessary? Yes: scaffolding, cut it. No: it is one of the four keep-classes.

| Keep-class | What it is | Why it survives |
|---|---|---|
| **Safety-gate** | Confirmation, destructive-op guard, approval boundary | About authority and consequence, not competence |
| **Verified-gotcha** | A documented non-obvious failure the model would otherwise hit. Needs provenance (a dated incident, failing test, or reproduction); without provenance it is methodology, so cut it | An empirical world-fact, not a reasoning crutch |
| **Tool-contract** | Exact command syntax, API parameters, file paths, invocation recipe | The precise WHAT of a tool call; cannot be guessed |
| **Output-format-contract** | The shape, schema or template the deliverable must match | Model free on HOW, bound on final form |

Deterministic programs are exempt; they do one fixed thing by design. Everything else that reads as procedure is a candidate to cut.

---

## 2. Cutting no-ops: the delete-test

Cut the line, re-read the prompt. If behavior would not change, the line was a no-op; leave it cut. Restore it only if you can name the specific non-default behavior it forces. Delete failing sentences whole rather than trimming words.

Three no-op classes:
- **Restating the default:** "be thorough", "write clean code", "be comprehensive".
- **Intensifier stacking:** MANDATORY / CRITICAL / "not optional" on a rule already stated. Emphasis is not a constraint; models obey specificity, not volume.
- **Unfalsifiable lines:** "use good judgment", "as appropriate". A line with no falsifier constrains nothing.

**Scope boundary.** Quality modifiers ("include as many relevant features as possible, go beyond the basics") earn their place when they shape open-ended *generative output* such as frontend, prose or design, where they measurably raise effort. The same words are no-ops as *rules* inside an instruction file. Put them in what you ask for; cut them from how a system is wired.

---

## 3. Writing principles

**Prompt the positive.** Prohibition names the banned thing and raises its availability ("don't think of an elephant"). State the target behavior instead. Keep a prohibition only as a hard guardrail that cannot be phrased positively, and pair it with what to do instead.

| Avoid | Use instead |
|---|---|
| "Do not use markdown or bullet points." | "Write in flowing prose paragraphs with natural transitions." |
| "NEVER do X" | "Do Y" |
| "CRITICAL: You MUST use this tool" | "Use this tool when..." |
| "You might want to consider..." | "Do X" (imperative, direct) |
| "Make it better" | "Change X to achieve Y" |
| Ten examples | One to three examples |
| Everything about the domain up front | Minimal context plus just-in-time loading |

**Give the reason.** Models generalize from motivation. "Your response will be read aloud by text-to-speech, so never use ellipses" beats "NEVER use ellipses": the reason also covers cases the rule did not list.

**Be direct and specific.** "Use the `calculate_tax` tool with amount and jurisdiction" beats a paragraph of hedged suggestion. Imperative voice. Clarity over completeness.

**Leading words.** A leading word is a compact concept already in the model's pretraining that anchors a whole region of behavior in a few tokens: *relentless*, *tight*, *red* (a failing test), *fog*, *tracer bullet*, *frontier*. Hunt for restatements one word retires: "fast, deterministic, low-overhead" becomes *tight*. A weak word is a no-op ("be thorough"); the fix is a stronger word (*relentless*), not more prose. Repeat the token, never the sentence. A coined word recruits no priors unless you define it.

**State scope explicitly.** Current frontier models follow instructions literally and do not silently generalize. An instruction meant for every item must say so: "Apply this to every section, not just the first."

**Examples are copied.** Models reproduce the details of examples closely, including accidental ones. Every example must match the desired output exactly. One to three is the sweet spot; returns diminish after three. Include an edge case when one matters.

**Soft tool language.** Aggressive phrasing ("you MUST use this tool") causes overtriggering on current models. Describe when the tool applies instead. If you want more tool use, describe when and how, rather than shouting.

**Format leaks.** Prompt style shapes output style. A prompt free of markdown gets less markdown back. Use a header such as `## Prose Output` or `## JSON Output` to signal the desired form.

**Markdown structure.** Kai convention: structure prompts with markdown headers rather than XML tags. They are readable for humans and models alike and need no special parsing.

---

## 4. Section skeletons

Include only the sections the task needs.

```markdown
# {{task_name}}

## Context
{{why this matters, 1-3 sentences; the motivation the model generalizes from}}

## Background (optional)
{{minimal domain facts the model cannot infer; what and why, not history}}

## Goal
{{what done looks like, as checkable outcomes}}

## Constraints
{{boundaries; success and failure criteria}}

## Examples (optional)
{{1-3 input/output pairs matching the desired output exactly}}

## Tools (optional)
- `{{tool}}`: use when {{condition}}.

## Output Format
{{exact structure: schema, headings, length}}
```

**Section selection matrix**

| Task type | Required | Recommended | Optional |
|---|---|---|---|
| Simple query | Goal, Output Format | Context | - |
| Complex implementation | Context, Goal, Output Format, Tools | Examples, Constraints, Verification | Action bias, Parallel |
| Research or analysis | Context, Goal, Constraints | Examples, Research mode | State tracking |
| Agentic coding | Context, Goal, Tools, Verification | Constraints, Parallel | State tracking |
| Long-horizon, multi-session | Context, Goal, State tracking | Verification, Parallel | Others as needed |

**Agent or persona skeleton**

```markdown
# {{agent_name}}: {{primary_function}}

## Role
You are {{role}}, responsible for {{core_responsibility}}.

## Goal
{{what a finished job looks like}}

## Tools
- `{{tool}}`: use when {{condition}}.

## Constraints
- {{constraint}}

## Output Format
{{exact response shape}}
```

---

## 5. Reusable behavior blocks

Paste the block that matches the behavior you want. Each changes a default, so each passes the delete-test.

**Action bias, implementation:** "Implement changes rather than only suggesting them. When intent is unclear, infer the most useful action and use tools to discover missing details instead of guessing."

**Action bias, research:** "Do not implement unless clearly instructed. Default to information, research and recommendations."

**Parallel tool calls:** "When calls have no dependencies, make them all in parallel. Call sequentially only when one result feeds the next. Never guess parameters or use placeholders."

**Read before edit:** "Never speculate about code you have not opened. If a file is referenced, read it before answering or proposing changes."

**Minimal change:** "Make only the changes requested or clearly necessary. No unrequested features, surrounding refactors, or speculative flexibility. Reuse existing abstractions."

**General solutions:** "Implement logic that works for all valid inputs, not just the test cases. Do not hard-code values to make tests pass."

**Cleanup:** "Remove any temporary files, scripts or helpers you created before finishing."

**Summary after tool work:** "After completing a task that involved tool use, give a short summary of what you did." (Current models often skip this by default.)

**Research mode:** "Define what a complete answer looks like. Verify claims across multiple sources. Develop competing hypotheses and track your confidence in each. Persist findings in structured notes."

**Distinctive frontend:** "Avoid generic, on-distribution design. Use distinctive typography, a cohesive palette with a dominant color and sharp accents, purposeful motion at high-impact moments, and atmospheric backgrounds. Skip cliches such as purple gradients on white."

---

## 6. Finder prompts: separate find from filter

Current models obey "only report high-severity", "be conservative" and "don't nitpick" more faithfully than older ones. A finder tuned that way investigates just as deeply but silently drops real low-severity issues: precision rises, recall falls.

At the finding stage, prompt for coverage. Move filtering to a separate verify stage.

```
Report every issue you find, including ones you are uncertain about or
consider low-severity. Do not filter for importance or confidence at this
stage; a separate verification step will do that. Coverage is the goal. For
each finding, include a confidence level and an estimated severity so a
downstream stage can rank them.
```

If you must filter in a single pass, state a concrete bar ("report any bug that could cause incorrect behavior, a test failure, or a misleading result; omit only pure style nits"), never a qualitative word like "important". In Kai, a natural split is finders via the `task` tool, then `@kai-reviewer` as the adversarial verifier.

---

## 7. Context management

- **Just-in-time loading.** Instead of pasting a hundred product records, say "Use `get_product(sku)` to fetch details when needed." Load detail only when a branch needs it.
- **Compaction.** When context grows, summarize old segments, preserve decisions and state, drop resolved subtasks, keep recent context verbatim. Often a fresh context that rediscovers state from files beats a degraded long one.
- **External state.** For multi-step or multi-session work, persist state outside the context: JSON for structured data (test status, schemas), free text for progress notes, git for checkpoints. Reference it by lightweight identifiers. Set up tests and success criteria in the first session so later sessions can verify without a human.
- **Subagents.** Give each one minimal, task-specific context, a clear success criterion, and a defined return format. The parent coordinates and synthesizes. To restrict delegation, say "delegate only when a task clearly benefits from a fresh context window."

---

## 8. Tool design

- One clear purpose per tool: `calculate_shipping_cost(origin, destination, weight, service_level)`, not `process_order(order_data)`.
- All needed parameters in the definition; complete, actionable results; graceful errors.
- Descriptions say when to use the tool, in plain language, without "MUST".

---

## 9. Writing skills and long-lived prompts

A skill or system prompt exists to make a stochastic system **predictable**: the same process every run, not the same output.

**Invocation cost.** A model-invoked skill carries a description that sits in context every turn (context load); write it with concrete trigger phrases. A user-invoked skill costs nothing in context but relies on the human remembering it (cognitive load). When user-invoked skills multiply, add one router skill that names the others.

**Information hierarchy.** A skill mixes *steps* (ordered actions, each ending on a completion criterion) and *reference* (rules and facts consulted on demand). Rank them by how immediately the agent needs each:
1. In-skill steps.
2. In-skill reference. A flat peer-set of rules is fine.
3. Disclosed reference behind a pointer to another file.

Inline what every branch needs; move behind a pointer what only some branches reach. The *wording* of a pointer decides how reliably it fires; a must-have target behind a weak pointer is a variance bug. Keep a concept's definition, rules and caveats under one heading.

**Completion criteria have two axes.** *Clarity* (can the agent tell done from not-done?) resists premature completion. *Demand* (how much it requires) sets the legwork: "every modified model accounted for" forces digging that "produce a change list" does not. The strongest criteria are both checkable and exhaustive.

**When to split.** Split off a separately invocable skill when a distinct trigger should fire it alone or another skill must reach it. Split a run of steps when the steps ahead tempt the agent to rush the current one; hiding only works across a real context boundary such as a subagent dispatch.

**Failure modes.**
- *Premature completion:* sharpen the criterion first; split only if it stays fuzzy and you observe the rush.
- *Duplication:* each meaning lives in exactly one place.
- *Sediment:* stale layers that settle because adding feels safe and removing feels risky. Prune on purpose.
- *Sprawl:* too long even when every line is live. Disclose reference, split by branch or sequence.
- *No-op:* see section 2.
- *Negation:* see "prompt the positive".

Settle disagreements about whether a line matters by running the skill, not by debate.

---

## 10. Review checklist

- [ ] States the ideal state as checkable outcomes, plus constraints and tools.
- [ ] No reasoning choreography outside the four keep-classes.
- [ ] Every line passes the delete-test.
- [ ] Positive targets instead of prohibitions; reasons given where they generalize.
- [ ] Scope stated explicitly wherever an instruction applies to many items.
- [ ] Examples, if any, match the desired output exactly; three or fewer.
- [ ] Tool descriptions use "use when", not "MUST".
- [ ] Detail is loaded just in time, not dumped up front.
- [ ] Output format is explicit.
- [ ] Tested on real inputs if the prompt matters.

## Sources

- Anthropic, prompt engineering overview: https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview
- Anthropic, "Effective context engineering for AI agents": https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents
- "The Prompt Report", arXiv:2406.06608
- "The Prompt Canvas", arXiv:2412.05127

When revising these standards, check them against the current versions of the first two sources; that guidance shifts with each model generation. Report divergence; don't silently adopt.
