"""Render a prompt template with JSON data. Stdlib only (Handlebars-style subset).

  python render_template.py --template T.md --data D.json [--output out.md] [--strict]

Supported: {{var}} and dotted {{a.b.c}}; {{#each list}}...{{/each}} with {{this}}, {{this.x}},
{{@index}} (0-based), {{@number}} (1-based); {{#if x}}...{{else}}...{{/if}}; {{#unless x}}...{{/unless}};
helpers {{upper x}}, {{lower x}}, {{join list ", "}}. --strict fails on any unresolved variable.
"""
import argparse
import json
import re
import sys
from pathlib import Path

BLOCK = re.compile(r"{{#(each|if|unless)\s+([^}]+?)}}(.*?){{/\1}}", re.S)
VAR = re.compile(r"{{\s*([^#/{}][^}]*?)\s*}}")


class Unresolved(KeyError):
    pass


def lookup(path, ctx, strict):
    path = path.strip()
    if path.startswith("@"):
        if path in ctx.get("_meta", {}):
            return ctx["_meta"][path]
    cur = ctx
    parts = path.split(".")
    if parts[0] == "this":
        cur, parts = ctx.get("this", ctx), parts[1:]
    for p in parts:
        if isinstance(cur, dict) and p in cur:
            cur = cur[p]
        elif isinstance(cur, list) and p.isdigit() and int(p) < len(cur):
            cur = cur[int(p)]
        elif "_parent" in ctx and cur is ctx:
            return lookup(path, ctx["_parent"], strict)
        else:
            if strict:
                raise Unresolved(path)
            return ""
    return cur


def render(tpl, ctx, strict=False):
    def block(m):
        kind, expr, body = m.group(1), m.group(2), m.group(3)
        main, _, alt = body.partition("{{else}}")
        val = lookup(expr, ctx, strict)
        if kind == "each":
            items = val if isinstance(val, list) else (list(val.values()) if isinstance(val, dict) else [])
            out = []
            for i, item in enumerate(items):
                child = dict(item) if isinstance(item, dict) else {}
                child.update({"this": item, "_parent": ctx, "_meta": {"@index": i, "@number": i + 1}})
                out.append(render(main, child, strict))
            return "".join(out) if items else render(alt, ctx, strict)
        truthy = bool(val)
        if kind == "unless":
            truthy = not truthy
        return render(main if truthy else alt, ctx, strict)

    prev = None
    while prev != tpl:  # innermost-first expansion handles nesting
        prev, tpl = tpl, BLOCK.sub(block, tpl, count=1)

    def var(m):
        expr = m.group(1).strip()
        if expr == "else":
            return ""
        head, _, rest = expr.partition(" ")
        if head in ("upper", "lower"):
            v = str(lookup(rest, ctx, strict))
            return v.upper() if head == "upper" else v.lower()
        if head == "join":
            name, _, sep = rest.partition(" ")
            sep = sep.strip().strip('"').strip("'") or ", "
            v = lookup(name, ctx, strict)
            return sep.join(str(x) for x in v) if isinstance(v, list) else str(v)
        v = lookup(expr, ctx, strict)
        return json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v)

    return VAR.sub(var, tpl)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--template", "-t", required=True)
    ap.add_argument("--data", "-d", required=True, help="JSON file")
    ap.add_argument("--output", "-o")
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args(argv)
    try:
        data = json.loads(Path(a.data).read_text(encoding="utf-8-sig"))
        out = render(Path(a.template).read_text(encoding="utf-8-sig"), data, a.strict)
    except Unresolved as e:
        print(f"unresolved variable: {e.args[0]}", file=sys.stderr)
        return 2
    except (OSError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    if a.output:
        Path(a.output).write_text(out, encoding="utf-8")
    else:
        sys.stdout.write(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
