"""Kai content intake: chunk external notes, classify each chunk to a Kai destination with
a confidence score, then commit approved chunks with provenance. Stdlib only (Python 3.8+).

    python migrate.py scan (--source <file|dir> | --stdin) [--json] [--dry-run]
    python migrate.py list [--status pending|approved|rejected|all] [--target T] [--json]
    python migrate.py show <id>
    python migrate.py approve (--trusted | --target T | --id ID [--to T]) [--dry-run]
                              [--confirm] [--allow-duplicate]
    python migrate.py reject <id> [<id> ...]
    python migrate.py targets
    python migrate.py clear [--all]           drop finished (or all) proposals from the queue

Destinations:
    knowledge/idea|person|company|research   a typed note via the cortex skill (seedling, tag "migrated")
    learning                                  one line in MEMORY/LEARNING/learnings.md
    profile                                   facts and preferences about the user -> the user
                                              section of copilot-instructions.md (needs --id and --confirm)
    rule                                      AI-collaboration rules -> the same user section, or by hand
                                              to a hook or a skill's Gotchas (needs --id and --confirm)
    UNCLEAR                                   no rule matched; needs --id ID --to <target>

Confidence: >= 0.70 trusted (bulk-approvable), 0.40-0.70 confirm, < 0.40 walk through.
Bulk approval (--trusted, --target) never commits profile, rule, UNCLEAR or secret-bearing chunks.
Exit codes: 0 ok, 1 nothing to do / failure, 2 bad input. Queue: <Kai home>/MEMORY/MIGRATION/queue.json.
"""
import argparse
import datetime as _dt
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

TRUSTED = 0.70
MEDIUM = 0.40
MIN_CHUNK = 40
TEXT_EXT = {".md", ".markdown", ".txt", ".mdc"}
RULE_FILES = {".cursorrules", ".windsurfrules", ".clinerules"}
SKIP_DIRS = {".git", ".obsidian", ".trash", "node_modules", "__pycache__", ".venv"}

TARGETS = [
    "knowledge/idea", "knowledge/person", "knowledge/company", "knowledge/research",
    "learning", "profile", "rule", "UNCLEAR",
]
GATED = {"profile", "rule"}
KNOWLEDGE_TYPE = {"knowledge/idea": "idea", "knowledge/person": "person",
                  "knowledge/company": "company", "knowledge/research": "research"}

RULES = [
    ("rule", 3, [r"\b(always|never|do not|don't)\s+(do|use|include|write|add|run|ask|say|commit|push)\b",
                 r"\bwhen you\b", r"\b(you|kai|copilot|the assistant|the ai|claude|cursor)\s+(should|must)\b",
                 r"\bfrom now on\b", r"^\s*rule:", r"\bprefer\s+\S+\s+over\b"]),
    ("profile", 2, [r"\bI am (a|an)\b", r"\bmy (role|job|background|timezone|name)\b", r"\bI work (as|at|on)\b",
                    r"\bmy goals?\b", r"\bI (like|love|enjoy|hate|dislike)\b", r"\bI prefer\b",
                    r"\bmy (family|partner|kids)\b", r"\bI live in\b"]),
    ("learning", 2, [r"\blearned that\b", r"\blesson\b", r"\binsight\b", r"\brule of thumb\b",
                     r"\bhard[-\s]won\b", r"\bmental model\b", r"\bheuristic\b", r"\btakeaway\b",
                     r"\bnext time\b"]),
    ("knowledge/idea", 2, [r"\bidea:", r"\bthesis\b", r"\bhypothesis\b", r"\btheory\b", r"\bwhat if\b",
                           r"\bconcept\b"]),
    ("knowledge/person", 2, [r"\b(?i:met|met with|know|talked to|talked with|spoke with|spoke to|friends with|"
                             r"meeting with|call with|lunch with|coffee with)\s+[A-Z][a-z]+\s+[A-Z][a-z]+",
                             r"\b(he|she|they) (works|worked) (at|for)\b", r"\bcontact:\b"]),
    ("knowledge/company", 1, [r"\b(company|startup|corporation|vendor|competitor)\b",
                              r"\b[A-Z][A-Za-z]+ (Inc|Ltd|LLC|GmbH|Corp)\b"]),
    ("knowledge/research", 1, [r"\bresearch\b", r"\bstudy (shows|found)\b", r"\baccording to\b",
                               r"\bpaper\b", r"\bdoi\.org\b", r"\bfindings?\b"]),
]
COMPILED = [(t, w, [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in ps]) for t, w, ps in RULES]
# Person-name patterns must stay case-sensitive to mean anything.
COMPILED[4] = ("knowledge/person", 2, [re.compile(RULES[4][2][0]), re.compile(RULES[4][2][1], re.I),
                                       re.compile(RULES[4][2][2], re.I)])

SECRET = re.compile(
    r"(-----BEGIN [A-Z ]*PRIVATE KEY-----|\bAKIA[0-9A-Z]{16}\b|\bgh[pousr]_[A-Za-z0-9]{30,}\b|"
    r"\bsk-[A-Za-z0-9_-]{20,}\b|\bxox[abpr]-[A-Za-z0-9-]{10,}\b|"
    r"\b(password|passwd|api[_-]?key|secret|token)\s*[:=]\s*\S{6,})", re.IGNORECASE)


def kai_home():
    if os.environ.get("KAI_HOME"):
        return Path(os.environ["KAI_HOME"])
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"]) / "kai"
    return Path.home() / ".copilot" / "kai"


def copilot_home():
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"])
    return kai_home().parent


def queue_path():
    return kai_home() / "MEMORY" / "MIGRATION" / "queue.json"


def now():
    return _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat()


# ---------------------------------------------------------------------------
# Reading and chunking (pure, unit-tested)
# ---------------------------------------------------------------------------

def decode(raw):
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16", errors="replace")
    return raw.decode("utf-8-sig", errors="replace")


def strip_frontmatter(text):
    if text.startswith("---\n") or text.startswith("---\r\n"):
        end = re.search(r"^---\s*$", text[3:], re.MULTILINE)
        if end:
            return text[3 + end.end():].lstrip("\r\n")
    return text


def wanted(path):
    return path.suffix.lower() in TEXT_EXT or path.name.lower() in RULE_FILES


def read_sources(source):
    p = Path(source)
    if not p.exists():
        raise FileNotFoundError("source does not exist: %s" % source)
    if p.is_file():
        return [(str(p), decode(p.read_bytes()))]
    out = []
    for root, dirs, files in os.walk(str(p)):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
        for name in sorted(files):
            f = Path(root) / name
            if wanted(f):
                try:
                    out.append((str(f), decode(f.read_bytes())))
                except OSError:
                    continue
    return out


def chunk(file_label, text):
    """Split on H1-H3 headings; without headings, on blank-line paragraph groups."""
    text = strip_frontmatter(text.replace("\r\n", "\n"))
    name = Path(file_label).name or file_label
    chunks = []
    if re.search(r"^#{1,3}\s+\S", text, re.MULTILINE):
        parts = re.split(r"^(#{1,3}\s+.+)$", text, flags=re.MULTILINE)
        if parts[0].strip():
            chunks.append(("%s:preamble" % name, parts[0].strip()))
        for i in range(1, len(parts), 2):
            heading = re.sub(r"^#{1,3}\s+", "", parts[i]).strip()
            body = (parts[i + 1] if i + 1 < len(parts) else "").strip()
            if body:
                chunks.append(("%s:%s" % (name, heading), body))
    else:
        paras = [x.strip() for x in re.split(r"\n\s*\n", text) if len(x.strip()) > 30]
        for i, para in enumerate(paras, 1):
            chunks.append(("%s:p%d" % (name, i), para))
    return [(s, b) for s, b in chunks if len(b) >= MIN_CHUNK]


def classify(body):
    scores = {}
    for target, weight, pats in COMPILED:
        hits = [p.pattern for p in pats if p.search(body)]
        if hits:
            entry = scores.setdefault(target, {"score": 0, "reasons": []})
            entry["score"] += len(hits) * weight
            entry["reasons"].extend("matched /%s/" % h for h in hits)
    if not scores:
        return {"target": "UNCLEAR", "confidence": 0.0, "reasons": ["no patterns matched"],
                "alternatives": []}
    ranked = sorted(scores.items(), key=lambda kv: (-kv[1]["score"], TARGETS.index(kv[0])))
    top_t, top = ranked[0]
    runner = ranked[1][1]["score"] if len(ranked) > 1 else 0
    margin = top["score"] - runner
    confidence = min(1.0, (margin + top["score"] * 0.3) / 10.0)
    return {"target": top_t, "confidence": round(confidence, 3), "reasons": top["reasons"][:3],
            "alternatives": [t for t, _ in ranked[1:4]]}


def band(conf):
    return "trusted" if conf >= TRUSTED else ("confirm" if conf >= MEDIUM else "walk-through")


def make_id(source, section, body):
    return hashlib.sha1(("%s\n%s\n%s" % (source, section, body)).encode("utf-8")).hexdigest()[:10]


def propose(sources):
    out = []
    for label, text in sources:
        for section, body in chunk(label, text):
            heading = section.split(":", 1)[-1]
            c = classify(body if re.match(r"^(preamble|p\d+)$", heading) else heading + "\n" + body)
            out.append({
                "id": make_id(label, section, body),
                "ts": now(),
                "source": label,
                "section": section,
                "preview": re.sub(r"\s+", " ", body)[:160],
                "body": body,
                "target": c["target"],
                "confidence": c["confidence"],
                "band": band(c["confidence"]),
                "reasons": c["reasons"],
                "alternatives": c["alternatives"],
                "secret": bool(SECRET.search(body)),
                "status": "pending",
            })
    return out


def bulk_eligible(p):
    return (p["status"] == "pending" and not p["secret"] and p["target"] not in GATED
            and p["target"] != "UNCLEAR")


# ---------------------------------------------------------------------------
# Queue storage
# ---------------------------------------------------------------------------

def load_queue():
    q = queue_path()
    if not q.exists():
        return []
    try:
        data = json.loads(q.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, list) else []
    except ValueError:
        return []


def save_queue(items):
    q = queue_path()
    q.parent.mkdir(parents=True, exist_ok=True)
    tmp = q.with_suffix(".tmp")
    tmp.write_text(json.dumps(items, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(str(tmp), str(q))


def merge_queue(existing, new):
    seen = {p["id"] for p in existing}
    added = [p for p in new if p["id"] not in seen]
    return existing + added, len(added)


# ---------------------------------------------------------------------------
# Commit
# ---------------------------------------------------------------------------

def provenance(p):
    return "<!-- migrated from %s :: %s on %s -->" % (p["source"], p["section"], now()[:10])


def norm(text):
    return re.sub(r"\s+", " ", text).strip().lower()


def instructions_file():
    return copilot_home() / "copilot-instructions.md"


def learnings_file():
    return kai_home() / "MEMORY" / "LEARNING" / "learnings.md"


def commit_user_section(p, allow_duplicate=False):
    f = instructions_file()
    if not f.exists():
        return False, "copilot-instructions.md not found at %s" % f
    existing = f.read_text(encoding="utf-8-sig")
    if not allow_duplicate and norm(p["body"]) in norm(existing):
        return False, "duplicate: already in copilot-instructions.md"
    block = "\n\n%s\n%s\n" % (provenance(p), p["body"].strip())
    with open(str(f), "a", encoding="utf-8") as fh:
        if not existing.endswith("\n"):
            fh.write("\n")
        fh.write(block)
    return True, str(f)


def commit_learning(p, allow_duplicate=False):
    line = re.sub(r"\s+", " ", p["body"]).strip()
    if len(line) > 500:
        return False, "too long for a one-line learning (%d chars); use --to knowledge/idea" % len(line)
    f = learnings_file()
    f.parent.mkdir(parents=True, exist_ok=True)
    existing = f.read_text(encoding="utf-8-sig") if f.exists() else "# Learnings\n\n"
    if not allow_duplicate and norm(line) in norm(existing):
        return False, "duplicate: already in learnings.md"
    if not f.exists():
        f.write_text(existing, encoding="utf-8")
    with open(str(f), "a", encoding="utf-8") as fh:
        fh.write("- %s: %s (migrated from %s)\n" % (_dt.date.today().isoformat(), line,
                                                     Path(p["source"]).name))
    return True, str(f)


def title_for(p):
    heading = p["section"].split(":", 1)[-1]
    if heading and not re.match(r"^(preamble|p\d+)$", heading):
        return heading[:80]
    first = re.sub(r"^[#>*\-\s]+", "", p["body"].strip().splitlines()[0])
    return (first[:77] + "...") if len(first) > 80 else first


def commit_knowledge(p, runner=subprocess.run):
    tool = copilot_home() / "skills" / "cortex" / "tools" / "cortex.py"
    if not tool.exists():
        return False, "cortex skill not installed (%s)" % tool
    body = "%s\n\n%s\n" % (provenance(p), p["body"].strip())
    fd, tmp = tempfile.mkstemp(suffix=".md")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(body)
        cmd = [sys.executable, str(tool), "add", KNOWLEDGE_TYPE[p["target"]], title_for(p),
               "--tags", "migrated", "--body-file", tmp, "--status", "seedling",
               "--force-unlinked", "--source-kind", "internal",
               "--source-name", Path(p["source"]).name[:80]]
        r = runner(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                   timeout=60, env=dict(os.environ))
        if r.returncode != 0:
            return False, "cortex add failed: %s" % ((r.stderr or r.stdout or "").strip()[:200])
        return True, (r.stdout or "").strip().splitlines()[-1] if (r.stdout or "").strip() else "added"
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def commit(p, allow_duplicate=False, runner=subprocess.run):
    t = p["target"]
    if t in KNOWLEDGE_TYPE:
        return commit_knowledge(p, runner)
    if t == "learning":
        return commit_learning(p, allow_duplicate)
    if t in GATED:
        return commit_user_section(p, allow_duplicate)
    return False, "UNCLEAR chunks need --to <target>"


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def summary(props):
    by = {}
    for p in props:
        e = by.setdefault(p["target"], {"n": 0, "conf": 0.0})
        e["n"] += 1
        e["conf"] += p["confidence"]
    return {t: {"chunks": v["n"], "avg_confidence": round(v["conf"] / v["n"], 3)} for t, v in by.items()}


def cmd_scan(ns):
    try:
        if ns.stdin:
            # Raw bytes: PowerShell 5.1 pipes may arrive as UTF-16 or UTF-8 with a BOM,
            # and the console code page would mangle non-ASCII text.
            sources = [("<stdin>", decode(sys.stdin.buffer.read()))]
        else:
            sources = read_sources(ns.source)
    except (FileNotFoundError, OSError) as e:
        print(str(e), file=sys.stderr)
        return 2
    props = propose(sources)
    added = 0
    if not ns.dry_run and props:
        items, added = merge_queue(load_queue(), props)
        save_queue(items)
    result = {
        "sources": len(sources), "chunks": len(props), "added_to_queue": added,
        "avg_confidence": round(sum(p["confidence"] for p in props) / len(props), 3) if props else 0.0,
        "by_target": summary(props),
        "unclear": sum(1 for p in props if p["target"] == "UNCLEAR"),
        "low_confidence": sum(1 for p in props if p["band"] == "walk-through" and p["target"] != "UNCLEAR"),
        "secrets_flagged": sum(1 for p in props if p["secret"]),
        "queue": None if ns.dry_run else str(queue_path()),
    }
    if ns.json:
        result["proposals"] = props
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    print("Scanned %d source(s), %d chunk(s), avg confidence %d%%"
          % (result["sources"], result["chunks"], round(result["avg_confidence"] * 100)))
    for t, v in sorted(result["by_target"].items(), key=lambda kv: -kv[1]["chunks"]):
        print("  %-20s %3d chunks  (%d%% avg)" % (t, v["chunks"], round(v["avg_confidence"] * 100)))
    if result["unclear"]:
        print("  %d UNCLEAR chunk(s) need the user's routing call" % result["unclear"])
    if result["low_confidence"]:
        print("  %d chunk(s) under 40%% confidence: walk through them" % result["low_confidence"])
    if result["secrets_flagged"]:
        print("  %d chunk(s) look like they hold secrets: never committed; tell the user" % result["secrets_flagged"])
    print("Queue: %s" % ("(dry run, not written)" if ns.dry_run else "%s (+%d new)" % (queue_path(), added)))
    return 0


def select(items, status=None, target=None):
    out = items
    if status and status != "all":
        out = [p for p in out if p["status"] == status]
    if target:
        out = [p for p in out if p["target"] == target]
    return out


def cmd_list(ns):
    rows = select(load_queue(), ns.status, ns.target)
    if ns.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return 0
    if not rows:
        print("no proposals match")
        return 0
    for p in rows:
        flag = " SECRET" if p["secret"] else ""
        print("%s  %-18s %3d%% %-12s %-8s%s  %s" % (p["id"], p["target"], round(p["confidence"] * 100),
                                                   p["band"], p["status"], flag, p["preview"][:70]))
    return 0


def find(items, pid):
    for p in items:
        if p["id"] == pid:
            return p
    return None


def cmd_show(ns):
    p = find(load_queue(), ns.id)
    if not p:
        print("no proposal %s" % ns.id, file=sys.stderr)
        return 1
    print("id:          %s" % p["id"])
    print("source:      %s :: %s" % (p["source"], p["section"]))
    print("target:      %s (%d%%, %s)" % (p["target"], round(p["confidence"] * 100), p["band"]))
    print("alternatives: %s" % (", ".join(p["alternatives"]) or "-"))
    print("reasons:     %s" % "; ".join(p["reasons"]))
    print("status:      %s%s" % (p["status"], "  (SECRET-LIKE CONTENT: do not commit)" if p["secret"] else ""))
    print("-" * 60)
    print(SECRET.sub("[REDACTED]", p["body"]) if p["secret"] else p["body"])
    return 0


def cmd_approve(ns):
    items = load_queue()
    if ns.id:
        p = find(items, ns.id)
        if not p:
            print("no proposal %s" % ns.id, file=sys.stderr)
            return 1
        if p["status"] != "pending":
            print("proposal %s is already %s" % (p["id"], p["status"]), file=sys.stderr)
            return 1
        if ns.to:
            if ns.to not in TARGETS or ns.to == "UNCLEAR":
                print("--to must be one of: %s" % ", ".join(TARGETS[:-1]), file=sys.stderr)
                return 2
            p["target"] = ns.to
        if p["target"] == "UNCLEAR":
            print("UNCLEAR: pick a destination with --to", file=sys.stderr)
            return 2
        if p["secret"]:
            print("refused: this chunk looks like it holds a secret; it is never committed", file=sys.stderr)
            return 1
        if p["target"] in GATED and not ns.confirm:
            print("%s chunks change the user's own instructions: show the chunk, get a yes, "
                  "then re-run with --confirm" % p["target"], file=sys.stderr)
            return 2
        chosen = [p]
    elif ns.trusted:
        chosen = [p for p in items if bulk_eligible(p) and p["confidence"] >= TRUSTED]
    elif ns.target:
        if ns.target in GATED or ns.target == "UNCLEAR":
            print("%s chunks are approved one at a time with --id" % ns.target, file=sys.stderr)
            return 2
        chosen = [p for p in items if bulk_eligible(p) and p["target"] == ns.target]
    else:
        print("approve needs --trusted, --target T or --id ID", file=sys.stderr)
        return 2
    if not chosen:
        print("nothing to approve")
        return 1
    failures = 0
    for p in chosen:
        if ns.dry_run:
            print("would commit %s -> %s  %s" % (p["id"], p["target"], p["preview"][:60]))
            continue
        ok, info = commit(p, ns.allow_duplicate)
        if ok:
            p["status"] = "approved"
            p["committed"] = {"ts": now(), "to": info}
            print("committed %s -> %s (%s)" % (p["id"], p["target"], info))
        else:
            failures += 1
            if info.startswith("duplicate"):
                p["status"] = "duplicate"
            print("skipped %s: %s" % (p["id"], info))
    if not ns.dry_run:
        save_queue(items)
    return 1 if failures and failures == len(chosen) else 0


def cmd_reject(ns):
    items = load_queue()
    n = 0
    for pid in ns.ids:
        p = find(items, pid)
        if p and p["status"] == "pending":
            p["status"] = "rejected"
            n += 1
    save_queue(items)
    print("rejected %d proposal(s)" % n)
    return 0 if n else 1


def cmd_clear(ns):
    items = load_queue()
    keep = [] if ns.all else [p for p in items if p["status"] == "pending"]
    save_queue(keep)
    print("removed %d proposal(s), %d left" % (len(items) - len(keep), len(keep)))
    return 0


def cmd_targets(_ns):
    for t in TARGETS:
        print(t)
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="migrate.py", description="Kai content intake")
    sub = p.add_subparsers(dest="cmd")
    s = sub.add_parser("scan")
    src = s.add_mutually_exclusive_group(required=True)
    src.add_argument("--source")
    src.add_argument("--stdin", action="store_true")
    s.add_argument("--json", action="store_true")
    s.add_argument("--dry-run", action="store_true")
    s.set_defaults(fn=cmd_scan)
    ls = sub.add_parser("list")
    ls.add_argument("--status", default="pending",
                    choices=["pending", "approved", "rejected", "duplicate", "all"])
    ls.add_argument("--target")
    ls.add_argument("--json", action="store_true")
    ls.set_defaults(fn=cmd_list)
    sh = sub.add_parser("show")
    sh.add_argument("id")
    sh.set_defaults(fn=cmd_show)
    a = sub.add_parser("approve")
    a.add_argument("--trusted", action="store_true")
    a.add_argument("--target")
    a.add_argument("--id")
    a.add_argument("--to")
    a.add_argument("--confirm", action="store_true")
    a.add_argument("--dry-run", action="store_true")
    a.add_argument("--allow-duplicate", action="store_true")
    a.set_defaults(fn=cmd_approve)
    r = sub.add_parser("reject")
    r.add_argument("ids", nargs="+")
    r.set_defaults(fn=cmd_reject)
    c = sub.add_parser("clear")
    c.add_argument("--all", action="store_true")
    c.set_defaults(fn=cmd_clear)
    t = sub.add_parser("targets")
    t.set_defaults(fn=cmd_targets)
    return p


def _utf8_stdio():
    """Windows consoles and pipes default to a legacy code page; never crash on a CJK name or an emoji."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            pass


def main(argv=None):
    _utf8_stdio()
    p = build_parser()
    ns = p.parse_args(argv)
    if not getattr(ns, "fn", None):
        p.print_help()
        return 2
    return ns.fn(ns)


if __name__ == "__main__":
    sys.exit(main())
