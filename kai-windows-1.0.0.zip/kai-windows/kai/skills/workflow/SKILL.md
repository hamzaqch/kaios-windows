---
name: workflow
description: "Run a deterministic multi-agent workflow: a script of Copilot agent steps that fan out in parallel under a concurrency cap, flow through pipelines with no barrier, return validated structured JSON, retry on failure, journal every step, resume from the journal, and finish with a synthesis step. Use when the user says workflow, fan out, run agents in parallel, orchestrate agents, sweep, audit everything, review thoroughly, be comprehensive, judge panel, adversarial verify, loop until dry, or when a task is too big or too important for one context (broad reviews, migrations over many files, multi-angle research, design bake-offs). Not for a single quick question (just answer) or a one-off delegation (use @kai-researcher / @kai-engineer directly)."
argument-hint: "<spec.json|spec.py> [--args JSON] | example | list | show <run> | resume <run>"
---

# Workflow

One context can hold one line of thought. A workflow holds many: it spawns independent `copilot` processes, each a clean context with one job, and a small Python orchestrator decides what runs, in what order, how outputs are checked, and how they come back together. Control flow lives in code, not in the model's judgment, so fan-out, voting, retries and loops behave the same every run.

The engine is `~/.copilot/kai/bin/kai_workflow.py` (Python 3.8+ stdlib, works on Windows and Linux). Each step is one non-interactive run of the Copilot CLI with the prompt piped on stdin, `--output-format json`, `--no-ask-user`, an optional `--agent kai-<name>`, and `--allow-all-tools` **only when the spec says so**.

## When I use it

- **Comprehensive**: the work decomposes into parts that can be covered in parallel (every module, every source, every dimension).
- **Confident**: a claim matters enough to get independent perspectives and adversarial checks before I commit to it.
- **Scale**: more material than one context can hold (repo-wide audits, migrations, broad sweeps).

I scout first in my own context (list the files, scope the diff, find the sources) to discover the work list, then hand that list to a workflow as `--args`. For multi-phase work (understand, design, implement, review) I run one workflow per phase and read each result before choosing the next, so I stay in the loop. A quick question or one delegation does not need a workflow.

## Running it

From PowerShell (Windows) or a shell:

```
python "$HOME\.copilot\kai\bin\kai_workflow.py" run review.json --args @args.json   # Windows PowerShell
python ~/.copilot/kai/bin/kai_workflow.py run review.json --args '{"path": "src/"}'  # bash / pwsh 7.3+
python ~/.copilot/kai/bin/kai_workflow.py run review.json --dry-run      # trace steps, spend nothing
python ~/.copilot/kai/bin/kai_workflow.py validate review.json
python ~/.copilot/kai/bin/kai_workflow.py list
python ~/.copilot/kai/bin/kai_workflow.py show <run-id> [--full]
python ~/.copilot/kai/bin/kai_workflow.py resume <run-id>                # finished steps come from the journal
python ~/.copilot/kai/bin/kai_workflow.py example json|py                 # starter spec
```

**Windows PowerShell 5.1 and `--args`:** it strips the inner double quotes when it passes `'{"path": "src/"}'` to a native program, so the engine receives `{path: src/}`. Write the JSON to a file (`Set-Content args.json '{"path": "src/"}' -Encoding UTF8`) and pass `--args @args.json`. A value that starts with `{` or `[` but does not parse is rejected with this hint rather than passed on as a plain string.

Run overrides: `--concurrency N`, `--max-agents N`, `--timeout SEC`, `--retries N`, `--cwd DIR`, `--quiet`. The final summary is printed as JSON on stdout (`status`, `result`, `failed_steps`, `agents_spawned`, `cache_hits`, `journal`); progress goes to stderr. Exit code is 0 only when the run finished.

**Cost.** Every step is a premium request. Always `--dry-run` a new spec first, keep `max_agents` honest, and tell the user the expected agent count before a big run.

## Spec format 1: JSON (declarative)

```json
{
  "name": "review-module",
  "description": "one line",
  "defaults": {"agent": "kai-reviewer", "concurrency": 4, "retries": 1, "timeout": 900, "max_agents": 60},
  "phases": [
    {"title": "Find", "steps": [
      {"id": "find", "prompt": "Find bugs in {{args.path}}", "schema": {"type": "object", "required": ["bugs"], "properties": {"bugs": {"type": "array"}}}}
    ]},
    {"title": "Verify", "foreach": "steps.find.bugs", "limit": 12, "stages": [
      {"id": "verify", "repeat": 3, "prompt": "Try to refute: {{item}}", "schema": {"type": "object", "required": ["refuted"], "properties": {"refuted": {"type": "boolean"}}}}
    ]}
  ],
  "synthesis": {"prompt": "Keep bugs that most verifiers did not refute. {{results}}"}
}
```

- **Phases run in order.** A phase holds either `steps` (all run in parallel, a barrier at the end) or `foreach` + `stages` (a pipeline).
- **`foreach`** is a path into earlier results (`steps.<id>.<field>`, `args.files`) or a literal list. Each item flows through every stage on its own, with **no barrier between stages**: item 2 can be in stage 3 while item 1 is still in stage 1. `limit` caps the items and logs what it dropped.
- **Templates**: `{{args.x}}`, `{{steps.<id>}}`, `{{steps.<id>.field}}`, `{{steps.<id>[0]}}`; inside a pipeline also `{{item}}`, `{{index}}`, `{{prev}}` (the previous stage's output for this item); with `repeat` also `{{attempt}}`. In `synthesis`, `{{results}}` is every step's output; if the prompt does not use it, all results are appended as JSON automatically. Non-string values render as JSON. An undefined variable is an error, not a blank: the run aborts with `spec error: ...` before that step spawns.
- **Step keys**: `id`, `prompt`, `schema`, `agent`, `model`, `effort` (`low`..`max`), `allow_all_tools`, `allow_tools` / `deny_tools` (Copilot `--allow-tool` rules such as `shell(git:*)`), `add_dirs`, `extra_args`, `retries`, `timeout`, `cwd`, `required`, `repeat` (N independent copies, returns a list; each copy is told it is independent), `label`. Any of these except `id`/`prompt`/`repeat`/`label` can sit in `defaults`.
- **Results**: a step's output is its final text, or the validated object when it has a `schema`. A `foreach` stage's output is a list aligned with the items. A step that failed every attempt is `null`, and the run continues (fail-open) unless the step is `required: true`, which aborts the run: live sibling processes are killed and queued steps never start.

## Spec format 2: Python (for loops and conditionals)

A `.py` file defines `META` and `run(wf, args)`. It is executed as your own code, so only run workflow files you wrote or reviewed.

```python
META = {"name": "panel", "description": "...", "defaults": {"agent": "kai-architect", "concurrency": 4}}

def run(wf, args):
    wf.phase("Design")
    scored = wf.pipeline(ANGLES,
        lambda prev, angle, i: wf.agent(f"Design for {args['problem']} from angle {angle}", label=f"design-{i}"),
        lambda design, angle, i: wf.agent(f"Score 0-10:\n{design}", schema=SCORE, agent="kai-reviewer"))
    wf.log(f"{sum(1 for s in scored if s)} designs scored")
    return wf.synthesize("Merge the best design with the runners-up' best ideas.", results=scored)
```

| Call | What it does |
|------|--------------|
| `wf.agent(prompt, schema=None, label=None, agent=None, model=None, effort=None, allow_all_tools=None, allow_tools=None, deny_tools=None, add_dirs=None, extra_args=None, retries=None, timeout=None, cwd=None, required=False)` | One Copilot run. Returns text, the validated dict, or `None` after all attempts fail. |
| `wf.parallel([thunk, ...])` | Run callables concurrently; a barrier. A thunk that raises yields `None`. |
| `wf.pipeline(items, stage1, stage2, ...)` | Each item runs through every stage independently. Stages get `(prev, item, index)`. A stage that raises or returns `None` drops that item to `None`. |
| `wf.synthesize(prompt, results=None, schema=None, **kw)` | One agent that sees `results` (default: every step output so far) as JSON. |
| `wf.phase(title)`, `wf.log(msg)`, `wf.args` | Progress grouping, journal and stderr messages, the `--args` value. |

**Default to `pipeline`.** Use a barrier (`parallel` between stages) only when the next stage needs all prior results together: dedup across the whole set before expensive verification, an early exit when the count is zero, or a prompt that compares findings with each other. "I need to flatten or filter first" is not a reason; do it inside a stage.

## Structured output

With a `schema`, the prompt gets an output contract: end the final message with one fenced `json` block holding an object that matches the schema (a JSON Schema subset: `type`, `required`, `properties`, `items`, `enum`, `minItems`, `maxItems`, `minLength`, `minimum`, `maximum`, `additionalProperties: false`). The engine takes the last fenced object (falling back to the last bare `{...}`), validates it, and on a miss retries with the exact validation error appended. The schema root must be `type: object` and `required` must be a subset of `properties`.

## Journal and resume

Every run lives in `~/.copilot/kai/MEMORY/STATE/workflows/<run-id>/`:

- `journal.jsonl`: one line per event (`run_start`, `phase`, `step_start`, `step_done` with the output and usage, `step_fail` with the error and output tail, `step_dead`, `cache_hit`, `log`, `run_end`). Each step records the Copilot `session_id`, so its full transcript is at `~/.copilot/session-state/<session_id>/events.jsonl`.
- `run.json` (spec path, args, settings) and `result.json` (the final summary).

`resume <run-id>` (or `run <spec> --resume <run-id>`) replays the spec and returns any step whose prompt, schema and flags hash to a finished step instantly; only new, changed or failed steps run live. Edit a later phase and resume: the earlier phases cost nothing. Before diagnosing an odd result, read the journal; it holds each step's actual output.

## Quality patterns

Pick by task and compose. Worked examples are in `examples/` next to this file.

- **Adversarial verify** (`examples/adversarial-review.json`): for each finding, N independent skeptics each prompted to REFUTE it, defaulting to refuted when unsure. Keep a finding only when a majority fail to refute it. This kills plausible-but-wrong findings.
- **Perspective-diverse verify**: when a claim can fail in several ways, give each verifier a different lens (reproduces? reachable? impact real? security?) instead of N identical refuters.
- **Judge panel** (`examples/judge-panel.py`): N attempts from deliberately different angles, scored by parallel judges, the winner synthesized with the runners-up's best ideas. Beats iterating on one attempt when the solution space is wide.
- **Loop-until-dry** (`examples/loop-until-dry.py`): for discovery of unknown size, keep running diverse finders until K consecutive rounds return nothing new. Dedup against everything seen (not only what was confirmed) or rejected items come back every round and the loop never converges. Keep a round cap and log if it was hit.
- **Multi-modal sweep + completeness critic** (`examples/research-sweep.json`): parallel agents each search a different way (primary sources, practitioners, contrarian, recent); a critic then asks what is missing (angle not run, claim on one weak source, researcher that returned null), and those gaps become the next round of work.
- **No silent caps**: if a workflow bounds coverage (a `limit`, a round cap, sampling, a failed step), log it and say it in the report. Silent truncation reads as full coverage.

Scale to the request: "find any bugs" means a few finders and a single verify; "audit this thoroughly" means more finders, 3 to 5 skeptic votes, and a synthesis stage.

## Rules for workers

- Workers' final text is data for the orchestrator. Child processes run with `KAI_WORKFLOW_CHILD=1` and `KAI_FORMAT_GATE=0`, so the Kai response-format gate does not apply to them; prompts should still ask for raw output, no banner.
- Prompts must be self-contained: a worker has no memory of my conversation. Name the files, the question, and what done looks like.
- `--allow-all-tools` is opt-in per spec or step. Without it, a headless worker can only use tools that are pre-approved (`allow_tools`) and everything else is denied. The Kai preToolUse safety rules apply inside workers either way.
- Workers that write files in parallel must not touch the same files: partition the work list by file, or give each worker its own `cwd`.
- After a run I read `result.json`, check `failed_steps`, and report what was covered, what failed, and what was dropped, before claiming anything was verified.
