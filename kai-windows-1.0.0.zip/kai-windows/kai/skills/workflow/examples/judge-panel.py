"""Judge panel: N independent designs from different angles, each scored by a panel of
lens-diverse judges, then the winner is synthesized with the best ideas of the runners-up.

Run:  python ~/.copilot/kai/bin/kai_workflow.py run judge-panel.py --args '{"problem": "..."}'
(Windows PowerShell 5.1 mangles inline JSON: put it in args.json and pass --args @args.json.)
"""
META = {
    "name": "judge-panel",
    "description": "Three design attempts from different angles, scored by three judges each, merged into one.",
    "defaults": {"agent": "kai-architect", "concurrency": 4, "retries": 1, "timeout": 1200},
}

ANGLES = [
    "MVP-first: the smallest design that fully solves the problem",
    "risk-first: design around the failure modes and how to detect them",
    "user-first: design from the experience of the person using it",
]
LENSES = ["correctness and completeness", "simplicity and cost to build", "operability and failure handling"]
SCORE = {
    "type": "object",
    "required": ["score", "strengths", "weaknesses"],
    "properties": {
        "score": {"type": "integer", "minimum": 0, "maximum": 10},
        "strengths": {"type": "array", "items": {"type": "string"}},
        "weaknesses": {"type": "array", "items": {"type": "string"}},
    },
}


def run(wf, args):
    problem = args.get("problem") if isinstance(args, dict) else args
    if not problem:
        raise ValueError("pass --args '{\"problem\": \"...\"}'")

    def design(_prev, angle, i):
        return wf.agent(f"Design a solution.\n\nProblem: {problem}\n\nYour angle: {angle}\n"
                        "Give the design, the key decisions with reasons, and what you deliberately left out.",
                        label=f"design-{i}")

    def judge(text, angle, i):
        votes = wf.parallel([
            (lambda lens=lens, k=k: wf.agent(
                f"Judge this design strictly through the lens of {lens}. Problem: {problem}\n\n{text}",
                schema=SCORE, agent="kai-reviewer", label=f"judge-{i}-{k}"))
            for k, lens in enumerate(LENSES)])
        votes = [v for v in votes if v]
        if not votes:
            return None
        return {"angle": angle, "design": text, "votes": votes,
                "score": sum(v["score"] for v in votes) / len(votes)}

    wf.phase("Design and judge")
    scored = [s for s in wf.pipeline(ANGLES, design, judge) if s]  # no barrier: each design is judged as soon as it exists
    dropped = len(ANGLES) - len(scored)
    if dropped:
        wf.log(f"{dropped} design(s) produced no design or no judge votes and were dropped")
    if not scored:
        return {"error": "no design survived"}
    scored.sort(key=lambda s: s["score"], reverse=True)

    wf.phase("Synthesis")
    final = wf.synthesize(
        "Write the final design. Start from the highest-scored design, fix the weaknesses its judges named, "
        "and graft in the strongest ideas from the runners-up. Credit each grafted idea to its angle.",
        results=scored)
    return {"ranking": [{"angle": s["angle"], "score": round(s["score"], 2)} for s in scored], "final": final}
