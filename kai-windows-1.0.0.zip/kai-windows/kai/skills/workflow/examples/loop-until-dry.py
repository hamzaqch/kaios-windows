"""Loop-until-dry discovery: keep running diverse finders until two consecutive rounds surface
nothing new, verify every fresh finding with lens-diverse skeptics, report the survivors.

Run:  python ~/.copilot/kai/bin/kai_workflow.py run loop-until-dry.py --args '{"target": "src/", "kind": "bugs"}'
(Windows PowerShell 5.1 mangles inline JSON: put it in args.json and pass --args @args.json.)
"""
META = {
    "name": "loop-until-dry",
    "description": "Find issues round after round until two rounds add nothing new; verify each with three lenses.",
    "defaults": {"agent": "kai-reviewer", "concurrency": 4, "retries": 1, "timeout": 900, "max_agents": 120},
}

FINDERS = [
    "read the code top to bottom and look for logic errors",
    "start from the inputs and trace them through; look for unvalidated or mishandled data",
    "start from error paths and cleanup code; look for what happens when things fail",
]
LENSES = ["does it reproduce from the code as written", "is it reachable from a real caller", "is the impact real"]
FOUND = {
    "type": "object", "required": ["items"],
    "properties": {"items": {"type": "array", "items": {
        "type": "object", "required": ["where", "what"],
        "properties": {"where": {"type": "string"}, "what": {"type": "string"}}}}},
}
VERDICT = {"type": "object", "required": ["real", "why"],
           "properties": {"real": {"type": "boolean"}, "why": {"type": "string"}}}
MAX_ROUNDS = 6


def key(item):
    return (item["where"].strip().lower(), " ".join(item["what"].lower().split())[:120])


def run(wf, args):
    target = args.get("target", ".") if isinstance(args, dict) else str(args or ".")
    kind = args.get("kind", "bugs") if isinstance(args, dict) else "bugs"
    seen, confirmed, rejected = set(), [], []
    dry, rnd = 0, 0
    while dry < 2 and rnd < MAX_ROUNDS:
        rnd += 1
        wf.phase(f"Round {rnd}")
        known = "\n".join(f"- {w}: {t}" for w, t in sorted(seen)) or "(none yet)"
        found = wf.parallel([
            (lambda f=f, i=i: wf.agent(
                f"Find {kind} in {target}. Method: {f}.\nAlready known (do not repeat these):\n{known}\n"
                "Report only what you verified in the code. Empty list if you found nothing new.",
                schema=FOUND, label=f"r{rnd}-finder-{i}"))
            for i, f in enumerate(FINDERS)])
        fresh = []
        for res in filter(None, found):
            for item in res["items"]:
                if key(item) not in seen:
                    seen.add(key(item))  # dedup against everything seen, not only confirmed, so the loop converges
                    fresh.append(item)
        if not fresh:
            dry += 1
            wf.log(f"round {rnd}: nothing new ({dry}/2 dry rounds)")
            continue
        dry = 0
        wf.log(f"round {rnd}: {len(fresh)} new candidate(s)")

        def verify(item, n):
            votes = wf.parallel([
                (lambda lens=lens, k=k: wf.agent(
                    f"Judge this reported issue through one lens: {lens}. Read the code. If you cannot confirm it, "
                    f"real=false.\n\nWhere: {item['where']}\nWhat: {item['what']}",
                    schema=VERDICT, label=f"r{rnd}-verify-{n}-{k}"))
                for k, lens in enumerate(LENSES)])
            yes = sum(1 for v in votes if v and v["real"])
            return {"item": item, "votes": votes, "real": yes >= 2}

        for v in wf.parallel([(lambda it=it, n=n: verify(it, n)) for n, it in enumerate(fresh)]):
            if v:
                (confirmed if v["real"] else rejected).append(v)
    if rnd >= MAX_ROUNDS and dry < 2:
        wf.log(f"stopped at the {MAX_ROUNDS}-round cap before going dry; coverage may be incomplete")
    return {"rounds": rnd, "confirmed": [c["item"] for c in confirmed],
            "rejected": [r["item"] for r in rejected], "went_dry": dry >= 2}
