---
name: cortex
description: "Operate Kai's long-term knowledge: the typed Knowledge Archive (People, Companies, Ideas, Research notes with typed related: links, so the archive is a graph) plus recall of prior work across task ISAs, project ISAs, session logs and past Copilot sessions. Search, add, ingest a URL or file with a ripple pass through related notes, harvest candidates, develop seedlings, find contradictions, traverse the graph, retrieve ranked context, write a weekly digest, and recall past work by topic or date phrase. Use when the user says cortex, knowledge base, what do we know about X, add this to knowledge, save this person/company/idea, ingest this article, harvest, develop notes, contradictions, knowledge graph, weekly digest, recall, what did we do, prior work, previous sessions, pick up where we left off, yesterday's work, last week, or the one about X. NOT FOR one-line lessons (use /memory) or web research (use /research)."
argument-hint: "[status|search|add|ingest|harvest|develop|contradictions|graph|retrieve|distill|recall] <args>"
---
# Cortex

Two halves, one tool. The **Knowledge Archive** is curated, typed notes in `~/.copilot/kai/MEMORY/KNOWLEDGE/<People|Companies|Ideas|Research>/`, each with the kb-v3 envelope and typed `related:` links (`Schema.md`). **Recall** finds prior work by topic or date phrase across task ISAs, project ISAs, session logs and Copilot transcripts. Notes saved in isolation are never found again; mandatory typed links built at write time are what make the archive retrievable.

Tool (stdlib Python; every command takes `--json`):

```
python ~/.copilot/skills/cortex/tools/cortex.py <command> ...
```

## Routing

If the arguments match no subcommand, treat them as a `search` query; if search finds nothing, try `recall`.

| Trigger | Command / workflow |
|---|---|
| `/cortex` (no args), "knowledge status" | `cortex.py status` |
| "what do we know about X", `/cortex <query>` | `cortex.py search "<q>"`, then `retrieve "<q>"` for ranked excerpts; read the best notes |
| "add <person/company/idea/research> X" | `Workflows/Add.md` |
| "ingest <url or file>", "save this article" | `Workflows/Ingest.md` |
| "harvest", process the capture queue | `Workflows/Harvest.md` |
| "develop notes", weekly gardening | `Workflows/Develop.md` |
| "contradictions", "what conflicts" | `Workflows/Contradictions.md` |
| "knowledge graph", "what connects to X" | `cortex.py graph [slug] --hops 2` |
| "weekly digest", "distill" | `Workflows/Distill.md` |
| "recall", "what did we do", "last week", "pick up where we left off" | `Workflows/Recall.md` |
| schema check | `cortex.py lint` (exit 1 on errors) |

**Done looks like:** answers cite note paths or recall paths; every new or changed note passes `cortex.py lint`; nothing about past work is stated without a hit to point at.

## Rules

- **Write the archive only through `cortex.py`** (`add`, `link`, `promote`, `touch`, `queue`). It mints ids, enforces the envelope, validates related slugs and keeps the indexes and `_log.md` current. Editing a note's body in place with the edit tool is fine; run `cortex.py touch <slug>` afterwards, and `cortex.py lint` before saying done.
- **Every note ships with 2+ typed `related:` links** once the archive has 2+ notes (`add` refuses otherwise and prints candidates). Use `cortex.py suggest` to find them. `--force-unlinked` is only for a note that genuinely relates to nothing yet.
- **Topic is a tag, not a type.** A security insight is an `idea` tagged `security`; a security vendor is a `company` tagged `security`. If it isn't a person, company, idea or research write-up, it isn't knowledge: one-line lessons go to `kai.py learn`, task state goes in an ISA.
- **The lookup test:** would someone look this up by name later? If not, don't archive it.
- **Never delete a note without asking.** Superseded notes get a callout and a `contradicts` or `preceded-by` edge instead.
- **Never store secrets, credentials or private details about third parties** beyond what the user explicitly asked to keep.

## Gotchas

- **Wikilinks are strict kebab-case** (`[[prompt-injection]]`, not `[[Prompt Injection]]`); `lint` flags anything else as an orphan or non-kebab link.
- **`created`/`updated` are archive dates, not publication dates.** A source's own date goes in `--source-date`. Never guess a date the source doesn't state.
- **Untyped notes** (written by `kai.py memory add` into the archive root) are not part of the graph until promoted; `harvest` queues them for typing.
- **Notes written by `kai.py knowledge add`** land in the type folders without the kb-v3 envelope (no id, quality or convention; `related` as plain slugs), so `lint` reports them. Run `cortex.py adopt --all` to fill the envelope and type the links, then add tags where it says `still needs: tags`. Its `Blogs/` folder is outside the archive's four types and is ignored here.
- **Recall scores token overlap times recency**, so half-remembered phrasing works, but a query of only stopwords finds nothing. Date phrases (`yesterday`, `last week`, `3 days ago`, `2026-11-02`) become filters and the rest of the query still scores.
