# Ingest a source

Reading a source doesn't just create one note; it ripples updates through the existing notes it touches. That ripple is what keeps the archive a living graph instead of a pile of summaries.

**Done looks like:** one primary note created with typed links baked in at creation, every substantively related existing note updated (reverse edge, new evidence, or a contradiction callout), the ripple plan shown to the user, one `_log.md` line summarizing it, and `lint` clean.

## 1. Fetch

- URL: the web fetch tool; if blocked, the research skill's `Workflows/Retrieve.md`.
- File: the view tool.

Summarize in 2-3 sentences and list the key entities, claims and insights. If there is no usable content (paywall stub, empty page), stop and say so.

## 2. Classify and draft the primary note

Most sources become an `idea`; a multi-source investigation with a method becomes `research`; a profile becomes `person` or `company`. Check for duplicates first (`cortex.py search`, and `queue list` for an existing capture of the same URL).

## 3. Ripple pass

```
python ~/.copilot/skills/cortex/tools/cortex.py suggest "<summary>" --tags <tags> --limit 10
python ~/.copilot/skills/cortex/tools/cortex.py search "<key entity>"
```

Read each candidate (up to 10). Decide whether the new source adds information, adds context, contradicts a claim, or has no substantive connection. Present the plan before writing:

```
INGEST RIPPLE PLAN
  PRIMARY: Ideas/<new-slug> "<Title>" (create)
    related: <slug-1> extends, <slug-2> supports, <person-slug> related
  RIPPLE:
    <slug-1>: add reverse edge (extends) + [[new-slug]] in Implications
    <slug-2>: add the new data point to Evidence + reverse edge
    <slug-3>: CONTRADICTION - source says X, note says Y (contradicts)
  NO CHANGE: <slug-4> (shares a tag, no real connection)
```

Low-risk cross-references can proceed without waiting; content changes to existing notes and contradiction callouts wait for the user's yes.

## 4. Execute

- Primary: `cortex.py add <type> "<title>" --tags ... --related ... --body-file <tmp> --source-url <url> --source-kind <kind> [--source-date <as stated>]`.
- Reverse edges: `cortex.py link <existing> <new-slug> <type>`.
- Body updates: edit the existing note's prose in place, then `cortex.py touch <slug>`.
- Contradictions: add `> **Contradiction:** this note claims X; [[new-slug]] reports Y.` to the older note and a `contradicts` edge both ways.

## 5. Log

```
python ~/.copilot/skills/cortex/tools/cortex.py log "ingest | <Title> | source <url> | primary Ideas/<slug> | ripple N updated, N contradictions"
python ~/.copilot/skills/cortex/tools/cortex.py lint
```

If the source had been queued (`queue list`), drop the queue entry once the note exists.
