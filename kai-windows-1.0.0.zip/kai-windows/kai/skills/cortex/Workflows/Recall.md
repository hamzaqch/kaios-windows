# Recall

Find prior work by topic, half-remembered words, or a date phrase.

```
python ~/.copilot/skills/cortex/tools/cortex.py recall "<query>" [--since YYYY-MM-DD] [--until YYYY-MM-DD] [--limit 10] [--json]
```

Searches, in one pass:
- **task ISAs:** `~/.copilot/kai/MEMORY/WORK/*/ISA.md` (goal, phase, criteria, decisions)
- **project ISAs:** `ISA.md` in every working directory Kai has logged a session in
- **session logs:** `~/.copilot/kai/MEMORY/LEARNING/sessions/**` (prompts, tool counts, ISAs touched per session)
- **Copilot transcripts:** `~/.copilot/session-state/*/events.jsonl` (the user messages of every past CLI and app session)

Scoring is token overlap times recency. `today`, `yesterday`, `this week`, `last week`, `last month`, `N days ago` and `YYYY-MM-DD` become date filters; the remaining words still score. A date phrase alone lists everything in that window.

## Two modes

1. **Standalone** (`/context-search <topic>`, "what did we do about X"): show the result block, then say "Context loaded on <topic>. Most recent: <title, date>. What would you like to do?" Read the top result's path before answering follow-ups about it.
2. **Paired with a request** (the user asks for something that obviously continues earlier work): run recall quietly first, read the top one or two paths, and use them to ground the answer. Mention which prior session or ISA you built on in one line; don't dump the search block.

## Gotchas

- No hit means no evidence. Say "I found nothing about X in prior sessions" rather than reconstructing from guesswork.
- Transcripts store the original prompt, not what Kai answered. For what was decided, prefer the ISA's Decisions and Verification sections.
- Every query rescans the files (no index). On a large history it takes a second or two; that's expected.
