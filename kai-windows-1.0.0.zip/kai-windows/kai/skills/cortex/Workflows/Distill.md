# Distill

A weekly pass that turns recent archive activity into a short, cited digest. Distill is a router, not a destination: it points at notes and next actions, never creates or edits notes itself (that is `develop`, `contradictions` and `ingest`), and never re-surfaces an item a previous digest already covered.

**Done looks like:** `~/.copilot/kai/MEMORY/KNOWLEDGE/_digests/YYYY-MM-DD-distill.md` with at most 10 items across three lanes, every item citing 2+ source notes as `[[slug]]`, overflow named with a dropped count, and the surfaced notes marked so next week skips them.

## 1. Gather (deterministic)

```
python ~/.copilot/skills/cortex/tools/cortex.py distill gather --days 7
```

Returns new or updated notes in the window (minus already-surfaced ones), hot tags (window count against the archive baseline), and the seedling count.

## 2. Synthesize

Cluster the notes into items. Each item needs 2+ source notes, a why-now line (recent activity, a growing tag cluster, or relevance to an active task ISA), and a one-sentence pitch in plain language. Lanes:
- **Worth writing up:** ideas that could become a post, a doc, or a talk.
- **System improvements:** anything that suggests a change to how Kai works; hand these to `/upgrade` as candidates rather than acting on them here.
- **Archive health:** contradiction candidates and seedling counts, report-only, routed to `/cortex contradictions` or `/cortex develop`.

## 3. Write and mark

Write the digest (lanes as sections; each item: pitch, why now, sources as `[[slug]]` links, suggested next step), then:

```
python ~/.copilot/skills/cortex/tools/cortex.py distill mark --digest <digest path>
```

Reply with the digest path and the top three items.
