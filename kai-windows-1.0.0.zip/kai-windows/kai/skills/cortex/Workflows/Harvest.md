# Harvest

Pulls knowledge candidates out of the rest of Kai's memory into a review queue. Nothing is written to the archive directly; a human-reviewed promotion step turns candidates into typed notes.

**Sources:** untyped notes in the archive root (from `kai.py memory add`), the `## Decisions` of task ISAs whose phase is `complete`, and lessons in `LEARNING/learnings.md`. Each source item is harvested once (state in `MEMORY/STATE/cortex-harvest.json`); an untyped note that grows new content is offered again. Other skills drop captures into the same queue with `cortex.py queue add` (the fabric skill does this for summaries of URLs).

## Steps

1. Preview: `cortex.py harvest --dry-run`. Then run it for real: `cortex.py harvest`.
2. Review the queue: `cortex.py queue list`, `cortex.py queue show <name>`.
3. For each candidate, decide:
   - **Promote**: it passes the lookup test. Create the typed note through `Workflows/Add.md` (or `Ingest.md` if it has a source URL worth reading in full), then `cortex.py queue drop <name>`.
   - **Merge**: it belongs inside an existing note. Edit that note, `touch` it, drop the candidate.
   - **Drop**: transient, duplicated, or task-only. `cortex.py queue drop <name>`.
4. Batch the decisions into one short table for the user before promoting more than three notes, since each promotion becomes permanent archive content.
5. Finish with `cortex.py lint` and `cortex.py status`.
