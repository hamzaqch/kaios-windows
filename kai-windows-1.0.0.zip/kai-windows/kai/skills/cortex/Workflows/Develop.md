# Develop

Weekly gardening: surface seedling notes and enrich the ones that are ready.

```
python ~/.copilot/skills/cortex/tools/cortex.py develop
```

Lists seedlings oldest first, with their empty template sections and up to three link candidates each.

For each seedling worth the time (start with the oldest and the most linked-to):
1. Read the note, its related notes, and anything newer that touches it (`cortex.py retrieve "<title>"`, `cortex.py recall "<title>"` for recent task work).
2. Draft the enrichment: fill empty sections, add evidence, propose new typed links and wikilinks.
3. Show the user the proposed change (a short diff or before/after) and wait for approval.
4. Apply: edit the body, add links with `cortex.py link`, then `cortex.py promote <slug> budding` (or `evergreen` when the note is comprehensive and well-sourced). `promote` updates the `updated` date; leave `created` alone.

If nothing is a seedling, report that the archive is clean. Seedlings untouched for 90+ days show in `cortex.py status` as stale; ask whether to enrich or drop them, never delete silently.
