# Add a note

**Done looks like:** one new note in the right type folder, envelope complete, 2+ typed `related:` links (once the archive has 2+ notes), real body content in the type's sections, and `cortex.py lint` clean.

1. Classify: person, company, idea, or research (see the lookup test in SKILL.md). Topic becomes tags.
2. Check it doesn't already exist: `cortex.py search "<name or key phrase>"`. If it does, enrich that note in place and `touch` it instead.
3. Find links: `cortex.py suggest "<title + one-line summary>" --tags a,b`. Read the top candidates and pick the most specific relationship type for each (`Schema.md`).
4. Write the body to a temp file using the type's sections, with 1 to 3 `[[slug]]` wikilinks where natural. Then:

```
python ~/.copilot/skills/cortex/tools/cortex.py add idea "<Title>" --tags security,llm --related slug-a:extends,slug-b:supports --body-file <tmp.md>
```

   Optional provenance flags: `--source-url <url> --source-kind blog --source-date 2026-10-01 --source-author "<name>" --quality 5`. Keep the command on one line; PowerShell does not treat `\` as a line continuation.

5. Add the reverse edges where they matter: `cortex.py link slug-a <new-slug> extends`.
6. `cortex.py lint`, then reply with the note path and its links.
