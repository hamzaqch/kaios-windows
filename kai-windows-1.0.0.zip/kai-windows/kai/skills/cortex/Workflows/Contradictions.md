# Contradictions

Find and resolve conflicting claims across notes.

```
python ~/.copilot/skills/cortex/tools/cortex.py contradictions
```

Returns explicit `contradicts` edges plus candidate pairs that share 2+ tags and have overlapping validity windows, ranked by overlap.

For each explicit edge and the top 10 candidate pairs, read both notes and compare the key claims (Thesis, Evidence, Findings). Classify:
- **Direct contradiction:** A says X, B says not-X.
- **Superseded:** B's newer evidence makes A's claim outdated.
- **Scope conflict:** both speak to the same question and reach different conclusions under different assumptions.
- **No conflict:** shared topic only.

Report:

```
CONTRADICTION SCAN: N pairs checked, N contradictions, N superseded
  CONTRADICTION: [[note-a]] claims "X"; [[note-b]] claims "Y". Suggested resolution: ...
  SUPERSEDED: [[older]] (2026-01-15) "X is true"; [[newer]] (2026-03-20) "X stopped being true because Y". Action: add correction to older.
```

Only with the user's approval: add a callout to the affected note (`> **Contradiction:** ... see [[other]]` or `> **Updated:** see [[newer]] for current information`), add `contradicts` or `preceded-by` edges with `cortex.py link`, `touch` the edited notes, set `valid_until` on a superseded claim when its end date is known, and finish with `cortex.py lint`.
