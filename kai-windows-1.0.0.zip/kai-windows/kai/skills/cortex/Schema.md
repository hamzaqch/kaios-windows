# Knowledge Archive schema (kb-v3)

`cortex.py` enforces this contract on write (`add`, `link`) and checks it with `lint`. Notes are markdown with flat YAML frontmatter, so any editor or markdown tool can read them.

## Types and folders

| Type | Folder | Body sections (template) |
|---|---|---|
| `person` | `People/` | Who, Why they matter, Notes |
| `company` | `Companies/` | What they do, Why it matters, Notes |
| `idea` | `Ideas/` | Thesis, Evidence, Implications, Open questions |
| `research` | `Research/` | Question, Method, Findings, Sources, Confidence |

Files starting with `_` are tool-owned: `_index.md` (maps of content, regenerated on every add), `_log.md` (append-only change log), `_harvest-queue/` (capture candidates awaiting review), `_digests/` (weekly distill output).

## Envelope (every note)

| Field | Required | Format | Notes |
|---|---|---|---|
| `id` | yes | `kb_` + 12 hex | minted from slug and created date; stable across renames |
| `type` | yes | person, company, idea, research | must match the folder |
| `title` | yes | text | the filename is its kebab-case slug (max 60 chars) |
| `tags` | yes | list, 1+ | topics live here |
| `quality` | yes | 0-10 | below 3 means a stub worth enriching |
| `created` | yes | YYYY-MM-DD | when the note entered the archive |
| `updated` | yes | YYYY-MM-DD | last meaningful edit |
| `convention` | yes | `kb-v3` | schema version |
| `status` | no | inbox, seedling, budding, evergreen | new notes start as `seedling`; only `develop` promotes |
| `confidence` | no | 0-1 | below 0.5 means revisit |
| `source_url`, `source_name`, `source_author`, `source_date` | no | text / date | provenance; `source_date` is the source's own publication date |
| `source_kind` | no | blog, video, paper, tweet, conversation, bookmark, internal | `internal` waives source requirements |
| `valid_from`, `valid_until` | no | date | when a fact was true; the contradiction finder skips non-overlapping windows |
| `related` | yes once 2+ notes exist | list of `{slug, type}` | typed edges, see below |

`research` notes also need `source_url` unless `source_kind: internal`.

## Relationship types

| Type | Meaning |
|---|---|
| `related` | generic association; only when nothing more specific fits |
| `supports` | provides evidence for the linked note |
| `contradicts` | conflicts with the linked note |
| `extends` | builds on the linked note |
| `part-of` | component of a larger whole |
| `instance-of` | example of a pattern |
| `caused-by` | result of the linked note |
| `preceded-by` | came before, in time |
| `derived-from` | distilled from the linked source note |

```yaml
related:
  - slug: other-note-slug
    type: extends
  - slug: another-note
    type: supports
```

Besides frontmatter edges, weave 1 to 3 `[[slug]]` wikilinks into the body where they read naturally. `add` appends a `## Related` list of wikilinks when the body you pass has none.
