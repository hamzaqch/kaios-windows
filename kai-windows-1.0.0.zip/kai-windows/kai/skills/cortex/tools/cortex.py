"""cortex.py - Kai's typed Knowledge Archive plus recall of prior work. Stdlib only.

The archive lives in <Kai home>/MEMORY/KNOWLEDGE/<People|Companies|Ideas|Research>/<slug>.md.
Every note carries the kb-v3 envelope (flat YAML frontmatter) and typed `related:` links,
so the archive is a graph, not a pile. All writes go through this tool.

Archive
  status [--json]                         health: counts, seedlings, orphans, queue, last harvest
  search <query> [--type T] [--tag X] [--json]   title/tags, body and [[wikilink]] passes
  suggest "<text>" [--tags a,b] [--limit 5] [--json]   related-note candidates for a new note
  add <person|company|idea|research> "<title>" --tags a,b [--related slug:type,...]
      [--body TEXT | --body-file F] [--status seedling] [--quality N] [--confidence 0-1]
      [--source-url U] [--source-kind K] [--source-date D] [--source-author A] [--source-name N]
      [--force-unlinked]
  link <from-slug> <to-slug> <type> [--reverse <type>]   add a typed edge (and its mirror)
  promote <slug> <inbox|seedling|budding|evergreen>
  touch <slug>                            set updated: today after an in-place edit
  log "<line>"                            append a dated line to KNOWLEDGE/_log.md
  lint [--json]                           schema conformance; exit 1 on errors
  adopt <slug...> | --all [--dry-run]     fill the kb-v3 envelope on notes written by other tools
                                          (e.g. `kai.py knowledge add`): id, quality, convention, typed related
  index                                   regenerate the _index.md maps of content
  graph [slug] [--hops N] [--json]        graph stats, or the neighborhood of one note
  contradictions [--json]                 note pairs likely to conflict (shared tags, contradicts edges)
  retrieve <query> [--top N] [--raw] [--json]   BM25-ranked compressed context
  develop [--json]                        seedlings to enrich, oldest first

Capture
  harvest [--dry-run] [--json]            candidates from untyped notes, finished ISAs, learnings
  queue list | queue show <name> | queue drop <name>
  queue add --title T [--source-url U] [--type T] [--body TEXT | --body-file F]
  distill gather [--days 7] [--json]      in-window notes + hot tags for the weekly digest
  distill mark --digest <path>            record what a digest surfaced

Recall
  recall "<query>" [--since YYYY-MM-DD] [--until YYYY-MM-DD] [--limit 10] [--json]
      searches task ISAs, project ISAs, session logs and Copilot transcripts; date phrases
      like today, yesterday, last week, this week, last month, "3 days ago", 2026-11-02 work inline.

Exit codes: 0 ok, 1 not found / validation failure, 2 usage error.
"""
import datetime as dt
import hashlib
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict, deque
from pathlib import Path

# ---------------------------------------------------------------- locations


def _kai_home():
    if os.environ.get("KAI_HOME"):
        return Path(os.environ["KAI_HOME"])
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"]) / "kai"
    guess = Path(__file__).resolve().parents[3] / "kai"
    if (guess / "MEMORY").exists() or (guess / "VERSION").exists():
        return guess
    return Path.home() / ".copilot" / "kai"


KAI_HOME = _kai_home()
COPILOT_HOME = Path(os.environ.get("COPILOT_HOME") or KAI_HOME.parent)
MEM = KAI_HOME / "MEMORY"
KNOW = MEM / "KNOWLEDGE"
QUEUE = KNOW / "_harvest-queue"
DIGESTS = KNOW / "_digests"
STATE = MEM / "STATE"

TYPES = {"person": "People", "company": "Companies", "idea": "Ideas", "research": "Research"}
DIR_TO_TYPE = {v: k for k, v in TYPES.items()}
STATUSES = ["inbox", "seedling", "budding", "evergreen"]
REL_TYPES = ["related", "supports", "contradicts", "extends", "part-of", "instance-of",
             "caused-by", "preceded-by", "derived-from"]
SOURCE_KINDS = ["blog", "video", "paper", "tweet", "conversation", "bookmark", "internal"]
REQUIRED = ["id", "type", "title", "tags", "quality", "created", "updated", "convention"]
FIELD_ORDER = ["id", "type", "title", "tags", "status", "quality", "confidence", "source_name", "source_url",
               "source_author", "source_date", "source_kind", "source_session", "created", "updated",
               "valid_from", "valid_until", "convention", "related"]
CONVENTION = "kb-v3"
TEMPLATES = {
    "person": ["Who", "Why they matter", "Notes"],
    "company": ["What they do", "Why it matters", "Notes"],
    "idea": ["Thesis", "Evidence", "Implications", "Open questions"],
    "research": ["Question", "Method", "Findings", "Sources", "Confidence"],
}
STOP = set("the a an on in of to that it is was we you i and or for with this be are at by from as do "
           "did what how why when which about my me our your can will just not no yes".split())
WIKI_RE = re.compile(r"\[\[([^\]|#]+)(?:[|#][^\]]*)?\]\]")

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


class UsageError(Exception):
    pass


class Fail(Exception):
    pass


def today():
    return dt.date.today().isoformat()


def now_iso():
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def kebab(s, limit=60):
    out = re.sub(r"[^a-z0-9]+", "-", str(s).lower()).strip("-")
    return out[:limit].rstrip("-") or "note"


WIN_RESERVED = {"con", "prn", "aux", "nul"} | {f"com{i}" for i in range(1, 10)} | {f"lpt{i}" for i in range(1, 10)}


def file_slug(s, limit=60):
    """kebab() that is also a legal Windows filename stem (CON, NUL, COM1... are device names)."""
    out = kebab(s, limit)
    return out + "-note" if out in WIN_RESERVED else out


def mint_id(slug, created):
    return "kb_" + hashlib.sha1(f"{slug}|{created}".encode("utf-8")).hexdigest()[:12]


def tokens(text):
    return [t for t in re.findall(r"[a-z0-9][a-z0-9'\-]*", str(text).lower()) if t not in STOP and len(t) > 1]


def load_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


# ---------------------------------------------------------------- frontmatter (YAML subset)

def _scalar(v):
    v = v.strip()
    if not v:
        return ""
    if v.startswith('"'):
        try:
            return json.loads(v)
        except ValueError:
            return v.strip('"')
    if v.startswith("'") and v.endswith("'") and len(v) >= 2:
        return v[1:-1].replace("''", "'")
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        return [_scalar(x) for x in _split_inline(inner)] if inner else []
    if v in ("null", "~"):
        return None
    if v in ("true", "false"):
        return v == "true"
    return v


def _split_inline(s):
    out, cur, q = [], "", None
    for ch in s:
        if q:
            cur += ch
            if ch == q:
                q = None
        elif ch in "\"'":
            q = ch
            cur += ch
        elif ch == ",":
            out.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    return [x.strip() for x in out]


def parse_note_text(text):
    """-> (frontmatter dict, body str). Handles scalars, inline lists, block lists and lists of maps."""
    m = re.match(r"^﻿?---\s*\n(.*?)\n---\s*(?:\n|$)", text, re.S)
    if not m:
        return {}, text
    fm, key, lines = {}, None, m.group(1).splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.lstrip().startswith("#"):
            i += 1
            continue
        if not line.startswith((" ", "\t", "-")) and ":" in line:
            key, val = line.split(":", 1)
            key = key.strip()
            val = val.strip()
            fm[key] = _scalar(val) if val else []
            i += 1
            continue
        stripped = line.strip()
        if key and stripped.startswith("- "):
            item = stripped[2:]
            if re.match(r"^[\w-]+:\s", item + " ") and not item.startswith('"'):
                obj = {}
                k, v = item.split(":", 1)
                obj[k.strip()] = _scalar(v)
                i += 1
                while i < len(lines) and lines[i].startswith((" ", "\t")) and not lines[i].strip().startswith("- "):
                    if ":" in lines[i]:
                        k, v = lines[i].split(":", 1)
                        obj[k.strip()] = _scalar(v)
                    i += 1
                if not isinstance(fm.get(key), list):
                    fm[key] = []
                fm[key].append(obj)
                continue
            if not isinstance(fm.get(key), list):
                fm[key] = []
            fm[key].append(_scalar(item))
        i += 1
    return fm, text[m.end():]


def _fmt_scalar(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if v is None:
        return "null"
    s = str(v)
    if s == "" or re.search(r"[:#\[\]{},&*!|>'\"%@`]|^\s|\s$|^-|^\d", s) or s in ("true", "false", "null"):
        return json.dumps(s, ensure_ascii=False)
    return s


def dump_frontmatter(fm):
    keys = [k for k in FIELD_ORDER if k in fm] + sorted(k for k in fm if k not in FIELD_ORDER)
    out = ["---"]
    for k in keys:
        v = fm[k]
        if v is None or v == "" or (isinstance(v, list) and not v and k != "tags"):
            continue
        if k == "related":
            out.append("related:")
            for r in v:
                out.append(f"  - slug: {_fmt_scalar(r.get('slug', ''))}")
                out.append(f"    type: {_fmt_scalar(r.get('type', 'related'))}")
        elif isinstance(v, list):
            out.append(f"{k}: [" + ", ".join(_fmt_scalar(x) for x in v) + "]")
        else:
            out.append(f"{k}: {_fmt_scalar(v)}")
    out.append("---")
    return "\n".join(out) + "\n"


# ---------------------------------------------------------------- note model

class Note:
    def __init__(self, path):
        self.path = Path(path)
        self.slug = self.path.stem
        text = self.path.read_text(encoding="utf-8", errors="replace")
        self.fm, self.body = parse_note_text(text)
        self.typed = self.path.parent.name in DIR_TO_TYPE

    @property
    def type(self):
        return self.fm.get("type") or DIR_TO_TYPE.get(self.path.parent.name, "untyped")

    @property
    def title(self):
        return str(self.fm.get("title") or self.slug)

    @property
    def tags(self):
        t = self.fm.get("tags") or []
        return [str(x).lower() for x in (t if isinstance(t, list) else [t])]

    @property
    def related(self):
        r = self.fm.get("related") or []
        return [x for x in r if isinstance(x, dict) and x.get("slug")]

    @property
    def wikilinks(self):
        return [w.strip() for w in WIKI_RE.findall(self.body)]

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(dump_frontmatter(self.fm) + self.body, encoding="utf-8")
        os.replace(tmp, self.path)


def typed_notes():
    out = []
    for d in TYPES.values():
        folder = KNOW / d
        if folder.is_dir():
            out += [Note(p) for p in sorted(folder.glob("*.md")) if not p.name.startswith("_")]
    return out


def untyped_notes():
    if not KNOW.is_dir():
        return []
    return [Note(p) for p in sorted(KNOW.glob("*.md")) if not p.name.startswith("_")]


def note_map():
    return {n.slug: n for n in typed_notes()}


def get_note(slug):
    n = note_map().get(slug)
    if not n:
        raise Fail(f"no note with slug '{slug}' (run `cortex.py search` to find it)")
    return n


def append_log(line):
    KNOW.mkdir(parents=True, exist_ok=True)
    log = KNOW / "_log.md"
    if not log.exists():
        log.write_text("# Knowledge log\n\n", encoding="utf-8")
    with open(log, "a", encoding="utf-8") as f:
        f.write(f"- [{today()}] {line}\n")


# ---------------------------------------------------------------- arg helpers

def opt(args, name, default=None):
    if name in args:
        i = args.index(name)
        if i + 1 >= len(args):
            raise UsageError(f"{name} needs a value")
        return args[i + 1]
    return default


VALUED = {"--type", "--tag", "--tags", "--limit", "--related", "--body", "--body-file", "--status", "--quality",
          "--confidence", "--source-url", "--source-kind", "--source-date", "--source-author", "--source-name",
          "--reverse", "--hops", "--top", "--since", "--until", "--days", "--digest", "--title"}


def positional(args):
    out, skip = [], False
    for a in args:
        if skip:
            skip = False
        elif a in VALUED:
            skip = True
        elif not a.startswith("--"):
            out.append(a)
    return out


def emit(obj, args, text_fn):
    if "--json" in args:
        print(json.dumps(obj, indent=2, ensure_ascii=False, default=str))
    else:
        print(text_fn(obj))


def read_body(args):
    body, bf = opt(args, "--body"), opt(args, "--body-file")
    if bf:
        return Path(bf).read_text(encoding="utf-8-sig")
    return body


# ---------------------------------------------------------------- scoring helpers

def similarity_candidates(text, tags, exclude=(), limit=5):
    qt, qtags = set(tokens(text)), {t.lower() for t in tags}
    rows = []
    for n in typed_notes():
        if n.slug in exclude:
            continue
        tag_hits = len(qtags & set(n.tags))
        title_hits = len(qt & set(tokens(n.title)))
        body_hits = len(qt & set(tokens(n.body)))
        score = tag_hits * 3 + title_hits * 2 + min(body_hits, 10) * 0.5
        if score > 0:
            rows.append({"slug": n.slug, "type": n.type, "title": n.title, "score": round(score, 2),
                         "shared_tags": sorted(qtags & set(n.tags))})
    rows.sort(key=lambda r: (-r["score"], r["slug"]))
    return rows[:limit]


def parse_related(spec, known):
    out = []
    for part in [p.strip() for p in (spec or "").split(",") if p.strip()]:
        slug, _, typ = part.partition(":")
        slug, typ = slug.strip(), (typ.strip() or "related")
        if typ not in REL_TYPES:
            raise Fail(f"related type '{typ}' not one of: {', '.join(REL_TYPES)}")
        if slug not in known:
            raise Fail(f"related slug '{slug}' does not exist in the archive")
        out.append({"slug": slug, "type": typ})
    return out


# ---------------------------------------------------------------- archive commands

def cmd_add(args):
    pos = positional(args)
    if len(pos) < 2 or pos[0] not in TYPES:
        raise UsageError('usage: cortex.py add <person|company|idea|research> "<title>" --tags a,b '
                         '[--related slug:type,...] [--body TEXT|--body-file F]')
    typ, title = pos[0], pos[1]
    tags = [kebab(t, 40) for t in (opt(args, "--tags") or "").split(",") if t.strip()]
    if not tags:
        raise Fail("at least one tag is required (--tags a,b); topic is a tag, not a type")
    slug = file_slug(title)
    known = note_map()
    path = KNOW / TYPES[typ] / f"{slug}.md"
    if slug in known or path.exists():
        raise Fail(f"'{slug}' already exists at {known[slug].path if slug in known else path}; "
                   f"edit it in place and run `cortex.py touch {slug}`")
    related = parse_related(opt(args, "--related"), known)
    need = min(2, len(known))
    if len(related) < need and "--force-unlinked" not in args:
        cands = similarity_candidates(title + " " + " ".join(tags), tags, limit=6)
        hint = "\n".join(f"  {c['slug']} ({c['type']}, score {c['score']})" for c in cands) or "  (no candidates)"
        raise Fail(f"every note needs {need}+ typed related links (--related slug:type,...). Candidates:\n{hint}\n"
                   "Pass --force-unlinked only when nothing in the archive genuinely relates.")
    status = opt(args, "--status", "seedling")
    if status not in STATUSES:
        raise Fail(f"status must be one of {', '.join(STATUSES)}")
    try:
        quality = int(opt(args, "--quality", "3"))
        assert 0 <= quality <= 10
    except (ValueError, AssertionError):
        raise Fail("--quality must be an integer 0-10")
    kind = opt(args, "--source-kind")
    if kind and kind not in SOURCE_KINDS:
        raise Fail(f"--source-kind must be one of {', '.join(SOURCE_KINDS)}")
    if typ == "research" and not opt(args, "--source-url") and kind != "internal":
        raise Fail("research notes need --source-url (or --source-kind internal)")
    created = today()
    fm = {"id": mint_id(slug, created), "type": typ, "title": title, "tags": tags, "status": status,
          "quality": quality, "created": created, "updated": created, "convention": CONVENTION,
          "related": related}
    conf = opt(args, "--confidence")
    if conf is not None:
        try:
            fm["confidence"] = float(conf)
            assert 0 <= fm["confidence"] <= 1
        except (ValueError, AssertionError):
            raise Fail("--confidence must be a number 0-1")
    for flag, key in (("--source-url", "source_url"), ("--source-date", "source_date"),
                      ("--source-author", "source_author"), ("--source-name", "source_name")):
        if opt(args, flag):
            fm[key] = opt(args, flag)
    if kind:
        fm["source_kind"] = kind
    body = read_body(args)
    if not body:
        body = "\n".join(f"## {h}\n\n" for h in TEMPLATES[typ])
    if not body.lstrip().startswith("# "):
        body = f"# {title}\n\n" + body.lstrip("\n")
    if related and not WIKI_RE.search(body):
        body = body.rstrip() + "\n\n## Related\n\n" + "\n".join(
            f"- {r['type']}: [[{r['slug']}]]" for r in related) + "\n"
    note_path = KNOW / TYPES[typ] / f"{slug}.md"
    note_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = note_path.with_name(note_path.name + ".tmp")
    tmp.write_text(dump_frontmatter(fm) + "\n" + body.lstrip("\n"), encoding="utf-8")
    os.replace(tmp, note_path)
    append_log(f"add | {TYPES[typ]}/{slug} | related: {', '.join(r['slug'] for r in related) or 'none'}")
    build_indexes()
    print(note_path)
    return 0


def cmd_link(args):
    pos = positional(args)
    if len(pos) < 3:
        raise UsageError("usage: cortex.py link <from-slug> <to-slug> <type> [--reverse <type>]")
    src, dst, typ = pos[0], pos[1], pos[2]
    rev = opt(args, "--reverse")
    for t in [typ] + ([rev] if rev else []):
        if t not in REL_TYPES:
            raise Fail(f"relationship type '{t}' not one of: {', '.join(REL_TYPES)}")
    a, b = get_note(src), get_note(dst)
    if src == dst:
        raise Fail("a note cannot link to itself")
    changed = []
    for note, target, t in ([(a, dst, typ)] + ([(b, src, rev)] if rev else [])):
        rel = [r for r in note.related if not (r["slug"] == target and r.get("type") == t)]
        rel.append({"slug": target, "type": t})
        note.fm["related"] = rel
        note.fm["updated"] = today()
        note.save()
        changed.append(f"{note.slug} -[{t}]-> {target}")
    append_log("link | " + "; ".join(changed))
    print("\n".join(changed))
    return 0


def cmd_promote(args):
    pos = positional(args)
    if len(pos) < 2 or pos[1] not in STATUSES:
        raise UsageError(f"usage: cortex.py promote <slug> <{'|'.join(STATUSES)}>")
    n = get_note(pos[0])
    old = n.fm.get("status", "?")
    n.fm["status"], n.fm["updated"] = pos[1], today()
    n.save()
    append_log(f"promote | {n.slug} {old} -> {pos[1]}")
    print(f"{n.slug}: {old} -> {pos[1]}")
    return 0


def cmd_touch(args):
    pos = positional(args)
    if not pos:
        raise UsageError("usage: cortex.py touch <slug>")
    n = get_note(pos[0])
    n.fm["updated"] = today()
    n.save()
    print(f"{n.slug}: updated {today()}")
    return 0


def cmd_log(args):
    line = " ".join(positional(args)).strip()
    if not line:
        raise UsageError('usage: cortex.py log "<line>"')
    append_log(line)
    print(KNOW / "_log.md")
    return 0


def lint_notes():
    notes = typed_notes()
    known = {n.slug for n in notes}
    errors, warnings = [], []
    for n in notes:
        rel = f"{n.path.parent.name}/{n.slug}"
        missing = [k for k in REQUIRED if n.fm.get(k) in (None, "", [])]
        if missing:
            errors.append(f"{rel}: missing envelope field(s) {', '.join(missing)}"
                          + ("" if missing == ["tags"] else f" (run `cortex.py adopt {n.slug}`)"))
        raw_rel = n.fm.get("related")
        if isinstance(raw_rel, list) and any(not isinstance(x, dict) for x in raw_rel if x not in (None, "")):
            errors.append(f"{rel}: related has untyped entries (plain slugs); run `cortex.py adopt {n.slug}`")
        if n.fm.get("type") and n.fm.get("type") != DIR_TO_TYPE.get(n.path.parent.name):
            errors.append(f"{rel}: type '{n.fm.get('type')}' does not match folder {n.path.parent.name}")
        if n.fm.get("convention") and n.fm.get("convention") != CONVENTION:
            warnings.append(f"{rel}: convention {n.fm.get('convention')} (current {CONVENTION})")
        if n.fm.get("status") and n.fm["status"] not in STATUSES:
            errors.append(f"{rel}: status '{n.fm['status']}' not in {STATUSES}")
        q = n.fm.get("quality")
        if q not in (None, ""):
            try:
                if not 0 <= float(q) <= 10:
                    raise ValueError
            except (TypeError, ValueError):
                errors.append(f"{rel}: quality '{q}' must be 0-10")
        if n.slug != kebab(n.slug):
            errors.append(f"{rel}: filename is not kebab-case")
        for r in n.related:
            if r["slug"] not in known:
                errors.append(f"{rel}: related slug '{r['slug']}' does not exist")
            if r.get("type") not in REL_TYPES:
                errors.append(f"{rel}: related type '{r.get('type')}' not allowed")
        if not n.related and len(known) > 1:
            warnings.append(f"{rel}: no typed related links")
        for w in n.wikilinks:
            if w != kebab(w):
                warnings.append(f"{rel}: wikilink [[{w}]] is not kebab-case")
            elif w not in known:
                warnings.append(f"{rel}: orphan wikilink [[{w}]]")
        if n.type == "research" and not n.fm.get("source_url") and n.fm.get("source_kind") != "internal":
            warnings.append(f"{rel}: research note without source_url (enrichment gap)")
    return notes, errors, warnings


def adopt_note(n, known):
    """Fill the kb-v3 envelope on a typed-folder note written by another tool (e.g. `kai.py knowledge add`).
    Returns (changes, still_missing). Never invents tags or links."""
    fm, changes = n.fm, []
    folder_type = DIR_TO_TYPE.get(n.path.parent.name)
    if fm.get("type") != folder_type:
        changes.append(f"type {fm.get('type')!r} -> {folder_type}")
        fm["type"] = folder_type
    if not fm.get("title"):
        fm["title"] = n.slug.replace("-", " ").title()
        changes.append("title from filename")
    if not fm.get("created"):
        fm["created"] = dt.date.fromtimestamp(n.path.stat().st_mtime).isoformat()
        changes.append("created from file date")
    if not fm.get("updated"):
        fm["updated"] = str(fm["created"])
        changes.append("updated = created")
    if not fm.get("id"):
        fm["id"] = mint_id(n.slug, str(fm["created"]))
        changes.append("minted id")
    if fm.get("quality") in (None, ""):
        fm["quality"] = 3
        changes.append("quality 3")
    if not fm.get("status"):
        fm["status"] = "seedling"
        changes.append("status seedling")
    if fm.get("convention") != CONVENTION:
        fm["convention"] = CONVENTION
        changes.append(f"convention {CONVENTION}")
    tags = fm.get("tags")
    if isinstance(tags, str) and tags.strip():
        fm["tags"] = [kebab(t, 40) for t in tags.split(",") if t.strip()]
        changes.append("tags to list")
    src = fm.pop("source", None)
    if src and not fm.get("source_url"):
        if re.match(r"^https?://", str(src)):
            fm["source_url"] = str(src)
        else:
            fm["source_name"] = str(src)
        changes.append("source -> source_url/source_name")
    raw = fm.get("related") or []
    raw = raw if isinstance(raw, list) else [raw]
    typed, dropped = [], []
    for r in raw:
        if isinstance(r, dict) and r.get("slug"):
            typed.append({"slug": r["slug"], "type": r.get("type") if r.get("type") in REL_TYPES else "related"})
        elif isinstance(r, str) and r.strip():
            cand = r.strip()
            cand = cand if cand in known else kebab(cand)
            if cand in known and cand != n.slug:
                typed.append({"slug": cand, "type": "related"})
            else:
                dropped.append(r.strip())
    if typed != raw:
        fm["related"] = typed
        changes.append(f"related typed ({len(typed)} kept" + (f", unknown dropped: {', '.join(dropped)})" if dropped else ")"))
    still = [k for k in REQUIRED if fm.get(k) in (None, "", [])]
    return changes, still


def cmd_adopt(args):
    pos = positional(args)
    notes = note_map()
    if "--all" in args:
        targets = list(notes.values())
    elif pos:
        targets = [get_note(s) for s in pos]
    else:
        raise UsageError("usage: cortex.py adopt <slug> [slug...] | adopt --all  [--dry-run]")
    known = set(notes)
    report = []
    for n in targets:
        changes, still = adopt_note(n, known)
        if changes and "--dry-run" not in args:
            n.save()
        if changes or still:
            report.append({"slug": n.slug, "changes": changes, "still_missing": still})
    if report and "--dry-run" not in args:
        append_log("adopt | " + ", ".join(r["slug"] for r in report if r["changes"]))
        build_indexes()
    emit(report, args, lambda rs: "\n".join(
        f"{r['slug']}: {'; '.join(r['changes']) or 'no envelope change'}"
        + (f"  [still needs: {', '.join(r['still_missing'])}]" if r["still_missing"] else "") for r in rs)
        or "every note already carries the kb-v3 envelope")
    return 0


def cmd_lint(args):
    notes, errors, warnings = lint_notes()
    data = {"notes": len(notes), "errors": errors, "warnings": warnings}

    def text(d):
        lines = [f"[ERR] {e}" for e in d["errors"]] + [f"[warn] {w}" for w in d["warnings"]]
        lines.append(f"{d['notes']} notes, {len(d['errors'])} errors, {len(d['warnings'])} warnings")
        lines.append("RESULT: " + ("CONFORMANT" if not d["errors"] else "NONCONFORMANT"))
        return "\n".join(lines)
    emit(data, args, text)
    return 1 if errors else 0


def build_indexes():
    notes = typed_notes()
    KNOW.mkdir(parents=True, exist_ok=True)
    top = ["# Knowledge archive", "", f"_Generated by cortex.py on {today()}. Do not edit._", ""]
    for typ, d in TYPES.items():
        group = sorted((n for n in notes if n.path.parent.name == d), key=lambda n: n.title.lower())
        top.append(f"- [{d}]({d}/_index.md): {len(group)} notes")
        if not group:
            continue
        lines = [f"# {d}", "", f"_Generated by cortex.py on {today()}. Do not edit._", "",
                 "| Note | Status | Tags | Updated |", "|---|---|---|---|"]
        for n in group:
            lines.append(f"| [[{n.slug}]] {n.title} | {n.fm.get('status', '')} | {', '.join(n.tags)} | "
                         f"{n.fm.get('updated', '')} |")
        (KNOW / d / "_index.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (KNOW / "_index.md").write_text("\n".join(top) + "\n", encoding="utf-8")


def cmd_index(args):
    build_indexes()
    print(KNOW / "_index.md")
    return 0


def cmd_status(args):
    notes, errors, warnings = lint_notes()
    by_type = Counter(n.type for n in notes)
    by_status = Counter(n.fm.get("status", "none") for n in notes)
    stale_cut = (dt.date.today() - dt.timedelta(days=90)).isoformat()
    stale = [n.slug for n in notes if n.fm.get("status") == "seedling" and str(n.fm.get("updated", "")) < stale_cut]
    orphans = sorted({w.split("[[")[-1].split("]]")[0] for w in warnings if "orphan wikilink" in w})
    harvest = load_json(STATE / "cortex-harvest.json", {})
    queue = sorted(p.name for p in QUEUE.glob("*.md")) if QUEUE.is_dir() else []
    data = {"archive": str(KNOW), "notes": len(notes), "by_type": dict(by_type), "by_status": dict(by_status),
            "unlinked": [w.split(":")[0] for w in warnings if "no typed related" in w],
            "orphan_wikilinks": orphans, "stale_seedlings": stale, "lint_errors": len(errors),
            "untyped_notes": [n.slug for n in untyped_notes()], "queue": queue,
            "last_harvest": harvest.get("last_run")}

    def text(d):
        lines = [f"Knowledge archive: {d['archive']}", f"  notes: {d['notes']}  " +
                 "  ".join(f"{TYPES[t]}={c}" for t, c in sorted(d["by_type"].items()) if t in TYPES),
                 "  status: " + ", ".join(f"{k}={v}" for k, v in sorted(d["by_status"].items())),
                 f"  lint errors: {d['lint_errors']}  unlinked: {len(d['unlinked'])}  "
                 f"orphan wikilinks: {len(d['orphan_wikilinks'])}",
                 f"  stale seedlings (>90d): {len(d['stale_seedlings'])}",
                 f"  untyped notes awaiting harvest: {len(d['untyped_notes'])}",
                 f"  harvest queue: {len(d['queue'])}",
                 f"  last harvest: {d['last_harvest'] or 'never'}"]
        return "\n".join(lines)
    emit(data, args, text)
    return 0


def cmd_search(args):
    q = " ".join(positional(args)).strip()
    if not q:
        raise UsageError('usage: cortex.py search "<query>" [--type T] [--tag X]')
    terms = [t.lower() for t in q.split()]
    want_type, want_tag = opt(args, "--type"), (opt(args, "--tag") or "").lower()
    rows = []
    for n in typed_notes() + untyped_notes():
        if want_type and n.type != want_type:
            continue
        if want_tag and want_tag not in n.tags:
            continue
        hay_meta = (n.title + " " + " ".join(n.tags) + " " + n.slug).lower()
        hay_body = n.body.lower()
        where = []
        if all(t in hay_meta for t in terms):
            where.append("title/tags")
        if all(t in hay_body for t in terms):
            where.append("body")
        if any(all(t in w.lower() for t in terms) for w in n.wikilinks):
            where.append("wikilink")
        if where:
            rows.append({"slug": n.slug, "type": n.type, "status": n.fm.get("status", ""), "tags": n.tags,
                         "matched": where, "path": str(n.path)})
    rows.sort(key=lambda r: (-len(r["matched"]), "title/tags" not in r["matched"], r["slug"]))

    def text(rs):
        if not rs:
            return "no matches (try `cortex.py recall` for prior work, or `retrieve` for fuzzy ranking)"
        lines = ["| Note | Type | Status | Tags | Matched in |", "|---|---|---|---|---|"]
        lines += [f"| {r['slug']} | {r['type']} | {r['status']} | {', '.join(r['tags'])} | {', '.join(r['matched'])} |"
                  for r in rs]
        return "\n".join(lines)
    emit(rows, args, text)
    return 0 if rows else 1


def cmd_suggest(args):
    text = " ".join(positional(args)).strip()
    tags = [t.strip().lower() for t in (opt(args, "--tags") or "").split(",") if t.strip()]
    if not text and not tags:
        raise UsageError('usage: cortex.py suggest "<title or summary>" [--tags a,b]')
    rows = similarity_candidates(text, tags, limit=int(opt(args, "--limit", "5")))
    emit(rows, args, lambda rs: "\n".join(
        f"{r['slug']}  ({r['type']}, score {r['score']}{', tags ' + ','.join(r['shared_tags']) if r['shared_tags'] else ''})"
        for r in rs) or "no candidates")
    return 0 if rows else 1


def edges():
    """-> list of (src, dst, kind) over typed notes. kind = relationship type or 'wikilink'."""
    m = note_map()
    out = []
    for n in m.values():
        for r in n.related:
            if r["slug"] in m:
                out.append((n.slug, r["slug"], r.get("type", "related")))
        for w in set(n.wikilinks):
            if w in m and w != n.slug and not any(r["slug"] == w for r in n.related):
                out.append((n.slug, w, "wikilink"))
    return m, out


def cmd_graph(args):
    pos = positional(args)
    m, es = edges()
    adj = defaultdict(set)
    for a, b, k in es:
        adj[a].add((b, k))
        adj[b].add((a, k))
    if pos:
        start = pos[0]
        if start not in m:
            raise Fail(f"no note with slug '{start}'")
        hops = int(opt(args, "--hops", "2"))
        seen, q, layers = {start: 0}, deque([start]), []
        while q:
            cur = q.popleft()
            if seen[cur] >= hops:
                continue
            for nxt, kind in sorted(adj[cur]):
                if nxt not in seen:
                    seen[nxt] = seen[cur] + 1
                    q.append(nxt)
                    layers.append({"slug": nxt, "hop": seen[nxt], "via": cur, "edge": kind,
                                   "type": m[nxt].type, "title": m[nxt].title})
        data = {"start": start, "hops": hops, "neighbors": layers}
        emit(data, args, lambda d: f"{d['start']} (within {d['hops']} hops)\n" + "\n".join(
            f"  {'  ' * (x['hop'] - 1)}{x['via']} -[{x['edge']}]- {x['slug']}  ({x['type']})"
            for x in d["neighbors"]) if d["neighbors"] else f"{d['start']}: no connections")
        return 0
    degree = {s: len(adj[s]) for s in m}
    hubs = sorted(degree.items(), key=lambda kv: (-kv[1], kv[0]))[:5]
    data = {"nodes": len(m), "edges": len(es), "edge_kinds": dict(Counter(k for _, _, k in es)),
            "hubs": [{"slug": s, "degree": d} for s, d in hubs if d],
            "isolated": sorted(s for s, d in degree.items() if d == 0)}
    emit(data, args, lambda d: "\n".join([
        f"nodes: {d['nodes']}  edges: {d['edges']}  " + ", ".join(f"{k}={v}" for k, v in sorted(d["edge_kinds"].items())),
        "hubs: " + (", ".join(f"{h['slug']}({h['degree']})" for h in d["hubs"]) or "none"),
        f"isolated ({len(d['isolated'])}): " + (", ".join(d["isolated"][:20]) or "none")]))
    return 0


def _windows_overlap(a, b):
    a0, a1 = str(a.fm.get("valid_from") or "0000"), str(a.fm.get("valid_until") or "9999")
    b0, b1 = str(b.fm.get("valid_from") or "0000"), str(b.fm.get("valid_until") or "9999")
    return a0 <= b1 and b0 <= a1


def cmd_contradictions(args):
    notes = typed_notes()
    explicit = []
    for n in notes:
        for r in n.related:
            if r.get("type") == "contradicts":
                explicit.append({"a": n.slug, "b": r["slug"]})
    pairs = []
    for i, a in enumerate(notes):
        for b in notes[i + 1:]:
            shared = set(a.tags) & set(b.tags)
            if len(shared) >= 2 and _windows_overlap(a, b):
                pairs.append({"a": a.slug, "b": b.slug, "shared_tags": sorted(shared), "overlap": len(shared),
                              "updated": [str(a.fm.get("updated", "")), str(b.fm.get("updated", ""))]})
    pairs.sort(key=lambda p: (-p["overlap"], p["a"], p["b"]))
    data = {"explicit_contradicts": explicit, "candidate_pairs": pairs[:25]}
    emit(data, args, lambda d: "\n".join(
        ["Explicit contradicts edges:"] + ([f"  {x['a']} <-> {x['b']}" for x in d["explicit_contradicts"]]
                                           or ["  none"]) +
        ["Candidate pairs (2+ shared tags, overlapping validity) - read both and compare claims:"] +
        ([f"  {p['a']} / {p['b']}  [{', '.join(p['shared_tags'])}]" for p in d["candidate_pairs"]]
         or ["  none"])))
    return 0


def bm25(docs, query, k1=1.4, b=0.75):
    """docs: list of (key, field_text dict). Title/tags weigh 3x/2x body. Returns [(score, key)]."""
    qt = tokens(query)
    if not qt or not docs:
        return []
    toks = {}
    for key, fields in docs:
        toks[key] = tokens(fields["title"]) * 3 + tokens(" ".join(fields["tags"])) * 2 + tokens(fields["body"])
    n = len(docs)
    avg = sum(len(t) for t in toks.values()) / n or 1
    df = Counter()
    for t in toks.values():
        df.update(set(t))
    out = []
    for key, t in toks.items():
        tf = Counter(t)
        s = 0.0
        for q in qt:
            if q not in tf:
                continue
            idf = math.log(1 + (n - df[q] + 0.5) / (df[q] + 0.5))
            s += idf * tf[q] * (k1 + 1) / (tf[q] + k1 * (1 - b + b * len(t) / avg))
        if s > 0:
            out.append((s, key))
    return sorted(out, reverse=True)


def summarize_note(n, query, raw=False, lines=3):
    qt = set(tokens(query))
    body_lines = [l.strip() for l in n.body.splitlines() if l.strip() and not l.startswith("#")]
    if raw:
        hits = [l for l in body_lines if qt & set(tokens(l))][:lines] or body_lines[:lines]
        return hits
    lead = body_lines[0] if body_lines else ""
    hits = [l for l in body_lines[1:] if qt & set(tokens(l))][: lines - 1]
    return [x[:300] for x in [lead] + hits if x]


def cmd_retrieve(args):
    q = " ".join(positional(args)).strip()
    if not q:
        raise UsageError('usage: cortex.py retrieve "<query>" [--top N] [--raw]')
    notes = typed_notes() + untyped_notes()
    m = {n.slug: n for n in notes}
    ranked = bm25([(n.slug, {"title": n.title, "tags": n.tags, "body": n.body}) for n in notes], q)
    top = int(opt(args, "--top", "5"))
    rows = [{"slug": k, "type": m[k].type, "title": m[k].title, "score": round(s, 3), "path": str(m[k].path),
             "related": [r["slug"] for r in m[k].related],
             "excerpt": summarize_note(m[k], q, raw="--raw" in args)} for s, k in ranked[:top]]

    def text(rs):
        if not rs:
            return "nothing relevant in the archive"
        out = []
        for r in rs:
            out.append(f"## {r['title']}  ({r['type']}, {r['slug']}, score {r['score']})")
            out += [f"  {x}" for x in r["excerpt"]]
            if r["related"]:
                out.append(f"  related: {', '.join(r['related'])}")
        return "\n".join(out)
    emit(rows, args, text)
    return 0 if rows else 1


def cmd_develop(args):
    seeds = sorted((n for n in typed_notes() if n.fm.get("status") == "seedling"),
                   key=lambda n: str(n.fm.get("updated", "")))
    rows = []
    for n in seeds:
        cands = similarity_candidates(n.title + " " + n.body[:2000], n.tags,
                                      exclude={n.slug} | {r["slug"] for r in n.related}, limit=3)
        empty = [h for h in TEMPLATES.get(n.type, [])
                 if re.search(rf"^## {re.escape(h)}\s*\n\s*(?=## |\Z)", n.body, re.M)]
        rows.append({"slug": n.slug, "type": n.type, "updated": str(n.fm.get("updated", "")), "path": str(n.path),
                     "empty_sections": empty, "link_candidates": [c["slug"] for c in cands]})
    emit(rows, args, lambda rs: "\n".join(
        f"{r['slug']} ({r['type']}, updated {r['updated']}) empty: {', '.join(r['empty_sections']) or '-'}; "
        f"link candidates: {', '.join(r['link_candidates']) or '-'}" for r in rs) or "no seedlings; archive is clean")
    return 0


# ---------------------------------------------------------------- harvest + queue

def queue_files():
    return sorted(QUEUE.glob("*.md")) if QUEUE.is_dir() else []


def known_source_urls():
    urls = set()
    for n in typed_notes():
        v = n.fm.get("source_url")
        for u in (v if isinstance(v, list) else [v]):
            if u:
                urls.add(str(u).strip())
    for p in queue_files():
        fm, _ = parse_note_text(p.read_text(encoding="utf-8", errors="replace"))
        if fm.get("source_url"):
            urls.add(str(fm["source_url"]).strip())
    return urls


def write_candidate(title, body, source, ctype="idea", source_url=None, extra=None):
    QUEUE.mkdir(parents=True, exist_ok=True)
    base = file_slug(title, 50)
    path, n = QUEUE / f"{base}.md", 2
    while path.exists():
        path = QUEUE / f"{base}-{n}.md"
        n += 1
    fm = {"title": title, "candidate_type": ctype, "source": source, "queued": today()}
    if source_url:
        fm["source_url"] = source_url
    fm.update(extra or {})
    path.write_text(dump_frontmatter(fm) + "\n" + body.strip() + "\n", encoding="utf-8")
    return path


def harvest_sources():
    """Yield (key, title, body, source, ctype) for every harvestable item."""
    for n in untyped_notes():
        yield (f"untyped:{n.slug}:{hashlib.sha1(n.body.encode('utf-8')).hexdigest()[:10]}",
               n.title, n.body, str(n.path), "idea")
    work = MEM / "WORK"
    if work.is_dir():
        for isa in sorted(work.glob("*/ISA.md")):
            fm, body = parse_note_text(isa.read_text(encoding="utf-8", errors="replace"))
            if str(fm.get("phase", "")).lower() != "complete":
                continue
            m = re.search(r"^## Decisions\s*\n(.*?)(?=^## |\Z)", body, re.S | re.M)
            decisions = [l.strip()[2:].strip() for l in (m.group(1) if m else "").splitlines()
                         if l.strip().startswith("- ") and len(l.strip()) > 12]
            for d in decisions:
                key = f"isa:{isa.parent.name}:{hashlib.sha1(d.encode('utf-8')).hexdigest()[:10]}"
                goal = fm.get("principal_stated_goal", "")
                yield (key, d[:80], f"{d}\n\nFrom task `{isa.parent.name}` (goal: {goal}).", str(isa), "idea")
    learn = MEM / "LEARNING" / "learnings.md"
    if learn.exists():
        for line in learn.read_text(encoding="utf-8", errors="replace").splitlines():
            s = line.strip()
            if s.startswith("- ") and len(s) > 20:
                lesson = re.sub(r"^- \d{4}-\d{2}-\d{2}:\s*", "", s)
                key = f"learning:{hashlib.sha1(lesson.encode('utf-8')).hexdigest()[:10]}"
                yield (key, lesson[:80], lesson, str(learn), "idea")


def cmd_harvest(args):
    state_path = STATE / "cortex-harvest.json"
    state = load_json(state_path, {"seen": [], "last_run": None})
    seen = set(state.get("seen", []))
    new = [(k, t, b, s, c) for k, t, b, s, c in harvest_sources() if k not in seen]
    written = []
    if "--dry-run" not in args:
        for k, t, b, s, c in new:
            written.append(str(write_candidate(t, b, s, c)))
            seen.add(k)
        state.update({"seen": sorted(seen), "last_run": now_iso()})
        save_json(state_path, state)
    data = {"candidates": [{"title": t, "source": s} for _, t, _, s, _ in new], "written": written,
            "dry_run": "--dry-run" in args, "queue": str(QUEUE)}
    emit(data, args, lambda d: (f"{len(d['candidates'])} new candidate(s)" +
                                (" (dry run, nothing written)" if d["dry_run"] else f" queued in {d['queue']}") +
                                "".join(f"\n  - {c['title']}  <- {c['source']}" for c in d["candidates"]))
         if d["candidates"] else "sources already harvested; nothing new")
    return 0


def cmd_queue(args):
    pos = positional(args)
    sub = pos[0] if pos else "list"
    if sub == "list":
        rows = []
        for p in queue_files():
            fm, body = parse_note_text(p.read_text(encoding="utf-8", errors="replace"))
            rows.append({"name": p.name, "title": fm.get("title", p.stem), "type": fm.get("candidate_type", "idea"),
                         "source": fm.get("source_url") or fm.get("source", ""), "queued": fm.get("queued", "")})
        emit(rows, args, lambda rs: "\n".join(f"{r['name']}  [{r['type']}] {r['title']}  <- {r['source']}"
                                              for r in rs) or "queue is empty")
        return 0
    if sub == "add":
        title = opt(args, "--title")
        if not title:
            raise UsageError('usage: cortex.py queue add --title "<t>" [--source-url U] [--type idea] '
                             '[--body TEXT|--body-file F]')
        url = opt(args, "--source-url")
        if url and url.strip() in known_source_urls():
            print(f"duplicate: {url} is already in the archive or queue; nothing written")
            return 0
        ctype = opt(args, "--type", "idea")
        if ctype not in TYPES:
            raise Fail(f"--type must be one of {', '.join(TYPES)}")
        body = read_body(args) or ""
        print(write_candidate(title, body, "manual", ctype, url))
        return 0
    if sub in ("show", "drop"):
        if len(pos) < 2:
            raise UsageError(f"usage: cortex.py queue {sub} <name>")
        name = pos[1] if pos[1].endswith(".md") else pos[1] + ".md"
        p = QUEUE / Path(name).name
        if not p.exists():
            raise Fail(f"no queued candidate {name}")
        if sub == "show":
            print(p.read_text(encoding="utf-8", errors="replace"))
        else:
            p.unlink()
            print(f"dropped {p.name}")
        return 0
    raise UsageError("usage: cortex.py queue list|add|show|drop")


# ---------------------------------------------------------------- distill

def cmd_distill(args):
    pos = positional(args)
    sub = pos[0] if pos else ""
    state_path = STATE / "distill.json"
    state = load_json(state_path, {"surfaced": [], "runs": []})
    if sub == "gather":
        days = int(opt(args, "--days", "7"))
        cut = (dt.date.today() - dt.timedelta(days=days)).isoformat()
        notes = typed_notes()
        surfaced = set(state.get("surfaced", []))
        window = [n for n in notes if max(str(n.fm.get("created", "")), str(n.fm.get("updated", ""))) >= cut]
        fresh = [n for n in window if n.slug not in surfaced]
        win_tags = Counter(t for n in window for t in n.tags)
        all_tags = Counter(t for n in notes for t in n.tags)
        hot = sorted(({"tag": t, "window": c, "archive": all_tags[t],
                       "lift": round(c / max(1.0, all_tags[t] * days / 365.0), 2)} for t, c in win_tags.items()),
                     key=lambda x: (-x["lift"], -x["window"], x["tag"]))[:10]
        data = {"window_days": days, "since": cut,
                "notes": [{"slug": n.slug, "type": n.type, "title": n.title, "tags": n.tags, "path": str(n.path),
                           "status": n.fm.get("status")} for n in fresh],
                "already_surfaced": len(window) - len(fresh), "hot_tags": hot,
                "seedlings": sum(1 for n in notes if n.fm.get("status") == "seedling"),
                "digest_dir": str(DIGESTS)}
        emit(data, args, lambda d: "\n".join(
            [f"{len(d['notes'])} new/updated notes since {d['since']} ({d['already_surfaced']} already surfaced)"] +
            [f"  {n['slug']} ({n['type']}) [{', '.join(n['tags'])}]" for n in d["notes"]] +
            ["hot tags: " + ", ".join(f"{h['tag']}x{h['window']}" for h in d["hot_tags"])] +
            [f"seedlings: {d['seedlings']}", f"write the digest to {d['digest_dir']}/{today()}-distill.md"]))
        return 0
    if sub == "mark":
        digest = opt(args, "--digest")
        if not digest or not Path(digest).exists():
            raise UsageError("usage: cortex.py distill mark --digest <existing digest path>")
        text = Path(digest).read_text(encoding="utf-8", errors="replace")
        known = set(note_map())
        slugs = sorted({w for w in WIKI_RE.findall(text) if w in known} |
                       {s for s in re.findall(r"/([a-z0-9-]+)\.md", text) if s in known})
        state["surfaced"] = sorted(set(state.get("surfaced", [])) | set(slugs))
        state.setdefault("runs", []).append({"ts": now_iso(), "digest": str(digest), "items": len(slugs)})
        save_json(state_path, state)
        print(f"marked {len(slugs)} note(s) as surfaced")
        return 0
    raise UsageError("usage: cortex.py distill gather [--days N] | distill mark --digest <path>")


# ---------------------------------------------------------------- recall

def parse_date_phrases(query, ref=None):
    """-> (remaining query, since date|None, until date|None). Pure; unit-tested."""
    ref = ref or dt.date.today()
    q, since, until = f" {query.lower()} ", None, None
    m = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", q)
    if m:
        d = dt.date.fromisoformat(m.group(1))
        since = until = d
        q = q.replace(m.group(0), " ")
    m = re.search(r"\b(\d+)\s+days?\s+ago\b", q)
    if m:
        since = until = ref - dt.timedelta(days=int(m.group(1)))
        q = q.replace(m.group(0), " ")
    table = [("yesterday", 1, 1), ("today", 0, 0), ("this week", ref.weekday(), 0), ("last week", 7, 0),
             ("past week", 7, 0), ("this month", ref.day - 1, 0), ("last month", 31, 0)]
    for phrase, back, fwd in table:
        if f" {phrase} " in q:
            since = ref - dt.timedelta(days=back)
            until = ref - dt.timedelta(days=fwd) if phrase in ("yesterday", "today") else ref
            q = q.replace(f" {phrase} ", " ")
    return re.sub(r"\s+", " ", q).strip(), since, until


def _to_date(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        try:
            return dt.datetime.fromtimestamp(v / 1000 if v > 1e11 else v).date()
        except (OverflowError, OSError, ValueError):
            return None
    m = re.match(r"(\d{4}-\d{2}-\d{2})", str(v))
    return dt.date.fromisoformat(m.group(1)) if m else None


def recall_items():
    """Yield dicts {source, title, date, text, path} from every recall source."""
    cwds = set()
    work = MEM / "WORK"
    if work.is_dir():
        for isa in work.glob("*/ISA.md"):
            text = isa.read_text(encoding="utf-8", errors="replace")
            fm, body = parse_note_text(text)
            d = _to_date(fm.get("created")) or dt.date.fromtimestamp(isa.stat().st_mtime)
            yield {"source": "task-isa", "title": f"{isa.parent.name} [{fm.get('phase', '?')}]",
                   "date": d, "text": f"{fm.get('principal_stated_goal', '')}\n{body}", "path": str(isa),
                   "mtime": dt.date.fromtimestamp(isa.stat().st_mtime)}
    sess_root = MEM / "LEARNING" / "sessions"
    if sess_root.is_dir():
        for p in sess_root.glob("**/*.md"):
            text = p.read_text(encoding="utf-8", errors="replace")
            m = re.search(r"^- cwd:\s*(.+)$", text, re.M)
            if m and m.group(1).strip():
                cwds.add(m.group(1).strip())
            m = re.match(r"(\d{4}-\d{2}-\d{2})", p.name)
            d = dt.date.fromisoformat(m.group(1)) if m else dt.date.fromtimestamp(p.stat().st_mtime)
            first = re.search(r"^## Prompts\s*\n- (.+)$", text, re.M)
            yield {"source": "session-log", "title": (first.group(1)[:90] if first else p.stem), "date": d,
                   "text": text, "path": str(p)}
    for st in (STATE / "sessions").glob("*.json") if (STATE / "sessions").is_dir() else []:
        c = load_json(st, {}).get("cwd")
        if c:
            cwds.add(c)
    for c in sorted(cwds):
        isa = Path(c) / "ISA.md"
        try:
            if isa.is_file():
                fm, body = parse_note_text(isa.read_text(encoding="utf-8", errors="replace"))
                yield {"source": "project-isa", "title": f"{Path(c).name} project ISA [{fm.get('phase', '?')}]",
                       "date": dt.date.fromtimestamp(isa.stat().st_mtime),
                       "text": f"{fm.get('principal_stated_goal', '')}\n{body}", "path": str(isa)}
        except OSError:
            continue
    ss = COPILOT_HOME / "session-state"
    if ss.is_dir():
        for ev in ss.glob("*/events.jsonl"):
            first_ts, prompts = None, []
            try:
                with open(ev, encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f):
                        if i > 5000 or len(prompts) >= 40:
                            break
                        try:
                            obj = json.loads(line)
                        except ValueError:
                            continue
                        if first_ts is None:
                            first_ts = _to_date(obj.get("timestamp"))
                        if obj.get("type") == "user.message":
                            c = (obj.get("data") or {}).get("content")
                            if isinstance(c, str) and c.strip():
                                prompts.append(c.strip())
            except OSError:
                continue
            if not prompts:
                continue
            d = first_ts or dt.date.fromtimestamp(ev.stat().st_mtime)
            yield {"source": "copilot-session", "title": prompts[0][:90].replace("\n", " "), "date": d,
                   "text": "\n".join(prompts), "path": str(ev)}


def snippet(text, qt, width=160):
    for line in text.splitlines():
        if qt & set(tokens(line)):
            s = line.strip()
            return s[:width] + ("..." if len(s) > width else "")
    s = " ".join(text.split())
    return s[:width]


def cmd_recall(args):
    raw = " ".join(positional(args)).strip()
    query, since, until = parse_date_phrases(raw)
    if opt(args, "--since"):
        since = dt.date.fromisoformat(opt(args, "--since"))
    if opt(args, "--until"):
        until = dt.date.fromisoformat(opt(args, "--until"))
    if not query and not since and not until:
        raise UsageError('usage: cortex.py recall "<topic or date phrase>" [--since D] [--until D] [--limit N]')
    qt = set(tokens(query))
    limit = int(opt(args, "--limit", "10"))
    ref = dt.date.today()
    rows = []
    for it in recall_items():
        d = it["date"]
        d_check = max(d, it.get("mtime", d))
        if since and d_check < since:
            continue
        if until and d > until:
            continue
        itoks = set(tokens(it["title"] + " " + it["text"]))
        overlap = len(qt & itoks) if qt else 0
        if qt and overlap == 0:
            continue
        title_bonus = len(qt & set(tokens(it["title"]))) * 0.5 if qt else 0
        age = max(0, (ref - d).days)
        score = ((overlap / max(1, len(qt)) + title_bonus) if qt else 1.0) * (1.0 / (1.0 + age / 14.0))
        rows.append({"score": round(score, 4), "date": d.isoformat(), "source": it["source"],
                     "title": it["title"], "snippet": snippet(it["text"], qt), "path": it["path"],
                     "days_ago": age})
    rows.sort(key=lambda r: (-r["score"], r["days_ago"], r["title"]))
    rows = rows[:limit]
    data = {"query": query, "since": since.isoformat() if since else None,
            "until": until.isoformat() if until else None, "results": rows}

    def text(d):
        if not d["results"]:
            return f"no prior work found for '{raw}'"
        win = f" [{d['since'] or '...'} .. {d['until'] or '...'}]" if d["since"] or d["until"] else ""
        out = [f"Recall: '{d['query'] or '(date only)'}'{win}"]
        for i, r in enumerate(d["results"], 1):
            out.append(f"{i:2}. {r['date']}  {r['source']:15} {r['title']}")
            out.append(f"      {r['snippet']}")
            out.append(f"      {r['path']}")
        return "\n".join(out)
    emit(data, args, text)
    return 0 if rows else 1


# ---------------------------------------------------------------- main

COMMANDS = {
    "status": cmd_status, "search": cmd_search, "suggest": cmd_suggest, "add": cmd_add, "link": cmd_link,
    "promote": cmd_promote, "touch": cmd_touch, "log": cmd_log, "lint": cmd_lint, "index": cmd_index,
    "graph": cmd_graph, "contradictions": cmd_contradictions, "retrieve": cmd_retrieve, "develop": cmd_develop,
    "harvest": cmd_harvest, "queue": cmd_queue, "adopt": cmd_adopt, "distill": cmd_distill, "recall": cmd_recall,
}


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 0
    fn = COMMANDS.get(argv[0])
    if not fn:
        sys.stderr.write(f"unknown command '{argv[0]}'\n\n{__doc__}")
        return 2
    try:
        return fn(argv[1:])
    except UsageError as e:
        sys.stderr.write(f"{e}\n")
        return 2
    except Fail as e:
        sys.stderr.write(f"{e}\n")
        return 1
    except ValueError as e:
        sys.stderr.write(f"bad value: {e}\n")
        return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
