"""equity-brain engine: indicators, position sizing, risk gate and decision ledger.

READ-ONLY BY CONSTRUCTION. This file never talks to a broker, never places, simulates or
cancels an order, and makes no network calls. It turns numbers into numbers and a yes/no.
The model narrates; this code decides. Stdlib only (Python 3.8+).

    python engine.py indicators            < bars.json      ATR-14 (stops), RSI-14 / EMA-20 (risk-sizing only)
    python engine.py size --equity N --risk-pct N --entry N --stop N
    python engine.py gate [--format json|text] < proposal.json
    python engine.py limits [init]          show the limits file, or write the placeholder one
    python engine.py ledger log             < decision.json   append a decision, print its id
    python engine.py ledger action --id N --action CONFIRM|REJECT|EXPIRED
    python engine.py ledger outcome --id N --horizon 1d|1w|1m --return-pct X [--index-return-pct Y]
    python engine.py ledger list [--ticker T] [--limit N] [--json]
    python engine.py scorecard [--json]

Options: --limits <path> (default $KAI_EQUITY_LIMITS or <Kai home>/MEMORY/EQUITY/limits.json).
Exit codes: 0 computed (a gate may still say VETO), 1 input or limits error, 2 usage.
"""
import argparse
import datetime as _dt
import json
import math
import os
import sys
from pathlib import Path

NUMERIC_LIMIT_KEYS = ["risk_per_trade_pct", "max_position_pct", "max_open_positions",
                      "max_daily_loss_pct", "portfolio_heat_pct", "drawdown_halt_pct"]
BOOLEAN_LIMIT_KEYS = ["placeholder", "pdt_guard", "wash_sale_guard"]
REQUIRED_GATE_FIELDS = ["equity", "entry", "stop", "openPositions", "portfolioHeatPct",
                        "dailyPnlPct", "drawdownPct", "dayTradesLast5Days"]
GATE_RESULTS = ("PASS", "VETO", "HOLD")
VERDICTS = ("BUY", "SELL", "HOLD")
ACTIONS = ("NONE", "CONFIRM", "REJECT", "EXPIRED")
HORIZONS = ("1d", "1w", "1m")

PLACEHOLDER_LIMITS = {
    "placeholder": True,
    "risk_per_trade_pct": 0,
    "max_position_pct": 0,
    "max_open_positions": 0,
    "max_daily_loss_pct": 0,
    "portfolio_heat_pct": 0,
    "drawdown_halt_pct": 0,
    "pdt_guard": True,
    "wash_sale_guard": True,
    "pdt_equity_threshold": 25000,
    "pdt_max_day_trades_per_5d": 3,
    "wash_sale_window_days": 30,
    "_note": "All *_pct values are percent of equity (2 = 2%). Fill every number, then set placeholder to false. The gate refuses everything until then.",
}


class InputError(Exception):
    pass


def finite(n):
    return isinstance(n, (int, float)) and not isinstance(n, bool) and math.isfinite(n)


def kai_home():
    if os.environ.get("KAI_HOME"):
        return Path(os.environ["KAI_HOME"])
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"]) / "kai"
    return Path.home() / ".copilot" / "kai"


def equity_dir():
    return kai_home() / "MEMORY" / "EQUITY"


def default_limits_path():
    return Path(os.environ["KAI_EQUITY_LIMITS"]) if os.environ.get("KAI_EQUITY_LIMITS") else equity_dir() / "limits.json"


def ledger_path():
    return equity_dir() / "ledger.jsonl"


def now():
    return _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat()


# ---------------------------------------------------------------------------
# Indicators
# ---------------------------------------------------------------------------

def normalize_bars(raw):
    if not isinstance(raw, list):
        raise InputError("OHLCV input must be a JSON array")
    bars = []
    for i, r in enumerate(raw):
        if isinstance(r, list):
            if len(r) >= 5 and not finite(r[0]):
                nums = r[1:]
            elif len(r) == 6:
                nums = r[1:]
            else:
                nums = r
            nums = list(nums) + [None] * 5
            bar = {"open": nums[0], "high": nums[1], "low": nums[2], "close": nums[3], "volume": nums[4]}
        elif isinstance(r, dict):
            def pick(*keys):
                for k in keys:
                    if k in r:
                        return r[k]
                return None
            bar = {"open": pick("open", "o"), "high": pick("high", "h"), "low": pick("low", "l"),
                   "close": pick("close", "c"), "volume": pick("volume", "v"),
                   "time": pick("time", "t", "datetime", "date")}
        else:
            raise InputError("bar %d: unrecognised shape" % i)
        for k in ("open", "high", "low", "close"):
            if not finite(bar[k]):
                raise InputError("bar %d: %s is not a finite number" % (i, k))
        if bar["high"] < bar["low"]:
            raise InputError("bar %d: high < low" % i)
        bars.append(bar)
    return bars


def atr(bars, period=14):
    """Wilder ATR. First ATR = mean of the first `period` true ranges, then smoothed."""
    if len(bars) < period:
        return None
    tr = []
    for i, b in enumerate(bars):
        if i == 0:
            tr.append(b["high"] - b["low"])
        else:
            pc = bars[i - 1]["close"]
            tr.append(max(b["high"] - b["low"], abs(b["high"] - pc), abs(b["low"] - pc)))
    value = sum(tr[:period]) / period
    for x in tr[period:]:
        value = (value * (period - 1) + x) / period
    return value


def rsi(bars, period=14):
    """Wilder RSI on closes. 100 with no losses, 50 on a flat series."""
    if len(bars) < period + 1:
        return None
    gain = loss = 0.0
    for i in range(1, period + 1):
        d = bars[i]["close"] - bars[i - 1]["close"]
        if d > 0:
            gain += d
        else:
            loss -= d
    avg_gain, avg_loss = gain / period, loss / period
    for i in range(period + 1, len(bars)):
        d = bars[i]["close"] - bars[i - 1]["close"]
        avg_gain = (avg_gain * (period - 1) + max(d, 0)) / period
        avg_loss = (avg_loss * (period - 1) + max(-d, 0)) / period
    if avg_loss == 0:
        return 50.0 if avg_gain == 0 else 100.0
    return 100 - 100 / (1 + avg_gain / avg_loss)


def ema(bars, period=20):
    """EMA on closes, seeded with the mean of the first `period` closes."""
    if len(bars) < period:
        return None
    k = 2 / (period + 1)
    value = sum(b["close"] for b in bars[:period]) / period
    for b in bars[period:]:
        value = b["close"] * k + value * (1 - k)
    return value


def indicators(bars):
    return {
        "bars": len(bars),
        "atr14": {"value": atr(bars, 14), "purpose": "stops",
                  "note": "Use for stop placement / invalidation distance only. Not a signal."},
        "rsi14": {"value": rsi(bars, 14), "purpose": "risk-sizing only",
                  "note": "RISK-SIZING ONLY. Never generate or justify an entry from this number."},
        "ema20": {"value": ema(bars, 20), "purpose": "risk-sizing only",
                  "note": "RISK-SIZING ONLY. Never generate or justify an entry from this number."},
    }


# ---------------------------------------------------------------------------
# Sizing
# ---------------------------------------------------------------------------

def position_size(equity, risk_pct, entry, stop):
    for k, v in (("equity", equity), ("riskPct", risk_pct), ("entry", entry), ("stop", stop)):
        if not finite(v):
            raise InputError("size: %s must be a finite number" % k)
    if equity <= 0:
        raise InputError("size: equity must be > 0")
    if risk_pct <= 0:
        raise InputError("size: riskPct must be > 0")
    if entry <= 0:
        raise InputError("size: entry must be > 0")
    risk_per_share = abs(entry - stop)
    if risk_per_share <= 0:
        raise InputError("size: stop must differ from entry (a real invalidation level)")
    risk_dollars = equity * (risk_pct / 100.0)
    shares = int(math.floor(risk_dollars / risk_per_share + 1e-9))
    notional = shares * entry
    return {"shares": shares, "riskDollars": risk_dollars, "riskPerShare": risk_per_share,
            "notional": notional, "notionalPct": notional / equity * 100.0,
            "direction": "long" if stop < entry else "short"}


# ---------------------------------------------------------------------------
# Limits
# ---------------------------------------------------------------------------

def parse_limits(raw):
    if not isinstance(raw, dict):
        raise InputError("limits must be a JSON object")
    for k in NUMERIC_LIMIT_KEYS:
        if not finite(raw.get(k)):
            raise InputError("limits: %s missing or not a finite number" % k)
    for k in BOOLEAN_LIMIT_KEYS:
        if not isinstance(raw.get(k), bool):
            raise InputError("limits: %s missing or not a boolean" % k)
    return raw


def load_limits(path=None):
    p = Path(path) if path else default_limits_path()
    if not p.exists():
        raise InputError("limits file not found: %s (run `engine.py limits init`)" % p)
    try:
        raw = json.loads(p.read_text(encoding="utf-8-sig"))
    except ValueError as e:
        raise InputError("limits file is not valid JSON: %s" % e)
    return parse_limits(raw), str(p)


# ---------------------------------------------------------------------------
# Risk gate: code decides. Any broken limit means VETO.
# ---------------------------------------------------------------------------

def risk_gate(proposal, limits, limits_path="limits.json"):
    if not isinstance(proposal, dict):
        raise InputError("proposal must be a JSON object")
    reasons, checks = [], []

    def fail(rule, detail):
        reasons.append(rule)
        checks.append({"rule": rule, "ok": False, "detail": detail})

    def ok(rule, detail):
        checks.append({"rule": rule, "ok": True, "detail": detail})

    def result(size):
        allowed = not reasons
        return {"allowed": allowed, "gate_result": "PASS" if allowed else "VETO", "reasons": reasons,
                "checks": checks, "size": size, "limits_path": limits_path}

    # 0. Placeholder limits: nothing passes until the user sets real numbers.
    if limits.get("placeholder"):
        fail("limits_placeholder", "limits file still has placeholder:true; set real numbers in %s" % limits_path)
    else:
        ok("limits_placeholder", "limits are user-set")

    # 1. Fail closed on missing inputs.
    for k in REQUIRED_GATE_FIELDS:
        if not finite(proposal.get(k)):
            fail("missing_field:%s" % k, "%s is required and must be a finite number" % k)
    if any(r.startswith("missing_field:") for r in reasons):
        return result(None)

    # 1b. Sign conventions. Counts, heat and drawdown are non-negative by definition
    # (drawdownPct is a positive distance from the high-water mark). A negative value is
    # almost always a sign mix-up that would silently disable a limit, so it vetoes.
    for k in ("openPositions", "portfolioHeatPct", "drawdownPct", "dayTradesLast5Days"):
        if proposal[k] < 0:
            fail("invalid_field:%s" % k, "%s must be >= 0 (got %s); drawdownPct is a positive "
                 "number, e.g. 8 for 8%% below the high-water mark" % (k, proposal[k]))

    # 2. A written thesis-invalidation condition is the exit rule. No condition, no trade.
    inv = proposal.get("invalidation")
    if isinstance(inv, str) and inv.strip():
        ok("thesis_invalidation", inv.strip()[:120])
    else:
        fail("thesis_invalidation", "proposal has no written thesis-invalidation condition")

    # 3. Sizing: a stop is mandatory.
    risk_pct = proposal["riskPct"] if finite(proposal.get("riskPct")) else limits["risk_per_trade_pct"]
    if risk_pct > limits["risk_per_trade_pct"] + 1e-9:
        fail("risk_per_trade_pct", "riskPct %s%% > limit %s%%" % (risk_pct, limits["risk_per_trade_pct"]))
    else:
        ok("risk_per_trade_pct", "%s%% <= %s%%" % (risk_pct, limits["risk_per_trade_pct"]))
    size = None
    try:
        size = position_size(proposal["equity"], risk_pct, proposal["entry"], proposal["stop"])
        ok("stop_valid", "risk/share %.4f (%s)" % (size["riskPerShare"], size["direction"]))
        if size["shares"] < 1:
            fail("size_below_one_share", "risk budget $%.2f buys 0 shares at $%.2f risk/share"
                 % (size["riskDollars"], size["riskPerShare"]))
        else:
            ok("size_positive", "%d shares, notional $%.2f (%.2f%% of equity)"
               % (size["shares"], size["notional"], size["notionalPct"]))
    except InputError as e:
        fail("stop_invalid", str(e))

    # 4. Numeric limits. Every one is a veto; none is advisory.
    eq = proposal["equity"]
    if size:
        if size["notionalPct"] > limits["max_position_pct"]:
            fail("max_position_pct", "notional %.2f%% > limit %s%%" % (size["notionalPct"], limits["max_position_pct"]))
        else:
            ok("max_position_pct", "%.2f%% <= %s%%" % (size["notionalPct"], limits["max_position_pct"]))
        heat_after = proposal["portfolioHeatPct"] + size["riskDollars"] / eq * 100.0
        if heat_after > limits["portfolio_heat_pct"] + 1e-9:
            fail("portfolio_heat_pct", "heat after entry %.2f%% > cap %s%%" % (heat_after, limits["portfolio_heat_pct"]))
        else:
            ok("portfolio_heat_pct", "%.2f%% <= %s%%" % (heat_after, limits["portfolio_heat_pct"]))

    if proposal["openPositions"] + 1 > limits["max_open_positions"]:
        fail("max_open_positions", "%s open + 1 > limit %s" % (proposal["openPositions"], limits["max_open_positions"]))
    else:
        ok("max_open_positions", "%s <= %s" % (proposal["openPositions"] + 1, limits["max_open_positions"]))

    if proposal["dailyPnlPct"] <= -limits["max_daily_loss_pct"]:
        fail("max_daily_loss_pct", "today %.2f%% <= -%s%%; no new risk today" % (proposal["dailyPnlPct"], limits["max_daily_loss_pct"]))
    else:
        ok("max_daily_loss_pct", "today %.2f%% within -%s%%" % (proposal["dailyPnlPct"], limits["max_daily_loss_pct"]))

    if proposal["drawdownPct"] >= limits["drawdown_halt_pct"]:
        fail("drawdown_halt_pct", "drawdown %.2f%% >= halt %s%%: KILL SWITCH" % (proposal["drawdownPct"], limits["drawdown_halt_pct"]))
    else:
        ok("drawdown_halt_pct", "drawdown %.2f%% < %s%%" % (proposal["drawdownPct"], limits["drawdown_halt_pct"]))

    # 5. Retail rules.
    pdt_threshold = limits.get("pdt_equity_threshold", 25000)
    pdt_max = limits.get("pdt_max_day_trades_per_5d", 3)
    day = proposal.get("isDayTrade") is True
    if limits.get("pdt_guard"):
        if eq < pdt_threshold and day and proposal["dayTradesLast5Days"] >= pdt_max:
            fail("pdt_guard", "equity < $%s and this would be day trade #%d in 5 days"
                 % (pdt_threshold, proposal["dayTradesLast5Days"] + 1))
        else:
            ok("pdt_guard", "equity %s $%s, day trades %s/%s, isDayTrade=%s"
               % (">=" if eq >= pdt_threshold else "<", pdt_threshold, proposal["dayTradesLast5Days"], pdt_max, day))
    if limits.get("wash_sale_guard"):
        if proposal.get("realizedLossSameTickerWithinWindow") is True:
            fail("wash_sale_guard", "realized loss on this name within %s days" % limits.get("wash_sale_window_days", 30))
        else:
            ok("wash_sale_guard", "no realized loss on this name in window")

    return result(size)


# ---------------------------------------------------------------------------
# Ledger (append-only JSONL; updates are appended events, folded on read)
# ---------------------------------------------------------------------------

def read_events():
    p = ledger_path()
    if not p.exists():
        return []
    out = []
    for line in p.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except ValueError:
            continue
    return out


def append_event(ev):
    p = ledger_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(str(p), "a", encoding="utf-8") as fh:
        fh.write(json.dumps(ev, ensure_ascii=False) + "\n")


def fold(events):
    rows = {}
    for ev in events:
        kind = ev.get("event")
        if kind == "decision":
            rows[ev["id"]] = dict(ev["row"], id=ev["id"], ts=ev["ts"], outcomes={}, human_action="NONE")
        elif kind == "action" and ev.get("id") in rows:
            rows[ev["id"]]["human_action"] = ev["action"]
            rows[ev["id"]]["action_ts"] = ev["ts"]
        elif kind == "outcome" and ev.get("id") in rows:
            rows[ev["id"]]["outcomes"][ev["horizon"]] = {
                "return_pct": ev["return_pct"], "index_return_pct": ev.get("index_return_pct"), "ts": ev["ts"]}
    return [rows[k] for k in sorted(rows)]


def validate_decision(row):
    if not isinstance(row, dict):
        raise InputError("decision must be a JSON object")
    for k in ("ticker", "user_thesis"):
        if not isinstance(row.get(k), str) or not row[k].strip():
            raise InputError("decision: %s is required" % k)
    if row.get("gate_result") not in GATE_RESULTS:
        raise InputError("decision: gate_result must be one of %s" % "/".join(GATE_RESULTS))
    if row.get("verdict", "HOLD") not in VERDICTS:
        raise InputError("decision: verdict must be one of %s" % "/".join(VERDICTS))
    if row.get("human_action", "NONE") != "NONE":
        raise InputError("decision: human_action is NONE at write time; record actions with `ledger action`")
    size = row.get("size_proposed", 0)
    if not (isinstance(size, int) and not isinstance(size, bool) and size >= 0):
        raise InputError("decision: size_proposed must be a non-negative integer")
    clean = {k: row.get(k) for k in ("ticker", "user_thesis", "bull_case", "kill_case", "gate_reason")}
    clean.update({"ticker": row["ticker"].strip().upper(), "gate_result": row["gate_result"],
                  "verdict": row.get("verdict", "HOLD"), "size_proposed": size,
                  "overruled": bool(row.get("overruled", False))})
    return clean


def log_decision(row):
    clean = validate_decision(row)
    rows = fold(read_events())
    new_id = (max(r["id"] for r in rows) + 1) if rows else 1
    append_event({"event": "decision", "id": new_id, "ts": now(), "row": clean})
    return new_id


def scorecard(rows):
    total = len(rows)
    by_gate = {g: sum(1 for r in rows if r["gate_result"] == g) for g in GATE_RESULTS}
    by_verdict = {v: sum(1 for r in rows if r["verdict"] == v) for v in VERDICTS}
    by_action = {a: sum(1 for r in rows if r["human_action"] == a) for a in ACTIONS}
    horizons = {}
    for h in HORIZONS:
        rets = [r["outcomes"][h] for r in rows if h in r["outcomes"]]
        if not rets:
            continue
        rs = [o["return_pct"] for o in rets]
        excess = [o["return_pct"] - o["index_return_pct"] for o in rets if finite(o.get("index_return_pct"))]
        horizons[h] = {"n": len(rs), "avg_return_pct": round(sum(rs) / len(rs), 4),
                       "hit_rate": round(sum(1 for x in rs if x > 0) / len(rs), 4),
                       "avg_excess_vs_index_pct": round(sum(excess) / len(excess), 4) if excess else None}
    return {"decisions": total, "gate": by_gate, "verdict": by_verdict, "human_action": by_action,
            "overruled": sum(1 for r in rows if r.get("overruled")), "outcomes": horizons}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def read_stdin_json():
    raw = sys.stdin.read().strip()
    if not raw:
        raise InputError("expected JSON on stdin")
    try:
        return json.loads(raw)
    except ValueError as e:
        raise InputError("stdin is not valid JSON: %s" % e)


def print_gate_text(g):
    print("Risk gate: %s" % ("ALLOWED (PASS)" if g["allowed"] else "REFUSED (VETO)"))
    for c in g["checks"]:
        print("  %s %-24s %s" % ("ok" if c["ok"] else "NO", c["rule"], c["detail"]))
    if g["size"]:
        s = g["size"]
        print("  size: %d shares, risk $%.2f, notional $%.2f" % (s["shares"], s["riskDollars"], s["notional"]))


def dump(obj):
    print(json.dumps(obj, indent=2, ensure_ascii=False))


def run(ns):
    if ns.cmd == "indicators":
        dump(indicators(normalize_bars(read_stdin_json())))
    elif ns.cmd == "size":
        dump(position_size(ns.equity, ns.risk_pct, ns.entry, ns.stop))
    elif ns.cmd == "gate":
        limits, path = load_limits(ns.limits)
        g = risk_gate(read_stdin_json(), limits, path)
        print_gate_text(g) if ns.format == "text" else dump(g)
    elif ns.cmd == "limits":
        if ns.action == "init":
            p = Path(ns.limits) if ns.limits else default_limits_path()
            if p.exists() and not ns.force:
                raise InputError("limits file already exists at %s (use --force to reset it to the placeholder)" % p)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(PLACEHOLDER_LIMITS, indent=2), encoding="utf-8")
            print("wrote placeholder limits to %s; fill the numbers and set placeholder to false" % p)
        else:
            limits, path = load_limits(ns.limits)
            dump({"path": path, "placeholder": limits["placeholder"], "limits": limits})
    elif ns.cmd == "ledger":
        if ns.action == "log":
            print(json.dumps({"id": log_decision(read_stdin_json()), "ledger": str(ledger_path())}))
        elif ns.action == "action":
            rows = {r["id"]: r for r in fold(read_events())}
            if ns.id not in rows:
                raise InputError("no decision #%s" % ns.id)
            append_event({"event": "action", "id": ns.id, "action": ns.human_action, "ts": now()})
            print("decision #%d: human_action=%s" % (ns.id, ns.human_action))
        elif ns.action == "outcome":
            if not finite(ns.return_pct) or (ns.index_return_pct is not None and not finite(ns.index_return_pct)):
                raise InputError("outcome: returns must be finite numbers")
            rows = {r["id"]: r for r in fold(read_events())}
            if ns.id not in rows:
                raise InputError("no decision #%s" % ns.id)
            ev = {"event": "outcome", "id": ns.id, "horizon": ns.horizon, "return_pct": ns.return_pct, "ts": now()}
            if ns.index_return_pct is not None:
                ev["index_return_pct"] = ns.index_return_pct
            append_event(ev)
            print("decision #%d: %s outcome %+.2f%%" % (ns.id, ns.horizon, ns.return_pct))
        else:
            rows = fold(read_events())
            if ns.ticker:
                rows = [r for r in rows if r["ticker"] == ns.ticker.upper()]
            rows = rows[-ns.limit:]
            if ns.json:
                dump(rows)
            else:
                for r in rows:
                    print("#%-4d %s %-6s gate %-4s verdict %-4s action %-7s %s"
                          % (r["id"], r["ts"][:10], r["ticker"], r["gate_result"], r["verdict"],
                             r["human_action"], ", ".join("%s %+.1f%%" % (h, o["return_pct"]) for h, o in r["outcomes"].items())))
                if not rows:
                    print("ledger is empty (%s)" % ledger_path())
    elif ns.cmd == "scorecard":
        s = scorecard(fold(read_events()))
        if ns.json:
            dump(s)
        else:
            print("decisions %d | gate %s | verdict %s | actions %s | overruled %d" % (
                s["decisions"], s["gate"], s["verdict"], s["human_action"], s["overruled"]))
            for h, v in s["outcomes"].items():
                print("  %s: n=%d avg %+.2f%% hit %.0f%% excess-vs-index %s" % (
                    h, v["n"], v["avg_return_pct"], v["hit_rate"] * 100,
                    "n/a" if v["avg_excess_vs_index_pct"] is None else "%+.2f%%" % v["avg_excess_vs_index_pct"]))
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="engine.py", description="equity-brain engine (read-only; no broker access)")
    p.add_argument("--limits", default=None, help="limits file path")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--limits", default=argparse.SUPPRESS, help="limits file path")
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("indicators", help="stdin: OHLCV array, oldest first")
    s = sub.add_parser("size")
    s.add_argument("--equity", type=float, required=True)
    s.add_argument("--risk-pct", dest="risk_pct", type=float, required=True)
    s.add_argument("--entry", type=float, required=True)
    s.add_argument("--stop", type=float, required=True)
    g = sub.add_parser("gate", help="stdin: proposal object", parents=[common])
    g.add_argument("--format", choices=["json", "text"], default="json")
    lm = sub.add_parser("limits", parents=[common])
    lm.add_argument("action", nargs="?", choices=["show", "init"], default="show")
    lm.add_argument("--force", action="store_true")
    lg = sub.add_parser("ledger")
    lsub = lg.add_subparsers(dest="action")
    lsub.add_parser("log", help="stdin: decision JSON")
    la = lsub.add_parser("action")
    la.add_argument("--id", type=int, required=True)
    la.add_argument("--action", dest="human_action", choices=list(ACTIONS[1:]), required=True)
    lo = lsub.add_parser("outcome")
    lo.add_argument("--id", type=int, required=True)
    lo.add_argument("--horizon", choices=list(HORIZONS), required=True)
    lo.add_argument("--return-pct", dest="return_pct", type=float, required=True)
    lo.add_argument("--index-return-pct", dest="index_return_pct", type=float)
    ll = lsub.add_parser("list")
    ll.add_argument("--ticker")
    ll.add_argument("--limit", type=int, default=20)
    ll.add_argument("--json", action="store_true")
    sc = sub.add_parser("scorecard")
    sc.add_argument("--json", action="store_true")
    return p


def _utf8_stdio():
    """Windows consoles and pipes default to a legacy code page; never crash on a CJK name or an emoji."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            pass


def main(argv=None):
    _utf8_stdio()
    p = build_parser()
    ns = p.parse_args(argv)
    if not ns.cmd or (ns.cmd == "ledger" and not ns.action):
        p.print_help()
        return 2
    try:
        return run(ns)
    except InputError as e:
        print("engine error: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
