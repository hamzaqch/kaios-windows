"""trim: deterministic helpers for shrinking an always-loaded instruction file (stdlib only).

    python trim.py measure [--cwd DIR]                 # the always-on set, largest first (bytes, ~tokens)
    python trim.py resolve [NAME] [--cwd DIR]          # bare name -> path; no name -> the largest file
    python trim.py sections FILE                       # where the weight sits, per heading
    python trim.py gc FILE [--apply]                   # provable removals only: superseded, exact dup, absorbed
    python trim.py coverage --original OLD --replacement NEW   # safety gate for a semantic edit
    python trim.py relocate FILE --heading "## X" --to REF.md [--apply]   # move a section, leave a stub
    python trim.py backup FILE | backups FILE | restore FILE [--id ID]

Every write (gc --apply, relocate --apply) first saves a timestamped backup to
~/.copilot/kai/MEMORY/STATE/trim-backups/, so each change is reversible even
outside git. Nothing here makes a judgment call; semantic merges and tightenings
are proposed by the model, approved by the human, and checked with `coverage`.
"""
import argparse
import datetime as _dt
import json
import os
import re
import shutil
import sys
from pathlib import Path

TAIL_HEADINGS = re.compile(r"^#{2,3}\s+.*\b(proposals?|inbox|appended|auto[- ]?added|learnings? log)\b", re.I)
COMMON_CAPS = set("""A An The This That These Those It Its If When Where While Before After Use Run Never Always Don't Do
Keep Make Write Read Add Prefer Avoid Only Every Each All No Not Be For To In On Of At By With From As Or And But So
Then Else Also Note Example Examples See Each Any Some One Two Three I You We They He She My Your Our Their Here
There What Why How Who Which Yes Ok OK Step Steps Done Good Bad True False None Null""".split())
IMPERATIVE = re.compile(r"\b(never|always|must|must not|don't|do not|only|avoid|prefer|required?|forbidden|ban(ned)?)\b"
                        r"(\s+\w+){0,3}", re.I)


def kai_home():
    if os.environ.get("KAI_HOME"):
        return Path(os.environ["KAI_HOME"])
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"]) / "kai"
    return Path.home() / ".copilot" / "kai"


def copilot_home():
    return Path(os.environ.get("COPILOT_HOME") or (Path.home() / ".copilot"))


def always_on(cwd):
    home, cwd = copilot_home(), Path(cwd)
    files = [home / "copilot-instructions.md", cwd / "AGENTS.md", cwd / "CLAUDE.md", cwd / "GEMINI.md",
             cwd / ".github" / "copilot-instructions.md"]
    for d in (cwd / ".github" / "instructions", home / "instructions"):
        if d.is_dir():
            files += sorted(d.rglob("*.instructions.md"))
    learn = kai_home() / "MEMORY" / "LEARNING" / "learnings.md"
    files.append(learn)  # its tail is injected at every session start
    return [f for f in files if f.is_file()]


def read(path):
    return Path(path).read_text(encoding="utf-8-sig")


def size(path):
    return len(Path(path).read_bytes())


def kai_block(text):
    m = re.search(r"<!-- KAI:BEGIN.*?-->(.*?)<!-- KAI:END", text, re.S)
    return m.group(1) if m else None


# ------------------------------------------------------------------ backups

def backup_dir(path):
    key = re.sub(r"[^A-Za-z0-9._-]+", "_", str(Path(path).resolve()))[-120:]
    return kai_home() / "MEMORY" / "STATE" / "trim-backups" / key


def make_backup(path):
    d = backup_dir(path)
    d.mkdir(parents=True, exist_ok=True)
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    dst = d / f"{stamp}{Path(path).suffix or '.bak'}"
    shutil.copy2(path, dst)
    (d / "SOURCE.txt").write_text(str(Path(path).resolve()), encoding="utf-8")
    return dst


def atomic_write(path, text):
    path = Path(path)
    tmp = path.with_name(path.name + ".trim-tmp")
    # Keep the file's existing line endings: text mode would turn LF into CRLF on Windows
    # and make a trimmed file larger on disk than the measurement promised.
    nl = "\r\n" if path.exists() and b"\r\n" in path.read_bytes() else "\n"
    with open(tmp, "w", encoding="utf-8", newline=nl) as f:
        f.write(text.replace("\r\n", "\n"))
    os.replace(tmp, path)


# ------------------------------------------------------------------ sections

def split_sections(text):
    """[(heading or '(preamble)', level, start_line, text)] by markdown headings outside code fences."""
    out, cur, level, start, buf = [], "(preamble)", 0, 1, []
    in_fence = False
    for i, line in enumerate(text.splitlines(keepends=True), 1):
        if re.match(r"^\s*(```|~~~)", line):
            in_fence = not in_fence
        m = None if in_fence else re.match(r"^(#{1,4})\s+(.*\S)\s*$", line)
        if m:
            out.append((cur, level, start, "".join(buf)))
            cur, level, start, buf = line.strip(), len(m.group(1)), i, [line]
        else:
            buf.append(line)
    out.append((cur, level, start, "".join(buf)))
    return [s for s in out if s[3] or s[0] != "(preamble)"]


# ------------------------------------------------------------------ gc

def normalize(entry):
    e = re.sub(r"<!--\s*applied:[^>]*-->", "", entry, flags=re.I)
    e = re.sub(r"^\s*[-*]\s*(\[[ xX]\]\s*)?", "", e)
    return re.sub(r"\s+", " ", e).strip().lower()


def applied_ts(entry):
    m = re.search(r"<!--\s*applied:\s*([^>]+?)\s*-->", entry, re.I)
    return m.group(1).strip() if m else ""


def gc_plan(text):
    """Provable removals. Returns (removals, new_text)."""
    lines = text.splitlines(keepends=True)
    in_fence = False
    bullets = []
    tail_start = None
    for i, line in enumerate(lines):
        if re.match(r"^\s*(```|~~~)", line):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        if tail_start is None and TAIL_HEADINGS.match(line):
            tail_start = i
        if re.match(r"^\s*[-*]\s+\S", line) and len(line.strip()) > 3:
            bullets.append(i)
    remove, removals = set(), []
    for i in bullets:
        if re.search(r"\[SUPERSEDED", lines[i], re.I):
            remove.add(i)
            removals.append({"line": i + 1, "reason": "superseded", "text": lines[i].strip()})
    if tail_start is not None:
        body = normalize("".join(lines[:tail_start]))
        for i in bullets:
            if i > tail_start and i not in remove:
                core = normalize(lines[i])[:60]
                if len(core) >= 30 and core in body:
                    remove.add(i)
                    removals.append({"line": i + 1, "reason": "absorbed", "text": lines[i].strip()})
    groups = {}
    for i in bullets:
        if i in remove:
            continue
        key = normalize(lines[i])
        if key:
            groups.setdefault(key, []).append(i)
    for key, idx in groups.items():
        if len(idx) < 2:
            continue
        keep = max(idx, key=lambda j: (applied_ts(lines[j]), -j)) if any(applied_ts(lines[j]) for j in idx) else idx[0]
        for j in idx:
            if j != keep:
                remove.add(j)
                removals.append({"line": j + 1, "reason": "exact-dup", "text": lines[j].strip()})
    new_text = "".join(l for i, l in enumerate(lines) if i not in remove)
    removals.sort(key=lambda r: r["line"])
    return removals, new_text


# ------------------------------------------------------------------ coverage gate

def directive_tokens(text):
    toks = set()
    for m in re.finditer(r"`([^`\n]+)`", text):
        toks.add(("code", m.group(1).strip()))
    for m in re.finditer(r"(?<![\w`])((?:~|\.{1,2}|[A-Za-z]:)?[\\/]?[\w.-]+(?:[\\/][\w.<>*-]+)+|[\w-]+\.(?:md|py|ps1|json|yaml|yml|toml|txt|js|ts|sh|cmd|exe))(?![\w`])", text):
        toks.add(("path", m.group(1)))
    for m in re.finditer(r"(?<![\w-])(--[a-z][\w-]+)", text):
        toks.add(("flag", m.group(1)))
    for m in re.finditer(r"(\$env:\w+|%\w+%|\$\{?[A-Z][A-Z0-9_]+\}?|\b[A-Z][A-Z0-9]*_[A-Z0-9_]+\b)", text):
        toks.add(("env", m.group(1)))
    for m in re.finditer(r"\b([A-Z][a-z]+(?:[A-Z][a-z]+)+|[A-Z][a-z]{2,}|[A-Z]{2,}[a-z]*)\b", text):
        w = m.group(1)
        if w not in COMMON_CAPS:
            toks.add(("name", w))
    for m in IMPERATIVE.finditer(text):
        phrase = re.sub(r"\s+", " ", m.group(0).lower()).strip()
        toks.add(("imperative", phrase))
    return toks


def coverage(original, replacement):
    o, r = directive_tokens(original), replacement.lower()
    missing = []
    for kind, tok in sorted(o):
        probe = tok.lower()
        if kind == "imperative":
            head = probe.split()[0]
            words = probe.split()[1:]
            # the modal must survive, and so must at least the verb it governs (if any)
            ok = re.search(r"\b" + re.escape(head) + r"\b", r) is not None and (not words or any(w in r for w in words[:1]))
        else:
            ok = probe in r
        if not ok:
            missing.append({"kind": kind, "token": tok})
    return missing


# ------------------------------------------------------------------ commands

def cmd_measure(a):
    files = always_on(a.cwd)
    if not files:
        print("No always-on instruction files found (checked the Copilot home and the working directory).")
        return 0
    rows = sorted(((size(f), f) for f in files), key=lambda r: -r[0])
    total = sum(s for s, _ in rows)
    for s, f in rows:
        extra = ""
        if f.name == "copilot-instructions.md":
            blk = kai_block(read(f))
            if blk is not None:
                extra = f"  (Kai block {len(blk.encode('utf-8'))} B, reinstall overwrites it)"
        print(f"{s:>8,} B  ~{s // 4:>6,} tok  {f}{extra}")
    print(f"{total:>8,} B  ~{total // 4:>6,} tok  total")
    return 0


def resolve_target(name, cwd):
    files = always_on(cwd)
    if name:
        p = Path(name).expanduser()
        if p.is_file():
            return p
        stem = re.sub(r"\.md$", "", name.lower())
        hits = [f for f in files if f.stem.lower() == stem or f.name.lower() == name.lower()]
        return hits[0] if hits else None
    return max(files, key=size) if files else None


def cmd_resolve(a):
    t = resolve_target(a.name, a.cwd)
    if not t:
        print(f"no always-on file matches {a.name!r}", file=sys.stderr)
        return 2
    print(f"{t.resolve()}  ({size(t):,} B)")
    return 0


def cmd_sections(a):
    text = read(a.file)
    secs = split_sections(text)
    total = len(text.encode("utf-8"))
    print(f"{a.file}: {total:,} B, {len(secs)} sections\n")
    for head, level, start, body in sorted(secs, key=lambda s: -len(s[3].encode("utf-8"))):
        b = len(body.encode("utf-8"))
        print(f"{b:>7,} B {100 * b / total if total else 0:5.1f}%  L{start:<5} {'  ' * max(level - 1, 0)}{head[:80]}")
    return 0


def cmd_gc(a):
    text = read(a.file)
    removals, new_text = gc_plan(text)
    if not removals:
        print("gc: nothing provably removable.")
        return 0
    saved = len(text.encode("utf-8")) - len(new_text.encode("utf-8"))
    for r in removals:
        print(f"L{r['line']:<5} {r['reason']:<10} {r['text'][:100]}")
    print(f"\n{len(removals)} provable removal(s), {saved:,} B")
    if a.apply:
        if read(a.file) != text:
            print("file changed while planning; re-run", file=sys.stderr)
            return 1
        b = make_backup(a.file)
        atomic_write(a.file, new_text)
        print(f"applied. backup: {b}  ({size(a.file):,} B now)")
    else:
        print("dry run; add --apply to write (a backup is taken first).")
    return 0


def cmd_coverage(a):
    original = read(a.original) if a.original else a.original_text
    replacement = read(a.replacement) if a.replacement else a.replacement_text
    if original is None or replacement is None:
        print("coverage needs --original/--original-text and --replacement/--replacement-text", file=sys.stderr)
        return 2
    missing = coverage(original, replacement)
    total = len(directive_tokens(original))
    if a.json:
        print(json.dumps({"tokens_checked": total, "missing": missing, "pass": not missing}, indent=2))
    elif missing:
        print(f"FAIL: {len(missing)} of {total} directive tokens from the original are missing in the replacement:")
        for m in missing:
            print(f"  [{m['kind']}] {m['token']}")
        print("Keep the original, or rewrite the replacement so every one survives.")
    else:
        print(f"PASS: all {total} directive tokens survive (names, paths, commands, flags, env vars, imperatives).")
    return 0 if not missing else 1


def cmd_relocate(a):
    text = read(a.file)
    secs = split_sections(text)
    match = [s for s in secs if s[0].strip().lower() == a.heading.strip().lower()]
    if not match:
        print(f"heading not found: {a.heading!r}. Headings: " + "; ".join(s[0] for s in secs[:30]), file=sys.stderr)
        return 2
    head, level, start, body = match[0]
    # include nested subsections
    idx = secs.index(match[0])
    for s in secs[idx + 1:]:
        if s[1] and s[1] <= level:
            break
        body += s[3]
    ref = Path(a.to).expanduser()
    if not ref.is_absolute():
        ref = Path(a.file).resolve().parent / ref
    title = re.sub(r"^#+\s*", "", head)
    stub = f"{head}\n\nDetail moved to `{a.stub_path or ref}`; read it when {a.when or 'this topic comes up'}.\n\n"
    new_text = text.replace(body, stub, 1)
    saved = len(text.encode("utf-8")) - len(new_text.encode("utf-8"))
    print(f"relocate {len(body.encode('utf-8')):,} B section '{title}' -> {ref}; source shrinks by {saved:,} B")
    if not a.apply:
        print("dry run; add --apply to write (backups of both files are taken first).")
        return 0
    existing = ref.read_text(encoding="utf-8") if ref.exists() else ""
    if ref.exists():
        make_backup(ref)
    ref.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(ref, existing + ("\n" if existing and not existing.endswith("\n") else "") + body)
    if body not in ref.read_text(encoding="utf-8"):
        print("verification failed: content did not land verbatim; source left untouched", file=sys.stderr)
        return 1
    if read(a.file) != text:
        print("source changed during relocate; re-run", file=sys.stderr)
        return 1
    b = make_backup(a.file)
    atomic_write(a.file, new_text)
    print(f"applied. verified verbatim copy in {ref}. backup: {b}")
    return 0


def cmd_backup(a):
    print(make_backup(a.file))
    return 0


def list_backups(path):
    d = backup_dir(path)
    return sorted((p for p in d.glob("*") if p.name != "SOURCE.txt"), key=lambda p: p.name) if d.exists() else []


def cmd_backups(a):
    bs = list_backups(a.file)
    if not bs:
        print("no backups")
    for p in bs:
        print(f"{p.stem}  {size(p):,} B  {p}")
    return 0


def cmd_restore(a):
    bs = list_backups(a.file)
    if not bs:
        print("no backups to restore", file=sys.stderr)
        return 2
    pick = next((p for p in bs if p.stem == a.id), None) if a.id else bs[-1]
    if not pick:
        print(f"backup not found: {a.id}", file=sys.stderr)
        return 2
    make_backup(a.file)
    shutil.copy2(pick, a.file)
    print(f"restored {a.file} from {pick.name} ({size(a.file):,} B)")
    return 0


def build():
    ap = argparse.ArgumentParser(prog="trim.py", description="Deterministic helpers for trimming always-on context files")
    sp = ap.add_subparsers(dest="cmd")
    p = sp.add_parser("measure")
    p.add_argument("--cwd", default=os.getcwd())
    p = sp.add_parser("resolve")
    p.add_argument("name", nargs="?")
    p.add_argument("--cwd", default=os.getcwd())
    p = sp.add_parser("sections")
    p.add_argument("file")
    p = sp.add_parser("gc")
    p.add_argument("file")
    p.add_argument("--apply", action="store_true")
    p = sp.add_parser("coverage")
    p.add_argument("--original")
    p.add_argument("--original-text")
    p.add_argument("--replacement")
    p.add_argument("--replacement-text")
    p.add_argument("--json", action="store_true")
    p = sp.add_parser("relocate")
    p.add_argument("file")
    p.add_argument("--heading", required=True)
    p.add_argument("--to", required=True)
    p.add_argument("--stub-path", help="path to show in the stub (default: the resolved --to path)")
    p.add_argument("--when", help="when the reader should open the reference")
    p.add_argument("--apply", action="store_true")
    for n in ("backup", "backups"):
        p = sp.add_parser(n)
        p.add_argument("file")
    p = sp.add_parser("restore")
    p.add_argument("file")
    p.add_argument("--id")
    return ap


CMDS = {"measure": cmd_measure, "resolve": cmd_resolve, "sections": cmd_sections, "gc": cmd_gc,
        "coverage": cmd_coverage, "relocate": cmd_relocate, "backup": cmd_backup, "backups": cmd_backups,
        "restore": cmd_restore}


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = build()
    a = ap.parse_args(argv)
    if not a.cmd:
        ap.print_help()
        return 2
    return CMDS[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
