# Trim

**Goal:** meaningfully shrink one always-on context file without dropping a single directive. Safest cuts first; the human approves every judgment call.

## Step 0: resolve the target

```
python "$HOME/.copilot/skills/trim/tools/trim.py" measure                 # the always-on set, largest first
python "$HOME/.copilot/skills/trim/tools/trim.py" resolve <name>          # or with no name: the largest file
```

Confirm the resolved absolute path with the user before touching anything.

## Step 1: show the state (grounding, not a claim)

```
python "$HOME/.copilot/skills/trim/tools/trim.py" sections <file>
```

Report `<file>: <bytes>` and where the weight actually sits; per-section bytes beat a single total, and an auto-appended tail is often the answer. State the target reduction for this run so step 5 has something to measure against.

## Step 2: deterministic wins first (zero risk)

```
python "$HOME/.copilot/skills/trim/tools/trim.py" gc <file>               # dry run: superseded, exact duplicates, absorbed
python "$HOME/.copilot/skills/trim/tools/trim.py" gc <file> --apply       # on approval; a backup is taken first
```

These removals are provably redundant. Re-measure. If the file is now small enough, stop here.

## Step 3: semantic reductions (human-gated)

Read the file. Build a ranked list of candidate trims, each with the exact target text and the estimated bytes saved, using three moves in decreasing safety:

- **RELOCATE** (safest): rarely needed detail (long mechanism explanations, enumerations, examples, war stories) goes to an on-demand reference, leaving a one-line stub and pointer. Good homes: a reference file next to the trimmed one (for a repo, under `docs/`), a skill's supporting file, or `~/.copilot/kai/MEMORY/KNOWLEDGE/<topic>.md` for user-level rules (MEMORY survives Kai reinstalls; the rest of the Kai home does not). `python "$HOME/.copilot/skills/trim/tools/trim.py" relocate <file> --heading "## X" --to <ref.md> --when "<when to read it>"` previews; `--apply` writes.
- **TIGHTEN:** a verbose multi-sentence rule becomes one plain sentence carrying the same directive. Cut throat-clearing, dated anecdotes and emphasis-only restatements, never the instruction itself.
- **MERGE:** two or more rules saying overlapping things become one rule carrying every distinct directive from all of them.

Rank by bytes saved times safety (relocate and tighten above merge). Present the list; the human picks which to apply, or says "all safe ones". Apply one at a time.

## Step 4: safety gate (before every semantic write)

1. **Coverage check:** save the original passage and your replacement to two files and run `python "$HOME/.copilot/skills/trim/tools/trim.py" coverage --original old.md --replacement new.md`. Any missing token (proper noun, path, tool or command, flag, env var, imperative) means the edit drops a directive: abort it and keep the original.
2. **Re-read** the replacement as the file's reader: does it still compel the same behaviour? If weaker, it is a bad trim.
3. **Relocations:** the tool verifies the moved content landed verbatim in the reference before it rewrites the source; confirm the stub points to it.

Deterministic GC skips this gate; only semantic edits need it.

## Step 5: commit and re-verify

- Take a backup before any manual edit: `python "$HOME/.copilot/skills/trim/tools/trim.py" backup <file>`. Undo with `python "$HOME/.copilot/skills/trim/tools/trim.py" restore <file>`.
- If the file is in a git repository, commit only that file: `git add <file>` then `git commit -m "trim: <file> <old> -> <new> B (-<pct>%)"`.
- Re-run `python "$HOME/.copilot/skills/trim/tools/trim.py" measure` (or `sections`) and report the new size. If it fell short of the step 1 target, say how much remains and offer to continue.

## Output shape

Lead with before and after: `AGENTS.md 40,456 -> 28,043 B (-31%)`. Then a short list of what was removed, merged or relocated, and the backup or commit reference. If the safety gate declined a candidate, say which one and why. Never claim the file was trimmed without the re-measured byte count as evidence.
