---
name: trim
description: "Shrinks an always-loaded instruction file that has grown too big (copilot-instructions.md, AGENTS.md, .github/copilot-instructions.md, *.instructions.md) through a human-gated pass: measure, provable garbage collection first (superseded, exact duplicates, already absorbed), then ranked semantic merges, tightenings and relocations, each checked by a coverage gate so no directive is dropped and each backed up so it can be undone. Use when the user says /trim, trim the context, this file is too big, my instructions are bloated, shrink copilot-instructions.md, prune AGENTS.md, reduce an always-loaded file, fold the proposals section. NOT FOR deciding which rules are dead weight across a whole setup (use /bitter-pill-engineering), general code refactoring, trimming audio or video, or removing AI writing patterns from prose."
---
# Trim

Shrink an always-on context file that has grown too big. `/trim <file>` walks the reduction, safest cuts first, and never drops a rule.

## Workflow routing

| Request | Workflow |
|---|---|
| /trim <file>, this file is too big, shrink my instructions, fold the proposals | `Workflows/Trim.md` |

## Quick reference

- **Target:** a bare name (`AGENTS`, `copilot-instructions`) resolves against the always-on set: the user instructions in the Copilot home, the repo's `AGENTS.md`, `CLAUDE.md`, `GEMINI.md`, `.github/copilot-instructions.md` and `.github/instructions/*.instructions.md`, plus Kai's `MEMORY/LEARNING/learnings.md` (its tail is injected every session). No argument: the largest.
- **Order is safest first:** show the state, deterministic GC, semantic trims (human-gated), safety gate, re-measure.
- **Three semantic moves:** MERGE overlapping rules, TIGHTEN verbose ones, RELOCATE rarely used detail to an on-demand reference with a stub and pointer.
- **The invariant:** a trim never drops a distinct directive. If a merge would, keep the original.

## Tool

`python "$HOME/.copilot/skills/trim/tools/trim.py" <command>`, standard library only:

| Command | Does |
|---|---|
| `measure [--cwd DIR]` | the always-on set with bytes and approximate tokens, largest first |
| `resolve [NAME]` | bare name to path; no name gives the largest file |
| `sections FILE` | bytes per heading, so you can see where the weight sits |
| `gc FILE [--apply]` | provable removals only: `[SUPERSEDED]` entries, exact duplicate bullets (keeps the newest `<!-- applied: ... -->`), and entries in a proposals/inbox section already present verbatim in the body |
| `coverage --original OLD --replacement NEW` | the safety gate: every code span, path, flag, env var, proper name and imperative in OLD must survive in NEW; exit 1 lists what is missing |
| `relocate FILE --heading "## X" --to REF.md [--when "..."] [--apply]` | moves a section verbatim to a reference file, verifies it landed, leaves a stub with a pointer |
| `backup` / `backups` / `restore [--id]` | timestamped copies in `~/.copilot/kai/MEMORY/STATE/trim-backups/`; every `--apply` backs up first |

## Gotchas

- **The Kai block is managed.** In `~/.copilot/copilot-instructions.md`, everything between `KAI:BEGIN` and `KAI:END` is overwritten by the next Kai install. Trim the user's own text outside the block freely; for the block, make the change in the install source too or it comes back.
- **The file can change mid-edit.** Hooks and other sessions may append to these files. If a write reports the file changed since it was read, re-read before writing; never write from a stale read. The tool refuses to apply when the file changed during planning.
- **Semantic edits are the risky class.** Run `coverage` before every merge or tighten. A missing token means the edit drops a directive: abort that edit and keep the original. Deterministic GC is always safe.
- **Deterministic first, always.** Run `gc` before proposing any semantic edit; the free, zero-risk removals often clear enough that no judgment call is needed.
- **Commit when it's in git.** If the file lives in a repository, commit only the trimmed file with a message like `trim: AGENTS.md 40,456 -> 28,043 B (-31%)`. Never sweep unrelated changes into that commit.

## Example

```
/trim AGENTS
-> AGENTS.md 40,456 B; weight sits in "## Proposals" (61%)
-> gc: 9 provable removals (3 superseded, 4 duplicates, 2 absorbed), applied, backup taken
-> ranked semantic trims: relocate "## Release process" (6.1 KB), merge 3 overlapping testing rules
-> coverage gate passes on each approved edit
-> AGENTS.md 28,043 B (-31%)
```
