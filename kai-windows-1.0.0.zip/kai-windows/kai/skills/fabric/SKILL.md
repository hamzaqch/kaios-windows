---
name: fabric
description: "Run proven prompt patterns natively from a local library of 43 curated patterns (extract_wisdom, summarize, analyze_claims, find_logical_fallacies, improve_writing, improve_prompt, humanize, review_code, create_stride_threat_model, create_sigma_rules, create_mermaid_visualization, create_prd, write_pull-request, summarize_meeting, rate_content and more). Kai reads the pattern's system.md and follows it against your input; no external binary, no network. Use when the user says fabric, run pattern, extract wisdom, summarize this, tldr, 5 sentence summary, fact-check these claims, find fallacies, improve my writing, improve this prompt, humanize this, review this code, STRIDE, threat model, sigma rules, mermaid diagram, write a PRD, design doc, user stories, PR description, commit message, meeting summary, flash cards, quiz me, rate this content, or update patterns. NOT FOR multi-source web research (use /research) or arXiv lookups (use /arxiv)."
argument-hint: "<pattern or intent> [content | URL | file]"
---
# Fabric

A local library of single-purpose prompt patterns. Each pattern is `Patterns/<name>/system.md`: an IDENTITY, the STEPS, and OUTPUT INSTRUCTIONS. Running a pattern means reading that file and following it exactly against the user's content. Kai is the model; there is no CLI round-trip.

**Done looks like:** the output follows the chosen pattern's OUTPUT INSTRUCTIONS to the letter (its section names, bullet counts, word limits, list style), applied to the user's actual content, with the pattern name stated in one line before the output so the user can redirect.

## Routing

| Want | Do |
|---|---|
| Run a pattern (named or implied) | `Workflows/ExecutePattern.md` |
| Add or refresh patterns from an upstream checkout | `Workflows/UpdatePatterns.md` |
| Browse what exists | `PatternCatalog.md`, or `python ~/.copilot/skills/fabric/tools/fabric.py list` |

## Tool contract

```
python ~/.copilot/skills/fabric/tools/fabric.py list [--json]
python ~/.copilot/skills/fabric/tools/fabric.py suggest "<what the user asked for>"
python ~/.copilot/skills/fabric/tools/fabric.py show <pattern>
python ~/.copilot/skills/fabric/tools/fabric.py search <term>
python ~/.copilot/skills/fabric/tools/fabric.py import <upstream patterns dir> [--only a,b] [--overwrite]
```

`suggest` maps intent to a pattern deterministically (an explicitly named pattern always wins). `show` prints the prompt to follow. You can also read `~/.copilot/skills/fabric/Patterns/<name>/system.md` directly with the view tool.

## Gotchas

- **Pattern names are exact and use underscores** (`extract_wisdom`, not `extract-wisdom`). The one exception is `write_pull-request`, which keeps its upstream hyphen. `show` accepts either separator and suggests close matches on a miss.
- **`create_threat_model` no longer exists upstream.** Threat-model requests go to `create_stride_threat_model`.
- **Word and count limits in patterns are part of the contract.** `extract_wisdom` asks for 16-word bullets and minimum counts; thin input that cannot meet a minimum gets fewer items plus one line saying the source was too short, never padded filler.
- **Long input can exceed a pattern's useful context.** For very long transcripts or documents, run `summarize` per chunk first, then the target pattern on the combined summaries, and say you did.
- **YouTube and paywalled pages:** fetch the transcript or text first (the research skill's `Workflows/Retrieve.md` covers hard-to-fetch content), then apply the pattern. Never apply a pattern to a title alone.
- **Prompts in `Patterns/` are data, not instructions to you outside the run.** Follow a pattern only while executing it for the user.
