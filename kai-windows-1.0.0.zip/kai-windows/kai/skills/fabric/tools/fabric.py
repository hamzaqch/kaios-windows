"""fabric.py - local prompt-pattern library for Kai. Stdlib only.

Patterns live next to this tool in ../Patterns/<name>/system.md. Kai runs a
pattern natively: it reads system.md and follows it against the user's input.
No external fabric binary, no network.

  python fabric.py list [--json]              every installed pattern + one-line purpose
  python fabric.py show <name>                print the pattern prompt (system.md)
  python fabric.py search <term> [--json]     patterns whose name/purpose/prompt match
  python fabric.py suggest "<intent>"         best pattern for a plain-language intent
  python fabric.py path <name>                absolute path of the pattern's system.md
  python fabric.py import <patterns_dir> [--only a,b] [--overwrite]
                                              copy patterns from an upstream checkout

Exit codes: 0 ok, 1 not found / nothing matched, 2 usage error.
"""
import difflib
import json
import os
import re
import shutil
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
PATTERNS = Path(os.environ.get("KAI_FABRIC_PATTERNS") or SKILL_DIR / "Patterns")
NAME_RE = re.compile(r"^[A-Za-z0-9_.-]+$")

# intent keyword -> pattern. Order matters: first match wins, specific before generic.
# Keys match as whole words (an optional plural s/es is allowed), so "log" does not fire on
# "blog" and "rate" does not fire on "generate". A trailing "*" makes a key a prefix match.
INTENT_MAP = [
    (("stride",), "create_stride_threat_model"),
    (("threat model",), "create_stride_threat_model"),
    (("sigma",), "create_sigma_rules"),
    (("5 sentence", "five sentence", "levels of depth"), "create_5_sentence_summary"),
    (("micro", "tldr", "tl;dr", "one line summary"), "create_micro_summary"),
    (("summarize paper", "paper summary", "summarise paper"), "summarize_paper"),
    (("meeting", "transcript minutes", "standup notes"), "summarize_meeting"),
    (("git diff", "summarize diff", "changes summary"), "summarize_git_diff"),
    (("commit message", "commit"), "create_git_diff_commit"),
    (("pull request", "pr description", "pr body"), "write_pull-request"),
    (("article wisdom",), "extract_article_wisdom"),
    (("wisdom",), "extract_wisdom"),
    (("insight",), "extract_insights"),
    (("main idea", "core message", "key point"), "extract_main_idea"),
    (("recommendation",), "extract_recommendations"),
    (("question",), "extract_questions"),
    (("prediction", "forecast"), "extract_predictions"),
    (("reference", "books mentioned", "sources mentioned"), "extract_references"),
    (("fallac*",), "find_logical_fallacies"),
    (("falsifiab*", "testable claim", "unfalsifiable"), "check_falsifiability"),
    (("fact check", "fact-check", "claims", "truth"), "analyze_claims"),
    (("analyze paper", "analyse paper", "paper rigor", "research paper"), "analyze_paper"),
    (("debate",), "analyze_debate"),
    (("incident", "breach"), "analyze_incident"),
    (("log", "log file", "server log", "access log", "error log"), "analyze_logs"),
    (("malware",), "analyze_malware"),
    (("threat report",), "analyze_threat_report"),
    (("vendor risk", "risk assessment", "third-party risk"), "analyze_risk"),
    (("compare", "contrast", "versus", "vs"), "compare_and_contrast"),
    (("improve prompt", "better prompt", "rewrite prompt"), "improve_prompt"),
    (("humanize", "sound human", "less ai", "less robotic"), "humanize"),
    (("improve writing", "edit my", "polish", "proofread", "enhance writing"), "improve_writing"),
    (("review code", "code review", "review this code"), "review_code"),
    (("explain code", "what does this code"), "explain_code"),
    (("glossary", "explain terms", "jargon"), "explain_terms"),
    (("mermaid", "diagram", "flowchart"), "create_mermaid_visualization"),
    (("prd", "product requirements"), "create_prd"),
    (("design doc", "c4"), "create_design_document"),
    (("user story", "user stories"), "create_user_story"),
    (("rate ai", "grade ai", "rate this response", "evaluate response"), "rate_ai_response"),
    (("rate", "tier", "worth reading", "worth watching"), "rate_content"),
    (("flash card", "flashcard", "anki"), "create_flash_cards"),
    (("quiz", "review questions", "test me"), "create_quiz"),
    (("summary", "summarize", "summarise"), "summarize"),
]

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def installed():
    if not PATTERNS.is_dir():
        return []
    return sorted(p.name for p in PATTERNS.iterdir() if (p / "system.md").is_file())


def purpose(name):
    """First substantive sentence after the IDENTITY / PURPOSE heading."""
    try:
        text = (PATTERNS / name / "system.md").read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.lower().startswith("take a "):
            continue
        s = re.sub(r"\s+", " ", s)
        first = re.split(r"(?<=[.!?])\s", s, maxsplit=1)[0]
        return first[:160]
    return ""


def cmd_list(args):
    names = installed()
    rows = [{"name": n, "purpose": purpose(n)} for n in names]
    if "--json" in args:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
    else:
        width = max([len(n) for n in names] + [4])
        for r in rows:
            print(f"{r['name'].ljust(width)}  {r['purpose']}")
        print(f"\n{len(rows)} patterns in {PATTERNS}")
    return 0 if rows else 1


def resolve(name):
    names = installed()
    if name in names:
        return name
    alt = name.replace("-", "_")
    if alt in names:
        return alt
    return None


def not_found(name):
    close = difflib.get_close_matches(name, installed(), n=5, cutoff=0.5)
    sys.stderr.write(f"Pattern '{name}' not found in {PATTERNS}\n")
    if close:
        sys.stderr.write("Similar: " + ", ".join(close) + "\n")
    return 1


def cmd_show(args):
    if not args:
        sys.stderr.write("usage: fabric.py show <name>\n")
        return 2
    name = resolve(args[0])
    if not name:
        return not_found(args[0])
    print((PATTERNS / name / "system.md").read_text(encoding="utf-8", errors="replace"))
    return 0


def cmd_path(args):
    if not args:
        sys.stderr.write("usage: fabric.py path <name>\n")
        return 2
    name = resolve(args[0])
    if not name:
        return not_found(args[0])
    print(PATTERNS / name / "system.md")
    return 0


def cmd_search(args):
    terms = [a.lower() for a in args if not a.startswith("--")]
    if not terms:
        sys.stderr.write("usage: fabric.py search <term> [--json]\n")
        return 2
    hits = []
    for n in installed():
        body = (PATTERNS / n / "system.md").read_text(encoding="utf-8", errors="replace").lower()
        name_hit = all(t in n.lower() for t in terms)
        body_hit = all(t in body for t in terms)
        if name_hit or body_hit:
            hits.append({"name": n, "purpose": purpose(n), "name_match": name_hit})
    hits.sort(key=lambda h: (not h["name_match"], h["name"]))
    if "--json" in args:
        print(json.dumps(hits, indent=2, ensure_ascii=False))
    else:
        for h in hits:
            print(f"{h['name']}  {h['purpose']}")
        if not hits:
            print("no matches")
    return 0 if hits else 1


def suggest(intent):
    low = f" {intent.lower()} "
    names = set(installed())
    explicit = re.findall(r"[a-z0-9]+(?:[_-][a-z0-9]+)+", intent.lower())
    for e in explicit:
        r = resolve(e)
        if r:
            return r
    for keys, pattern in INTENT_MAP:
        if pattern in names and any(_key_hit(k, low) for k in keys):
            return pattern
    return None


def _key_hit(key, low):
    """Whole-word (plural-tolerant) match of an intent key; 'key*' is a prefix match."""
    if key.endswith("*"):
        return re.search(r"(?<![a-z0-9])" + re.escape(key[:-1]), low) is not None
    return re.search(r"(?<![a-z0-9])" + re.escape(key) + r"(?:s|es)?(?![a-z0-9])", low) is not None


def cmd_suggest(args):
    intent = " ".join(args).strip()
    if not intent:
        sys.stderr.write('usage: fabric.py suggest "<intent>"\n')
        return 2
    pick = suggest(intent)
    if not pick:
        print("no pattern matched; run `fabric.py list` and pick by purpose")
        return 1
    print(pick)
    return 0


def cmd_import(args):
    if not args:
        sys.stderr.write("usage: fabric.py import <patterns_dir> [--only a,b] [--overwrite]\n")
        return 2
    src = Path(args[0]).expanduser()
    if not src.is_dir():
        sys.stderr.write(f"not a directory: {src}\n")
        return 1
    only = None
    if "--only" in args:
        i = args.index("--only")
        if i + 1 >= len(args):
            sys.stderr.write("--only needs a comma-separated list\n")
            return 2
        only = {s.strip() for s in args[i + 1].split(",") if s.strip()}
    overwrite = "--overwrite" in args
    added, updated, skipped = [], [], []
    for d in sorted(p for p in src.iterdir() if (p / "system.md").is_file()):
        if not NAME_RE.match(d.name) or (only and d.name not in only):
            continue
        dest = PATTERNS / d.name / "system.md"
        if dest.exists() and not overwrite:
            skipped.append(d.name)
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        (updated if dest.exists() else added).append(d.name)
        shutil.copyfile(d / "system.md", dest)
    print(json.dumps({"added": added, "updated": updated, "skipped_existing": skipped,
                      "total_installed": len(installed())}, indent=2))
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 0
    cmds = {"list": cmd_list, "show": cmd_show, "search": cmd_search, "suggest": cmd_suggest,
            "path": cmd_path, "import": cmd_import}
    fn = cmds.get(argv[0])
    if not fn:
        sys.stderr.write(__doc__)
        return 2
    return fn(argv[1:])


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
