# UpdatePatterns

Add patterns to the local library, or refresh existing ones, from a checkout of the open-source Fabric patterns collection. Kai ships 43 curated patterns; the upstream collection has 250+.

**Done looks like:** the requested patterns exist under `~/.copilot/skills/fabric/Patterns/<name>/system.md`, the import report shows what was added, updated or skipped, and `fabric.py list` shows the new total.

## Steps

1. Get the upstream patterns folder. Any of these works:
   - `git clone --depth 1 <fabric repository URL> <temp dir>` then use `<temp dir>/data/patterns` (the user supplies the URL; confirm it before cloning).
   - A patterns folder the user already has on disk.
2. Preview: list the folder and pick what the user wants. Default to `--only` with named patterns rather than importing all 250+; the curated set is deliberately small so `list` stays readable.
3. Import:
   ```
   python ~/.copilot/skills/fabric/tools/fabric.py import <patterns dir> --only name_a,name_b
   ```
   Existing patterns are skipped unless `--overwrite` is passed. Ask before overwriting, because a local pattern may have been edited on purpose.
4. Read each newly added `system.md` once before reporting. Patterns are prompts; reject any that reference private people, tools you do not have, or template variables the run cannot fill (`{{query_language_info}}` style placeholders), and delete those folders.
5. Report the JSON summary and the new `list` count. Add one line per new pattern to `PatternCatalog.md` so routing knows it exists.

## Gotchas

- **The installer overwrites the skill folder on reinstall.** Patterns imported into `~/.copilot/skills/fabric/Patterns` survive normal use but are replaced when Kai is reinstalled. If you maintain many custom patterns, keep a full patterns folder elsewhere (copy the curated set into it too) and set the `KAI_FABRIC_PATTERNS` environment variable to that folder; the tool then reads only that folder.
- **Upstream licensing.** Upstream patterns are MIT-licensed. Keep `NOTICE.md` in place when redistributing the skill.
