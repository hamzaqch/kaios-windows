# ExecutePattern

Apply one pattern to the user's content and return exactly the shape the pattern specifies.

## Pick the pattern

- If the user named a pattern, use it. Confirm it exists with `fabric.py show <name>`; on a miss, offer the close matches it prints.
- Otherwise run `python ~/.copilot/skills/fabric/tools/fabric.py suggest "<the user's request>"`. If it prints a name, use it. If nothing matches, pick from `PatternCatalog.md` by purpose.
- When two patterns fit (for example `summarize` vs `create_micro_summary`), state the pick in one line (`Using create_micro_summary; say "full summary" for summarize.`) and proceed. Do not stop to ask.

## Get the content

| Input | How |
|---|---|
| Text pasted in the prompt | use as-is |
| Local file | read it with the view tool |
| URL | fetch it with the web fetch tool; if blocked, use the research skill's `Workflows/Retrieve.md` |
| YouTube | get the transcript first (Retrieve workflow); a title or description is not content |
| Nothing provided | ask for the text, URL, or file in one line |

## Run it

Read `Patterns/<name>/system.md` (via `fabric.py show <name>` or the view tool) and follow its STEPS and OUTPUT INSTRUCTIONS against the content. The `INPUT:` line at the end of each pattern marks where the content goes; `{{input}}` placeholders mean the same.

Output contract:
1. One line naming the pattern used.
2. The pattern's output, in the pattern's own section names and list style. Most patterns say "only output Markdown, no warnings or notes"; honor that inside the pattern output.
3. Anything Kai needs to add (a caveat about thin input, a chunking note) goes after the pattern output, not inside it.

## Keep it (summarize-family only)

For `summarize`, `create_5_sentence_summary`, `create_micro_summary`, `summarize_paper`, `summarize_meeting`, `extract_wisdom` and `extract_article_wisdom`, when the input is a URL or at least 200 characters of text, drop a capture into the knowledge harvest queue so it can be promoted into a typed note later:

```
python ~/.copilot/skills/cortex/tools/cortex.py queue add --title "<source title>" --source-url "<url, if any>" --body-file <file with the summary>
```

This is a side effect. If the cortex skill is not installed or the command fails, still deliver the summary and mention the failure in one line. Never let capture block or replace the summary. The queue de-duplicates by source URL, so re-running on the same URL reports `duplicate` and writes nothing.
