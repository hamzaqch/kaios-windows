# Pattern catalog

The 43 patterns shipped with Kai, grouped by job. `fabric.py list` prints the live set, including anything imported later.

## Extract

| Pattern | Use it for |
|---|---|
| `extract_wisdom` | Ideas, insights, quotes, habits, facts, references and recommendations from talks, podcasts and long reads |
| `extract_article_wisdom` | The same sections, tuned for written articles |
| `extract_insights` | Only the most powerful insights, as 16-word bullets |
| `extract_main_idea` | The single main idea plus the key recommendation |
| `extract_recommendations` | Practical recommendations as a flat list |
| `extract_questions` | Every question an interviewer asked |
| `extract_predictions` | Predictions with date, confidence and how to verify them |
| `extract_references` | Books, art, papers and other works the content mentions |

## Summarize

| Pattern | Use it for |
|---|---|
| `summarize` | One-sentence summary, ten main points, five takeaways |
| `create_5_sentence_summary` | The content at five depths, from five words down to one |
| `create_micro_summary` | A 20-word summary with a few points and takeaways |
| `summarize_paper` | Academic paper: approach, setup, results, limits |
| `summarize_meeting` | Meeting transcript: decisions, tasks, owners, next steps |
| `summarize_git_diff` | A diff turned into a clear change summary |

## Analyze and judge

| Pattern | Use it for |
|---|---|
| `analyze_claims` | Rate truth claims with evidence for and against, fallacies, verdict |
| `find_logical_fallacies` | Name and explain formal and informal fallacies in an argument |
| `check_falsifiability` | Whether claims and frameworks can be tested and proven wrong |
| `analyze_paper` | Research paper rigor, findings and quality grade |
| `analyze_debate` | Arguments, agreements and disagreements in a debate, with ratings |
| `compare_and_contrast` | A markdown table comparing items across topics |
| `rate_content` | Labels plus an S-to-D tier and a 1-100 quality score |
| `rate_ai_response` | Grade an AI response against what an expert human would produce |

## Security

| Pattern | Use it for |
|---|---|
| `create_stride_threat_model` | STRIDE threat model: assets, trust boundaries, threats, mitigations |
| `create_sigma_rules` | Sigma detection rules from TTPs in security writeups |
| `analyze_incident` | Structured facts from a breach or incident report |
| `analyze_threat_report` | Trends, stats, quotes and recommendations from a threat report |
| `analyze_malware` | Indicators, techniques and detection ideas from malware analysis |
| `analyze_logs` | Patterns, anomalies and reliability fixes in server logs |
| `analyze_risk` | Third-party vendor risk score with suggested controls |

## Build and write

| Pattern | Use it for |
|---|---|
| `create_prd` | A product requirements document |
| `create_design_document` | C4-style system design with business and security posture |
| `create_user_story` | Technical user stories with acceptance criteria |
| `create_mermaid_visualization` | A standalone Mermaid diagram explaining a concept |
| `write_pull-request` | A PR description from `git diff` output |
| `create_git_diff_commit` | Conventional-commit message and the git commands to commit |
| `review_code` | Code review: correctness, security, performance, readability |
| `explain_code` | Plain explanation of code, config or tool output |
| `explain_terms` | Glossary of advanced terms with analogies |

## Improve

| Pattern | Use it for |
|---|---|
| `improve_writing` | Grammar, clarity and style fixes that keep the meaning |
| `improve_prompt` | Rewrite an AI prompt using prompt-engineering practice |
| `humanize` | Make stiff AI-sounding text read naturally |

## Learn

| Pattern | Use it for |
|---|---|
| `create_flash_cards` | Question/answer flash cards for key concepts |
| `create_quiz` | Review questions for stated learning objectives |
