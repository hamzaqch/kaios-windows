# SketchDiagram

Produce a diagram as a `.tldr` canvas in tldraw's hand-drawn style, the sketch alternative to polished generated art.

## Sufficiency check

Before drawing, know what the diagram must communicate, roughly how many elements it has, and where the file should go (the user's path, else the current project folder). If an interpretation fork would change the structure, flag it in one line (`Picking left-to-right flow over a hub-and-spoke because the steps are sequential; redirect if wrong.`) and proceed.

## Ideal state

- A `.tldr` file exists at the agreed path, passes `validate`, and holds the full diagram: every concept the user named is a shape, every relationship an arrow, nothing extra.
- Layout reads left-to-right or top-to-bottom in flow order; no overlapping shapes; related items visibly grouped by proximity or a frame.
- The reply gives the file path and how to open it (SKILL.md, Opening a canvas), local options first for private content.

## Tool contract

```
python ~/.copilot/skills/tldraw/tools/tldr.py create <file.tldr> [--title "Heading"]
python ~/.copilot/skills/tldraw/tools/tldr.py add <file.tldr> --spec <spec.json>
python ~/.copilot/skills/tldraw/tools/tldr.py validate <file.tldr>
python ~/.copilot/skills/tldraw/tools/tldr.py inspect <file.tldr>
```

Spec kinds: `box`, `ellipse`, `text`, `note`, `frame`, `arrow`. Full prop table: `../References/TldrFormat.md`.

## Layout conventions

- Boxes default to 220x120. Leave at least 140 px horizontal and 100 px vertical between shapes so bound arrows have room.
- Give every shape a `name` and reference those names in arrows. Shapes must come before the arrows that connect them (earlier in the same spec array is fine).
- Color carries meaning: 2 to 4 colors from the enum, `fill: "solid"` only on the shapes that should pop.
- A `frame` groups and titles a region. Prefer one frame per cluster over floating labels. Size the frame to enclose its shapes with ~40 px padding.

## Verification

`validate` passing plus `inspect` output matching the intended shape and edge list closes the claim. You can't see rendered pixels from here, so say "validated structurally; open it to eyeball the layout", never "it looks good".
