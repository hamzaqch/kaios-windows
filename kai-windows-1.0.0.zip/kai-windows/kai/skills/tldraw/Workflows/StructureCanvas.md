# StructureCanvas

Read a human's rough canvas (scattered notes, boxes, fragments) and write back an organized version: clustered, framed, connected, nothing lost.

## Sufficiency check

Confirm the file path and whether the user wants the same file changed (default) or a structured copy alongside it. If the canvas is open in an editor, ask them to close it or to expect to reopen it (editors hold files in memory).

## Ideal state

- Every piece of the user's content survives. No shape's text is deleted or reworded: organizing means moving, grouping, framing and connecting. Adding new summary or label shapes is fine and encouraged.
- Related items sit in named clusters (frames with titles), spatially separated from other clusters; cross-cluster relationships are drawn as labeled arrows.
- The file still passes `validate`, and `inspect --json` before and after shows identical user text.
- The reply summarizes the structure found: the clusters and the one-line story of the canvas. The reading is a deliverable, not just the file change.

## Safety gate

Before the first change, run `tldr.py backup <file.tldr>` (writes `<name>.bak.tldr` beside it) and say so. The canvas is the user's own work and the backup is the undo.

## Tool contract

```
python ~/.copilot/skills/tldraw/tools/tldr.py inspect <file.tldr> --json          # full read: shapes, text, positions, edges
python ~/.copilot/skills/tldraw/tools/tldr.py backup <file.tldr>
python ~/.copilot/skills/tldraw/tools/tldr.py move <file.tldr> --id <id> --x N --y N
python ~/.copilot/skills/tldraw/tools/tldr.py add <file.tldr> --spec <spec.json>  # frames, arrows, summary labels
python ~/.copilot/skills/tldraw/tools/tldr.py validate <file.tldr>
```

Save the first `inspect --json` output to a file so the before/after text comparison is a real diff, not a recollection.

## Privacy

An ideation canvas is personal content. Keep all reading and writing local, and never suggest a web surface for a private canvas.
