---
name: tldraw
description: "Read, create and edit tldraw .tldr canvas files deterministically: sketch hand-drawn-style diagrams (boxes, ellipses, sticky notes, frames, text, bound arrows) straight into a canvas file the user opens in tldraw.com, the VS Code tldraw extension or the desktop app, and read a rough canvas back as structured data to cluster and organize it. Use when the user says tldraw, .tldr file, whiteboard, canvas, sketch a diagram, hand-drawn diagram, draw this on a canvas, put this on the whiteboard, map this out visually, structure my canvas, organize my whiteboard, read my canvas, or cluster my sticky notes. NOT FOR polished images or Mermaid diagrams (use /fabric create_mermaid_visualization), web UI design (use /webdesign), or HTML reports (use /html)."
argument-hint: "sketch <what> | structure <file.tldr>"
---
# tldraw

The `.tldr` format is plain JSON (`{tldrawFileFormatVersion: 1, schema, records}`). `tools/tldr.py` writes records that pass tldraw's own validator, so generated files open cleanly in any tldraw surface. Two directions: Kai to canvas (sketch a diagram) and canvas to Kai (read and organize a human's rough thinking).

## Routing

| Workflow | Trigger | File |
|---|---|---|
| SketchDiagram | "sketch a diagram", "draw this on a canvas", "tldraw diagram" | `Workflows/SketchDiagram.md` |
| StructureCanvas | "structure my canvas", "organize my whiteboard", "read my canvas" | `Workflows/StructureCanvas.md` |

## Tool contract

```
python ~/.copilot/skills/tldraw/tools/tldr.py <create|inspect|add|remove|move|settext|validate|backup> <file.tldr> [flags]
```

Record shapes, the spec format and coordinate conventions: `References/TldrFormat.md`. Vendored schema (tldraw 5.2.5): `References/SchemaSnapshot.json`. Every mutating command loads, changes and saves atomically; an invalid spec aborts the whole `add` before anything is written.

## Opening a canvas

- **VS Code**: the tldraw extension opens `.tldr` files in the editor, fully local. The right choice for private content.
- **tldraw desktop app**: File > Open (or import) the `.tldr` file.
- **tldraw.com**: File > Open. Content goes to a third-party web app, so only for content already meant to be public.
- **Export to image**: in any tldraw surface, select all, then Export as SVG or PNG. No headless export ships with this skill.

## Gotchas

- **Write spec JSON to a file and pass `--spec <file>`.** Shells mangle inline JSON (PowerShell drops quotes; some shells expand `\n` inside strings). `--spec -` reads stdin.
- **Text is `richText`, never a plain string.** Labels on geo, text, note and arrow shapes are ProseMirror doc JSON; tldraw's validator rejects a bare `text` prop. The tool builds this; never hand-write records.
- **Arrow bindings need `terminal: "start"|"end"`.** tldraw's own defaults omit it but its validator rejects bindings without it. The tool sets it; keep it if you ever hand-edit.
- **Raw records need every prop.** Records in the file bypass editor defaulting, so one missing prop (for example `growY` on a geo shape) fails the load. Always go through `add`.
- **Fractional `index` strings order shapes.** They are base62, lexicographic, and must never end in `0`. The tool generates them; `validate` flags bad ones.
- **The desktop app's native `.tldraw` save is a different format** (a zip with a database). This skill targets portable `.tldr` JSON, which every surface can open or import.
- **Editors hold files in memory.** If the canvas is open while you edit it on disk, the editor may not reload or may overwrite your change on save. Ask the user to close it first, or to reopen it after your write.
