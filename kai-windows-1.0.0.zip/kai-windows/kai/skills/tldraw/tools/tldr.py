"""tldr.py - deterministic read/write for tldraw .tldr canvas files. Stdlib only.

Writes records matching tldraw's store schema (verified against tldraw 5.2.5's
own load path). The vendored schema snapshot in ../References/SchemaSnapshot.json
makes new files loadable by any tldraw surface at or above that version.

  python tldr.py create   <file> [--title "Heading text"] [--force]
  python tldr.py inspect  <file> [--json]
  python tldr.py add      <file> --spec <spec.json | ->
  python tldr.py remove   <file> --ids id1,id2
  python tldr.py move     <file> --id <shapeId> [--x N] [--y N]
  python tldr.py settext  <file> --id <shapeId> --text "New label"
  python tldr.py validate <file>
  python tldr.py backup   <file>            copy to <file>.bak.tldr before mutating

Spec: a JSON array of simplified shape specs; kinds box, ellipse, text, note,
frame, arrow. Full table in ../References/TldrFormat.md.
Exit codes: 0 ok, 1 error (message on stderr).
"""
import json
import re
import shutil
import sys
from pathlib import Path

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "References" / "SchemaSnapshot.json"
COLORS = ["black", "grey", "light-violet", "violet", "blue", "light-blue", "yellow", "orange",
          "green", "light-green", "light-red", "red", "white"]
GEOS = ["rectangle", "ellipse", "triangle", "diamond", "pentagon", "hexagon", "octagon", "star",
        "rhombus", "oval", "trapezoid", "arrow-right", "arrow-left", "arrow-up", "arrow-down",
        "x-box", "check-box", "heart", "cloud"]
FILLS = ["none", "semi", "solid", "pattern", "fill"]
DASHES = ["draw", "solid", "dashed", "dotted"]
SIZES = ["s", "m", "l", "xl"]
FONTS = ["draw", "sans", "serif", "mono"]
HEADS = ["none", "arrow", "triangle", "square", "dot", "pipe", "diamond", "inverted", "bar"]
DIGITS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"


class TldrError(Exception):
    pass


# ---------------------------------------------------------------- helpers

def rich_text(text):
    paras = []
    for line in str(text).split("\n"):
        p = {"type": "paragraph"}
        if line:
            p["content"] = [{"type": "text", "text": line}]
        paras.append(p)
    return {"type": "doc", "content": paras}


def plain_text(rt):
    if not isinstance(rt, dict):
        return ""

    def walk(node):
        if node.get("type") == "text":
            return node.get("text", "")
        inner = "".join(walk(c) for c in node.get("content", []) if isinstance(c, dict))
        return inner + "\n" if node.get("type") == "paragraph" else inner

    return walk(rt).rstrip()


def next_index(last):
    """Next fractional index strictly after `last` (base62, never ending in '0')."""
    if not last:
        return "a1"
    pos = DIGITS.find(last[-1])
    if 0 <= pos < len(DIGITS) - 1:
        return last[:-1] + DIGITS[pos + 1]
    return last + "1"


def slug(s):
    out = re.sub(r"[^a-z0-9]+", "-", str(s).lower()).strip("-")[:40]
    return out or "shape"


def load(path):
    try:
        doc = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        raise TldrError(f"{path} does not exist")
    except ValueError as e:
        raise TldrError(f"{path} is not valid JSON: {e}")
    if doc.get("tldrawFileFormatVersion") != 1 or not isinstance(doc.get("records"), list):
        raise TldrError(f"{path} is not a v1 .tldr file")
    return doc


def save(path, doc):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)


def page_id(doc):
    for r in doc["records"]:
        if r.get("typeName") == "page":
            return r["id"]
    raise TldrError("no page record found")


def max_index(doc):
    idxs = sorted(r.get("index", "") for r in doc["records"] if r.get("typeName") == "shape")
    return idxs[-1] if idxs else None


def unique_id(doc, prefix, base, taken=None):
    ids = {r.get("id") for r in doc["records"]} | (taken or set())
    cand, n = f"{prefix}:{base}", 2
    while cand in ids:
        cand = f"{prefix}:{base}-{n}"
        n += 1
    return cand


def base_shape(sid, typ, parent, x, y, index, props):
    return {"id": sid, "typeName": "shape", "type": typ, "parentId": parent, "x": x, "y": y,
            "rotation": 0, "index": index, "isLocked": False, "opacity": 1, "meta": {}, "props": props}


def find_shape(doc, ref):
    for r in doc["records"]:
        if r.get("typeName") == "shape" and (r.get("id") == ref or r.get("id") == f"shape:{ref}"):
            return r
    return None


def center_of(shape):
    w = (shape.get("props") or {}).get("w", 0) or 0
    h = (shape.get("props") or {}).get("h", 0) or 0
    return {"x": shape.get("x", 0) + w / 2, "y": shape.get("y", 0) + h / 2}


def pick(spec, key, allowed, default):
    v = spec.get(key, default)
    if v not in allowed:
        raise TldrError(f'invalid {key} "{v}" - one of: {", ".join(allowed)}')
    return v


def num(spec, key, default):
    v = spec.get(key, default)
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise TldrError(f"{key} must be a number (got {v!r})")
    return v


# ---------------------------------------------------------------- spec expansion

def expand_spec(doc, spec, pid, index):
    if not isinstance(spec, dict):
        raise TldrError(f"spec entries must be objects (got {spec!r})")
    kind = spec.get("kind")
    color = pick(spec, "color", COLORS, "black")
    font = pick(spec, "font", FONTS, "draw")
    size = pick(spec, "size", SIZES, "m")
    name = spec.get("name") or slug(spec.get("text") or spec.get("title") or kind or "shape")
    x, y = num(spec, "x", 0), num(spec, "y", 0)

    if kind in ("box", "ellipse"):
        geo = "ellipse" if kind == "ellipse" else pick(spec, "geo", GEOS, "rectangle")
        return [base_shape(unique_id(doc, "shape", name), "geo", pid, x, y, index, {
            "geo": geo, "w": num(spec, "w", 220), "h": num(spec, "h", 120), "color": color,
            "labelColor": "black", "fill": pick(spec, "fill", FILLS, "none"),
            "dash": pick(spec, "dash", DASHES, "draw"), "size": size, "font": font,
            "align": "middle", "verticalAlign": "middle", "growY": 0, "url": str(spec.get("url", "")),
            "scale": 1, "richText": rich_text(spec.get("text", ""))})]
    if kind == "text":
        return [base_shape(unique_id(doc, "shape", name), "text", pid, x, y, index, {
            "color": color, "size": size, "w": num(spec, "w", 400), "font": font,
            "textAlign": pick(spec, "textAlign", ["start", "middle", "end"], "start"),
            "autoSize": "w" not in spec, "scale": 1, "richText": rich_text(spec.get("text", ""))})]
    if kind == "note":
        return [base_shape(unique_id(doc, "shape", name), "note", pid, x, y, index, {
            "color": pick(spec, "color", COLORS, "yellow"), "richText": rich_text(spec.get("text", "")),
            "size": size, "font": font, "align": "middle", "verticalAlign": "middle", "labelColor": "black",
            "growY": 0, "fontSizeAdjustment": 1, "url": "", "scale": 1, "textLastEditedBy": None})]
    if kind == "frame":
        return [base_shape(unique_id(doc, "shape", name), "frame", pid, x, y, index, {
            "w": num(spec, "w", 640), "h": num(spec, "h", 360),
            "name": str(spec.get("title", spec.get("text", ""))), "color": color})]
    if kind == "arrow":
        src, dst = find_shape(doc, str(spec.get("from"))), find_shape(doc, str(spec.get("to")))
        if not src or not dst:
            raise TldrError(f'arrow needs existing from/to shapes ("{spec.get("from")}" -> "{spec.get("to")}")')
        a, b = center_of(src), center_of(dst)
        arrow_name = spec.get("name") or (slug(spec["text"]) if spec.get("text")
                                          else f"arrow-{slug(spec.get('from'))}-{slug(spec.get('to'))}")
        aid = unique_id(doc, "shape", arrow_name)
        bprops = {"isPrecise": False, "isExact": False, "normalizedAnchor": {"x": 0.5, "y": 0.5}, "snap": "none"}
        start_id = unique_id(doc, "binding", f"{slug(spec.get('from'))}-start")
        end_id = unique_id(doc, "binding", f"{slug(spec.get('to'))}-end", taken={start_id})
        return [
            base_shape(aid, "arrow", pid, 0, 0, index, {
                "kind": "arc", "elbowMidPoint": 0.5, "dash": pick(spec, "dash", DASHES, "draw"), "size": size,
                "fill": "none", "color": color, "labelColor": "black", "bend": num(spec, "bend", 0),
                "start": a, "end": b,
                "arrowheadStart": pick(spec, "arrowheadStart", HEADS, "none"),
                "arrowheadEnd": pick(spec, "arrowheadEnd", HEADS, "arrow"),
                "richText": rich_text(spec.get("text", "")), "labelPosition": 0.5, "font": font, "scale": 1}),
            {"id": start_id, "typeName": "binding", "type": "arrow", "fromId": aid, "toId": src["id"],
             "props": dict(bprops, terminal="start"), "meta": {}},
            {"id": end_id, "typeName": "binding", "type": "arrow", "fromId": aid, "toId": dst["id"],
             "props": dict(bprops, terminal="end"), "meta": {}},
        ]
    raise TldrError(f'unknown spec kind "{kind}" - one of: box, ellipse, text, note, frame, arrow')


# ---------------------------------------------------------------- commands

def opt(args, name):
    if name in args:
        i = args.index(name)
        if i + 1 < len(args):
            return args[i + 1]
        raise TldrError(f"{name} needs a value")
    return None


def cmd_create(path, args):
    if Path(path).exists() and "--force" not in args:
        raise TldrError(f"{path} already exists (pass --force to overwrite)")
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    doc = {"tldrawFileFormatVersion": 1, "schema": schema, "records": [
        {"gridSize": 10, "name": "", "meta": {}, "id": "document:document", "typeName": "document"},
        {"meta": {}, "id": "page:page", "name": "Page 1", "index": "a1", "typeName": "page"}]}
    title = opt(args, "--title")
    if title:
        doc["records"].append(base_shape("shape:title", "text", "page:page", 0, -80, "a1", {
            "color": "black", "size": "xl", "w": 700, "font": "draw", "textAlign": "start",
            "autoSize": False, "scale": 1, "richText": rich_text(title)}))
    save(path, doc)
    return f"created {path} ({len(doc['records'])} records)"


def inspect_data(path, doc):
    shapes = [r for r in doc["records"] if r.get("typeName") == "shape"]
    binds = [r for r in doc["records"] if r.get("typeName") == "binding"]
    out = {"file": str(path),
           "pages": [{"id": r["id"], "name": r.get("name")} for r in doc["records"] if r.get("typeName") == "page"],
           "shapes": [], "edges": []}
    for s in shapes:
        p = s.get("props") or {}
        row = {"id": s["id"], "type": s.get("type"), "x": s.get("x"), "y": s.get("y"),
               "w": p.get("w"), "h": p.get("h"), "color": p.get("color")}
        txt = plain_text(p.get("richText"))
        if txt:
            row["text"] = txt
        if s.get("type") == "frame":
            row["title"] = p.get("name")
        if s.get("parentId") and not str(s["parentId"]).startswith("page:"):
            row["parent"] = s["parentId"]
        out["shapes"].append({k: v for k, v in row.items() if v is not None})
    for b in binds:
        if (b.get("props") or {}).get("terminal") != "start":
            continue
        end = next((x for x in binds if x.get("fromId") == b.get("fromId")
                    and (x.get("props") or {}).get("terminal") == "end"), None)
        arrow = next((s for s in shapes if s["id"] == b.get("fromId")), None)
        label = plain_text((arrow or {}).get("props", {}).get("richText"))
        edge = {"arrow": b.get("fromId"), "from": b.get("toId"), "to": end.get("toId") if end else None}
        if label:
            edge["label"] = label
        out["edges"].append(edge)
    return out


def cmd_inspect(path, args):
    data = inspect_data(path, load(path))
    if "--json" in args:
        return json.dumps(data, indent=2, ensure_ascii=False)
    lines = [f"{path} - {len(data['pages'])} page(s), {len(data['shapes'])} shape(s)"]
    for s in data["shapes"]:
        dims = f" {s['w']}x{s['h']}" if s.get("w") is not None and s.get("h") is not None else ""
        txt = f' "{s["text"].replace(chr(10), " / ")}"' if s.get("text") else ""
        ttl = f' [{s["title"]}]' if s.get("title") else ""
        lines.append(f"  {s['id']} [{s['type']}] @({s['x']},{s['y']}){dims}{ttl}{txt}")
    for e in data["edges"]:
        lines.append(f"  {e['from']} -> {e['to']}" + (f' "{e["label"]}"' if e.get("label") else ""))
    return "\n".join(lines)


def cmd_add(path, args):
    doc = load(path)
    src = opt(args, "--spec")
    if not src:
        raise TldrError("add requires --spec <file|->")
    raw = sys.stdin.buffer.read().decode("utf-8-sig") if src == "-" else Path(src).read_text(encoding="utf-8-sig")
    try:
        specs = json.loads(raw)
    except ValueError as e:
        raise TldrError(f"--spec is not valid JSON: {e}")
    if not isinstance(specs, list):
        raise TldrError("--spec must be a JSON array of shape specs")
    pid, index, added = page_id(doc), max_index(doc), []
    for spec in specs:  # all-or-nothing: errors abort before save
        index = next_index(index)
        recs = expand_spec(doc, spec, pid, index)
        doc["records"].extend(recs)
        added.append(recs[0]["id"])
    save(path, doc)
    return f"added {len(added)} shape(s): {', '.join(added)}"


def cmd_remove(path, args):
    doc = load(path)
    ids = [s.strip() for s in (opt(args, "--ids") or "").split(",") if s.strip()]
    if not ids:
        raise TldrError("remove requires --ids a,b")
    drop = set()
    for ref in ids:
        rec = next((r for r in doc["records"] if r.get("id") in (ref, f"shape:{ref}")), None)
        if not rec:
            raise TldrError(f"no record {ref}")
        drop.add(rec["id"])
    # cascade to a fixpoint: bindings touching dropped shapes, then arrows left dangling,
    # then the arrow's OTHER binding (a single forward pass would leave it dangling)
    binds = [r for r in doc["records"] if r.get("typeName") == "binding"]
    size = -1
    while size != len(drop):
        size = len(drop)
        for b in binds:
            if b.get("toId") in drop or b.get("fromId") in drop:
                drop.add(b["id"])
                drop.add(b.get("fromId"))
        for r in doc["records"]:  # children of dropped frames
            if r.get("typeName") == "shape" and r.get("parentId") in drop:
                drop.add(r["id"])
    before = len(doc["records"])
    doc["records"] = [r for r in doc["records"] if r.get("id") not in drop]
    save(path, doc)
    return f"removed {before - len(doc['records'])} record(s)"


def cmd_move(path, args):
    doc = load(path)
    ref = opt(args, "--id")
    shape = find_shape(doc, ref) if ref else None
    if not shape:
        raise TldrError(f"no shape {ref}" if ref else "move requires --id")
    for axis in ("x", "y"):
        v = opt(args, f"--{axis}")
        if v is not None:
            try:
                shape[axis] = float(v) if "." in v else int(v)
            except ValueError:
                raise TldrError(f"--{axis} must be a number")
    save(path, doc)
    return f"moved {shape['id']} to ({shape['x']},{shape['y']})"


def cmd_settext(path, args):
    doc = load(path)
    ref, text = opt(args, "--id"), opt(args, "--text")
    if not ref or text is None:
        raise TldrError("settext requires --id and --text")
    shape = find_shape(doc, ref)
    if not shape:
        raise TldrError(f"no shape {ref}")
    props = shape.setdefault("props", {})
    if shape.get("type") == "frame":
        props["name"] = text
    elif "richText" in props:
        props["richText"] = rich_text(text)
    else:
        raise TldrError(f"shape {shape['id']} ({shape.get('type')}) has no text")
    save(path, doc)
    return f"set text on {shape['id']}"


def validate_doc(doc):
    errs = []
    ids = [r.get("id") for r in doc["records"]]
    idset = set(ids)
    if len(ids) != len(idset):
        dupes = sorted({i for i in ids if ids.count(i) > 1 and i})
        errs.append(f"duplicate record ids: {', '.join(dupes)}")
    if not any(r.get("typeName") == "document" for r in doc["records"]):
        errs.append("missing document record")
    if not any(r.get("typeName") == "page" for r in doc["records"]):
        errs.append("missing page record")
    for r in doc["records"]:
        if not r.get("id") or not r.get("typeName"):
            errs.append(f"record without id/typeName: {json.dumps(r)[:60]}")
            continue
        if r["typeName"] == "shape":
            if r.get("parentId") not in idset:
                errs.append(f"{r['id']}: parent {r.get('parentId')} not found")
            idx = r.get("index", "")
            if not idx or idx.endswith("0") or any(c not in DIGITS for c in idx):
                errs.append(f"{r['id']}: invalid fractional index {idx!r}")
            color = (r.get("props") or {}).get("color")
            if color is not None and color not in COLORS:
                errs.append(f"{r['id']}: invalid color {color}")
            if "text" in (r.get("props") or {}):
                errs.append(f"{r['id']}: plain 'text' prop is rejected by tldraw; use richText")
        if r["typeName"] == "binding":
            if (r.get("props") or {}).get("terminal") not in ("start", "end"):
                errs.append(f"{r['id']}: binding missing terminal start|end")
            if r.get("fromId") not in idset or r.get("toId") not in idset:
                errs.append(f"{r['id']}: dangling binding")
    return errs


def cmd_validate(path, args):
    doc = load(path)
    errs = validate_doc(doc)
    if errs:
        raise TldrError("INVALID:\n  " + "\n  ".join(errs))
    return f"valid: {path} ({len(doc['records'])} records)"


def cmd_backup(path, args):
    load(path)
    p = Path(path)
    dest = p.with_name(p.stem + ".bak.tldr")
    shutil.copyfile(p, dest)
    return f"backup: {dest}"


COMMANDS = {"create": cmd_create, "inspect": cmd_inspect, "add": cmd_add, "remove": cmd_remove,
            "move": cmd_move, "settext": cmd_settext, "validate": cmd_validate, "backup": cmd_backup}


def main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    if len(argv) < 2 or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 0 if (argv and argv[0] in ("-h", "--help", "help")) or not argv else 1
    fn = COMMANDS.get(argv[0])
    if not fn:
        sys.stderr.write(f'ERROR: unknown command "{argv[0]}"\n')
        return 1
    try:
        print(fn(argv[1], argv[2:]))
        return 0
    except TldrError as e:
        sys.stderr.write(f"ERROR: {e}\n")
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
