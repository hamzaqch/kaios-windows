# AcceptanceTestMutation

Test the ISA claims themselves. A claim is load-bearing only if its probe would judge a meaningfully different claim differently. If "every endpoint returns 401" and "every endpoint does not return 401" would both pass the same probe, the claim constrains nothing.

## Tool contract

```
python "$HOME/.copilot/skills/hardening/tools/isc_mutate.py" <path>/ISA.md
python "$HOME/.copilot/skills/hardening/tools/isc_mutate.py" <path>/ISA.md --claim C3 --json
```

It parses `- [ ] C1 <claim>. Probe: <check>` lines (criteria and anti-claims), flags claims that are fluff on their face (vague words with no measurable bound, no probe, a probe naming no tool or check, subjective probes, compound claims, example-shaped claims, aspirational wording), and generates mutants per claim: negated, numbers shifted (x10 and +1), quantifier swapped (every to some), comparator swapped (within to beyond), qualifier dropped. Read-only; it never runs probes.

## Judging mutants

For each mutant, ask: run against the current state, would the claim's probe pass for the mutant exactly as it does for the original?

- **The probe distinguishes** (the negated and number-shifted mutants would fail): the claim is load-bearing.
- **The probe can't tell**: the claim is fluff. Sharpen the claim with a bound, or sharpen the probe so it observes the claimed property (assert the status code, measure the latency, check every endpoint rather than one).

For many claims, hand the `--json` output to a subagent (`@kai-reviewer`) to judge each mutant against each probe, then verify a sample yourself.

## Done looks like

Every flagged or fluff claim rewritten in the ISA with a probe that would fail on its negation, the rewrites recorded in the ISA's Decisions section, and `python "$HOME/.copilot/kai/bin/kai.py" isa check <path>` still passing.
