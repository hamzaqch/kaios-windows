# MutationTest

Prove the test suite catches bugs by injecting them one at a time. Every surviving mutant is a bug the tests would let through.

## Done looks like

- A baseline mutation score for the target, with the survivors listed by file and line.
- Each survivor triaged: **killed** by a new or sharper assertion (confirmed by rerunning), **equivalent** (the change can't alter behaviour; say why), or **accepted** (not worth a test; say why).
- The final score, rerun after the new tests.

## Tool contract

```
python "$HOME/.copilot/skills/hardening/tools/mutate.py" --root <project> --target <file-or-folder> --list
python "$HOME/.copilot/skills/hardening/tools/mutate.py" --root <project> --target <file-or-folder> [--jobs 4] -- python -m pytest -q
python "$HOME/.copilot/skills/hardening/tools/mutate.py" ... --max-mutants 150 --seed 1   # sampled run for big targets
python "$HOME/.copilot/skills/hardening/tools/mutate.py" ... --lines 40-120 --json         # just the code you changed
```

Mutations: comparison flips (`<` to `<=` / `>=`, `==` to `!=`), arithmetic and bitwise swaps, `and`/`or`, `True`/`False`, `is`/`is not`, `in`/`not in`, `break`/`continue`, removed `not` and unary minus, constants (0 to 1, n to n+1), emptied strings, and `return <expr>` to `return None`. Docstrings, type annotations and lines marked `# pragma: no mutate` are skipped. Folder targets skip test files. The project itself is never modified; runs happen in temporary copies with bytecode writing off, and a timeout (5x baseline + 5 s by default) counts as killed.

The tool refuses to run if the baseline suite fails.

## Reading survivors

- A boundary flip surviving (`<` to `<=`) means no test sits exactly on the boundary. Add one.
- `return None` surviving means a caller never checks the value. Assert on it.
- A constant change surviving means the magic number is untested; test the behaviour at that value.
- `and`/`or` surviving means a branch is reachable with only one condition true; test each condition separately.

Scores are only comparable on the same mutant set. Report the command used. For other languages use their mutation tool (Stryker for JS/TS, PIT for Java, cargo-mutants for Rust) with the same triage.
