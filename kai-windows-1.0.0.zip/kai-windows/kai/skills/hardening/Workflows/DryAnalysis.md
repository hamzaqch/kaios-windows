# DryAnalysis

Find copy-pasted code. A bug fixed in one copy lives on in the others.

## Tool contract

```
python "$HOME/.copilot/skills/hardening/tools/dry.py" --root <project> --target <src> [--min-tokens 50]
python "$HOME/.copilot/skills/hardening/tools/dry.py" --root <project> --target <src> --normalize --json   # renamed copies too
python "$HOME/.copilot/skills/hardening/tools/dry.py" --root <project> --target <src> --ext .ps1 --ext .cs
```

Python is tokenized exactly; other languages (JS/TS, PowerShell, C#, Java, Go, Rust, C/C++, Ruby, shell and more) use a generic tokenizer that drops `//`, `#`, `--` and `/* */` comments. Windows of `--min-tokens` tokens that repeat are merged into maximal clone pairs with line ranges. Output includes the duplicated-line percentage.

## Done looks like

- Clone pairs ranked by size, each judged: **extract** (same logic that must stay in sync: one function), **leave** (coincidental similarity, test fixtures, generated code), or **parametrize** (test cases that differ only by data).
- Extractions done with the existing tests still green, and the duplication percentage rerun.

Lower `--min-tokens` (25-30) to see smaller clones; raise it to focus on the big ones. `--normalize` catches copies where only names and literals changed, at the cost of more coincidental matches.
