# CrapAnalysis

Rank functions by CRAP (Change Risk Anti-Patterns): `complexity^2 x (1 - coverage)^3 + complexity`. Complex, untested code scores high; complex but fully tested code scores just its complexity.

## Tool contract

```
python "$HOME/.copilot/skills/hardening/tools/crap.py" --root <project> --target <src> --run -- python -m pytest -q
python "$HOME/.copilot/skills/hardening/tools/crap.py" --root <project> --target <src> --coverage-json coverage.json
python "$HOME/.copilot/skills/hardening/tools/crap.py" --root <project> --target <src> --threshold 30 --top 25 --json
```

Coverage per function is executed statement lines divided by statement lines in that function (nested functions are scored separately). `--run` traces the test command with `sys.settrace` in a subprocess; `--coverage-json` reads a coverage.py JSON report (`coverage json`). With neither, every function counts as uncovered, which still ranks by complexity.

Complexity is cyclomatic: 1 plus each `if`/`elif`, loop, `except`, ternary, extra boolean operand, comprehension loop and filter, `match` case and `assert`.

## Done looks like

- The top risky functions (above the threshold, 30 by default) listed with complexity and coverage.
- For each: the cheaper fix chosen and done. Tests if the logic is right but unproven; a refactor (split branches, table-drive) if the complexity itself is the problem. Often both.
- A rerun showing the new CRAP for the functions touched.
