# PropertyTest

Find functions that deserve a universal claim, write the claim as a property, run it on hundreds of generated inputs, and land either a passing property test or a shrunk counterexample that becomes a fix plus a regression example.

## When a function qualifies

It is pure (deterministic, no side effects) and at least one of these holds. If none do, keep example tests.

| # | Category | Form | Example |
|---|---|---|---|
| 1 | Round-trip | `decode(encode(x)) == x` | `parse(render(cfg)) == cfg` |
| 2 | Idempotency | `f(f(x)) == f(x)` | `normalize_path(normalize_path(p)) == normalize_path(p)` |
| 3 | Commutativity | `f(a, b) == f(b, a)` | `merge(a, b) == merge(b, a)` |
| 4 | Associativity | `f(f(a, b), c) == f(a, f(b, c))` | three-layer config merge |
| 5 | Identity | `f(x, e) == x` | `render(template, {}) == template` (no placeholders) |
| 6 | Conservation | an invariant survives | `sorted(xs)` keeps every element and the length |
| 7 | Model-based | matches a trivial reference implementation | fast lookup vs linear scan |
| 8 | Metamorphic | a known input change implies a known output change | adding evidence never lowers a score |
| 9 | State machine | any legal sequence keeps invariants | a phase never moves backward except on resume |
| 10 | Oracle | matches a trusted alternative | your parser vs `json.loads` on valid JSON |

Candidate questions, for `f: A -> B`: is it pure; is there an inverse; does it normalise; does it take two same-typed arguments; is there a no-op argument; what does it preserve; is there a simpler reference; does it have ordering or monotonic semantics; is it part of a state machine; does another implementation exist? Two or three categories often apply; pick the strongest.

## Tool contract

```python
import sys; sys.path.insert(0, r"<path to>/hardening/tools")   # or copy proptest.py next to your tests
import proptest as pt

class TestSlug(unittest.TestCase):
    @pt.given(pt.text(max_size=60), runs=1000)
    def test_slug_is_idempotent(self, s):
        self.assertEqual(slugify(slugify(s)), slugify(s))
```

Generators: `integers(min, max)`, `floats(min, max, allow_nan, allow_infinity)`, `booleans()`, `text(alphabet, min_size, max_size)`, `binary()`, `lists(g, min_size, max_size, unique)`, `tuples(...)`, `dictionaries(k, v)`, `fixed_dictionaries({...})`, `sampled_from(seq)`, `one_of(...)`, `just(v)`, `none()`, `builds(fn, ...)`, `recursive_lists(leaf)`, plus `.map(fn)` and `.filter(pred)` on any generator. `pt.assume(cond)` discards an input. `pt.check(prop, *gens, runs=, seed=)` is the non-decorator form.

Budget: `runs=1000` by default for real properties, 10000 for invariant-critical code, 100 for slow generators. Boundary values (empty, zero, min, max) always run first.

On failure, `PropertyFailure` prints the minimal counterexample, the error, and the seed. Then either fix the code (the counterexample shows a bug) or fix the property (it was wrong), and add the counterexample as a plain example test with `# proptest seed: <seed>` beside it.

## Landing it

1. A test file next to the existing tests (for example `tests/test_<module>_properties.py`).
2. If an ISA governs the work, a claim whose probe runs it: `- [ ] C7 slugify is idempotent for all text up to 60 chars. Probe: python -m unittest tests.test_slug_properties` (Kai ISA format: `~/.copilot/kai/ISA_FORMAT.md`).
3. If a counterexample was found and fixed, a Decisions entry: conjectured (the property), refuted by (the shrunk input), learned (the missing case), criterion now (the tightened property).

Reference: John Hughes, QuickCheck (2000).
