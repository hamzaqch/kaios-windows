"""proptest: a small property-based testing library for Python, stdlib only.

Express a universal claim ("for all x, P(x)"), run it against hundreds of random
inputs plus boundary values, and when it fails, shrink the input to a minimal
counterexample and report the seed that reproduces it.

    import proptest as pt

    @pt.given(pt.lists(pt.integers()), runs=1000)
    def test_sort_idempotent(xs):
        assert sorted(sorted(xs)) == sorted(xs)

Works as a plain function, inside unittest.TestCase methods (the decorator keeps
`self`), or with pytest. Reproduce a failure with KAI_PROPTEST_SEED=<seed> or
`seed=` on the decorator. Copy this file next to your tests, or add the hardening
tools folder to sys.path.
"""
import functools
import inspect
import math
import os
import random
import string
import sys

__all__ = ["Gen", "integers", "floats", "booleans", "text", "binary", "lists", "tuples", "dictionaries",
           "fixed_dictionaries", "sampled_from", "one_of", "just", "none", "builds", "recursive_lists",
           "check", "given", "assume", "PropertyFailure", "Unsatisfiable"]


class Unsatisfiable(Exception):
    """Too many generated inputs were rejected by assume() or a filter."""


class _Reject(Exception):
    pass


def assume(condition):
    """Discard the current input if condition is false (not a failure)."""
    if not condition:
        raise _Reject()


class PropertyFailure(AssertionError):
    def __init__(self, message, counterexample, seed, original):
        super().__init__(message)
        self.counterexample = counterexample
        self.seed = seed
        self.original = original


# --------------------------------------------------------------------------- generators
#
# A generator works on "raw" values it can shrink, and realizes them into the value the
# property sees. map() and filter() wrap realize, so mapped values still shrink through
# their raw source.

class Gen:
    def draw(self, rng):
        raise NotImplementedError

    def shrink(self, raw):
        return iter(())

    def realize(self, raw):
        return raw

    def edges(self):
        return []

    def map(self, fn):
        return _Mapped(self, fn)

    def filter(self, pred, max_tries=100):
        return _Filtered(self, pred, max_tries)

    def example(self, seed=0):
        return self.realize(self.draw(random.Random(seed)))


class _Mapped(Gen):
    def __init__(self, inner, fn):
        self.inner, self.fn = inner, fn

    def draw(self, rng):
        return self.inner.draw(rng)

    def shrink(self, raw):
        return self.inner.shrink(raw)

    def realize(self, raw):
        return self.fn(self.inner.realize(raw))

    def edges(self):
        return self.inner.edges()


class _Filtered(Gen):
    def __init__(self, inner, pred, max_tries):
        self.inner, self.pred, self.max_tries = inner, pred, max_tries

    def _ok(self, raw):
        try:
            return bool(self.pred(self.inner.realize(raw)))
        except Exception:
            return False

    def draw(self, rng):
        for _ in range(self.max_tries):
            raw = self.inner.draw(rng)
            if self._ok(raw):
                return raw
        raise _Reject()

    def shrink(self, raw):
        return (r for r in self.inner.shrink(raw) if self._ok(r))

    def realize(self, raw):
        return self.inner.realize(raw)

    def edges(self):
        return [e for e in self.inner.edges() if self._ok(e)]


class _Integers(Gen):
    def __init__(self, min_value=None, max_value=None):
        if min_value is not None and max_value is not None and min_value > max_value:
            raise ValueError("min_value > max_value")
        self.lo, self.hi = min_value, max_value

    def _clamp(self, x):
        if self.lo is not None and x < self.lo:
            return self.lo
        if self.hi is not None and x > self.hi:
            return self.hi
        return x

    def _target(self):
        return self._clamp(0)

    def draw(self, rng):
        lo = self.lo if self.lo is not None else -(2 ** rng.choice((4, 8, 16, 32, 63)))
        hi = self.hi if self.hi is not None else 2 ** rng.choice((4, 8, 16, 32, 63))
        if rng.random() < 0.6 and hi - lo > 200:
            # bias toward small magnitudes, where most bugs live
            mid = self._target()
            span = rng.choice((2, 10, 100))
            return self._clamp(rng.randint(mid - span, mid + span))
        return rng.randint(lo, hi)

    def shrink(self, raw):
        t = self._target()
        if raw == t:
            return
        yield t
        d = raw - t
        halves = []
        while abs(d) > 1:
            d = int(d / 2)  # truncates toward zero
            halves.append(t + d)
        for cand in reversed(halves):  # closest to the target first
            cand = self._clamp(cand)
            if cand not in (raw, t):
                yield cand
        nxt = self._clamp(raw + (-1 if raw > t else 1))
        if nxt not in (raw, t):
            yield nxt

    def edges(self):
        vals = [self._target(), self._clamp(1), self._clamp(-1)]
        if self.lo is not None:
            vals += [self.lo, self._clamp(self.lo + 1)]
        if self.hi is not None:
            vals += [self.hi, self._clamp(self.hi - 1)]
        out = []
        for v in vals:
            if v not in out:
                out.append(v)
        return out


def integers(min_value=None, max_value=None):
    return _Integers(min_value, max_value)


class _Floats(Gen):
    def __init__(self, min_value=None, max_value=None, allow_nan=False, allow_infinity=False):
        self.lo, self.hi, self.nan, self.inf = min_value, max_value, allow_nan, allow_infinity

    def _ok(self, x):
        if math.isnan(x):
            return self.nan
        if math.isinf(x) and not self.inf:
            return False
        if self.lo is not None and x < self.lo:
            return False
        if self.hi is not None and x > self.hi:
            return False
        return True

    def draw(self, rng):
        for _ in range(50):
            r = rng.random()
            if r < 0.05 and self.nan:
                x = float("nan")
            elif r < 0.1 and self.inf:
                x = rng.choice((float("inf"), float("-inf")))
            elif self.lo is not None and self.hi is not None:
                x = rng.uniform(self.lo, self.hi)
            else:
                x = rng.choice((1, -1)) * rng.choice((rng.random(), rng.random() * 1000, 10 ** rng.uniform(-10, 10)))
            if self._ok(x):
                return x
        return self.lo if self.lo is not None else 0.0

    def shrink(self, raw):
        if math.isnan(raw) or math.isinf(raw):
            for c in (0.0, 1.0):
                if self._ok(c):
                    yield c
            return
        for c in (0.0, float(int(raw)), round(raw, 1), raw / 2):
            if c != raw and self._ok(c) and abs(c) <= abs(raw):
                yield c

    def edges(self):
        cands = [0.0, -0.0, 1.0, -1.0, 0.5, 1e-9, 1e9]
        if self.lo is not None:
            cands.append(float(self.lo))
        if self.hi is not None:
            cands.append(float(self.hi))
        if self.nan:
            cands.append(float("nan"))
        if self.inf:
            cands += [float("inf"), float("-inf")]
        return [c for c in cands if self._ok(c)]


def floats(min_value=None, max_value=None, allow_nan=False, allow_infinity=False):
    return _Floats(min_value, max_value, allow_nan, allow_infinity)


class _SampledFrom(Gen):
    def __init__(self, seq):
        self.seq = list(seq)
        if not self.seq:
            raise ValueError("sampled_from needs a non-empty sequence")

    def draw(self, rng):
        return rng.randrange(len(self.seq))

    def shrink(self, raw):
        for i in range(raw):
            yield i

    def realize(self, raw):
        return self.seq[raw]

    def edges(self):
        return sorted({0, len(self.seq) - 1})


def sampled_from(seq):
    return _SampledFrom(seq)


def booleans():
    return sampled_from([False, True])


def just(value):
    return sampled_from([value])


def none():
    return just(None)


class _Lists(Gen):
    def __init__(self, elem, min_size=0, max_size=None, unique=False):
        self.elem, self.min, self.max, self.unique = elem, min_size, max_size, unique

    def _size(self, rng):
        hi = self.max if self.max is not None else max(self.min, rng.choice((5, 10, 30, 100)))
        return rng.randint(self.min, max(self.min, hi))

    def draw(self, rng):
        n = self._size(rng)
        out, seen, tries = [], set(), 0
        while len(out) < n and tries < n * 10 + 10:
            tries += 1
            raw = self.elem.draw(rng)
            if self.unique:
                key = _key(self.elem.realize(raw))
                if key in seen:
                    continue
                seen.add(key)
            out.append(raw)
        if len(out) < self.min:
            raise _Reject()
        return out

    def _valid(self, raws):
        if len(raws) < self.min or (self.max is not None and len(raws) > self.max):
            return False
        if self.unique:
            keys = [_key(self.elem.realize(r)) for r in raws]
            return len(set(keys)) == len(keys)
        return True

    def shrink(self, raw):
        n = len(raw)
        # delete chunks, largest first
        size = n
        while size > 0:
            for start in range(0, n - size + 1):
                cand = raw[:start] + raw[start + size:]
                if self._valid(cand):
                    yield cand
            size //= 2
        # shrink individual elements
        for i, r in enumerate(raw):
            for s in self.elem.shrink(r):
                cand = raw[:i] + [s] + raw[i + 1:]
                if self._valid(cand):
                    yield cand

    def realize(self, raw):
        return [self.elem.realize(r) for r in raw]

    def edges(self):
        out = []
        if self.min == 0:
            out.append([])
        for e in self.elem.edges()[:2]:
            cand = [e] * max(1, self.min)
            if self._valid(cand):
                out.append(cand)
        return out


def _key(v):
    try:
        hash(v)
        return v
    except TypeError:
        return repr(v)


def lists(elem, min_size=0, max_size=None, unique=False):
    return _Lists(elem, min_size, max_size, unique)


def text(alphabet=None, min_size=0, max_size=None):
    """Strings. Default alphabet mixes ASCII letters, digits, punctuation, whitespace and some non-ASCII."""
    if alphabet is None:
        alphabet = string.ascii_letters + string.digits + string.punctuation + " \t\n" + "éßΩ中😀\u0000"
    return lists(sampled_from(alphabet), min_size, max_size).map("".join)


def binary(min_size=0, max_size=None):
    return lists(integers(0, 255), min_size, max_size).map(bytes)


class _Tuples(Gen):
    def __init__(self, gens):
        self.gens = gens

    def draw(self, rng):
        return tuple(g.draw(rng) for g in self.gens)

    def shrink(self, raw):
        for i, g in enumerate(self.gens):
            for s in g.shrink(raw[i]):
                yield raw[:i] + (s,) + raw[i + 1:]

    def realize(self, raw):
        return tuple(g.realize(r) for g, r in zip(self.gens, raw))

    def edges(self):
        firsts = [g.edges()[:1] for g in self.gens]
        if all(firsts):
            return [tuple(f[0] for f in firsts)]
        return []


def tuples(*gens):
    return _Tuples(list(gens))


def fixed_dictionaries(mapping):
    keys = list(mapping)
    return tuples(*[mapping[k] for k in keys]).map(lambda vals: dict(zip(keys, vals)))


def dictionaries(keys, values, min_size=0, max_size=None):
    return lists(tuples(keys, values), min_size, max_size).map(dict)


class _OneOf(Gen):
    def __init__(self, gens):
        self.gens = gens

    def draw(self, rng):
        i = rng.randrange(len(self.gens))
        return (i, self.gens[i].draw(rng))

    def shrink(self, raw):
        i, r = raw
        for j in range(i):  # earlier alternatives count as simpler
            for e in self.gens[j].edges()[:1]:
                yield (j, e)
        for s in self.gens[i].shrink(r):
            yield (i, s)

    def realize(self, raw):
        return self.gens[raw[0]].realize(raw[1])

    def edges(self):
        return [(i, e) for i, g in enumerate(self.gens) for e in g.edges()[:1]]


def one_of(*gens):
    return _OneOf(list(gens))


def builds(fn, *gens, **kwgens):
    keys = list(kwgens)
    return tuples(*gens, *[kwgens[k] for k in keys]).map(
        lambda vals: fn(*vals[:len(gens)], **dict(zip(keys, vals[len(gens):]))))


def recursive_lists(leaf, max_depth=3, max_size=4):
    """Nested lists of leaf values up to max_depth (trees, JSON-like structures)."""
    g = leaf
    for _ in range(max_depth):
        g = one_of(leaf, lists(g, max_size=max_size))
    return g


# --------------------------------------------------------------------------- runner

def _seed(seed):
    if seed is not None:
        return int(seed)
    env = os.environ.get("KAI_PROPTEST_SEED")
    if env:
        return int(env, 0)
    return random.SystemRandom().randrange(1, 2 ** 32)


def _fails(prop, gens, raws, args_prefix):
    vals = [g.realize(r) for g, r in zip(gens, raws)]
    try:
        prop(*args_prefix, *vals)
    except _Reject as rej:
        return False, rej
    except Exception as exc:  # any exception, assertion or crash, is a counterexample
        return True, exc
    return False, None


def _shrink(prop, gens, raws, exc, args_prefix, budget):
    steps = 0
    improved = True
    while improved and steps < budget:
        improved = False
        for i, g in enumerate(gens):
            for cand in g.shrink(raws[i]):
                steps += 1
                if steps >= budget:
                    break
                trial = raws[:i] + [cand] + raws[i + 1:]
                failed, e = _fails(prop, gens, trial, args_prefix)
                if failed and type(e) is type(exc):
                    raws, exc, improved = trial, e, True
                    break
            if improved or steps >= budget:
                break
    return raws, exc, steps


def check(prop, *gens, runs=200, seed=None, max_shrinks=2000, args_prefix=(), name=None):
    """Run prop(*values) on `runs` generated inputs. Raises PropertyFailure with the
    shrunk counterexample on the first failure. Returns a stats dict on success."""
    seed = _seed(seed)
    rng = random.Random(seed)
    gens = list(gens)
    name = name or getattr(prop, "__name__", "property")
    # boundary values first: the empty, zero and min/max cases most often break code
    edge_rows = []
    edge_lists = [g.edges() or [None] for g in gens]
    for k in range(max((len(e) for e in edge_lists), default=0)):
        row = [e[min(k, len(e) - 1)] for e in edge_lists]
        if all(r is not None for r in row):
            edge_rows.append(row)
    ran = rejected = 0
    attempts = 0
    while ran < runs:
        attempts += 1
        if attempts > runs * 20 + 100:
            raise Unsatisfiable(f"{name}: only {ran} of {runs} inputs satisfied assume()/filters (seed {seed})")
        try:
            raws = edge_rows.pop(0) if edge_rows else [g.draw(rng) for g in gens]
        except _Reject:
            rejected += 1
            continue
        failed, exc = _fails(prop, gens, raws, args_prefix)
        if isinstance(exc, _Reject):
            rejected += 1
            continue
        if failed:
            original = [g.realize(r) for g, r in zip(gens, raws)]
            raws, exc, steps = _shrink(prop, gens, raws, exc, args_prefix, max_shrinks)
            vals = [g.realize(r) for g, r in zip(gens, raws)]
            shown = vals[0] if len(vals) == 1 else tuple(vals)
            msg = (f"Property '{name}' falsified after {ran + 1} run(s) (seed {seed}, {steps} shrink steps).\n"
                   f"  minimal counterexample: {shown!r}\n"
                   f"  error: {type(exc).__name__}: {exc}\n"
                   f"  reproduce: KAI_PROPTEST_SEED={seed}  (pin it in a comment: # proptest seed: {seed})")
            raise PropertyFailure(msg, shown, seed, original) from exc
        ran += 1
    return {"name": name, "runs": ran, "rejected": rejected, "seed": seed}


def given(*gens, runs=200, seed=None, max_shrinks=2000):
    """Decorator form of check(). Keeps a leading `self` for unittest methods."""
    def deco(fn):
        params = list(inspect.signature(fn).parameters)
        extra = len(params) - len(gens)

        @functools.wraps(fn)
        def wrapper(*args):
            prefix = args[:extra] if extra > 0 else ()
            check(fn, *gens, runs=runs, seed=seed, max_shrinks=max_shrinks, args_prefix=prefix, name=fn.__name__)

        # hide the generated parameters from pytest's fixture resolution
        wrapper.__signature__ = inspect.Signature(
            [inspect.Parameter(p, inspect.Parameter.POSITIONAL_OR_KEYWORD) for p in params[:max(extra, 0)]])
        return wrapper
    return deco


def _demo_claim(xs):
    assert sorted(xs) == xs, "not sorted"


if __name__ == "__main__":
    # tiny demo: a deliberately wrong claim, shrunk to its minimal counterexample
    try:
        check(_demo_claim, lists(integers()), runs=500, seed=7, name="every_list_is_sorted")
    except PropertyFailure as pf:
        print(pf)
        sys.exit(0)
    print("demo property unexpectedly held")
    sys.exit(1)
