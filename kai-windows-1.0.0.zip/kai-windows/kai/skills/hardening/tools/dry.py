"""dry: copy-paste (clone) detection across a codebase, stdlib only.

Tokenizes source files, slides a window of N tokens, and reports every span that
appears more than once, merged into maximal clones with file and line ranges.
With --normalize, identifiers and literals are abstracted, so renamed copies
(type-2 clones) are found too.

    python dry.py --root . --target src                     # default: 50-token windows
    python dry.py --root . --target src --min-tokens 30 --normalize --json
    python dry.py --root . --target src --ext .py --ext .ps1

Python is tokenized exactly (tokenize module); other languages use a generic
tokenizer that drops // # -- and /* */ comments. Duplication rot is a signal:
fix the logic in one copy and the bug lives on in the other.
"""
import argparse
import hashlib
import io
import json
import re
import sys
import tokenize
from collections import defaultdict
from pathlib import Path

DEFAULT_EXTS = (".py", ".js", ".jsx", ".ts", ".tsx", ".ps1", ".psm1", ".cs", ".java", ".go", ".rb", ".rs",
                ".c", ".h", ".cpp", ".hpp", ".kt", ".swift", ".php", ".sh", ".lua", ".scala")
IGNORE_DIRS = {".git", "__pycache__", ".venv", "venv", "env", "node_modules", "dist", "build", ".tox", "vendor",
               "third_party", ".next", "target", "bin", "obj"}
GENERIC_TOKEN = re.compile(r'"(?:\\.|[^"\\\n])*"|\'(?:\\.|[^\'\\\n])*\'|`[^`]*`|[A-Za-z_$][\w$]*|\d[\w.]*|==|!=|<=|>=|=>|->|&&|\|\||\S')
KEYWORDS = {"if", "else", "elif", "for", "while", "return", "def", "class", "function", "var", "let", "const",
            "try", "except", "catch", "finally", "import", "from", "new", "switch", "case", "break", "continue",
            "in", "not", "and", "or", "is", "with", "as", "yield", "await", "async", "public", "private",
            "static", "void", "int", "string", "bool", "true", "false", "True", "False", "None", "null", "this",
            "self", "param", "foreach", "lambda", "pass", "raise", "throw", "func", "fn", "struct", "enum"}


def strip_comments(text):
    text = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    out = []
    for line in text.splitlines():
        s = line.lstrip()
        if s.startswith(("//", "#", "--")):
            out.append("")
        else:
            out.append(re.sub(r"\s//.*$", "", line))
    return "\n".join(out)


def tokens_python(text, normalize):
    out = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(text).readline):
            if tok.type in (tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
                            tokenize.ENDMARKER):
                continue
            s = tok.string
            if normalize:
                if tok.type == tokenize.NAME and s not in KEYWORDS:
                    s = "ID"
                elif tok.type in (tokenize.NUMBER, tokenize.STRING):
                    s = "LIT"
            out.append((s, tok.start[0]))
    except (tokenize.TokenError, IndentationError, SyntaxError):
        return tokens_generic(text, normalize)
    return out


def tokens_generic(text, normalize):
    out = []
    for lineno, line in enumerate(strip_comments(text).splitlines(), 1):
        for m in GENERIC_TOKEN.finditer(line):
            s = m.group(0)
            if normalize:
                if s[0] in "\"'`" or s[0].isdigit():
                    s = "LIT"
                elif (s[0].isalpha() or s[0] in "_$") and s not in KEYWORDS:
                    s = "ID"
            out.append((s, lineno))
    return out


def collect(root, targets, exts):
    files = []
    for t in targets:
        p = Path(t) if Path(t).is_absolute() else root / t
        if p.is_dir():
            for f in sorted(p.rglob("*")):
                if f.is_file() and f.suffix.lower() in exts and not any(x in IGNORE_DIRS for x in f.parts):
                    files.append(f)
        elif p.is_file():
            files.append(p)
    return files


def find_clones(file_tokens, min_tokens):
    """file_tokens: {name: [(tok, line), ...]}. Returns merged clone groups."""
    index = defaultdict(list)
    for name, toks in file_tokens.items():
        strs = [t for t, _ in toks]
        for i in range(0, len(strs) - min_tokens + 1):
            h = hashlib.blake2b("\x00".join(strs[i:i + min_tokens]).encode("utf-8"), digest_size=12).digest()
            index[h].append((name, i))
    # pair each later occurrence with the first; extend runs of consecutive window matches
    pairs = defaultdict(set)
    for occ in index.values():
        if len(occ) < 2:
            continue
        first = occ[0]
        for other in occ[1:]:
            if other[0] == first[0] and abs(other[1] - first[1]) < min_tokens:
                continue  # overlapping self-match (repetitive code like a = [0, 0, 0, ...])
            pairs[(first[0], other[0], other[1] - first[1])].add(first[1])
    clones = []
    for (fa, fb, offset), starts in pairs.items():
        run_start = prev = None
        for s in sorted(starts) + [None]:
            if s is not None and prev is not None and s == prev + 1:
                prev = s
                continue
            if run_start is not None:
                a0, a1 = run_start, prev + min_tokens - 1
                b0, b1 = a0 + offset, a1 + offset
                ta, tb = file_tokens[fa], file_tokens[fb]
                clones.append({"tokens": a1 - a0 + 1,
                               "a": {"file": fa, "start": ta[a0][1], "end": ta[a1][1]},
                               "b": {"file": fb, "start": tb[b0][1], "end": tb[b1][1]}})
            run_start = prev = s
    clones.sort(key=lambda c: (-c["tokens"], c["a"]["file"], c["a"]["start"]))
    return clones


def main(argv=None):
    ap = argparse.ArgumentParser(prog="dry.py", description="Clone (copy-paste) detection")
    ap.add_argument("--root", default=".")
    ap.add_argument("--target", action="append", required=True)
    ap.add_argument("--ext", action="append", help="file extension to include (repeatable); default: common languages")
    ap.add_argument("--min-tokens", type=int, default=50)
    ap.add_argument("--normalize", action="store_true", help="abstract identifiers and literals (find renamed copies)")
    ap.add_argument("--top", type=int, default=30)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    root = Path(args.root).resolve()
    exts = tuple(e.lower() if e.startswith(".") else "." + e.lower() for e in (args.ext or DEFAULT_EXTS))
    files = collect(root, args.target, exts)
    if not files:
        print("no source files found", file=sys.stderr)
        return 2
    toks, total_lines = {}, 0
    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        total_lines += text.count("\n") + 1
        name = str(f.relative_to(root)) if root in f.parents else str(f)
        toks[name] = tokens_python(text, args.normalize) if f.suffix == ".py" else tokens_generic(text, args.normalize)
    clones = find_clones(toks, args.min_tokens)
    dup_lines = set()
    for c in clones:
        for side in ("a", "b"):
            s = c[side]
            dup_lines.update((s["file"], ln) for ln in range(s["start"], s["end"] + 1))
    pct = 100.0 * len(dup_lines) / total_lines if total_lines else 0.0
    report = {"files": len(toks), "lines": total_lines, "clones": len(clones), "duplicated_lines": len(dup_lines),
              "duplication_pct": round(pct, 2), "min_tokens": args.min_tokens, "normalize": args.normalize,
              "groups": clones}
    if args.json:
        print(json.dumps(report, indent=2))
        return 0
    print(f"{len(toks)} files, {total_lines} lines: {len(clones)} clone pair(s), "
          f"{len(dup_lines)} duplicated lines ({pct:.1f}%) at >= {args.min_tokens} tokens"
          f"{' (normalized)' if args.normalize else ''}\n")
    for c in clones[:args.top]:
        a, b = c["a"], c["b"]
        print(f"{c['tokens']:>5} tokens  {a['file']}:{a['start']}-{a['end']}  ==  {b['file']}:{b['start']}-{b['end']}")
    if len(clones) > args.top:
        print(f"... {len(clones) - args.top} more (use --top)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
