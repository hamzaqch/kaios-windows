"""isc_mutate: acceptance-test mutation for ISA claims, stdlib only.

A claim is load-bearing only if a meaningfully different claim would be judged
differently by its probe. This tool reads an ISA (`- [ ] C1 <claim>. Probe: <check>`),
flags claims that are fluff on their face, and generates mutants of each claim
(negated, numbers shifted, quantifiers and comparators swapped). For each mutant,
ask: would the claim's probe still pass on the current state? If yes, the probe
does not discriminate and the claim is fluff; sharpen the claim or its probe.

    python isc_mutate.py path/to/ISA.md                 # report: flags + mutants per claim
    python isc_mutate.py path/to/ISA.md --json          # for a model or subagent to judge
    python isc_mutate.py path/to/ISA.md --claim C3      # one claim

Deterministic and read-only: it never edits the ISA and never runs probes.
"""
import argparse
import json
import re
import sys
from pathlib import Path

CLAIM_RE = re.compile(r"^\s*-\s*\[( |x|X)\]\s*((?:C|A)\d+)\s+(.*)$")
VAGUE = ["robust", "clean", "good", "nice", "proper", "properly", "appropriate", "appropriately", "user-friendly",
         "intuitive", "seamless", "seamlessly", "efficient", "efficiently", "fast", "quickly", "scalable", "secure",
         "reliable", "well-tested", "high quality", "high-quality", "as expected", "correctly", "works", "working",
         "handles", "gracefully", "optimal", "reasonable", "sufficient", "adequate", "better", "improved", "modern"]
QUANT_SWAPS = [("every", "some"), ("all", "some"), ("each", "one"), ("none", "some"), ("never", "sometimes"),
               ("always", "sometimes"), ("at least", "at most"), ("at most", "at least"), ("no ", "some "),
               ("only", "also")]
COMP_SWAPS = [("<=", ">"), (">=", "<"), ("<", ">="), (">", "<="), ("below", "above"), ("above", "below"),
              ("under", "over"), ("over", "under"), ("before", "after"), ("after", "before"),
              ("less than", "more than"), ("more than", "less than"), ("fewer than", "more than"),
              ("within", "beyond"), ("increase", "decrease"), ("decrease", "increase")]
NEG_INSERT = [(r"\b(return|exit|show|contain|pass|fail|list|print|write|read|block|allow|load|match|reject)(e?s)\b",
               r"does not \1"), (r"\b(is|are|was|were|has|have|can|will|does|do)\b(?! not)", r"\1 not")]
COMMANDISH = re.compile(r"`[^`]+`|\b(python|pytest|unittest|npm|node|pwsh|powershell|curl|grep|rg|git|copilot|"
                        r"Get-|Test-|Invoke-|kai\.py|evals\.py|mutate\.py|ls|cat|type|dir|wc|diff|jq)\b", re.I)


def parse_claims(text):
    out = []
    for i, line in enumerate(text.splitlines(), 1):
        m = CLAIM_RE.match(line)
        if not m:
            continue
        body = m.group(3).strip()
        claim, probe = body, ""
        pm = re.search(r"\bProbe:\s*(.*)$", body)
        if pm:
            claim, probe = body[:pm.start()].strip().rstrip("."), pm.group(1).strip()
        out.append({"id": m.group(2), "line": i, "closed": m.group(1).lower() == "x", "claim": claim, "probe": probe})
    return out


def flags(c):
    f = []
    low = " " + c["claim"].lower() + " "
    vague = [w for w in VAGUE if re.search(r"(?<![\w-])" + re.escape(w) + r"(?![\w-])", low)]
    has_number = bool(re.search(r"\d", c["claim"]))
    if vague and not has_number:
        f.append({"kind": "vague", "detail": "vague words with no measurable bound: " + ", ".join(vague[:5])})
    if not c["probe"]:
        f.append({"kind": "no-probe", "detail": "no `Probe:`; nothing can falsify this claim"})
    elif not COMMANDISH.search(c["probe"]) and len(c["probe"].split()) < 4:
        f.append({"kind": "weak-probe", "detail": "probe names no tool, command or observable check"})
    elif re.search(r"\b(manual(ly)?|eyeball|looks? (good|right)|inspect visually|review)\b", c["probe"], re.I):
        f.append({"kind": "subjective-probe", "detail": "probe relies on subjective review"})
    if re.search(r"\b(and|as well as|plus)\b", c["claim"], re.I) and len(c["claim"].split()) > 8:
        f.append({"kind": "compound", "detail": "likely two facts in one claim (Splitting test): one probe can pass while half fails"})
    if re.search(r"\b(e\.g\.|for example|such as)\b", c["claim"], re.I):
        f.append({"kind": "example-claim", "detail": "example-shaped; prefer a universal claim over named instances"})
    if re.search(r"\b(should|try to|aim to|ideally|where possible|if possible)\b", c["claim"], re.I):
        f.append({"kind": "soft", "detail": "aspirational wording; a claim states a fact that is true or false"})
    return f


def _sub_once(pattern, repl, text, flags_=re.I):
    new, n = re.subn(pattern, repl, text, count=1, flags=flags_)
    return new if n else None


def _third_person(verb):
    if re.search(r"(s|sh|ch|x|z|o)$", verb):
        return verb + "es"
    if re.search(r"[^aeiou]y$", verb):
        return verb[:-1] + "ies"
    return verb + "s"


def mutants(c):
    claim = c["claim"]
    out = []
    seen = {claim}

    def add(kind, text):
        if text and text not in seen:
            seen.add(text)
            out.append({"kind": kind, "claim": text})

    # negation: remove an existing one, or insert one
    removed = _sub_once(r"\bdoes not\s+(\w+)", lambda m: _third_person(m.group(1)), claim) or _sub_once(r"\b(not|never|no longer)\s+", "", claim)
    if removed:
        add("negation-removed", removed)
    elif not re.match(r"\s*no\b", claim, re.I):  # "No X ..." is covered by the quantifier swap
        for pat, rep in NEG_INSERT:
            t = _sub_once(pat, rep, claim)
            if t:
                add("negated", t)
                break
    # numbers: shift by an order of magnitude and by one
    for m in re.finditer(r"\d+(?:\.\d+)?", claim):
        num = m.group(0)
        val = float(num)
        for nv in (val * 10, val + 1 if "." not in num else val * 1.5):
            rep = (str(int(nv)) if nv.is_integer() else f"{nv:g}")
            add("number-shifted", claim[:m.start()] + rep + claim[m.end():])
        break
    for a, b in QUANT_SWAPS:
        t = _sub_once(r"(?<!\w)" + re.escape(a), b, claim)
        if t:
            add("quantifier-swapped", t)
            break
    for a, b in COMP_SWAPS:
        pat = re.escape(a) if not a[0].isalpha() else r"\b" + re.escape(a) + r"\b"
        t = _sub_once(pat, b, claim)
        if t:
            add("comparator-swapped", t)
            break
    # scope widening: drop a trailing qualifier clause
    t = _sub_once(r",?\s+(when|if|unless|for|on|in|under|within|after|before)\s+[^,]+$", "", claim)
    if t:
        add("qualifier-dropped", t)
    return out


def analyze(text, only=None):
    rows = []
    for c in parse_claims(text):
        if only and c["id"] not in only:
            continue
        c["flags"] = flags(c)
        c["mutants"] = mutants(c)
        rows.append(c)
    return rows


JUDGE_NOTE = ("For each mutant: if the claim's probe, run against the current state, would pass for the mutant "
              "exactly as it does for the original, the probe does not discriminate. Mark the claim FLUFF and "
              "sharpen the claim or the probe until at least the negated and number-shifted mutants would fail.")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="isc_mutate.py", description="Acceptance-test mutation for ISA claims")
    ap.add_argument("isa")
    ap.add_argument("--claim", action="append", help="limit to claim id(s), e.g. C3")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    p = Path(args.isa)
    if not p.exists():
        print(f"not found: {p}", file=sys.stderr)
        return 2
    rows = analyze(p.read_text(encoding="utf-8"), set(args.claim) if args.claim else None)
    if not rows:
        print("no claims found (expected lines like `- [ ] C1 <claim>. Probe: <check>`)", file=sys.stderr)
        return 2
    flagged = [r for r in rows if r["flags"]]
    if args.json:
        print(json.dumps({"isa": str(p), "claims": len(rows), "flagged": len(flagged), "instructions": JUDGE_NOTE,
                          "rows": rows}, indent=2, ensure_ascii=False))
        return 0
    print(f"{p}: {len(rows)} claim(s), {len(flagged)} flagged on their face\n")
    for r in rows:
        status = "x" if r["closed"] else " "
        print(f"[{status}] {r['id']} (line {r['line']}): {r['claim']}")
        print(f"     probe: {r['probe'] or '(none)'}")
        for f in r["flags"]:
            print(f"     ! {f['kind']}: {f['detail']}")
        for m in r["mutants"]:
            print(f"     ~ {m['kind']}: {m['claim']}")
        print()
    print(JUDGE_NOTE)
    return 0


if __name__ == "__main__":
    sys.exit(main())
