"""mutate: mutation testing for Python projects, stdlib only.

Injects one small bug at a time into the target files (flip a comparison, swap an
operator, change a constant, return None), runs your test command against each
mutant in a scratch copy of the project, and reports which mutants SURVIVED: bugs
your tests did not notice. Kill rate = killed / (mutants that compiled).

    python mutate.py --root . --target src/pkg/parser.py -- python -m unittest discover -s tests
    python mutate.py --root . --target src/pkg --list            # show mutants, run nothing
    python mutate.py --root . --target src/pkg/parser.py --jobs 4 --max-mutants 150 --json -- python -m pytest -q

Mutations are token-level (tokenize + ast positions), so they work on Python 3.8+.
Skip a line with a trailing `# pragma: no mutate`. Your project is never modified:
everything runs in temporary copies.
"""
import argparse
import ast
import concurrent.futures as cf
import io
import json
import os
import random
import shutil
import subprocess
import sys
import tempfile
import time
import tokenize
from pathlib import Path

OP_SWAPS = {
    "==": ["!="], "!=": ["=="], "<": [">=", "<="], ">": ["<=", ">="], "<=": [">", "<"], ">=": ["<", ">"],
    "+": ["-"], "-": ["+"], "*": ["/"], "/": ["*"], "//": ["/"], "%": ["*"], "**": ["*"],
    "+=": ["-="], "-=": ["+="], "*=": ["/="], "/=": ["*="],
    "&": ["|"], "|": ["&"], "^": ["&"], "<<": [">>"], ">>": ["<<"],
}
NAME_SWAPS = {"True": ["False"], "False": ["True"], "and": ["or"], "or": ["and"],
              "break": ["continue"], "continue": ["break"], "is": ["is not"], "in": ["not in"]}
IGNORE_DIRS = {".git", "__pycache__", ".venv", "venv", "env", "node_modules", ".mypy_cache", ".pytest_cache",
               ".tox", "dist", "build", ".eggs"}


class Mutant:
    __slots__ = ("id", "file", "line", "col", "end_line", "end_col", "original", "replacement", "kind", "source_line")

    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)

    def to_dict(self):
        return {k: getattr(self, k) for k in self.__slots__}


def _line_offsets(src):
    offs, pos = [0], 0
    for line in src.splitlines(keepends=True):
        pos += len(line)
        offs.append(pos)
    return offs


def _docstring_lines(tree):
    lines = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            body = getattr(node, "body", [])
            if body and isinstance(body[0], ast.Expr) and isinstance(getattr(body[0], "value", None), ast.Constant) \
                    and isinstance(body[0].value.value, str):
                end = getattr(body[0], "end_lineno", body[0].lineno)
                lines.update(range(body[0].lineno, end + 1))
    return lines


def _annotation_spans(tree):
    """(line, col, end_line, end_col) spans of type annotations; mutating them is noise."""
    spans = []
    for node in ast.walk(tree):
        anns = []
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            anns.append(node.returns)
            a = node.args
            for arg in list(a.args) + list(a.kwonlyargs) + list(getattr(a, "posonlyargs", [])) + [a.vararg, a.kwarg]:
                if arg is not None:
                    anns.append(arg.annotation)
        elif isinstance(node, ast.AnnAssign):
            anns.append(node.annotation)
        for ann in anns:
            if ann is not None and hasattr(ann, "end_lineno"):
                spans.append((ann.lineno, ann.col_offset, ann.end_lineno, ann.end_col_offset))
    return spans


def _in_spans(line, col, spans):
    for l1, c1, l2, c2 in spans:
        if (line, col) >= (l1, c1) and (line, col) < (l2, c2):
            return True
    return False


def find_mutants(path, rel):
    src = Path(path).read_text(encoding="utf-8")
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return []
    lines = src.splitlines()
    doc = _docstring_lines(tree)
    ann = _annotation_spans(tree)
    skip = {i + 1 for i, l in enumerate(lines) if "pragma: no mutate" in l}
    out = []

    def add(line, col, end_line, end_col, original, replacement, kind):
        if line in skip or line in doc:
            return
        out.append(Mutant(id=0, file=rel, line=line, col=col, end_line=end_line, end_col=end_col,
                          original=original, replacement=replacement, kind=kind,
                          source_line=lines[line - 1].strip() if line - 1 < len(lines) else ""))

    toks = list(tokenize.generate_tokens(io.StringIO(src).readline))
    prev_sig = None
    for i, tok in enumerate(toks):
        (l1, c1), (l2, c2) = tok.start, tok.end
        if _in_spans(l1, c1, ann):
            prev_sig = tok
            continue
        if tok.type == tokenize.OP and tok.string in OP_SWAPS:
            unary = tok.string in ("+", "-", "*", "**") and (
                prev_sig is None or (prev_sig.type == tokenize.OP and prev_sig.string not in (")", "]", "}"))
                or (prev_sig.type == tokenize.NAME and prev_sig.string in ("return", "in", "and", "or", "not", "if",
                                                                          "else", "lambda", "yield", "is")))
            if not unary:
                for rep in OP_SWAPS[tok.string]:
                    add(l1, c1, l2, c2, tok.string, rep, "operator")
            elif tok.string == "-":
                add(l1, c1, l2, c2, "-", "", "unary-minus-removed")
        elif tok.type == tokenize.NAME and tok.string in NAME_SWAPS:
            nxt = toks[i + 1].string if i + 1 < len(toks) else ""
            if tok.string == "is" and nxt == "not":
                pass
            elif tok.string == "in" and (prev_sig is not None and prev_sig.string == "not"):
                pass
            elif tok.string == "in" and _is_for_in(toks, i):
                pass
            else:
                for rep in NAME_SWAPS[tok.string]:
                    add(l1, c1, l2, c2, tok.string, rep, "keyword")
        elif tok.type == tokenize.NAME and tok.string == "not" and not (i + 1 < len(toks) and toks[i + 1].string == "in"):
            if not (prev_sig is not None and prev_sig.string == "is"):
                add(l1, c1, toks[i + 1].start[0], toks[i + 1].start[1], src_slice(src, tok.start, toks[i + 1].start),
                    "", "not-removed")
        elif tok.type == tokenize.NUMBER:
            rep = _number_mutant(tok.string)
            if rep is not None:
                add(l1, c1, l2, c2, tok.string, rep, "constant")
        elif tok.type == tokenize.STRING and not tok.string.lstrip("rbuRBU").startswith(("f", "F")):
            body = tok.string.lstrip("rbuRBUfF")
            q = body[:3] if body[:3] in ('"""', "'''") else body[:1]
            inner = body[len(q):-len(q)] if len(body) >= 2 * len(q) else ""
            prefix = tok.string[:len(tok.string) - len(body)]
            if inner and len(inner) < 200:
                add(l1, c1, l2, c2, tok.string, prefix + q + q, "string-emptied")
        if tok.type not in (tokenize.NL, tokenize.NEWLINE, tokenize.COMMENT, tokenize.INDENT, tokenize.DEDENT):
            prev_sig = tok

    for node in ast.walk(tree):
        if isinstance(node, ast.Return) and node.value is not None and hasattr(node.value, "end_lineno"):
            v = node.value
            if isinstance(v, ast.Constant) and v.value is None:
                continue
            add(v.lineno, v.col_offset, v.end_lineno, v.end_col_offset,
                src_slice(src, (v.lineno, v.col_offset), (v.end_lineno, v.end_col_offset)), "None", "return-none")
    out.sort(key=lambda m: (m.line, m.col, m.kind, m.replacement))
    return out


def _is_for_in(toks, i):
    depth = 0
    for j in range(i - 1, -1, -1):
        s = toks[j].string
        if toks[j].type in (tokenize.NEWLINE,):
            return False
        if s in (")", "]", "}"):
            depth += 1
        elif s in ("(", "[", "{"):
            if depth == 0:
                return False
            depth -= 1
        elif s == "for" and depth == 0:
            return True
        elif s in ("if", "while", "return", "=") and depth == 0:
            return False
    return False


def _number_mutant(s):
    try:
        v = ast.literal_eval(s)
    except Exception:
        return None
    if isinstance(v, complex):
        return None
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return "1" if v == 0 else "0" if v == 1 else str(v + 1)
    if isinstance(v, float):
        return "0.0" if v != 0 else "1.0"
    return None


def src_slice(src, start, end):
    offs = _line_offsets(src)
    return src[offs[start[0] - 1] + start[1]: offs[end[0] - 1] + end[1]]


def apply_mutant(src, m):
    offs = _line_offsets(src)
    a = offs[m.line - 1] + m.col
    b = offs[m.end_line - 1] + m.end_col
    rep = m.replacement
    if m.kind in ("keyword",) and src[a:b] != m.original:
        return None
    return src[:a] + rep + src[b:]


def compiles(src, name):
    try:
        compile(src, name, "exec")
        return True
    except (SyntaxError, ValueError):
        return False


def copy_project(root, dst):
    def ignore(d, names):
        return [n for n in names if n in IGNORE_DIRS or n.endswith((".pyc", ".pyo"))]
    shutil.copytree(root, dst, ignore=ignore)


def _kill_tree(proc):
    """End a timed-out test run and everything it spawned (shims, workers)."""
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
        else:
            import signal
            os.killpg(proc.pid, signal.SIGKILL)
    except Exception:
        pass
    try:
        proc.kill()
    except Exception:
        pass


def run_tests(cmd, cwd, timeout):
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["KAI_MUTATION_RUN"] = "1"
    kw = {"creationflags": getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)} if os.name == "nt" \
        else {"start_new_session": True}
    t0 = time.time()
    try:
        p = subprocess.Popen(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, **kw)
    except OSError as e:
        return "fail", 0.0, f"could not start test command {cmd!r}: {e}"
    try:
        out, _ = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        _kill_tree(p)
        try:
            p.communicate(timeout=10)
        except Exception:
            pass
        return "timeout", time.time() - t0, ""
    return ("pass" if p.returncode == 0 else "fail"), time.time() - t0, (out or b"").decode("utf-8", "replace")[-2000:]


def resolve_cmd(cmd):
    """Resolve the executable via PATH/PATHEXT so `pytest`, `npm`, `npx` (.exe/.cmd shims) start on Windows."""
    if cmd and not os.path.dirname(cmd[0]):
        found = shutil.which(cmd[0])
        if found:
            return [found] + list(cmd[1:])
    return list(cmd)


def collect_targets(root, targets):
    files = []
    for t in targets:
        p = (root / t).resolve() if not Path(t).is_absolute() else Path(t).resolve()
        if p.is_dir():
            for f in sorted(p.rglob("*.py")):
                if not any(part in IGNORE_DIRS for part in f.parts) and not f.name.startswith("test_") \
                        and not f.name.endswith("_test.py") and "tests" not in f.relative_to(root).parts:
                    files.append(f)
        elif p.suffix == ".py" and p.exists():
            files.append(p)
    return files


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    test_cmd = []
    if "--" in argv:
        k = argv.index("--")
        argv, test_cmd = argv[:k], argv[k + 1:]
    ap = argparse.ArgumentParser(prog="mutate.py", description="Mutation testing for Python projects (stdlib only)")
    ap.add_argument("--root", default=".", help="project root to copy (default: cwd)")
    ap.add_argument("--target", action="append", required=True, help="file or folder to mutate (repeatable)")
    ap.add_argument("--list", action="store_true", help="list mutants and exit")
    ap.add_argument("--max-mutants", type=int, default=0, help="seeded random sample of N mutants (0 = all)")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--timeout", type=float, default=0, help="per-mutant timeout in s (default: 5x baseline + 5)")
    ap.add_argument("--jobs", type=int, default=1)
    ap.add_argument("--lines", help="only mutate lines in this range, e.g. 10-80")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    if test_cmd and test_cmd[0] in ("python", "python3", "py"):
        test_cmd = [sys.executable] + test_cmd[1:]
    if not test_cmd:
        test_cmd = [sys.executable, "-m", "unittest", "discover"]
    test_cmd = resolve_cmd(test_cmd)

    root = Path(args.root).resolve()
    files = collect_targets(root, args.target)
    if not files:
        print("no Python target files found", file=sys.stderr)
        return 2
    mutants = []
    for f in files:
        mutants += find_mutants(f, str(f.relative_to(root)))
    if args.lines:
        lo, _, hi = args.lines.partition("-")
        lo, hi = int(lo), int(hi or lo)
        mutants = [m for m in mutants if lo <= m.line <= hi]
    if args.max_mutants and len(mutants) > args.max_mutants:
        mutants = sorted(random.Random(args.seed).sample(mutants, args.max_mutants), key=lambda m: (m.file, m.line, m.col))
    for i, m in enumerate(mutants, 1):
        m.id = i

    if args.list:
        for m in mutants:
            print(f"#{m.id:<4} {m.file}:{m.line}:{m.col}  {m.kind:<20} {m.original!r} -> {m.replacement!r}   | {m.source_line[:70]}")
        print(f"{len(mutants)} mutant(s) in {len(files)} file(s)")
        return 0

    work = Path(tempfile.mkdtemp(prefix="kai-mutate-"))
    try:
        base_dir = work / "w0"
        copy_project(root, base_dir)
        status, base_secs, base_out = run_tests(test_cmd, base_dir, timeout=args.timeout or 600)
        if status != "pass":
            print("Baseline test run did not pass; fix the suite before mutation testing.\n" + base_out, file=sys.stderr)
            return 2
        timeout = args.timeout or (base_secs * 5 + 5)
        jobs = max(1, args.jobs)
        dirs = [base_dir] + [work / f"w{i}" for i in range(1, jobs)]
        for d in dirs[1:]:
            shutil.copytree(base_dir, d)
        originals = {f: (root / f).read_text(encoding="utf-8") for f in {m.file for m in mutants}}
        free = list(dirs)
        import threading
        lock = threading.Lock()

        def run_one(m):
            src = originals[m.file]
            mutated = apply_mutant(src, m)
            if mutated is None or mutated == src or not compiles(mutated, m.file):
                return m, "invalid", 0.0
            with lock:
                d = free.pop()
            target = d / m.file
            try:
                target.write_text(mutated, encoding="utf-8")
                st, secs, _ = run_tests(test_cmd, d, timeout)
            finally:
                target.write_text(src, encoding="utf-8")
                with lock:
                    free.append(d)
            return m, {"pass": "survived", "fail": "killed", "timeout": "timeout"}[st], secs

        results = []
        t0 = time.time()
        with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
            for done, (m, outcome, secs) in enumerate(ex.map(run_one, mutants), 1):
                results.append((m, outcome))
                if not args.json:
                    print(f"[{done}/{len(mutants)}] {outcome:<8} {m.file}:{m.line} {m.original!r}->{m.replacement!r}",
                          file=sys.stderr)
    finally:
        shutil.rmtree(work, ignore_errors=True)

    valid = [(m, o) for m, o in results if o != "invalid"]
    killed = sum(1 for _, o in valid if o in ("killed", "timeout"))
    survived = [(m, o) for m, o in valid if o == "survived"]
    rate = killed / len(valid) if valid else 0.0
    report = {"root": str(root), "files": [str(f.relative_to(root)) for f in files], "test_cmd": test_cmd,
              "mutants": len(results), "valid": len(valid), "killed": killed,
              "timeouts": sum(1 for _, o in valid if o == "timeout"), "survived": len(survived),
              "invalid": len(results) - len(valid), "kill_rate": rate, "seconds": round(time.time() - t0, 1),
              "survivors": [m.to_dict() for m, _ in survived]}
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print(f"\nMutation score: {rate * 100:.1f}%  ({killed} killed incl. {report['timeouts']} timeouts, "
              f"{len(survived)} survived, {report['invalid']} did not compile; {report['seconds']}s)")
        if survived:
            print("\nSurvivors (each is a bug your tests would not catch):")
            for m, _ in survived:
                print(f"  {m.file}:{m.line}  {m.kind}: {m.original!r} -> {m.replacement!r}   | {m.source_line[:80]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
