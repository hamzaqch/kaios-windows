"""crap: CRAP scores for Python functions, stdlib only.

CRAP(f) = complexity(f)^2 * (1 - coverage(f))^3 + complexity(f)

High complexity with low test coverage is where bugs hide and changes break things.
The score ranks where new tests (or a refactor) buy the most safety. A common
threshold: CRAP > 30 is risky.

    python crap.py --root . --target src/pkg --run -- python -m unittest discover -s tests
    python crap.py --root . --target src/pkg --coverage-json coverage.json   # coverage.py JSON report
    python crap.py --root . --target src/pkg                                 # complexity only (coverage 0)

Coverage comes from (a) a coverage.py JSON report if you have one, or (b) the
built-in line tracer: `--run -- <test command>` runs your tests under sys.settrace
in a subprocess. The tracer is slower than coverage.py but needs nothing installed.
Cyclomatic complexity: 1 + decision points (if/elif, loops, except, ternary,
boolean operators, comprehension filters, match cases, assert).
"""
import argparse
import ast
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

IGNORE_DIRS = {".git", "__pycache__", ".venv", "venv", "env", "node_modules", "build", "dist", ".tox"}

TRACER = r'''
import json, os, runpy, sys, threading
targets = set(os.path.normcase(os.path.realpath(t)) for t in json.loads(os.environ["KAI_CRAP_TARGETS"]))
out = os.environ["KAI_CRAP_OUT"]
hits = {}
_norm = {}
def tracer(frame, event, arg):
    raw = frame.f_code.co_filename
    fn = _norm.get(raw)
    if fn is None:
        fn = _norm[raw] = os.path.normcase(os.path.realpath(raw))
    if fn not in targets:
        return None
    s = hits.setdefault(fn, set())
    def local(frame, event, arg):
        if event == "line":
            s.add(frame.f_lineno)
        return local
    s.add(frame.f_lineno)
    return local
def dump():
    with open(out, "w", encoding="utf-8") as f:
        json.dump({k: sorted(v) for k, v in hits.items()}, f)
import atexit
atexit.register(dump)
sys.settrace(tracer)
threading.settrace(tracer)
argv = json.loads(os.environ["KAI_CRAP_ARGV"])
if argv[0] == "-m":
    sys.argv = [argv[1]] + argv[2:]
    try:
        runpy.run_module(argv[1], run_name="__main__", alter_sys=True)
    except SystemExit:
        pass
else:
    sys.argv = argv
    try:
        runpy.run_path(argv[0], run_name="__main__")
    except SystemExit:
        pass
'''


def complexity(fn_node):
    c = 1
    for node in _walk_own(fn_node):
        if isinstance(node, (ast.If, ast.For, ast.AsyncFor, ast.While, ast.IfExp, ast.ExceptHandler, ast.Assert)):
            c += 1
        elif isinstance(node, ast.BoolOp):
            c += len(node.values) - 1
        elif isinstance(node, ast.comprehension):
            c += 1 + len(node.ifs)
        elif type(node).__name__ == "match_case":
            c += 1
    return c


def _walk_own(fn_node):
    """Walk a function body without descending into nested functions/classes (they are scored separately)."""
    stack = list(ast.iter_child_nodes(fn_node))
    while stack:
        node = stack.pop()
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            continue
        yield node
        stack.extend(ast.iter_child_nodes(node))


def statement_lines(fn_node):
    lines = set()
    body = fn_node.body
    start = 1 if body and isinstance(body[0], ast.Expr) and isinstance(getattr(body[0], "value", None), ast.Constant) \
        and isinstance(body[0].value.value, str) else 0
    stack = list(body[start:])
    while stack:
        node = stack.pop()
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            lines.add(node.lineno)  # the def statement itself executes
            continue
        if isinstance(node, ast.stmt):
            lines.add(node.lineno)
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.stmt, ast.excepthandler)) or type(child).__name__ == "match_case":
                stack.append(child)
    return lines


def functions(path):
    try:
        tree = ast.parse(Path(path).read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError):
        return []
    out = []

    def visit(node, prefix):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                name = f"{prefix}{child.name}"
                out.append((name, child))
                visit(child, name + ".")
            elif isinstance(child, ast.ClassDef):
                visit(child, f"{prefix}{child.name}.")
    visit(tree, "")
    return out


def crap_score(comp, cov):
    return comp ** 2 * (1 - cov) ** 3 + comp


def collect(root, targets):
    files = []
    for t in targets:
        p = Path(t) if Path(t).is_absolute() else root / t
        p = p.resolve()
        if p.is_dir():
            files += [f for f in sorted(p.rglob("*.py")) if not any(x in IGNORE_DIRS for x in f.parts)]
        elif p.suffix == ".py" and p.exists():
            files.append(p)
    return files


def trace_coverage(root, files, test_argv, timeout):
    with tempfile.TemporaryDirectory(prefix="kai-crap-") as td:
        out = Path(td) / "hits.json"
        boot = Path(td) / "boot.py"
        boot.write_text(TRACER, encoding="utf-8")
        argv = list(test_argv)
        if argv and re.fullmatch(r"(python[0-9.]*|py)(\.exe)?", Path(argv[0]).name.lower()):
            argv = argv[1:]
        elif argv and re.fullmatch(r"(pytest|py\.test)(\.exe)?", Path(argv[0]).name.lower()):
            argv = ["-m", "pytest"] + argv[1:]   # a bare `pytest` is not a script path; run it as a module
        if not argv:
            argv = ["-m", "unittest", "discover"]
        env = dict(os.environ)
        env.update({"KAI_CRAP_TARGETS": json.dumps([str(f) for f in files]), "KAI_CRAP_OUT": str(out),
                    "KAI_CRAP_ARGV": json.dumps(argv), "PYTHONDONTWRITEBYTECODE": "1"})
        try:
            p = subprocess.run([sys.executable, str(boot)], cwd=str(root), env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, timeout=timeout)
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"test run exceeded --timeout {timeout:g}s under the tracer")
        if not out.exists():
            raise RuntimeError("tracer produced no data:\n" + p.stdout.decode("utf-8", "replace")[-1500:])
        raw = json.loads(out.read_text(encoding="utf-8"))
    return {os.path.normcase(k): set(v) for k, v in raw.items()}


def _key(path):
    return os.path.normcase(os.path.realpath(str(path)))


def coverage_from_json(path, root):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    hits = {}
    for fname, info in (data.get("files") or {}).items():
        f = Path(fname) if Path(fname).is_absolute() else Path(root) / fname
        hits[_key(f)] = set(info.get("executed_lines") or [])
    return hits


def analyze(root, files, hits):
    rows = []
    for f in files:
        executed = hits.get(_key(f))
        for name, node in functions(f):
            stmts = statement_lines(node)
            if executed is None:
                cov = 0.0
            else:
                cov = (len(stmts & executed) / len(stmts)) if stmts else 1.0
            comp = complexity(node)
            rows.append({"file": str(f.relative_to(root)) if root in f.parents else str(f), "function": name,
                         "line": node.lineno, "complexity": comp, "coverage": round(cov, 3),
                         "crap": round(crap_score(comp, cov), 2)})
    rows.sort(key=lambda r: (-r["crap"], r["file"], r["line"]))
    return rows


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    test_cmd = []
    if "--" in argv:
        k = argv.index("--")
        argv, test_cmd = argv[:k], argv[k + 1:]
    ap = argparse.ArgumentParser(prog="crap.py", description="CRAP scores (complexity x missing coverage)")
    ap.add_argument("--root", default=".")
    ap.add_argument("--target", action="append", required=True)
    ap.add_argument("--coverage-json", help="coverage.py JSON report (coverage json)")
    ap.add_argument("--run", action="store_true", help="measure coverage by running the test command after --")
    ap.add_argument("--threshold", type=float, default=30.0)
    ap.add_argument("--top", type=int, default=25)
    ap.add_argument("--timeout", type=float, default=1800)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    root = Path(args.root).resolve()
    files = collect(root, args.target)
    if not files:
        print("no Python files found", file=sys.stderr)
        return 2
    source = "none (complexity only; every function counts as uncovered)"
    hits = {}
    if args.coverage_json:
        hits, source = coverage_from_json(args.coverage_json, root), f"coverage.py report {args.coverage_json}"
    elif args.run:
        try:
            hits = trace_coverage(root, files, test_cmd, args.timeout)
        except RuntimeError as e:
            print(str(e), file=sys.stderr)
            return 2
        source = "built-in tracer: " + " ".join(test_cmd or ["unittest discover"])
    rows = analyze(root, files, hits)
    risky = [r for r in rows if r["crap"] > args.threshold]
    if args.json:
        print(json.dumps({"coverage_source": source, "threshold": args.threshold, "functions": len(rows),
                          "risky": len(risky), "rows": rows}, indent=2))
        return 0
    print(f"Coverage source: {source}")
    print(f"{len(rows)} functions, {len(risky)} above CRAP {args.threshold:g}\n")
    print(f"{'CRAP':>8} {'cx':>4} {'cov':>6}  function")
    for r in rows[:args.top]:
        flag = "!" if r["crap"] > args.threshold else " "
        print(f"{r['crap']:>8.1f} {r['complexity']:>4} {r['coverage'] * 100:>5.0f}% {flag} {r['file']}:{r['line']} {r['function']}")
    if len(rows) > args.top:
        print(f"... {len(rows) - args.top} more (use --top)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
