---
name: hardening
description: "Hardens what already exists (tests, ISA claims, code) without adding features: property-based tests that shrink failures to a minimal counterexample, mutation testing that proves the suite catches injected bugs, CRAP scores that rank risky under-tested functions, copy-paste clone detection, and acceptance-test mutation that exposes fluff ISA claims. Stdlib Python tools, no installs. Use when the user says harden, hardening, property test, property-based testing, PBT, hypothesis-style test, fuzz this function, mutation test, test the tests, are my tests any good, CRAP score, risky code, untested complexity, duplication, DRY scan, copy-paste code, sharpen ISCs, fluff claims, find bugs my example tests miss, shrink a counterexample. NOT FOR writing tests for new features (just write them), grading AI output quality (use /evals), security vulnerability hunting, or building new functionality."
---
# Hardening

Example tests check the inputs their author thought of, so surviving bugs live in the inputs nobody thought of. A suite can be green and still weak, and an ISA claim can read as crisp pass/fail while anything would satisfy it. You can't see either by reading; you have to test the tests. Hardening mechanises that and never adds functionality.

## Done looks like

- Every finding names a file and line (or a claim ID) and the evidence that produced it: a shrunk counterexample with its seed, a surviving mutant, a CRAP row, a clone pair, a mutant claim the probe can't tell apart.
- Findings became durable: property tests committed, survivors killed by new assertions (and the kill confirmed by a rerun), risky functions tested or simplified, fluff claims rewritten with a discriminating probe.
- Numbers are before and after: mutation score, CRAP of the top function, duplication percentage.

## Tools

All in `~/.copilot/skills/hardening/tools/`, Python 3.8+ standard library only. Each prints help with `-h`.

| Tool | Does | Workflow |
|---|---|---|
| `proptest.py` | Property-based testing library: generators, boundary values first, shrinking, seeds. Import it from tests. | `Workflows/PropertyTest.md` |
| `mutate.py` | Mutation testing for Python: one injected bug per run in a scratch copy, reports survivors and the kill rate. | `Workflows/MutationTest.md` |
| `crap.py` | CRAP = complexity squared x (1 - coverage) cubed + complexity, per function; coverage from a built-in tracer or a coverage.py JSON report. | `Workflows/CrapAnalysis.md` |
| `dry.py` | Clone detection across many languages; `--normalize` also finds renamed copies. | `Workflows/DryAnalysis.md` |
| `isc_mutate.py` | Flags fluff ISA claims and generates claim mutants for the probe to tell apart. | `Workflows/AcceptanceTestMutation.md` |

`mutate.py` and `crap.py` take the test command after `--`, for example `-- python -m pytest -q` or `-- python -m unittest discover -s tests`. A leading `python` is replaced with the interpreter running the tool.

## Doctrine

All five work on the existing surface. Properties express the universal claim that example tests sample. Mutation grades the tests you have. CRAP and DRY say where tests or refactors pay off most. Acceptance-test mutation is the mechanical form of the ISA rule that claims must be hard to vary. One frame unifies them: test the things that test the system.

For non-Python projects, `dry.py` and `isc_mutate.py` work as is; for property and mutation testing use the language's own tools (fast-check, Stryker, PIT, cargo-mutants) with the same workflows, and say which tool you used.

## Gotchas

- **Pin the seed of every property failure.** Shrinking is reproducible only with the seed: `KAI_PROPTEST_SEED=<seed>` reruns it; leave `# proptest seed: <seed>` beside the regression example you extract.
- **Properties need pure code.** Functions that touch disk, network or the clock give flaky properties; extract the pure core or fake the side effect.
- **Generators must match the real input domain.** Too narrow (`integers(0, 100)` for code that takes any int) hides bugs; too wide (any text for an ASCII-only parser) produces false failures.
- **When a shrunk counterexample is `""`, `0` or `[]`, it is the classic missed empty case.** Check it first.
- **Mutation testing refuses a red baseline.** Fix failing tests first; a failing suite kills every mutant and the score means nothing.
- **Some survivors are equivalent mutants** (for example `>=` vs `>` where the boundary value can't occur). Say so explicitly rather than writing a test that can't fail; mark the line `# pragma: no mutate` if it keeps coming back.
- **Mutation cost is mutants x test-suite time.** Use `--list` to count first, then `--max-mutants N` (seeded sample) or `--lines a-b`, and `--jobs` for parallel copies.
- **The built-in coverage tracer is slow on big suites.** Prefer `--coverage-json` when coverage.py is already available.
