# Parallel Analysis

Attack an argument from many diverse perspectives at once, then produce the two things that matter: **the strongest steelman of the argument and the strongest surviving counter-argument against it**, plus severity-ranked findings with remediation.

Each of steelman and counter-argument is 8 points, 12-16 words per point, attacking real weaknesses (never strawmen), escalating in impact. The counter-argument must defeat the steelman, not a weaker version of it. A proponent should read the steelman and say "yes, that's my argument," and read the counter-argument and be unable to say "that's not what I meant."

Not nitpicking or contrarianism. Find the assumption that, if it falls, collapses the structure.

## Steps

### 1. Decompose

Invoke the `/first-principles` skill's Deconstruct on the argument to separate fundamental truths from assumed ones and expose the gap between stated and actual components. Then break the argument into **atomic, independently attackable claims**: each self-contained, specific, and challengeable by a competent critic. Number them.

Note the claim type (normative "we should," empirical, predictive), the hidden assumptions, relevant precedents, and whether the conclusion actually follows from the premises.

### 2. Dispatch parallel adversarial personas

Issue several parallel `task` calls together, one per persona, drawn from the library below. Route them to `@kai-reviewer` by default; use `@kai-researcher` for personas that need to find precedents or data via web fetch. Pick a diverse spread across all four groups; scale the count to the stakes (a handful for a quick check, the full roster for a major decision). Each call receives the full argument, the claim decomposition, and its persona, using the prompt template below.

### 3. Synthesize by convergence and severity

Weaknesses many personas land on independently are the critical findings; a lone sharp insight still counts. Rank by severity (Critical / High / Medium / Low), discard noise, and reach a verdict: **fundamentally sound with fixable execution**, or **fundamentally flawed despite good intentions**.

### 4. Challenge constraints

Before writing the counter-argument, run the `/first-principles` skill's Challenge: classify every constraint as HARD (physics/reality, cannot attack), SOFT (policy/choice, can be challenged), or ASSUMPTION (unvalidated, prime target). The most devastating critiques target "constraints" treated as HARD that are actually SOFT.

### 5. Write the deliverable

Steelman first (prevents strawmanning), then the counter-argument, then findings with remediation. Templates below.

## Persona library

### Engineers: technical and logical rigor

| ID | Persona | Attack angle |
|----|---------|--------------|
| EN-1 | **The Skeptical Systems Thinker**: 30 years building distributed systems, trusts nothing | "Where does this break at scale?" |
| EN-2 | **The Evidence Demander**: won't accept claims without data | "Show me the numbers that prove this." |
| EN-3 | **The Edge Case Hunter**: finds the 1% scenario that destroys assumptions | "What happens when X is not true?" |
| EN-4 | **The Historical Pattern Matcher**: has seen every failure mode | "We tried this before and here's what happened." |
| EN-5 | **The Complexity Realist**: knows simple solutions hide hard problems | "This is harder than it sounds because..." |
| EN-6 | **The Dependency Tracer**: follows assumptions to their roots | "This assumes X, which assumes Y, which is false." |
| EN-7 | **The Failure Mode Analyst**: thinks only about how things break | "Here are 5 ways this fails catastrophically." |
| EN-8 | **The Technical Debt Accountant**: calculates hidden costs | "The real price of this approach is..." |

### Architects: structural and systemic issues

| ID | Persona | Attack angle |
|----|---------|--------------|
| AR-1 | **The Big Picture Thinker**: sees how pieces connect (or don't) | "This ignores how it fits the larger system." |
| AR-2 | **The Trade-off Illuminator**: nothing is free | "You gain X but lose Y, and Y matters more." |
| AR-3 | **The Abstraction Questioner**: challenges categorical thinking | "These aren't the same category of problem." |
| AR-4 | **The Incentive Mapper**: follows money and motivation | "Who benefits from this being true?" |
| AR-5 | **The Second-Order Effects Tracker**: thinks three moves ahead | "This causes A, which causes B, which destroys C." |
| AR-6 | **The Integration Pessimist**: interfaces are where things break | "This doesn't compose with existing reality." |
| AR-7 | **The Scalability Skeptic**: what works for 10 fails at 10,000 | "This can't scale because..." |
| AR-8 | **The Reversibility Analyst**: some decisions can't be undone | "Once you do this, you can't go back, and here's why that's bad." |

### Pentesters: adversarial and security thinking

| ID | Persona | Attack angle |
|----|---------|--------------|
| PT-1 | **The Red Team Lead**: thinks like an attacker constantly | "Here's how I'd exploit this logic." |
| PT-2 | **The Assumption Breaker**: finds the weak link in the chain | "This depends on X, and X is false." |
| PT-3 | **The Game Theorist**: models rational adversaries | "A smart opponent would simply..." |
| PT-4 | **The Social Engineer**: humans are the weak point | "People will route around this because..." |
| PT-5 | **The Precedent Finder**: has seen this pattern before | "This is just [past example] in a new dress." |
| PT-6 | **The Defense Evaluator**: judges whether mitigations actually work | "This defense fails because attackers can..." |
| PT-7 | **The Threat Modeler**: maps attack surfaces systematically | "You've left this entire surface undefended." |
| PT-8 | **The Asymmetry Spotter**: finds where defenders are outmatched | "Attackers have unlimited time; defenders don't." |

### Interns: fresh eyes and unconventional angles

| ID | Persona | Attack angle |
|----|---------|--------------|
| IN-1 | **The Naive Questioner**: asks "why" until it breaks | "But why do we assume X in the first place?" |
| IN-2 | **The Analogy Finder**: connects to unrelated fields | "This is just like [other field] where it failed." |
| IN-3 | **The Contrarian**: takes the opposite position instinctively | "What if the exact opposite is true?" |
| IN-4 | **The Common Sense Checker**: if it sounds too clever, it's wrong | "This violates basic intuition because..." |
| IN-5 | **The Zeitgeist Reader**: knows what's happening on the ground | "In practice, nobody actually does this because..." |
| IN-6 | **The Simplicity Advocate**: Occam's razor everything | "The simpler explanation is..." |
| IN-7 | **The Edge Lord**: pushes every argument to its absurd conclusion | "If this is true, then [absurd consequence] must also be true." |
| IN-8 | **The Devil's Intern**: finds the argument the author hoped nobody would make | "The uncomfortable truth nobody wants to say is..." |

## Persona prompt template

```
# BALANCED ANALYSIS - [ID]: [PERSONA NAME]

You are [PERSONA DESCRIPTION]. Your perspective is: "[ATTACK ANGLE]"

## THE ARGUMENT TO ANALYZE:
[Full original argument]

## DECOMPOSED INTO CLAIMS:
[Numbered claim breakdown]

## YOUR MISSION:
From your specific perspective, give an INDEPENDENT BALANCED ANALYSIS of both the
strengths AND weaknesses of this argument.

## OUTPUT FORMAT (exactly):
**[ID] ANALYSIS:**

**Strongest Point FOR the Argument:** [Claim #X]
[2-3 sentences on why it is valid/compelling]
Take seriously because: [1 sentence]

**Strongest Point AGAINST the Argument:** [Claim #Y]
[2-3 sentences on the flaw]
Problematic because: [1 sentence]

**Overall Assessment:** [One sentence verdict]

Find REAL strengths, not strawmen. Find REAL weaknesses, not nitpicks.
```

## Output contracts

### Steelman

```
# STEELMAN

**The Position (Best Version):** [One sentence, strongest formulation]

**The Strongest Case FOR This Argument:**
1. [12-16 words: most compelling opening point]
2. [12-16 words: strong supporting evidence]
3. [12-16 words: supporting precedent or analogy]
4. [12-16 words: valid concern being addressed]
5. [12-16 words: what the critics get wrong]
6. [12-16 words: the real risk if ignored]
7. [12-16 words: why smart people believe this]
8. [12-16 words: strongest single reason to take this seriously]

**Validity Assessment:** [One sentence on the legitimate core concern]
```

### Counter-argument

```
# RED TEAM VERDICT

**The Position:** [One sentence summary of what was red-teamed]

**The Counter-Argument:**
1. [12-16 words: establishes the fundamental flaw]
2. [12-16 words: develops the core weakness]
3. [12-16 words: historical precedent or analogy]
4. [12-16 words: addresses the hidden assumption]
5. [12-16 words: the counterexample or exception]
6. [12-16 words: what's conveniently ignored]
7. [12-16 words: second-order effects]
8. [12-16 words: the knockout conclusion]

**Assessment:** [One sentence on fundamental soundness after analysis]
```

### Findings

```
# FINDINGS (severity-ranked)

| # | Severity | Finding | Claim | Converged (personas) | Remediation |
|---|----------|---------|-------|----------------------|-------------|
| 1 | Critical | [the collapse-the-structure flaw] | #X | EN-6, PT-2, IN-1 | [how to fix or de-risk] |

**Verdict:** Fundamentally sound with fixable execution / Fundamentally flawed.
```

Each point is self-contained, plain-language, attacks a real weakness, and builds toward the strongest possible objection.

## Worked example

**Argument:** "We should delay this product launch by six months to add more features."

**First-principles pass:** normative claim. Hidden assumptions: more features means more success; competitors won't act; market timing is flexible. Precedent cuts both ways (over-engineered failures, fast-MVP successes). The conclusion doesn't follow without evidence on the feature-value trade-off.

**Steelman:**
1. Shipping incomplete products damages brand reputation in ways that take years to recover from.
2. Customer acquisition cost is wasted if users churn due to missing core functionality they expected.
3. Deliberately delayed product releases often outperform rushed competitors on customer satisfaction metrics.
4. The features we're adding directly address the top three complaints from our beta user research.
5. Critics ignore that our competitors have those features; parity is table stakes, not gold-plating.
6. Six months of development costs less than one year of customer support for a broken product.
7. Engineering teams lose motivation when forced to ship work they know is incomplete and buggy.
8. The real risk isn't delay; it's launching something we'll have to apologize for publicly later.

**Counter-argument:**
1. This assumes we know which features matter, but only real users reveal what actually drives value.
2. Every month of delay is a month competitors can capture market share we'll never recover.
3. Many dominant platforms shipped embarrassingly incomplete first versions and still won their markets decisively.
4. The argument conflates "more features" with "better product"; complexity often destroys rather than creates value.
5. Six months assumes accurate estimation; software projects routinely take two to three times longer.
6. We can add features after launch; we cannot add back the time lost to delay.
7. Customer feedback on a live product is worth more than six months of internal speculation.
8. The fundamental error: treating product development as a single bet rather than iterative learning.
