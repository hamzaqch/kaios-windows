# Adversarial Validation (Battle of Bots)

Produce a better solution through competition: competing proposals, a brutal critic, then a collaborative synthesis. Premise: models are usually better at critiquing and editing than at original writing, so make them critique each other.

**Use when:** feature specs need stress-testing; architectural decisions before implementation; code reviews with multiple viable approaches; content that must withstand scrutiny; anything where quality matters more than speed.

**Don't use when:** the decision is simple with an obvious answer; time is critical; it's a creative task where many valid outputs are fine; expert consensus already exists.

## The three-round protocol

### Round 1: competing proposals

Dispatch 2-3 parallel `task` calls, each a distinct persona producing a complete solution that optimizes for its own priorities. Route builder personas to `@kai-engineer`, design/long-term personas to `@kai-architect`, risk/security personas to `@kai-reviewer`.

```
ADVERSARIAL VALIDATION - ROUND 1 (COMPETING PROPOSALS)

You are [PERSONA]. Generate your best solution to this problem.

Your perspective emphasizes:
- [Key concern 1]
- [Key concern 2]
- [Key concern 3]

Produce a complete solution that optimizes for YOUR priorities. Be specific and
detailed; it will be compared against other proposals.

[Problem/task description]
```

**Persona combinations:**

| Decision type | Personas |
|---------------|----------|
| Architecture | Engineer (implementation ease, maintainability); Architect (scalability, patterns, long-term); Security (attack surface, vulnerabilities) |
| Feature spec | Product (user value, simplicity); Engineer (feasibility, complexity); QA (testability, edge cases) |
| Content/writing | Subject-matter expert (accuracy, depth); Audience representative (clarity, engagement); Editor (structure, flow) |

### Round 2: brutal critique

One `task` call to `@kai-reviewer` as the Harsh Critic, given all proposals.

```
ADVERSARIAL VALIDATION - ROUND 2 (BRUTAL CRITIQUE)

You are the Harsh Critic. You have received [N] proposals for [problem].

For EACH proposal:
1. What they got RIGHT: genuine strengths, specifically.
2. What they got WRONG: flaws, gaps, what they conveniently ignored, where their
   perspective blinds them.
3. The Uncomfortable Truth: what none of them want to hear; the real problem they
   are all dancing around.
4. If forced to pick one: which has the strongest foundation, and why?

Be harsh but fair. The goal is truth, not destruction.

[Proposals from Round 1]
```

### Round 3: collaborative synthesis

Give the original personas (or one `@kai-architect` synthesis call holding all their perspectives) the proposals plus the critique.

```
ADVERSARIAL VALIDATION - ROUND 3 (COLLABORATIVE SYNTHESIS)

You are [PERSONA]. You have seen the Critic's assessment.

With your fellow proposers, produce a SINGLE UNIFIED solution that:
- addresses the valid criticisms
- incorporates the best elements from each proposal
- resolves the tensions between perspectives
- acknowledges remaining trade-offs honestly

This is synthesis, not compromise. The result must be BETTER than any individual
proposal, not a blend.

[Original proposals + Critic's assessment]
```

## Single-prompt variant

When parallel dispatch isn't worth it, run all three rounds in one pass:

```
ADVERSARIAL VALIDATION - FULL PROTOCOL

ROUND 1: Generate 3 distinct, complete, defensible solutions:
  A (Pragmatist): ease of implementation and quick wins
  B (Idealist): best practices and long-term quality
  C (Skeptic): risk reduction and failure prevention

ROUND 2: As a harsh but fair critic, evaluate all three: what each got right, what
each got wrong, the uncomfortable truth none addressed, which has the strongest
foundation.

ROUND 3: Synthesize a single superior solution that addresses valid criticisms,
incorporates strengths from each, resolves tensions, and honestly states remaining
trade-offs.

OUTPUT: brief summary of the three proposals; key critique points; final
synthesized recommendation with clear rationale.

[Problem/task]
```

## Quality signals

**Good:** each proposal genuinely represents its perspective; the critic finds real flaws, not nitpicks; the synthesis is demonstrably better than any single proposal; trade-offs are stated honestly; the result withstands scrutiny.

**Bad:** proposals too similar (not enough diversity); critic too gentle or too destructive; "synthesis" is one proposal with minor tweaks; trade-offs handwaved; the process feels performative.

## Worked example: API authentication flow

**Round 1:**
- **A (Pragmatist):** JWT, 24-hour expiry, refresh tokens, standard claims. Quick, well understood.
- **B (Idealist):** OAuth 2.0 with PKCE, 15-minute access tokens, secure token storage, audit logging. Industry best practice.
- **C (Skeptic):** API keys with rate limiting, IP allowlisting, manual rotation. Minimal attack surface, easy to revoke.

**Round 2:** A is fast, but JWT secrets are hard to rotate and 24h is too long. B is the gold standard but heavy overhead for the current team size. C is secure but doesn't scale to a public API. Uncomfortable truth: none addressed "what happens when we need to revoke all tokens immediately?"

**Round 3:** start with A's JWT approach, adopt B's 15-minute tokens and audit logging, add C's emergency revocation list. Defer full OAuth until a public API launch.

## Key principles

1. **Genuine competition:** proposals are real alternatives, not strawmen.
2. **Brutal but fair critique:** real flaws, real strengths.
3. **Synthesis over compromise:** the goal is better, not blended.
4. **Honest trade-offs:** don't pretend tensions are fully resolved.
5. **Permission to fail:** if no synthesis is clearly superior, say so.

Related: ParallelAnalysis stress-tests the synthesized result. For exploring many branches before committing, run a divergent-ideation pass first (see the be-creative skill).
