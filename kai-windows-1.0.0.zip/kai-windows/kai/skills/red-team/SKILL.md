---
name: red-team
description: "Adversarial analysis of ideas, strategies, plans, and arguments. Decomposes the argument into atomic claims, attacks each one with parallel expert personas (engineers, architects, pentesters, fresh-eyes interns), then synthesizes a steelman, the strongest surviving counter-argument, and severity-ranked findings with remediation. Also runs adversarial validation: competing proposals, a harsh critic, then a synthesis better than any single proposal. Use when the user says red team this, attack this idea, counterarguments, critique, stress test, devil's advocate, find weaknesses, break this, poke holes, what's the strongest objection, what could go wrong with this plan, or battle of bots. Targets arguments and plans, not network vulnerabilities. Not for collaborative deliberation to find the best path (use the council skill)."
---

# Red Team

People fall in love with their own plans. Once committed, the brain hunts for reasons an idea works and skips the reasons it doesn't, and the people around you are often too polite or too aligned to push hard. This skill is the hard question, asked many ways at once, so weak points surface while they're still cheap to fix.

Origin: military red teaming, where dedicated teams attack plans and assumptions to find vulnerabilities before the enemy does.

## Core insight

**The goal is not destruction.** It's finding the fundamental flaw that, if challenged, collapses the whole structure. The most powerful critique is usually one core issue:

- a hidden assumption that's actually false
- a logical step that doesn't follow
- a category error (treating X like Y)
- an ignored precedent that directly contradicts the claim

## Workflows

| Workflow | Use for | Output | File |
|----------|---------|--------|------|
| **ParallelAnalysis** | Stress-test existing content ("red team this plan") | Steelman + counter-argument, 8 points each, plus severity-ranked findings | `Workflows/ParallelAnalysis.md` |
| **AdversarialValidation** | Produce new content via competition ("which approach is better for X?") | Synthesized solution from competing proposals + critique | `Workflows/AdversarialValidation.md` |

Combine them for high-stakes work: AdversarialValidation produces a solution, ParallelAnalysis stress-tests it, iterate if critical flaws appear.

## Running on Copilot

Attacks run as parallel `task` calls, one per persona, all issued together. Route critique personas to `@kai-reviewer`; use `@kai-researcher` when a persona needs to dig up precedents or counterexamples with web fetch, and `@kai-architect` for structural/systemic personas when that reads more naturally. Each call gets the full argument, the claim decomposition, and its persona brief.

## Pairs with

- **Before:** invoke the `/research` skill to gather context and precedents.
- **During:** invoke the `/first-principles` skill. Deconstruct breaks the argument into fundamental parts; Challenge classifies constraints as HARD/SOFT/ASSUMPTION. The most damaging critiques come from "hard" constraints that are actually soft.
- **After collaborative deliberation:** the council skill finds the best path; this skill attacks it.

## Success criteria

- The steelman is strong enough that a proponent says "yes, that's my argument."
- The counter-argument defeats the steelman, not a weaker strawman.
- Multiple personas converged on the same insights.
- The reader says "I hadn't thought of that."

## Output discipline

- Steelman and counter-argument: 8 numbered points each, 12-16 words per point.
- Direct, substantive, non-performative. Plain language.
- Must include first-principles analysis and convergence (which weaknesses many personas found independently).
- Must avoid nitpicking, strawmanning, and generic objections.

## Gotchas

- **Attack ideas, not systems.** This finds flaws in arguments, strategies, and plans.
- **Many personas generate volume, not equal findings.** Rank by severity; discard noise.
- **Strengthen, don't just destroy.** Pair every serious weakness with a remediation path.

## Examples

- "red team this microservices migration plan" → ParallelAnalysis → steelman + counter-argument, findings ranked.
- "poke holes in my plan to raise prices 20%" → ParallelAnalysis → surfaces the one issue that could collapse the plan.
- "battle of bots: which approach is better for this feature?" → AdversarialValidation → synthesized best solution.
