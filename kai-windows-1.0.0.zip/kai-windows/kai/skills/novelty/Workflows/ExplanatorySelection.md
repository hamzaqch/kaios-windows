# Explanatory selection

## Ideal state

Only candidates that give a comparatively hard-to-vary causal explanation of the target phenomenon advance. A survivor is explicit about what it explains, which physical mechanism does the work, why its parts matter, how it can fail and what remains unexplained.

## Survivor artifact

For every candidate:

1. **Target:** the phenomenon and observations, defined independently of the candidate's vocabulary.
2. **Causal core:** a short causal chain from physical mechanism to target outcome.
3. **Necessary roles:** every core component, relation or parameter and its explanatory job.
4. **Counterfactuals:** component-ablation and parameter-substitution effects.
5. **Rival comparison:** a simpler or serious rival and a target observation it does not explain.
6. **Risky prediction:** a discriminating outcome that could demote or falsify the candidate.
7. **Cross-context behaviour:** predictions across relevant states, perturbations, development, failure or recovery.
8. **Remaining residue:** what is still unexplained.

## Gate

Run parameter substitution, component ablation, rival equivalence, cross-state comparison and causal-core compression (`../HardToVary.md`). Reject candidates that only restate labels, explain only report, access, attention or integration when the target differs, invoke an unfalsifiable intrinsic property, declare an identity without causal consequences, or keep their fit by arbitrary post-hoc variation.

For independence, run the stress tests in a different subagent from the one that wrote the candidate (`@kai-reviewer` with the artifact and the test definitions), then record the results:

```
python "$HOME/.copilot/skills/novelty/tools/novelty.py" stress <run> --file tests.json
python "$HOME/.copilot/skills/novelty/tools/novelty.py" select <run> [--portfolio 4] [--lineage-cap 2]
```

To filter explanations that didn't come from a Novelty run, `python "$HOME/.copilot/skills/novelty/tools/novelty.py" init` a run for the phenomenon and `add` them first.

## Output

A ranked survivor portfolio with causal core, hard-to-vary score, stress-test outcomes, rival comparison, risky prediction, cross-context predictions and remaining residue. Rank explanatory quality separately from empirical support and rhetorical appeal; the tool's `not_promoted` list says exactly why each other candidate stopped.
