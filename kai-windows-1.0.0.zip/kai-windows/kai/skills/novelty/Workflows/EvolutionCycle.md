# Evolution cycle

## Ideal state

An evolved portfolio of hard-to-vary explanations, not a brainstorm: each survivor has a traceable lineage, a distinct causal hypothesis, an explicit relation to the target phenomenon, and a clear test status.

## Start

`python "$HOME/.copilot/skills/novelty/tools/novelty.py" init "<phenomenon>" --observation "..." --constraint "..." --rival "..." [--prohibited "..."]`

## Full cycle

1. **CONSUME:** extract observations, anomalies, known mechanisms, constraints and serious rivals (use /research for the literature; keep what is evidence apart from what is claimed).
2. **DREAM:** generate strange but structured causal hypotheses; label each fantasy, hypothesis or evidence-backed.
3. **DAYDREAM:** apply counterfactuals, role reversals, scale changes and causal leaps to what you have.
4. **SALON:** collide independent disciplinary lenses without premature consensus. `python "$HOME/.copilot/skills/novelty/tools/novelty.py" disciplines <run> --count 3` picks them; run one parallel `task` per lens (`@kai-deep-analyst`, `@kai-architect` or a persona brief).
5. **STEAL:** transfer mechanisms across domains, deliberately imperfectly; record the useful mismatch in `transfer`.
6. **MATE:** recombine causal families and mutate assumptions, dependencies, scale or time horizon; record `parents`. Save the population: `python "$HOME/.copilot/skills/novelty/tools/novelty.py" add <run> --file candidates.json`.
7. **TEST:** challenge candidates against observations, constraints, evidence and feasible interventions; fill in the survivor fields.
8. **EXPLANATORY SELECTION:** run the five stress tests from `../HardToVary.md` on each candidate (`ExplanatorySelection.md`), record them with `python "$HOME/.copilot/skills/novelty/tools/novelty.py" stress <run> --file tests.json`. Demote candidates that merely fit, relabel or decorate the phenomenon.
9. **SELECT:** `python "$HOME/.copilot/skills/novelty/tools/novelty.py" select <run>` keeps a diverse portfolio of eligible survivors plus a controlled high-upside wildcard; useful mechanisms from rejected lineages stay in the archive.
10. **EVOLVE:** seed the next population from survivors and useful rejected mechanisms.
11. **META-LEARN:** update disciplines, mutations, tests and the selection rule from what survived and what was falsely attractive: `python "$HOME/.copilot/skills/novelty/tools/novelty.py" next <run> --lesson "..." [--selection-rule "..."]`.

Phases 2-7 can use /be-creative inside a phase for fast divergence; they never replace the selection.

## Output contract

`python "$HOME/.copilot/skills/novelty/tools/novelty.py" report <run>` produces: the phenomenon and evidence boundary; the survivor portfolio with causal core, lineage, necessary components, hard-to-vary tests and next experiment; the wildcard and retired mechanisms; the evolution report; and the revised selection rule.

## Stop conditions

Stop when the cycle budget is exhausted, evidence decisively favours a portfolio, constraints rule out the remaining candidates, or marginal explanatory learning collapses. State which condition stopped the run and what would justify resuming.
