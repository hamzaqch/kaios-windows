# Rapid cycle

## Ideal state

In a time-boxed setting, a small but genuinely evolved portfolio rather than a familiar list. Lineage is preserved, imagination is labelled separately from evidence, and the one reality check that should govern a longer run is named.

## Compact cycle

Run a compressed population through **CONSUME, DREAM, DAYDREAM, SALON, STEAL, MATE/MUTATE, TEST, SELECT**. Use at least two unrelated disciplinary lenses (`python "$HOME/.copilot/skills/novelty/tools/novelty.py" disciplines <run> --count 2`), one deliberately imperfect mechanism transfer, and several parent lineages. Treat the result as cycle 1, not as proof.

Use /be-creative inside CONSUME, DREAM, DAYDREAM or SALON only for fast divergent expansion; then apply Novelty's lineage, testing and selection contract (`python "$HOME/.copilot/skills/novelty/tools/novelty.py" add`, `python "$HOME/.copilot/skills/novelty/tools/novelty.py" stress`, `python "$HOME/.copilot/skills/novelty/tools/novelty.py" select`).

## Output contract

- **Reality frame:** the problem, hard constraints and the one decisive test.
- **Three or more candidates** in different niches, each with lineage, mutation or transfer, a fantasy-or-evidence label and test status.
- **Selected portfolio:** a leading candidate, a contrarian wildcard, and an explanation of the diversity kept.
- **Next evolution rule:** what to amplify, suppress or test in cycle 2.

## Guardrails

Don't compress away DREAM, deliberate misapplication, reality testing or diversity selection. If the time budget can't support them, recommend /be-creative for a single-pass brainstorm instead of claiming an evolutionary run.
