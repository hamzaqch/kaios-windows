"""novelty: run state and explanatory selection for the Novelty skill (stdlib only).

Keeps what a theory-discovery run must not lose (phenomenon, evidence boundary,
constraints, rivals, population, lineage, stress-test outcomes, survivors and
lessons) and applies the hard-to-vary selection rule mechanically, so survivors
are chosen by recorded tests rather than by how good a story sounds.

    python novelty.py init "<phenomenon>" [--observation "..."]... [--constraint "..."]... [--rival "..."]...
    python novelty.py disciplines <run> [--count 3]        # seeded lens/discipline rotation
    python novelty.py add <run> --file candidates.json     # candidates with lineage and survivor fields
    python novelty.py stress <run> --file tests.json       # record the five stress tests per candidate
    python novelty.py select <run> [--portfolio 4] [--lineage-cap 2]
    python novelty.py next <run> --lesson "..."            # close the cycle, seed the next
    python novelty.py report <run>
    python novelty.py status <run>

<run> is a run folder or its slug under ~/.copilot/kai/MEMORY/WORK/<slug>/novelty/.
"""
import argparse
import datetime as _dt
import hashlib
import json
import os
import random
import re
import sys
from pathlib import Path

SURVIVOR_FIELDS = ("target", "causal_core", "necessary_roles", "counterfactuals", "rival_comparison",
                   "risky_prediction", "cross_context", "residue")
STRESS_TESTS = ("parameter_substitution", "component_ablation", "rival_equivalence", "cross_state", "core_compression")
FAILURE_MODES = ("relabel", "identity_claim", "vague_mechanism", "unfalsifiable", "post_hoc", "target_mismatch")
LABELS = ("fantasy", "hypothesis", "evidence-backed")
DISCIPLINES = ["physics", "information theory", "control theory", "evolutionary biology", "neuroscience", "ecology",
               "thermodynamics", "economics", "game theory", "linguistics", "developmental biology", "immunology",
               "chemistry", "statistics", "computer science", "anthropology", "history of science", "cognitive science",
               "materials science", "network science", "epidemiology", "geology", "philosophy of mind", "sociology",
               "engineering failure analysis", "music theory", "complex systems", "cryptography", "medicine"]
SCORE = {"pass": 2, "partial": 1, "fail": 0}


def kai_home():
    if os.environ.get("KAI_HOME"):
        return Path(os.environ["KAI_HOME"])
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"]) / "kai"
    return Path.home() / ".copilot" / "kai"


def now_iso():
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def kebab(text, n=40):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:n].rstrip("-") or "run"


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except Exception:
        return default


def resolve(ref):
    p = Path(ref).expanduser()
    for cand in (p, p / "novelty", kai_home() / "MEMORY" / "WORK" / ref / "novelty"):
        if (cand / "state.json").exists():
            return cand
    raise SystemExit(f"run not found: {ref}")


def load(ref):
    d = resolve(ref)
    return d, read_json(d / "state.json", {})


def save(d, st):
    write_json(d / "state.json", st)


def root_of(st, cid, seen=None):
    seen = seen or set()
    c = st["candidates"].get(cid)
    if not c or not c.get("parents") or cid in seen:
        return cid
    seen.add(cid)
    return root_of(st, c["parents"][0], seen)


def completeness(c):
    have = 0
    for f in SURVIVOR_FIELDS:
        v = c.get(f)
        if isinstance(v, dict):
            ok = any(str(x).strip() for x in v.values())
        elif isinstance(v, list):
            ok = any(str(x).strip() for x in v)
        else:
            ok = bool(str(v or "").strip())
        have += ok
    return have / len(SURVIVOR_FIELDS)


def htv_score(c):
    """Hard-to-vary score 0..100 from recorded stress tests (70%) and artifact completeness (30%)."""
    tests = c.get("stress") or {}
    st = sum(SCORE.get(str((tests.get(t) or {}).get("result", "")).lower(), 0) for t in STRESS_TESTS)
    return round(70 * st / (2 * len(STRESS_TESTS)) + 30 * completeness(c), 1)


def gate(c):
    """Reasons a candidate cannot be promoted to explanation (empty list = eligible)."""
    reasons = []
    tests = c.get("stress") or {}
    missing = [t for t in STRESS_TESTS if t not in tests]
    if missing:
        reasons.append("untested: " + ", ".join(missing))
    for t in ("component_ablation", "rival_equivalence"):
        if str((tests.get(t) or {}).get("result", "")).lower() == "fail":
            reasons.append(f"failed {t}")
    flags = [f for f in (c.get("failure_modes") or []) if f in FAILURE_MODES]
    if flags:
        reasons.append("failure modes: " + ", ".join(flags))
    if completeness(c) < 1.0:
        gaps = [f for f in SURVIVOR_FIELDS if not c.get(f)]
        reasons.append("incomplete survivor artifact: " + ", ".join(gaps))
    if c.get("violates_constraint"):
        reasons.append("violates a hard constraint")
    return reasons


def cmd_init(a):
    slug = a.slug or f"{_dt.date.today().strftime('%Y%m%d')}-novelty-{kebab(a.phenomenon)}"
    d = Path(a.dir).expanduser() if a.dir else kai_home() / "MEMORY" / "WORK" / slug / "novelty"
    if (d / "state.json").exists() and not a.force:
        raise SystemExit(f"run exists: {d} (use --force)")
    seed = a.seed if a.seed is not None else int(hashlib.sha256(a.phenomenon.encode("utf-8")).hexdigest()[:8], 16)
    st = {"phenomenon": a.phenomenon, "slug": slug, "seed": seed, "created": now_iso(), "cycle": 1,
          "observations": a.observation or [], "constraints": a.constraint or [], "rivals": a.rival or [],
          "prohibited": a.prohibited or [], "candidates": {}, "disciplines_used": {}, "survivors": [],
          "wildcard": None, "archive": [], "lessons": [], "selection_rule": "rank by necessary mechanism, distinctive "
          "counterfactuals, discriminating risk, low accommodation cost", "rng_calls": 0, "history": []}
    save(d, st)
    print(json.dumps({"run": str(d), "slug": slug, "seed": seed}, indent=2))
    return 0


def cmd_disciplines(a):
    d, st = load(a.run)
    prev = set(st["disciplines_used"].get(str(st["cycle"] - 1), []))
    rng = random.Random(f"{st['seed']}|{st['cycle']}|{st['rng_calls']}")
    st["rng_calls"] += 1
    pool = [x for x in DISCIPLINES if x not in prev] or list(DISCIPLINES)
    picks = rng.sample(pool, min(a.count, len(pool)))
    st["disciplines_used"].setdefault(str(st["cycle"]), [])
    st["disciplines_used"][str(st["cycle"])] += [p for p in picks if p not in st["disciplines_used"][str(st["cycle"])]]
    save(d, st)
    print(json.dumps({"cycle": st["cycle"], "disciplines": picks, "excluded_from_last_cycle": sorted(prev)}, indent=2))
    return 0


def cmd_add(a):
    d, st = load(a.run)
    data = read_json(a.file)
    if isinstance(data, dict):
        data = data.get("candidates") or [data]
    if not isinstance(data, list):
        raise SystemExit("candidates file must be a JSON list")
    added = []
    for c in data:
        if not isinstance(c, dict) or not (c.get("title") or c.get("causal_core")):
            continue
        cid = c.get("id") or f"N-{len(st['candidates']) + 1:03d}"
        label = c.get("label", "hypothesis")
        if label not in LABELS:
            raise SystemExit(f"{cid}: label must be one of {', '.join(LABELS)}")
        c.update({"id": cid, "cycle": st["cycle"], "label": label, "status": "candidate",
                  "parents": c.get("parents") or [], "family": c.get("family") or "unassigned"})
        st["candidates"][cid] = c
        c["lineage_root"] = root_of(st, cid)
        added.append(cid)
    save(d, st)
    print(json.dumps({"added": added, "cycle": st["cycle"]}))
    return 0


def cmd_stress(a):
    d, st = load(a.run)
    data = read_json(a.file)
    if not isinstance(data, list):
        raise SystemExit("tests file must be a JSON list of {id, tests: {<test>: {result, note}}, failure_modes?}")
    updated = []
    for row in data:
        c = st["candidates"].get(row.get("id"))
        if not c:
            print(f"warning: unknown candidate {row.get('id')}", file=sys.stderr)
            continue
        for t, v in (row.get("tests") or {}).items():
            if t not in STRESS_TESTS:
                raise SystemExit(f"unknown stress test {t!r}; use {', '.join(STRESS_TESTS)}")
            v = v if isinstance(v, dict) else {"result": v}
            if str(v.get("result", "")).lower() not in SCORE:
                raise SystemExit(f"{c['id']}/{t}: result must be pass, partial or fail")
            c.setdefault("stress", {})[t] = {"result": v["result"].lower(), "note": v.get("note", "")}
        if row.get("failure_modes") is not None:
            c["failure_modes"] = [f for f in row["failure_modes"] if f in FAILURE_MODES]
        for k in ("empirical_support", "violates_constraint"):
            if k in row:
                c[k] = row[k]
        updated.append(c["id"])
    save(d, st)
    print(json.dumps({"updated": updated}))
    return 0


def cmd_select(a):
    d, st = load(a.run)
    cands = [c for c in st["candidates"].values() if c.get("status") in ("candidate", "survivor")]
    rows = []
    for c in cands:
        c["htv_score"] = htv_score(c)
        c["gate"] = gate(c)
        rows.append(c)
    eligible = sorted([c for c in rows if not c["gate"]], key=lambda c: (-c["htv_score"], c["id"]))
    portfolio, per_lineage, families = [], {}, set()
    # first pass: best per causal family (diversity), second pass: fill by score under the lineage cap
    for pass_no in (1, 2):
        for c in eligible:
            if len(portfolio) >= a.portfolio or c in portfolio:
                continue
            root = c.get("lineage_root", c["id"])
            if per_lineage.get(root, 0) >= a.lineage_cap:
                continue
            if pass_no == 1 and c["family"] in families:
                continue
            portfolio.append(c)
            per_lineage[root] = per_lineage.get(root, 0) + 1
            families.add(c["family"])
    wildcard = None
    rest = sorted([c for c in rows if c not in portfolio and not c.get("violates_constraint")],
                  key=lambda c: (-(c.get("upside") or 0), -c["htv_score"], c["id"]))
    if rest:
        wildcard = rest[0]
    for c in rows:
        if c in portfolio:
            c["status"] = "survivor"
        elif wildcard is not None and c is wildcard:
            c["status"] = "wildcard"
        else:
            c["status"] = "archived"
    st["survivors"] = [c["id"] for c in portfolio]
    st["wildcard"] = wildcard["id"] if wildcard else None
    st["archive"] = sorted({*st.get("archive", []), *[c["id"] for c in rows if c["status"] == "archived"]})
    st["history"].append({"cycle": st["cycle"], "ts": now_iso(), "candidates": len(rows), "eligible": len(eligible),
                          "survivors": st["survivors"], "wildcard": st["wildcard"]})
    save(d, st)
    print(json.dumps({
        "cycle": st["cycle"], "eligible": len(eligible), "candidates": len(rows),
        "portfolio": [{"id": c["id"], "title": c.get("title"), "family": c["family"], "htv_score": c["htv_score"],
                       "empirical_support": c.get("empirical_support"), "label": c["label"]} for c in portfolio],
        "wildcard": wildcard and {"id": wildcard["id"], "title": wildcard.get("title"), "why_not_promoted": wildcard["gate"]},
        "not_promoted": [{"id": c["id"], "reasons": c["gate"]} for c in rows if c["gate"]],
        "note": "Hard-to-vary score ranks explanatory quality only; empirical support and rhetorical appeal are separate."},
        indent=2, ensure_ascii=False))
    return 0


def cmd_next(a):
    d, st = load(a.run)
    if a.lesson:
        st["lessons"] += [{"cycle": st["cycle"], "lesson": x} for x in a.lesson]
    if a.selection_rule:
        st["selection_rule"] = a.selection_rule
    for cid in st.get("survivors", []) + ([st["wildcard"]] if st.get("wildcard") else []):
        st["candidates"][cid].setdefault("carried_into", []).append(st["cycle"] + 1)
        st["candidates"][cid]["status"] = "candidate"
    st["cycle"] += 1
    save(d, st)
    print(json.dumps({"cycle": st["cycle"], "seeded_from": st.get("survivors", []), "lessons": len(st["lessons"])}))
    return 0


def cmd_status(a):
    d, st = load(a.run)
    by_status = {}
    for c in st["candidates"].values():
        by_status[c.get("status", "candidate")] = by_status.get(c.get("status", "candidate"), 0) + 1
    print(json.dumps({"phenomenon": st["phenomenon"], "cycle": st["cycle"], "candidates": len(st["candidates"]),
                      "by_status": by_status, "survivors": st["survivors"], "wildcard": st["wildcard"],
                      "lessons": st["lessons"][-5:], "selection_rule": st["selection_rule"]}, indent=2, ensure_ascii=False))
    return 0


def _fmt(v):
    if isinstance(v, dict):
        return "; ".join(f"{k}: {x}" for k, x in v.items() if x)
    if isinstance(v, list):
        return "; ".join(str(x) for x in v if x)
    return str(v or "(missing)")


def cmd_report(a):
    d, st = load(a.run)
    C = st["candidates"]
    L = [f"# Novelty run: {st['phenomenon']}", "",
         f"Cycle {st['cycle']} · {len(C)} candidates · selection rule: {st['selection_rule']}", "",
         "## Phenomenon and evidence boundary", ""]
    L += [f"- Observation: {o}" for o in st["observations"]] or ["- (no observations recorded)"]
    L += [f"- Constraint: {x}" for x in st["constraints"]]
    L += [f"- Serious rival: {x}" for x in st["rivals"]]
    L += [f"- Prohibited direction: {x}" for x in st["prohibited"]]
    L += ["", "## Survivor portfolio", ""]
    for cid in st["survivors"]:
        c = C[cid]
        L.append(f"### {cid}: {c.get('title', '')} (hard-to-vary {c.get('htv_score', 0)}; family {c['family']}; {c['label']})")
        for f in SURVIVOR_FIELDS:
            L.append(f"- **{f.replace('_', ' ')}:** {_fmt(c.get(f))}")
        tests = c.get("stress") or {}
        L.append("- **stress tests:** " + "; ".join(f"{t} {tests[t]['result']}" for t in STRESS_TESTS if t in tests))
        L.append(f"- **lineage:** root {c.get('lineage_root')}, parents {', '.join(c['parents']) or 'none'}, born cycle {c['cycle']}")
        if c.get("empirical_support") is not None:
            L.append(f"- **empirical support (separate from explanatory quality):** {c['empirical_support']}")
        if c.get("next_experiment"):
            L.append(f"- **next experiment:** {c['next_experiment']}")
        L.append("")
    if not st["survivors"]:
        L += ["No candidate passed explanatory selection this cycle. That is a valid result; see why below.", ""]
    if st.get("wildcard"):
        w = C[st["wildcard"]]
        L += ["## Wildcard (kept, not promoted)", "", f"- {w['id']}: {w.get('title', '')} ({w['label']}). Not promoted because: "
              + ("; ".join(w.get("gate") or []) or "ranked below the portfolio"), ""]
    arch = [C[i] for i in st.get("archive", []) if i in C]
    if arch:
        L += ["## Retired and archived mechanisms", ""]
        for c in arch[:20]:
            L.append(f"- {c['id']}: {c.get('title', '')}: " + ("; ".join(c.get("gate") or []) or "outranked"))
        L.append("")
    L += ["## Evolution report", "", "| Cycle | Candidates | Eligible | Survivors | Wildcard |", "|---|---|---|---|---|"]
    for h in st["history"]:
        L.append(f"| {h['cycle']} | {h['candidates']} | {h['eligible']} | {', '.join(h['survivors']) or '-'} | {h['wildcard'] or '-'} |")
    L += ["", "## Lessons and revised selection rule", ""]
    L += [f"- cycle {x['cycle']}: {x['lesson']}" for x in st["lessons"]] or ["- (none recorded)"]
    L.append(f"- Selection rule now: {st['selection_rule']}")
    md = "\n".join(L) + "\n"
    (d / "report.md").write_text(md, encoding="utf-8")
    print(md)
    return 0


def build():
    ap = argparse.ArgumentParser(prog="novelty.py", description="Novelty run state and explanatory selection")
    sp = ap.add_subparsers(dest="cmd")
    p = sp.add_parser("init")
    p.add_argument("phenomenon")
    p.add_argument("--observation", action="append")
    p.add_argument("--constraint", action="append")
    p.add_argument("--rival", action="append")
    p.add_argument("--prohibited", action="append")
    p.add_argument("--slug")
    p.add_argument("--dir")
    p.add_argument("--seed", type=int)
    p.add_argument("--force", action="store_true")
    p = sp.add_parser("disciplines")
    p.add_argument("run")
    p.add_argument("--count", type=int, default=3)
    for n in ("add", "stress"):
        p = sp.add_parser(n)
        p.add_argument("run")
        p.add_argument("--file", required=True)
    p = sp.add_parser("select")
    p.add_argument("run")
    p.add_argument("--portfolio", type=int, default=4)
    p.add_argument("--lineage-cap", type=int, default=2)
    p = sp.add_parser("next")
    p.add_argument("run")
    p.add_argument("--lesson", action="append")
    p.add_argument("--selection-rule")
    for n in ("report", "status"):
        p = sp.add_parser(n)
        p.add_argument("run")
    return ap


CMDS = {"init": cmd_init, "disciplines": cmd_disciplines, "add": cmd_add, "stress": cmd_stress, "select": cmd_select,
        "next": cmd_next, "status": cmd_status, "report": cmd_report}


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = build()
    a = ap.parse_args(argv)
    if not a.cmd:
        ap.print_help()
        return 2
    return CMDS[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
