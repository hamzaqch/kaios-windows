# QuickCheck

Fast audit of one file or a pasted block of rules.

## Input

A file path, a pasted block of instructions, or "check this file" with a file already in context.

## Steps

1. Read the target. For a file, also run `python "$HOME/.copilot/skills/bitter-pill-engineering/tools/drift_lint.py" <file>` for mechanical candidates.
2. Apply the Five Questions from `../SKILL.md` to each rule, focusing on: restating default behaviour, vagueness, and one-off fixes for a single bad output.
3. Report.

## Report format

```
File: <path or "inline"> · Rules found: <n> · Verdict: <x> keep, <y> cut, <z> sharpen
### Cut
- <rule>: <reason>
### Sharpen
- <rule>: <sharpened version>
### Keep
- <rule>: <why>
```
