# Audit

Full audit of everything the model loads every session, for over-prompting.

## Done looks like

- Every always-loaded file was read in full and every rule in it got a classification with a one-line reason.
- Cross-file conflicts, duplicates and stale references are listed.
- Each file has a token cost and a verdict on whether it should load every session or on demand.
- The report follows the output format in `../SKILL.md`, with an estimated saving.
- No file was edited without the user approving the specific changes.

## Discover what loads

```
python "$HOME/.copilot/skills/bitter-pill-engineering/tools/drift_lint.py" --loaded            # from the project folder
python "$HOME/.copilot/skills/bitter-pill-engineering/tools/drift_lint.py" --loaded --json     # for your own analysis
```

This covers `~/.copilot/copilot-instructions.md` (the Kai block lives between `KAI:BEGIN` and `KAI:END`), the repo's `AGENTS.md`, `CLAUDE.md`, `GEMINI.md`, `.github/copilot-instructions.md` and `.github/instructions/**/*.instructions.md`, plus the frontmatter of every personal and repo skill and custom agent. Ask the user whether other files are injected (MCP server instructions, hook-fed context) and include them.

## Evaluate

Apply the Five Questions and the HOW-vs-WHAT test from `../SKILL.md` to each rule. Use linter hits as a starting list, then read for what a regex can't see: contradictions, rules that only made sense for an older model, and process descriptions nobody follows.

Common rules that restate default model behaviour: read files before editing, ask before destructive commands, make minimal changes and don't add unrequested features, don't modify quoted user text, prefer safer alternatives to destructive git operations.

For each file, weigh token cost against how often its content changes an output. Content needed for a minority of tasks belongs in a skill (loaded when relevant) or a reference file the instructions point to.

## Offer the trimmed version

On approval, produce the cleaned files with dead weight removed. Reinstalling Kai overwrites only the managed `KAI:BEGIN`/`KAI:END` block, so edits to that block should also go to the source copy the user installs from, or they will be lost on the next install. Rerun `drift_lint.py --loaded` and report before and after token counts.
