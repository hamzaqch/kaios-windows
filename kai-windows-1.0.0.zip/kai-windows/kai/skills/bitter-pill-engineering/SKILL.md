---
name: bitter-pill-engineering
description: "Audits any AI instruction set for over-prompting with one core test: would a smarter model make this rule unnecessary? Runs every rule through the Five Questions (already default behaviour, contradiction, redundancy, one-off fix, vague) plus the HOW-vs-WHAT test, classifies each as CUT, RESOLVE, MERGE, EVALUATE, SHARPEN, MOVE or KEEP, and estimates the tokens saved. A deterministic linter finds candidates; judgment decides. Use when the user says BPE, bitter pill, audit my setup, audit my instructions, over-prompting, trim my instructions, dead weight, simplify my setup, clean up copilot-instructions.md or AGENTS.md, are my rules still needed, my agent ignores my rules. NOT FOR attacking the logic of an idea (use /red-team) or shrinking one file by merging and relocating text (use /trim)."
---
# Bitter Pill Engineering

Instruction sets accumulate. Every time the model gets something wrong, someone adds a rule; months later the file is full of rules that restate default behaviour, contradict each other, or fixed one bad output that never recurred. Every unnecessary rule competes for attention with the rules that matter, so a bloated setup produces worse output than a lean one. This audit tells load-bearing rules from dead weight, rule by rule.

The principle: **less scaffolding, better output.** The core test for every rule is *would a smarter model make this unnecessary?* If yes, it is scaffolding and a candidate to cut.

## Workflow routing

| Request | Workflow |
|---|---|
| audit my setup, full audit, check all my rules | `Workflows/Audit.md` |
| quick check, check this file, check these rules | `Workflows/QuickCheck.md` |

## Tool

`python "$HOME/.copilot/skills/bitter-pill-engineering/tools/drift_lint.py"` finds candidates mechanically; it never edits and never decides.

| Call | Use |
|---|---|
| `drift_lint.py --loaded` | everything Copilot loads every session (user and repo instructions, AGENTS.md, `.github/instructions/*.instructions.md`, skill and agent frontmatter), with token cost |
| `drift_lint.py <file.md> ...` / `--dir <folder>` | specific files or a tree |
| `--json`, `--top N`, `--strict` | machine output, the worst N files, exit 1 on high-severity hits |

It flags coercive or shaming language, scripted reasoning choreography, rigid ordering, numeric personality scales, vague style rules, likely restatements of default behaviour, long step lists, NEVER stacks, routing dispatch tables, sentences duplicated across files, and backticked `~/.copilot/...` paths that no longer exist. Drift grows back after every cut, so rerun it after edits.

## The Five Questions

For every rule, instruction or preference:

1. **Default behaviour?** Does the model already do this without being told?
2. **Contradiction?** Does it conflict with another rule in the same or another file?
3. **Redundancy?** Is it already covered elsewhere?
4. **One-off fix?** Was it added to fix one specific bad output rather than improve outputs generally?
5. **Vague?** Would the model read it differently every time ("be more natural", "humor: 7/10")?

## The HOW-vs-WHAT test

Does the rule dictate execution method or reasoning choreography ("first analyze X, then consider Y, then decide Z") instead of stating the ideal state (what done looks like) plus the tools? If it scripts the HOW, it is scaffolding: flag it CUT.

Four keep-classes are legitimate HOW and are never cut:

| Keep-class | Example |
|---|---|
| **Safety gate** | confirm before a destructive or outward-facing action |
| **Verified gotcha** | a documented, non-obvious failure that will recur untold |
| **Tool contract** | the exact CLI, API or path recipe that can't be guessed |
| **Output-format contract** | a shape something downstream parses (the Kai banner and closer, a JSON schema) |

Deterministic code (scripts, hooks) is exempt. Kai's own authoring standard says the same thing for skills: `~/.copilot/skills/create-skill/AuthoringStandard.md`.

## Classification

| Finding | Action |
|---|---|
| restates default behaviour | **CUT** |
| contradicts another rule | **RESOLVE**: pick one, cut the other |
| duplicates another rule | **MERGE**: one place, one statement |
| one-off fix for a past mistake | **EVALUATE**: still happening, or already learned? |
| vague or unquantifiable | **SHARPEN** with DO/DON'T examples, or cut |
| loaded every session but rarely relevant | **MOVE** into a skill or an on-demand reference file |
| specific, actionable, non-default | **KEEP** |

**Anti-fragile (keep):** verification harnesses, ISA claims, data pipelines, specific DO/DON'T examples, tool preferences, routing rules.
**Fragile (cut):** chain-of-thought orchestrators, format parsers written in prose, retry cascades, numeric personality scales, abstract value statements, process descriptions nobody follows.

## Output format

```
## Bitter Pill audit
Scope: <what was audited> · Files: <n> · Rules evaluated: <n> · Always-loaded cost: ~<tokens> tokens
### CUT (restates defaults / scripted HOW)
- <rule> (<file>:<line>): <reason>
### RESOLVE (contradictions)
- <rule A> vs <rule B>: keep <which>, because <why>
### MERGE (redundancies)
- <locations> -> <one home>
### EVALUATE (one-off fixes)
- <rule>: <still needed? verdict and evidence>
### SHARPEN or CUT (vague)
- <rule>: <sharpened version> | <why cut>
### MOVE to on-demand
- <content> -> <skill or reference file>; needed <how often>
### KEEP (carrying weight)
- <rule>: <keep-class or why it matters>
Estimated savings: <lines> lines, ~<tokens> tokens per session
```

## Gotchas

- **The model's defaults move between versions.** What was default behaviour three months ago may not be now. When in doubt, test it (an eval case via /evals) rather than assume.
- **A rule that looks redundant may exist because the default was unreliable.** Check whether the failure it fixed still happens before cutting.
- **One-off rules sometimes guard a recurring failure.** Confirm the pattern is truly gone (search `~/.copilot/kai/MEMORY/LEARNING/` for it) before removing.
- **Skill and agent descriptions load every session too.** A long, synonym-stuffed description costs tokens on every turn; count it in the audit.
- **Linter hits are candidates, not verdicts.** A safety gate written in caps is still a safety gate.
