"""drift_lint: deterministic over-prompting scan for instruction files (stdlib only).

Surfaces candidates for a Bitter Pill audit; it never edits anything and never
decides. Hits may be legitimate keep-class lines (safety gates, verified gotchas,
tool contracts, output-format contracts). A human or the audit judges each one.

    python drift_lint.py --loaded                      # what Copilot loads every session, with token cost
    python drift_lint.py path/to/file.md other.md      # specific files
    python drift_lint.py --dir "$HOME/.copilot/skills" --top 10
    python drift_lint.py --loaded --json | --strict    # --strict exits 1 on any high-severity hit

Checks: coercive or shaming language (V2), scripted HOW instead of WHAT (V1),
vague or numeric-personality rules, file-shape heuristics (long step lists, NEVER
stacks, routing tables), sentences duplicated across or within files, and
backticked ~/.copilot paths that no longer exist.
"""
import argparse
import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

WEIGHT = {"high": 3, "med": 2, "low": 1}

LINE_RULES = [
    ("mandatory", "V2", "high", re.compile(r"\bMANDATORY\b"), "Coercive 'MANDATORY' framing; state the WHAT, drop the command."),
    ("required-before", "V2", "high", re.compile(r"REQUIRED BEFORE ANY ACTION", re.I), "Rigid 'before any action' ordering coercion."),
    ("not-optional", "V2", "high", re.compile(r"this is not optional", re.I), "Trust-deficit phrasing written for a weaker model."),
    ("before-anything-else", "V2", "med", re.compile(r"before (doing )?anything else", re.I), "Forced ordering; let the model choose when."),
    ("zero-exceptions", "V2", "high", re.compile(r"zero exceptions|exceptions:\s*none|no exceptions", re.I), "Absolutist enforcement language."),
    ("shame", "V2", "high", re.compile(r"\b(dishonest|lying|liar|lazy|unacceptable)\b", re.I), "Shame language; give facts, not threats."),
    ("theater", "V2", "med", re.compile(r"\btheater\b", re.I), "Distrust framing around tool discipline."),
    ("threat", "V2", "high", re.compile(r"critical failure|you will be (penalized|punished|fired)|or else", re.I), "Threat framing."),
    ("shouting", "V2", "med", re.compile(r"\b(CRITICAL|IMPORTANT|ALWAYS|NEVER EVER|ABSOLUTELY|MUST)\b[:!]"), "All-caps emphasis adds volume, not constraint."),
    ("immediately-upon", "V2", "med", re.compile(r"immediately upon (skill )?invocation", re.I), "Rigid timing coercion."),
    ("you-must", "V2", "low", re.compile(r"\byou must\b", re.I), "Imperative hand-holding (often legitimate; review)."),
    ("exact-order", "V1", "med", re.compile(r"in (the )?(exact )?order|in this order|step by step, in order", re.I), "Rigid sequencing; state the outcome and let the model order its work."),
    ("do-not-deviate", "V1", "med", re.compile(r"do not (deviate|fall back|skip|reorder|improvise)", re.I), "Procedural rigidity: prescribing HOW, not WHAT."),
    ("exactly-as", "V1", "low", re.compile(r"exactly (this|the following|as written|as specified)", re.I), "Over-specified HOW; prefer the ideal end state."),
    ("think-choreography", "V1", "med", re.compile(r"\bfirst,? (analy[sz]e|think|consider|understand)\b.*\bthen\b", re.I), "Reasoning choreography (first analyze, then consider); name the done-state instead."),
    ("exact-sed", "V1", "med", re.compile(r"\bsed -i\b"), "Hardcoded sed; brittle HOW, state the outcome."),
    ("hardcoded-home", "V1", "low", re.compile(r"(/(home|Users)/\w+/|[A-Za-z]:\\Users\\\w+\\)"), "Hardcoded absolute user path; brittle across machines."),
    ("personality-scale", "V3", "med", re.compile(r"\b(humou?r|enthusiasm|formality|verbosity|warmth|sarcasm|energy|curiosity)\b[^.\n]{0,20}\b\d{1,3}\s*(/\s*10|/\s*100|%)", re.I), "Numeric personality scale; the model can't calibrate it. Use DO/DON'T examples."),
    ("vague-style", "V3", "low", re.compile(r"\bbe (more )?(natural|human|engaging|creative|thoughtful|professional|helpful)\b", re.I), "Vague style rule; interpreted differently every time. Sharpen with examples or cut."),
    ("default-behavior", "V3", "low", re.compile(r"\b(read (the )?files? before (editing|modifying)|ask before (deleting|destructive)|don'?t add (unrequested|extra) features|make minimal changes)\b", re.I), "Likely restates default model behavior; check before keeping."),
]


def quoted(line, rx, in_fence):
    if in_fence or line.lstrip().startswith(">"):
        return True
    m = rx.search(line)
    if not m:
        return False
    before, after = line[:m.start()], line[m.end():]
    if re.search(r"`[^`]*$", before) and re.match(r"^[^`]*`", after):
        return True
    if re.search(r'"[^"]*$', before) and re.match(r'^[^"]*"', after):
        return True
    return False


def lint_text(text):
    findings = []
    in_fence = False
    for i, line in enumerate(text.splitlines(), 1):
        if re.match(r"^\s*(```|~~~)", line):
            in_fence = not in_fence
            continue
        for rid, typ, sev, rx, msg in LINE_RULES:
            if rx.search(line):
                q = quoted(line, rx, in_fence)
                findings.append({"line": i, "id": rid, "type": typ, "sev": "low" if q else sev,
                                 "msg": msg + (" (quoted/example: citing, not using)" if q else ""),
                                 "snippet": line.strip()[:100]})
    heur = []
    steps = len(re.findall(r"^\s*\d+\.\s", text, re.M))
    if steps >= 10:
        heur.append({"type": "V1", "sev": "med", "msg": f"Long imperative step list ({steps} numbered steps); prefer WHAT + tools over scripted HOW."})
    nevers = len(re.findall(r"\bNEVER\b", text))
    if nevers >= 4:
        heur.append({"type": "V2", "sev": "med", "msg": f"'NEVER' x{nevers}: defensive re-explanation; keep real guardrails, trim the rest."})
    fences = len(re.findall(r"```(bash|sh|powershell|pwsh|ps1)", text))
    if fences >= 4:
        heur.append({"type": "V1", "sev": "low", "msg": f"{fences} shell code blocks; check for prescribed command sequences vs illustrative examples."})
    routes = len(re.findall(r"[\"`][^\"`\n]{2,40}[\"`]\s*(?:→|->)\s*\w[\w/-]*\.md", text))
    if routes >= 3:
        heur.append({"type": "V1", "sev": "med", "msg": f"If-then routing dispatch ({routes} trigger -> file.md maps); a routing table plus judgment usually suffices."})
    return findings, heur


def score(findings, heur):
    return sum(WEIGHT[f["sev"]] for f in findings) + sum(WEIGHT[h["sev"]] for h in heur)


def tokens(text):
    return max(1, len(text) // 4)


def copilot_home():
    return Path(os.environ.get("COPILOT_HOME") or (Path.home() / ".copilot"))


def loaded_set(cwd):
    """Instruction files Copilot loads into every session, plus skill/agent frontmatter."""
    home = copilot_home()
    cwd = Path(cwd)
    files = []
    for p in [home / "copilot-instructions.md", cwd / "AGENTS.md", cwd / "CLAUDE.md", cwd / "GEMINI.md",
              cwd / ".github" / "copilot-instructions.md"]:
        if p.is_file():
            files.append((p, "instructions"))
    for d in (cwd / ".github" / "instructions", home / "instructions"):
        if d.is_dir():
            files += [(p, "instructions") for p in sorted(d.rglob("*.instructions.md"))]
    for d in (home / "skills", cwd / ".github" / "skills"):
        if d.is_dir():
            files += [(p, "skill-frontmatter") for p in sorted(d.glob("*/SKILL.md"))]
    for d in (home / "agents", cwd / ".github" / "agents"):
        if d.is_dir():
            files += [(p, "agent-frontmatter") for p in sorted(d.glob("*.agent.md"))]
    return files


def frontmatter(text):
    m = re.match(r"^﻿?---\s*\n(.*?)\n---", text, re.S)
    return m.group(1) if m else ""


def sentences(text):
    out = []
    in_fence = False
    for i, line in enumerate(text.splitlines(), 1):
        if re.match(r"^\s*(```|~~~)", line):
            in_fence = not in_fence
            continue
        if in_fence or line.strip().startswith(("|", "#")):
            continue
        for s in re.split(r"(?<=[.!?])\s+", line.strip().lstrip("-*> ").strip()):
            norm = re.sub(r"[^a-z0-9 ]", "", s.lower())
            norm = re.sub(r"\s+", " ", norm).strip()
            if len(norm) >= 40:
                out.append((norm, i, s.strip()[:100]))
    return out


def duplicates(texts):
    seen = defaultdict(list)
    for name, text in texts.items():
        for norm, line, raw in sentences(text):
            seen[norm].append((name, line, raw))
    return [occ for occ in seen.values() if len(occ) > 1]


def stale_paths(text):
    home = copilot_home()
    out = []
    for i, line in enumerate(text.splitlines(), 1):
        for m in re.finditer(r"`(~[/\\]\.copilot[/\\][^`\s<>*{}]+)`", line):
            rel = m.group(1)[len("~/.copilot/"):].replace("\\", "/")
            if "<" in rel or "*" in rel or "/MEMORY" in "/" + rel or "session-state" in rel:
                continue  # runtime data folders are created on demand
            if not (home / rel).exists():
                out.append({"line": i, "path": m.group(1)})
    return out


def collect(paths, dirs):
    out = []
    for d in dirs:
        root = Path(d).expanduser()
        if root.is_dir():
            out += [(p, "file") for p in sorted(root.rglob("*.md"))
                    if not any(x in (".git", "node_modules", "__pycache__") for x in p.parts)]
    for p in paths:
        p = Path(p).expanduser()
        if p.is_dir():
            out += [(f, "file") for f in sorted(p.rglob("*.md"))]
        elif p.is_file():
            out.append((p, "file"))
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(prog="drift_lint.py", description="Bitter Pill drift scan for instruction files")
    ap.add_argument("paths", nargs="*")
    ap.add_argument("--dir", action="append", default=[])
    ap.add_argument("--loaded", action="store_true", help="scan what Copilot loads every session (cwd + Copilot home)")
    ap.add_argument("--cwd", default=os.getcwd())
    ap.add_argument("--top", type=int, default=0)
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    targets = collect(args.paths, args.dir)
    if args.loaded:
        targets = loaded_set(args.cwd) + targets
    if not targets:
        print("drift_lint: nothing to scan. Pass files, --dir <path>, or --loaded.")
        return 0
    reports, texts, total_tokens = [], {}, 0
    for path, kind in targets:
        try:
            full = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeDecodeError):
            continue
        text = frontmatter(full) if kind in ("skill-frontmatter", "agent-frontmatter") else full
        tok = tokens(text)
        total_tokens += tok
        f, h = lint_text(text)
        stale = stale_paths(full)
        name = str(path)
        texts[name] = text
        reports.append({"file": name, "kind": kind, "tokens": tok, "lines": text.count("\n") + 1,
                        "score": score(f, h) + 2 * len(stale), "findings": f, "heuristics": h, "stale_paths": stale})
    dups = duplicates(texts)
    reports.sort(key=lambda r: (-r["score"], -r["tokens"]))
    flagged = [r for r in reports if r["score"] > 0]
    highs = sum(1 for r in reports for f in r["findings"] if f["sev"] == "high")
    if args.json:
        print(json.dumps({"scanned": len(reports), "flagged": len(flagged), "high": highs, "tokens_total": total_tokens,
                          "reports": reports, "duplicates": [[{"file": a, "line": b, "text": c} for a, b, c in occ]
                                                             for occ in dups]}, indent=2, ensure_ascii=False))
        return 1 if args.strict and highs else 0
    print(f"drift_lint: {len(reports)} scanned, {len(flagged)} flagged, {highs} high, ~{total_tokens} tokens total\n")
    if args.loaded:
        print("Always-loaded cost (largest first):")
        for r in sorted(reports, key=lambda r: -r["tokens"])[:15]:
            print(f"  ~{r['tokens']:>6} tok  {r['kind']:<18} {r['file']}")
        print()
    show = flagged[:args.top] if args.top else flagged
    for r in show:
        n_high = sum(1 for f in r["findings"] if f["sev"] == "high")
        print(f"> {r['file']}   drift={r['score']} ({n_high} high, ~{r['tokens']} tok)")
        for f in r["findings"]:
            print(f"    L{f['line']} [{f['type']}/{f['sev']}] {f['id']}: {f['msg']}")
        for h in r["heuristics"]:
            print(f"    [file] [{h['type']}/{h['sev']}] {h['msg']}")
        for s in r["stale_paths"]:
            print(f"    L{s['line']} [stale] {s['path']} does not exist")
        print()
    if args.top and len(flagged) > args.top:
        print(f"... +{len(flagged) - args.top} more flagged file(s)\n")
    if dups:
        print(f"Duplicated sentences ({len(dups)}): candidates to MERGE")
        for occ in dups[:20]:
            where = ", ".join(f"{Path(a).name}:{b}" for a, b, _ in occ)
            print(f"  {occ[0][2]!r}  <- {where}")
        print()
    print("Legend: V1 over-specified HOW, V2 trust-deficit scaffolding, V3 vague or obviated rule.")
    print("ADVISORY: hits may be legitimate safety gates, gotchas, tool or output contracts. Judge each; this tool never edits.")
    return 1 if args.strict and highs else 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    sys.exit(main())
