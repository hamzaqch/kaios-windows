#!/usr/bin/env python3
"""stat_signals.py - deterministic, keyless statistical AI-text signals.

Every signal is a FEATURE with an honesty tier, never a verdict. The survey
literature (arXiv:2310.15264) finds that no keyless statistic is a reliable
per-document AI detector, and paraphrase degrades all of them.

Signals (tier in parentheses):
  unigram/bigram Shannon entropy + type-token ratio  (real-but-imperfect)
  trigram repetition ratio                           (real-but-imperfect)
  burstiness: sentence-length coefficient of var.    (weak-alone)
  paragraph-length uniformity                        (weak-alone)
  function-word ratio                                (weak-alone)

Not implemented, with reasons (see --explain): DetectGPT (arXiv:2301.11305)
and Binoculars (arXiv:2401.12070) need reference-LM logprobs; Gloaguen et al.
(arXiv:2405.20777) needs query access to the generating model.

Usage:
  python stat_signals.py --file <path> [--file <path> ...]
  python stat_signals.py --text "..."
  <text> | python stat_signals.py
  [--json] [--explain]

Python 3.8+ standard library only.
"""
import argparse
import json
import math
import re
import sys
from collections import Counter

MIN_WORDS = 100

# Top English function words: a stable, genre-light stylometry basis.
FUNCTION_WORDS = frozenset("""
the of and a to in is it that for on with as was at by an be this which or from
but not are were his her they them we you i he she its their our your my me him
us who whom what when where how why all any both each few more most some such no
nor only own same so than too very can will just should would could may might
must shall do does did has have had if then else there here up down out off over
under again further once about into through during before after above below
between while because
""".split())

# A "word" is a run of letters or apostrophes (matches the TS \b[\p{L}']+\b).
WORD_RE = re.compile(r"\b(?:[^\W\d_]|')+\b", re.UNICODE)
SENT_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
PARA_SPLIT_RE = re.compile(r"\n\s*\n")
LINE_SPLIT_RE = re.compile(r"\n+")

REAL = "real-but-imperfect"
WEAK = "weak-alone"


def words(text):
    return WORD_RE.findall(text.lower())


def shannon_entropy(tokens):
    if not tokens:
        return 0.0
    n = len(tokens)
    h = 0.0
    for c in Counter(tokens).values():
        p = c / n
        h -= p * math.log2(p)
    return h


def ngrams(tokens, n):
    return [" ".join(tokens[i:i + n]) for i in range(0, len(tokens) - n + 1)]


def repeat_ratio(grams):
    if not grams:
        return 0.0
    repeats = sum(c - 1 for c in Counter(grams).values() if c > 1)
    return repeats / len(grams)


def coefficient_of_variation(xs):
    if len(xs) < 2:
        return 0.0
    mean = sum(xs) / len(xs)
    if mean == 0:
        return 0.0
    sd = math.sqrt(sum((x - mean) ** 2 for x in xs) / len(xs))
    return sd / mean


def sentence_lengths(text):
    return [n for n in (len(words(s)) for s in SENT_SPLIT_RE.split(text)) if n > 0]


def paragraph_lengths(text):
    paras = [n for n in (len(words(p)) for p in PARA_SPLIT_RE.split(text)) if n > 0]
    # Prose separated by single newlines reads as one giant paragraph under the
    # blank-line split; fall back to a line-level split.
    if len(paras) < 2:
        paras = [n for n in (len(words(p)) for p in LINE_SPLIT_RE.split(text)) if n > 0]
    return paras


def _r(x):
    return round(float(x), 4)


def analyze(text):
    """Return {"signals": [...], "words": int, "short_sample": bool}."""
    toks = words(text)
    sents = sentence_lengths(text)
    paras = paragraph_lengths(text)
    fn_count = sum(1 for t in toks if t in FUNCTION_WORDS)
    uniq = len(set(toks))
    n = len(toks)

    signals = [
        {"key": "unigram_entropy", "label": "Unigram Shannon entropy (bits/token)",
         "value": _r(shannon_entropy(toks)), "tier": REAL,
         "note": "AI text tends toward lower-entropy token distributions; length-sensitive, compare like with like."},
        {"key": "bigram_entropy", "label": "Bigram Shannon entropy (bits/bigram)",
         "value": _r(shannon_entropy(ngrams(toks, 2))), "tier": REAL,
         "note": "Low bigram entropy = more formulaic local structure; useful as a feature, weak alone."},
        {"key": "type_token_ratio", "label": "Type-token ratio (vocabulary diversity)",
         "value": _r(uniq / n if n else 0), "tier": REAL,
         "note": "Falls with length for everyone; only comparable between samples of similar size."},
        {"key": "trigram_repeat_ratio", "label": "Trigram repetition ratio",
         "value": _r(repeat_ratio(ngrams(toks, 3))), "tier": REAL,
         "note": "Elevated repetition is a measurable machine tell; low-entropy human writing scores high too."},
        {"key": "burstiness", "label": "Burstiness (sentence-length coefficient of variation)",
         "value": _r(coefficient_of_variation(sents)), "tier": WEAK,
         "note": "Low CV = uniform rhythm, the GPTZero-style signal. Formal or non-native human prose also scores low; folklore tier as a standalone."},
        {"key": "paragraph_uniformity", "label": "Paragraph-length coefficient of variation",
         "value": _r(coefficient_of_variation(paras)), "tier": WEAK,
         "note": "Uniform paragraph lengths are a structural AI tell word lists cannot see; genre-dependent."},
        {"key": "function_word_ratio", "label": "Function-word ratio",
         "value": _r(fn_count / n if n else 0), "tier": WEAK,
         "note": "Stylometric feature; author- and genre-dependent, corpus-level signal only."},
    ]
    return {"signals": signals, "words": n, "short_sample": n < MIN_WORDS}


EXPLAIN = """
stat_signals - keyless statistical AI-text signals, and what they are NOT
=========================================================================

These are FEATURES, never verdicts. Survey grounding (arXiv:2310.15264): as
models scale, the human/AI distributional gap narrows and paraphrase attacks
degrade ALL keyless statistical detectors. Two honesty tiers:

  real-but-imperfect - measurable, genuinely correlated with machine text:
    n-gram entropy, type-token ratio, repetition structure.
  weak-alone - real quantities, unreliable standalone (folklore tier):
    burstiness, paragraph uniformity, function-word stylometry. Formal,
    simple, or non-native human writing false-positives; sampled modern
    models false-negative.

Key-free techniques this tool does NOT implement, and why:
  * DetectGPT (arXiv:2301.11305) - probability-curvature scoring; needs a
    reference language model's logprobs, not available in a static scanner.
  * Binoculars (arXiv:2401.12070) - log-likelihood / cross-entropy ratio between
    two models; strongest zero-shot detector, same reference-LM requirement.
    An empirical model-based score needs a hosted detector; this skill ships
    none (see SKILL.md, "What was left out").
  * Gloaguen et al. watermark-presence fingerprinting (arXiv:2405.20777) -
    needs black-box QUERY access to the generating model; does not port to
    file scanning.
  * Unigram green-list recovery (arXiv:2306.17439) - statistically possible
    only over MANY generations known to come from one model, never from the
    documents in front of a scanner.

Watermark payloads (Kirchenbauer, Aaronson/Gumbel, SynthID, vendor in-text
marks) remain key-gated and unreadable from text - watermark_scan.py --explain
has the full impossibility model. Nothing here says "AI" or "human"; it
reports the distributional shape and its reliability tier, and interpretation
stays with the caller.
"""

CAVEAT = ("Features, not verdicts. No keyless statistic reliably detects AI text per-document "
          "(arXiv:2310.15264); paraphrase degrades all of them. Run --explain.")


def decode_bytes(data):
    """Decode file/stdin bytes: honor UTF-16 BOMs (Windows PowerShell 5.1 `>` writes UTF-16LE), else UTF-8."""
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16", errors="replace")
    return data.decode("utf-8", errors="replace")


def read_file(path):
    with open(path, "rb") as fh:
        text = decode_bytes(fh.read())
    return text.lstrip("\ufeff").replace("\r\n", "\n")


def read_stdin():
    return decode_bytes(sys.stdin.buffer.read()).lstrip("\ufeff").replace("\r\n", "\n")


def render_text(results):
    out = []
    for res in results:
        out.append("")
        out.append("stat_signals - {} - {} words".format(res["name"], res["words"]))
        out.append("=" * 56)
        if res["short_sample"]:
            out.append("! under {} words - every signal below is unreliable at this length".format(MIN_WORDS))
        for s in res["signals"]:
            tag = "* signal" if s["tier"] == REAL else ". weak  "
            out.append("{}  {}: {}".format(tag, s["label"], s["value"]))
            out.append("          {}".format(s["note"]))
    out.append("")
    out.append("-" * 56)
    out.append("Features, not verdicts - no keyless statistic is a reliable per-document")
    out.append("AI detector, and paraphrase degrades all of them. Run --explain.")
    out.append("")
    return "\n".join(out)


def render_json(results):
    return json.dumps({
        "documents": [{
            "name": r["name"], "words": r["words"], "short_sample": r["short_sample"],
            "signals": [{"key": s["key"], "value": s["value"], "tier": s["tier"], "note": s["note"]}
                        for s in r["signals"]],
        } for r in results],
        "caveat": CAVEAT,
    }, indent=2, ensure_ascii=False)


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description="Keyless statistical AI-text signals (features, never verdicts).")
    ap.add_argument("--file", action="append", default=[], help="file to analyze (repeatable)")
    ap.add_argument("--text", action="append", default=[], help="inline text to analyze (repeatable)")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    ap.add_argument("--explain", action="store_true", help="print what these signals are and are not")
    args = ap.parse_args(argv)

    if args.explain:
        print(EXPLAIN)
        return 0

    inputs = []
    for path in args.file:
        try:
            inputs.append((path, read_file(path)))
        except OSError as exc:
            print("error: cannot read {}: {}".format(path, exc), file=sys.stderr)
            return 2
    for t in args.text:
        inputs.append(("(text)", t))
    if not inputs and not sys.stdin.isatty():
        inputs.append(("(stdin)", read_stdin()))
    if not inputs:
        print('usage: stat_signals.py --file <path> [--file ...] | --text "..." | (stdin)   [--json] [--explain]',
              file=sys.stderr)
        return 2

    results = []
    for name, text in inputs:
        res = analyze(text)
        res["name"] = name
        results.append(res)
    print(render_json(results) if args.json else render_text(results))
    return 0


if __name__ == "__main__":
    sys.exit(main())
