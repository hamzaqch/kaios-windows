#!/usr/bin/env python3
"""watermark_scan.py - scan text for KEYLESS-detectable watermark and steganography signatures.

What this CAN find (deterministic, no key, no model): character-level covert
channels that leave literal artifacts in the bytes - zero-width characters,
variation-selector and Unicode Tags-block steganography, bidi controls,
homoglyph / mixed-script substitution and anomalous whitespace. Plus a weak
statistical tell (trigram repetition) reported as a heuristic, never a verdict.

What this CANNOT find, by mathematical design (stated in every report):
sampling-time statistical watermarks - Kirchenbauer green-list
(arXiv:2301.10226), Aaronson/Gumbel distortion-free (arXiv:2307.15593),
Google SynthID-Text (Nature s41586-024-08025-4) and vendor-announced in-text
marks. They are key-gated for single-text detection: without the secret key
the output is indistinguishable from unwatermarked text. See --explain.

Usage:
  python watermark_scan.py --file <path>
  python watermark_scan.py --text "..."
  <text> | python watermark_scan.py
  [--json] [--explain] [--strict]

Exit code: 0 normally; with --strict, 1 when a high-severity signature is found.
Python 3.8+ standard library only.
"""
import argparse
import json
import re
import sys
from collections import Counter

NAMED = {
    0x200B: "ZERO WIDTH SPACE",
    0x200C: "ZERO WIDTH NON-JOINER",
    0x200D: "ZERO WIDTH JOINER",
    0x2060: "WORD JOINER",
    0xFEFF: "ZERO WIDTH NO-BREAK SPACE / BOM",
    0x00AD: "SOFT HYPHEN",
    0x180E: "MONGOLIAN VOWEL SEPARATOR",
    0x061C: "ARABIC LETTER MARK",
    0x00A0: "NO-BREAK SPACE",
    0x2009: "THIN SPACE",
    0x200A: "HAIR SPACE",
    0x202F: "NARROW NO-BREAK SPACE",
    0x205F: "MEDIUM MATHEMATICAL SPACE",
    0x3000: "IDEOGRAPHIC SPACE",
    0x2007: "FIGURE SPACE",
    0x2028: "LINE SEPARATOR",
    0x2029: "PARAGRAPH SEPARATOR",
    0x202A: "LEFT-TO-RIGHT EMBEDDING",
    0x202B: "RIGHT-TO-LEFT EMBEDDING",
    0x202C: "POP DIRECTIONAL FORMATTING",
    0x202D: "LEFT-TO-RIGHT OVERRIDE",
    0x202E: "RIGHT-TO-LEFT OVERRIDE",
    0x2066: "LEFT-TO-RIGHT ISOLATE",
    0x2067: "RIGHT-TO-LEFT ISOLATE",
    0x2068: "FIRST STRONG ISOLATE",
    0x2069: "POP DIRECTIONAL ISOLATE",
}

# Cyrillic and Greek lookalikes most used for homoglyph swaps -> the Latin letter imitated.
CONFUSABLES = {
    0x0430: "a", 0x0435: "e", 0x043E: "o", 0x0440: "p", 0x0441: "c", 0x0445: "x",
    0x0443: "y", 0x0456: "i", 0x0458: "j", 0x0405: "S", 0x0410: "A", 0x0412: "B",
    0x0415: "E", 0x041A: "K", 0x041C: "M", 0x041D: "H", 0x041E: "O", 0x0420: "P",
    0x0421: "C", 0x0422: "T", 0x0425: "X", 0x0391: "A", 0x0392: "B", 0x0395: "E",
    0x0396: "Z", 0x0397: "H", 0x0399: "I", 0x039A: "K", 0x039C: "M", 0x039D: "N",
    0x039F: "O", 0x03A1: "P", 0x03A4: "T", 0x03A5: "Y", 0x03A7: "X", 0x03BF: "o",
    0x03B1: "a", 0x03B5: "e", 0x0501: "d",
}

BIDI = frozenset([0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069])
INVIS = frozenset([0x200B, 0x200C, 0x200D, 0x2060, 0xFEFF, 0x00AD, 0x180E, 0x061C])
ODD_WS = frozenset([0x00A0, 0x2009, 0x200A, 0x202F, 0x205F, 0x3000, 0x2007, 0x2028, 0x2029])

CLASSES = [
    ("invisible", "Zero-width / invisible characters", "high",
     "Zero-width chars carry no glyph; a classic covert channel for embedding a payload or ID. Rare in legitimate prose."),
    ("variation_selectors", "Variation-selector steganography", "high",
     "VS15/16 and the supplementary VS block ride invisibly after a base char - a documented channel for hiding data in emoji/text."),
    ("unicode_tags", "Unicode Tags block (deprecated covert channel)", "high",
     "U+E0000-E007F 'tag' chars are invisible and near-universally a deliberate hidden channel - almost never legitimate."),
    ("bidi_controls", "Bidirectional control overrides", "medium",
     "Bidi overrides can reorder rendered text (Trojan-Source style) and act as an invisible marker."),
    ("homoglyphs", "Homoglyph / mixed-script substitution", "medium",
     "Cyrillic/Greek lookalikes swapped for Latin letters encode a signal that survives copy-paste but is invisible to a reader."),
    ("whitespace", "Anomalous whitespace", "low",
     "Non-standard spaces (NBSP, thin/hair, ideographic) can encode bits; also common benign artifacts, so weight lightly."),
]

WORD_RE = re.compile(r"\b(?:[^\W\d_]|')+\b", re.UNICODE)


def decode_bytes(data):
    """Decode file/stdin bytes: honor UTF-16 BOMs (Windows PowerShell 5.1 `>` writes UTF-16LE), else UTF-8."""
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16", errors="replace")
    return data.decode("utf-8", errors="replace")


def cp_label(cp):
    return "U+{:04X}".format(cp)


def cp_name(cp):
    return NAMED.get(cp, cp_label(cp))


def classify(cp):
    """Return the class key for a codepoint, or None."""
    if cp in INVIS:
        return "invisible"
    if cp in BIDI:
        return "bidi_controls"
    if cp in ODD_WS:
        return "whitespace"
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return "variation_selectors"
    if 0xE0000 <= cp <= 0xE007F:
        return "unicode_tags"
    if cp in CONFUSABLES:
        return "homoglyphs"
    return None


def scan(text):
    """Scan text; return a list of class dicts with hits.

    Each hit: {"cp", "codepoint", "name", "index" (codepoint index), "byte_offset" (UTF-8)}.
    """
    hits = {key: [] for key, _, _, _ in CLASSES}
    byte_offset = 0
    for index, ch in enumerate(text):
        cp = ord(ch)
        # A single U+FEFF at the very start is a file-encoding byte-order mark (Notepad and
        # Windows PowerShell 5.1 write one), not a covert channel; report() notes it separately.
        key = None if (index == 0 and cp == 0xFEFF) else classify(cp)
        if key is not None:
            name = cp_name(cp)
            if key == "homoglyphs":
                name = "{} (imitates '{}')".format(name, CONFUSABLES[cp])
            hits[key].append({"cp": cp, "codepoint": cp_label(cp), "name": name,
                              "index": index, "byte_offset": byte_offset})
        byte_offset += len(ch.encode("utf-8", errors="surrogatepass"))
    return [{"key": key, "label": label, "severity": sev, "hits": hits[key], "note": note}
            for key, label, sev, note in CLASSES]


def repetition_score(text):
    toks = WORD_RE.findall(text.lower())
    if len(toks) < 30:
        return {"trigram_repeat_ratio": 0.0, "note": "sample too short for a meaningful repetition read"}
    grams = [" ".join(toks[i:i + 3]) for i in range(len(toks) - 2)]
    repeats = sum(c - 1 for c in Counter(grams).values() if c > 1)
    ratio = repeats / len(grams) if grams else 0.0
    return {"trigram_repeat_ratio": round(ratio, 4),
            "note": "elevated trigram repetition is a weak AI-text tell, not a watermark; "
                    "low-entropy human writing scores high too"}


EXPLAIN = """
watermark_scan - what it can and cannot detect
==============================================

DETECTABLE (this tool finds them, no key required):
  These are CHARACTER-LEVEL covert channels - they add literal codepoints to
  the bytes, so a scanner sees them directly.
  * Zero-width / invisible characters (U+200B..U+200D, U+FEFF, U+00AD, ...)
  * Variation-selector steganography (U+FE00..FE0F, U+E0100..E01EF)
  * Unicode Tags-block hidden channel (U+E0000..E007F)
  * Bidirectional control overrides (Trojan-Source class)
  * Homoglyph / mixed-script substitution (Cyrillic/Greek imitating Latin)
  * Anomalous whitespace (NBSP, thin/hair/ideographic spaces)

NOT DETECTABLE from text alone, BY DESIGN (this tool says so and stops):
  These are SAMPLING-TIME STATISTICAL watermarks - they bias token choice
  using a SECRET KEY and add no visible or invisible characters. Without the
  key the output is indistinguishable from ordinary text.
  * Kirchenbauer green-list/red-list  - arXiv:2301.10226 (z-test needs the hash key)
  * Aaronson / Gumbel distortion-free - arXiv:2307.15593 (marginal distribution unchanged)
  * Google SynthID-Text             - Nature s41586-024-08025-4 (code open, detection key-gated)
  * Vendor-announced in-text marks   - mechanisms undisclosed or key-gated; until a
                                       vendor ships a detection API, nothing detects
                                       them from text, with or without this tool.

  The one real keyless watermark-PRESENCE test (Gloaguen et al., ICLR 2025,
  arXiv:2405.20777) needs black-box QUERY access to the model, not a static
  file, so it is out of scope for a text scanner.

Bottom line: a clean result here means "no character-level covert channel
found." It does NOT mean the text is unwatermarked or human-written.
"""

UNDETECTABLE = ("Sampling-time statistical watermarks (Kirchenbauer, Gumbel/Aaronson, SynthID, "
                "vendor in-text marks) cannot be read from text without the secret key. Run --explain.")


def report(text):
    classes = scan(text)
    flagged = [c for c in classes if c["hits"]]
    return {
        "chars": len(text),
        "leading_bom": text[:1] == "\ufeff",
        "signatures_found": len(flagged),
        "high_severity": any(c["severity"] == "high" for c in flagged),
        "classes": classes,
        "heuristics": repetition_score(text),
    }


def render_json(rep):
    return json.dumps({
        "chars": rep["chars"],
        "leading_bom": rep["leading_bom"],
        "signatures_found": rep["signatures_found"],
        "high_severity": rep["high_severity"],
        "classes": [{
            "key": c["key"], "label": c["label"], "severity": c["severity"], "count": len(c["hits"]),
            "sample": [{"codepoint": h["codepoint"], "name": h["name"], "index": h["index"],
                        "byte_offset": h["byte_offset"]} for h in c["hits"][:8]],
            "note": c["note"],
        } for c in rep["classes"]],
        "heuristics": rep["heuristics"],
        "undetectable_by_design": UNDETECTABLE,
    }, indent=2, ensure_ascii=False)


def render_text(rep):
    out = ["", "watermark_scan - {} chars".format(rep["chars"]), "=" * 48]
    flagged = [c for c in rep["classes"] if c["hits"]]
    if rep["leading_bom"]:
        out.append("note: file starts with a U+FEFF byte-order mark (an encoding marker from the editor")
        out.append("      or shell that saved it, not a covert channel); not counted as a hit.")
    if not flagged:
        out.append("No character-level covert-channel signatures found.")
    for c in flagged:
        tag = {"high": "# HIGH", "medium": "* MED ", "low": ". LOW "}[c["severity"]]
        out.append("")
        out.append("{}  {} - {} hit(s)".format(tag, c["label"], len(c["hits"])))
        out.append("        {}".format(c["note"]))
        for h in c["hits"][:6]:
            out.append("        @{} (byte {})  {}".format(h["index"], h["byte_offset"], h["name"]))
        if len(c["hits"]) > 6:
            out.append("        ...+{} more".format(len(c["hits"]) - 6))
    heur = rep["heuristics"]
    out.append("")
    out.append("Heuristic - trigram repeat ratio: {}  ({})".format(heur["trigram_repeat_ratio"], heur["note"]))
    out.append("")
    out.append("-" * 48)
    out.append("Cannot detect from text alone: sampling-time statistical watermarks")
    out.append("(Kirchenbauer, Gumbel/Aaronson, SynthID, vendor in-text marks).")
    out.append("Key-gated by design. A clean scan does NOT mean unwatermarked. Run --explain.")
    out.append("")
    return "\n".join(out)


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description="Keyless character-level watermark / steganography scan.")
    ap.add_argument("--file", help="file to scan (UTF-8, or UTF-16 with a BOM; a leading BOM is noted, not counted as a hit)")
    ap.add_argument("--text", help="inline text to scan")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    ap.add_argument("--explain", action="store_true", help="print the detectability model and exit")
    ap.add_argument("--strict", action="store_true", help="exit 1 when a high-severity signature is found")
    args = ap.parse_args(argv)

    if args.explain:
        print(EXPLAIN)
        return 0
    if args.file:
        try:
            with open(args.file, "rb") as fh:
                text = decode_bytes(fh.read())
        except OSError as exc:
            print("error: cannot read {}: {}".format(args.file, exc), file=sys.stderr)
            return 2
    elif args.text is not None:
        text = args.text
    elif not sys.stdin.isatty():
        text = decode_bytes(sys.stdin.buffer.read())
    else:
        print('usage: watermark_scan.py --file <path> | --text "..." | (stdin)   [--json] [--explain] [--strict]',
              file=sys.stderr)
        return 2

    rep = report(text)
    print(render_json(rep) if args.json else render_text(rep))
    if args.strict and rep["high_severity"]:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
