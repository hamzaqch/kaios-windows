---
name: detect-ai
description: "Detects AI-generated writing with free, keyless measures: a heuristic audit against a severity-tiered catalog of known AI patterns, deterministic statistical signals (n-gram entropy, type-token ratio, repetition, burstiness, paragraph uniformity, function-word stylometry, reported as features with reliability tiers, never verdicts), and a byte-level scan for watermark and steganography signatures (zero-width and invisible characters, variation selectors, Unicode tag characters, homoglyphs, bidi controls, odd whitespace). Use when the user says detect AI writing, is this AI, did an AI write this, does this sound like AI, scan for AI tells, flag AI patterns, AI-isms, statistical AI signals, burstiness, text entropy, is this watermarked, detect a watermark, steganography, zero-width characters, hidden characters, invisible unicode, or compare drafts for AI-ness. Not for rewriting prose, plagiarism detection, detecting AI images, video or code, or judging whether writing is any good."
argument-hint: "<file | pasted text> [profile: blog|linkedin|technical-blog|investor-email|docs|casual]"
---

# Detect AI

## What it does

Answers two questions (*how much does this read as machine-generated?* and *does it carry an embedded mark?*) with three independent, free measures:

- **Heuristic audit.** Flags known AI tells (inflated vocabulary, the "not X, it's Y" tic, recycled transitions, uniform rhythm) against the severity-tiered catalog in `AIWritingPatterns.md`. Instant, and it explains *why* each flag fired.
- **Statistical signals.** A deterministic pass (`Tools/stat_signals.py`) measuring the keyless distributional tells the research literature rates real: n-gram entropy, type-token ratio, repetition structure, plus the weak-alone folklore tier (burstiness, paragraph uniformity, function-word stylometry), each labeled with its reliability. Features, never verdicts (arXiv:2310.15264: paraphrase degrades every keyless statistic).
- **Watermark scan.** A keyless, deterministic pass (`Tools/watermark_scan.py`) for character-level covert channels: invisible characters, variation-selector and Tags-block steganography, homoglyphs, bidi controls, odd whitespace. It catches embedded marks that live in the bytes; by design it *cannot* read sampling-time statistical watermarks (SynthID, Kirchenbauer, vendor in-text marks), which are key-gated.

The measures disagree often, and that disagreement is the useful part. Text can clear every pattern on the list and still show flat rhythm and low entropy, which tells you the tells are structural rather than lexical. A watermark hit is bytes-level proof regardless of what the other two say.

## The problem

"Does this sound like AI?" gets answered by vibes, and vibes are wrong in both directions. Word lists flag legitimate writing and miss AI text that avoided the obvious words. A single number with no baseline is close to meaningless. This skill runs the measures side by side, labels each with how far it can be trusted, and never turns a feature into an accusation.

## Workflow routing

| Workflow | Trigger | File |
|----------|---------|------|
| **Detect** | "scan for AI tells", "flag AI patterns", "does this sound like AI", "is this AI", "audit this for AI-isms", "statistical signals", "burstiness", "entropy", "compare these drafts" | `Workflows/Detect.md` |
| **Watermark** | "is this watermarked", "detect a watermark", "scan for hidden/invisible characters", "steganography", "zero-width chars" | `Workflows/Watermark.md` |

Asked simply "is this AI?", run Detect (heuristics + statistics) and say plainly that the answer is an assessment with stated uncertainty. "Is this watermarked?" routes to Watermark, which answers a different question: whether a covert channel is embedded in the bytes, not whether the prose reads as AI. For "is this AI and is it marked?", run both.

## The tools

Both are Python 3.8+ standard library, read UTF-8, and accept `--file <path>`, `--text "..."` or piped stdin. Add `--json` for machine output and `--explain` for what the tool can and cannot see. Prefer `--file`: it avoids shell quoting entirely.

```powershell
python "$HOME/.copilot/skills/detect-ai/Tools/stat_signals.py" --file draft.md
python "$HOME/.copilot/skills/detect-ai/Tools/stat_signals.py" --file a.md --file b.md --json   # compare drafts
python "$HOME/.copilot/skills/detect-ai/Tools/watermark_scan.py" --file draft.md
python "$HOME/.copilot/skills/detect-ai/Tools/watermark_scan.py" --file draft.md --json --strict # exit 1 on a high-severity hit
```

(The same lines work in bash; `$HOME` expands in both shells, while `~` does not expand for native programs in Windows PowerShell.)

When the text is pasted into the conversation, write it to a scratch file with `apply_patch` (or your file-create tool) and pass `--file`, instead of quoting it on a command line.

## Gotchas

- **Short samples are unreliable.** Every measure is weakest under ~5 sentences; `stat_signals.py` flags anything under 100 words as unreliable. Say so before reporting numbers, not after.
- **A number without a baseline says little.** Run the statistics on known-human writing by the same author, in the same genre and length, in the same batch. The A-vs-B comparison is the trustworthy part.
- **It measures detectability, not quality.** "Reads human" is not "reads well."
- **No measure here is ground truth.** Report findings as signals with tiers, never as a verdict, and never accuse a named person of AI authorship on this evidence.
- **A clean watermark scan does not mean human or unwatermarked.** Copy-paste through HTML or a summarizer strips most invisible characters, and statistical watermarks are invisible to any scanner.
- **Never degrade writing to beat a detector.** Injected typos, broken sentences and "humanizer" laundering damage the prose and don't fix the underlying problem. If text must read human, the fix is a human in the loop.

## Examples

- "Scan this post for AI tells, don't change it" → **Detect**: tiered P0/P1/P2 flag report, each marked clear problem vs judgment call, statistical signals with tiers, no edits.
- "Which of these three drafts reads most human?" → **Detect** in compare mode: `stat_signals.py --file` per draft plus the pattern audit, ranked table, relative comparison foregrounded.
- "Did my rewrite actually help?" → **Detect** before and after, with a known-human passage in the same batch as calibration.
- "Is there anything hidden in this text?" → **Watermark**: codepoint, name and offset for every hit, plus the hard-limit statement.

## What was left out

The original skill also had an empirical score from a paid, hosted AI-detection API (a Score workflow plus API-key setup). Kai ships no paid services and no API keys, so that seat is empty. If the user has their own detector, treat its score the way this skill treats every measure: one signal, calibrated against a known-human baseline, never a verdict.
