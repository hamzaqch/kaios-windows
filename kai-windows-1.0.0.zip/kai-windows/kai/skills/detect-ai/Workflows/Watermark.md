# Watermark workflow

Scan text for watermark and steganography signatures that are readable **without any key**: the character-level covert channels that live directly in the bytes.

## Run it

```powershell
python "$HOME/.copilot/skills/detect-ai/Tools/watermark_scan.py" --file <path>
# also: --text "..."  |  piped stdin  |  --json for machine output  |  --explain for the full model
# --strict exits 1 when a high-severity signature is present (useful in scripts)
```

Always scan the original bytes. If the user pasted the text, note that the paste itself may have stripped or normalized characters; a file they attach is the better evidence. The tool reads files as UTF-8 and reports a byte-order mark (U+FEFF) rather than silently stripping it.

## What it detects (keyless, deterministic)

Zero-width and invisible characters, variation-selector and Unicode Tags-block steganography, bidi-control overrides, homoglyph / mixed-script substitution, anomalous whitespace, plus a weak trigram-repetition heuristic (reported as a hint, never a verdict). Each hit reports its codepoint, name, character index and UTF-8 byte offset.

## The hard limit: state it every time

It **cannot** detect sampling-time statistical watermarks: Kirchenbauer green-list (arXiv:2301.10226), Aaronson/Gumbel (arXiv:2307.15593), Google SynthID-Text (Nature s41586-024-08025-4), or vendor-announced in-text marks. Those bias token choice using a secret key and leave no readable artifact in a single text; detection is key-gated by mathematical design. A clean scan does **not** mean the text is unwatermarked or human-written. Run `--explain` for the detectable-vs-impossible breakdown.

## Report

```
**Scan:** [N chars] — [K signature classes found / none]

- [HIGH|MED|LOW] [class] — [count] hit(s) — e.g. U+200B ZERO WIDTH SPACE at char [i] (byte [b])

**Reading:** [what the hits most plausibly are: deliberate covert channel, tracking ID, Trojan-Source risk, or benign artifact such as NBSP from a word processor]
**Limit:** statistical (key-gated) watermarks cannot be detected from text; a clean scan is not proof of human authorship.
```

Weight by severity: Tags-block and variation-selector runs are near-universally deliberate; zero-width characters are rare in clean prose; NBSP and thin spaces are common benign artifacts.

## Pairs with the other measures

Different questions, different tools: **Detect** (heuristics + `stat_signals.py`) answers "which AI tells fire, and what's the distributional shape?", and **Watermark** answers "is a covert character-level channel embedded?". For "is this AI and is it marked?", run both. Copy-paste through HTML or a summarizer strips most invisible characters, so a wild sample that scans clean may just have been laundered by transport.
