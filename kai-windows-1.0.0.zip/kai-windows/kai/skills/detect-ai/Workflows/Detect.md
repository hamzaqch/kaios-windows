# Detect: heuristic AI-pattern audit + statistical signals

Flag the AI tells in a piece of text and explain each one, and measure the keyless statistical signals underneath the prose. No edits, no network, no cost.

## Reference

Read `AIWritingPatterns.md` (in this skill's folder) before auditing. It holds the severity tiers (P0/P1/P2), the full word-replacement tables, the pattern categories, and the context tolerance matrix. Auditing from memory produces a shallower, less consistent report than auditing against the catalog.

## Get the text into a file

If the user gave a file, use its path. If they pasted text, write it verbatim to a scratch file (for example `detect-input.md` in the current working directory or a temp folder) so the tools read exactly what you audit. Don't alter it.

## Statistical signal pass

Run the deterministic signals alongside the pattern audit:

```powershell
python "$HOME/.copilot/skills/detect-ai/Tools/stat_signals.py" --file <path>          # human-readable
python "$HOME/.copilot/skills/detect-ai/Tools/stat_signals.py" --file <path> --json   # machine output
```

It measures n-gram entropy, type-token ratio and repetition (the tier the research rates real-but-imperfect) plus burstiness, paragraph uniformity and function-word ratio (weak alone: the GPTZero-class folklore tier). Every value carries its tier; nothing emits a verdict. These catch the *structural* tells the word list cannot see: a text can clear every pattern and still show flat rhythm and low entropy. Under ~100 words the tool flags itself unreliable; skip the numbers there. For the model-based zero-shot detectors (DetectGPT, Binoculars) that need reference-model log-probabilities, `--explain` states why they're absent.

**Compare mode** (several drafts, or a draft vs a known-human baseline): pass every file in one run (`--file a.md --file b.md --file human.md --json`) and compare like with like. Entropy and type-token ratio are length-sensitive, so only compare samples of similar length.

## Ideal state

A finished audit is one where:

- Every flag quotes the offending text, so the writer can find it.
- Every flag names its pattern category and severity tier.
- Every flag is marked **clear problem** or **judgment call**. Some AI-associated patterns are effective writing, and a report that demands all of them be fixed is worse than useless: it trains the writer to ignore the tool.
- The context profile is stated up front (blog, linkedin, technical-blog, investor-email, docs, casual). Tolerance differs by venue; the same em-dash density that's fine in an essay is a flag in a LinkedIn post.
- The statistical pass ran (on samples past ~100 words) and its signals appear with their tier labels, read as features feeding the assessment, never as a standalone verdict.
- Nothing is rewritten. This workflow reports.

## Output format

```
**Profile:** [detected profile] | **Severity pass:** [P0+P1 / full] | **Length:** [N words]

**P0 — Credibility killers:**
- "[offending text]" — [category] — MUST FIX

**P1 — Obvious AI smell:**
- "[offending text]" — [category] — [clear problem / judgment call]

**P2 — Stylistic polish:**
- "[offending text]" — [category] — [clear problem / fine in context]

**Statistical signals** (features, not verdicts):
- [signal]: [value] — [tier] — [one-line reading in context]

**Assessment:**
[clean / minor issues / needs rewrite] — [one or two sentences on which flags are real vs intentional, and what the structure says]
```

For compare mode, add a table: one row per draft with word count, flag counts by tier, entropy, burstiness and paragraph uniformity, then a one-line ranking with the caveat that the ordering is relative.

## Recommending a rewrite

When the text has 5+ flagged vocabulary hits across multiple categories, 3+ distinct pattern categories triggered, and uniform sentence and paragraph length, say so: patching a text in that state produces cleaner AI writing, not human writing. The honest recommendation is to state the core point in one sentence and rebuild.

## Reading heuristics and statistics together

The heuristic explains; the statistics measure shape. Text that clears the pattern audit but shows low burstiness, uniform paragraphs and low entropy has structural tells the word list cannot see: uniform rhythm, uniform paragraph length, absent specificity. That gap is the most informative result this workflow produces, so always report both.
