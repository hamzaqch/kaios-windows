# DirectDesign

Kai writes the design directly with the frontend-design doctrine loaded. No external design tool, no account, no network dependency.

## Step 0: load the doctrine

Read `~/.copilot/skills/webdesign/References/FrontendDesignPhilosophy.md` before anything else. It holds the register list, the forbidden defaults, the type-pair recipes per register, color, motion, spatial and background guidance, and the rule that implementation complexity matches the vision. If `~/.copilot/kai/MEMORY/KNOWLEDGE/design-preferences.md` exists, read it next; it biases the register choice but does not bind it.

## Step 1: declare the register (before any code)

Pick one register from the doctrine (or design one true to the brief) and print:

```
AESTHETIC: <register> - <one sentence tying it to the brief>
```

## Step 2: declare the output contract

| Contract | When |
|---|---|
| `single-file-html` | portable demo or prototype; one `.html` with inline `<style>` and `<script>` |
| `react-tailwind` | a `.tsx` component for a React app |
| `astro-component` | `.astro` for content sites |
| `vue-sfc` | `.vue` single-file component |
| `framework-matched-diff` | edits against an existing codebase, reusing its tokens and components |

```
OUTPUT: <contract> - <target path>
```

## Step 3: lock type, palette and motion

```
TYPE: display=<font>, body=<font>, mono=<font or n/a>
PALETTE: bg=<color>, fg=<color>, accent=<color>[, extra=<color>]
MOTION: <one named gesture, e.g. "staggered page-load reveal", "slow hover fade">
```

Take the type pair from the register's row in the doctrine's recipes table; a cross-register font needs a deliberate clash-as-design reason. Define the palette as CSS custom properties on `:root` so `verify_design.py` can compute contrast.

## Step 4: implement

- Real, working code. No lorem ipsum unless that is the joke.
- Complexity matches the register: maximalist earns layered effects and rich timelines; minimal earns precise spacing and restraint.
- None of the forbidden defaults unless the register explicitly calls for them.
- Name the memorable element in a comment at the top: `<!-- HERO: <thing someone will remember> -->` (or `// HERO:` in a component).
- Accessibility floor: body text at least WCAG AA on its surface (AAA on primary content), visible focus states on everything interactive, and every animation disabled or reduced under `@media (prefers-reduced-motion: reduce)`.

## Step 5: verify (required before calling it done)

1. For single-file HTML: `python ~/.copilot/skills/webdesign/tools/verify_design.py <file>`. Fix every FAIL; fix each WARN or state in one line why it is deliberate. For components, apply the same checks by reading the code.
2. Look at it rendered. If a browser or screenshot tool is available in this session, open the page, capture it, and check: fonts actually loaded (no fallback), the palette is visibly committed, motion fires on load or hover, the layout matches the register, the HERO element stands out. If no such tool exists, open it for the user (`Start-Process "<file>"` on Windows) and say "verified statically; the visual check is yours".

If anything fails, return to Step 4. Fix the implementation, never the claim.

## Step 6: hand off

In order, and nothing else:
1. The file path(s) written.
2. The `AESTHETIC | TYPE | PALETTE | MOTION` lines restated.
3. The verification result (checker RESULT line, and the screenshot path or "visual check is yours").
4. One sentence on the memorable element.
