"""verify_design.py - deterministic design checks for a single-file HTML page. Stdlib only.

  python verify_design.py <page.html> [--json] [--allow-lorem]

Checks (FAIL blocks "done"; WARN is a judgment call to justify or fix):
  viewport      FAIL  no <meta name="viewport"> (page breaks on phones)
  title         WARN  no <title>
  lorem         FAIL  lorem ipsum placeholder text (unless --allow-lorem)
  motion        FAIL  animations/transitions without a prefers-reduced-motion rule
  focus         WARN  interactive elements but no :focus / :focus-visible styling
  contrast      FAIL  declared body text color vs background below WCAG AA (4.5:1)
  fonts         WARN  a generic AI-default font (Inter, Roboto, Arial, Helvetica,
                      system-ui, bare sans-serif) is the PRIMARY family somewhere
  gradient      WARN  purple/indigo gradient (the AI-slop signature)
  tailwind      WARN  untouched Tailwind defaults (shadow-md/lg, rounded-lg everywhere)
  hero          WARN  no "HERO:" comment naming the memorable element
  external      INFO  external resources the page loads (fonts, scripts, images)

Exit codes: 0 no FAILs, 1 at least one FAIL, 2 usage / unreadable file.
Static checks only: they cannot see rendered pixels. Look at the page too.
"""
import json
import re
import sys
from html.parser import HTMLParser
from pathlib import Path

GENERIC_FONTS = {"inter", "roboto", "arial", "helvetica", "system-ui", "sans-serif", "-apple-system",
                 "segoe ui", "helvetica neue"}
NAMED = {"white": "#ffffff", "black": "#000000", "transparent": None}
PURPLE_HEX = re.compile(r"#(?:8b5cf6|7c3aed|6d28d9|a855f7|9333ea|6366f1|4f46e5|818cf8|a78bfa|c084fc)\b", re.I)


class Scan(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.css, self.text, self.comments = [], [], []
        self.viewport = self.title = False
        self.interactive = 0
        self.external = []
        self.classes = []
        self._in = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "meta" and (a.get("name") or "").lower() == "viewport":
            self.viewport = True
        if tag in ("style", "script", "title"):
            self._in = tag
        if tag in ("a", "button", "input", "select", "textarea", "summary") or a.get("tabindex"):
            self.interactive += 1
        for key in ("src", "href"):
            v = a.get(key) or ""
            if re.match(r"^(https?:)?//", v) and not (tag == "a" and key == "href"):
                self.external.append(v)
        if a.get("style"):
            self.css.append(a["style"])
        if a.get("class"):
            self.classes += a["class"].split()

    def handle_endtag(self, tag):
        if tag == self._in:
            self._in = None

    def handle_data(self, data):
        if self._in == "style":
            self.css.append(data)
        elif self._in == "title":
            self.title = self.title or bool(data.strip())
        elif self._in != "script":
            self.text.append(data)

    def handle_comment(self, data):
        self.comments.append(data)


def parse_color(value, variables):
    """CSS color -> (r, g, b) or None. Handles #rgb, #rrggbb, rgb(), named basics, var()."""
    v = value.strip().lower()
    for _ in range(5):
        m = re.match(r"var\(\s*(--[\w-]+)\s*(?:,\s*(.+))?\)$", v)
        if not m:
            break
        v = variables.get(m.group(1), (m.group(2) or "")).strip().lower()
    v = NAMED.get(v, v)
    if not v:
        return None
    m = re.match(r"#([0-9a-f]{3}|[0-9a-f]{6})\b", v)
    if m:
        h = m.group(1)
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    m = re.match(r"rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)", v)
    if m:
        return tuple(min(255, int(x)) for x in m.groups())
    return None


def luminance(rgb):
    def ch(c):
        c = c / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(x) for x in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = sorted((luminance(a), luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def rules(css):
    """-> list of (selector, {prop: value}) from flat CSS (media queries flattened)."""
    css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)
    out = []
    for sel, body in re.findall(r"([^{}]+)\{([^{}]*)\}", css):
        decls = {}
        for d in body.split(";"):
            if ":" in d:
                k, v = d.split(":", 1)
                decls[k.strip().lower()] = v.strip()
        out.append((sel.strip(), decls))
    return out


def strip_at_blocks(css):
    """Drop @media/@supports/@container/@layer blocks (balanced braces) so print or dark-mode
    overrides do not masquerade as the base palette when computing contrast."""
    out, i = [], 0
    for m in re.finditer(r"@(media|supports|container|layer|document)\b[^{;]*\{", css):
        if m.start() < i:
            continue
        out.append(css[i:m.start()])
        depth, j = 1, m.end()
        while j < len(css) and depth:
            depth += {"{": 1, "}": -1}.get(css[j], 0)
            j += 1
        i = j
    out.append(css[i:])
    return "".join(out)


def check(html_text, allow_lorem=False):
    s = Scan()
    s.feed(html_text)
    css = "\n".join(s.css)
    rs = rules(strip_at_blocks(re.sub(r"/\*.*?\*/", "", css, flags=re.S)))  # base rules only
    variables = {}
    for sel, d in rs:
        if ":root" in sel or sel in ("html", "body"):
            variables.update({k: v for k, v in d.items() if k.startswith("--")})
    findings = []

    def add(level, check_id, msg):
        findings.append({"level": level, "check": check_id, "message": msg})

    if not s.viewport:
        add("FAIL", "viewport", 'missing <meta name="viewport" content="width=device-width, initial-scale=1">')
    if not s.title:
        add("WARN", "title", "missing or empty <title>")
    if not allow_lorem and re.search(r"lorem ipsum|dolor sit amet", " ".join(s.text), re.I):
        add("FAIL", "lorem", "placeholder lorem ipsum text; write real copy")

    animated = re.search(r"@keyframes|animation\s*:|transition\s*:", css, re.I)
    if animated and not re.search(r"prefers-reduced-motion", css, re.I):
        add("FAIL", "motion", "animations or transitions without an @media (prefers-reduced-motion: reduce) rule")
    if s.interactive and not re.search(r":focus(-visible|-within)?\b", css):
        add("WARN", "focus", f"{s.interactive} interactive element(s) but no :focus/:focus-visible styles")

    fg = bg = None
    for sel, d in rs:
        if re.search(r"(^|[\s,])(body|html|:root)([\s,:{]|$)", sel):
            if "color" in d:
                fg = parse_color(d["color"], variables) or fg
            for key in ("background-color", "background"):
                if key in d:
                    c = parse_color(d[key].split()[0] if key == "background" else d[key], variables)
                    bg = c or bg
    if fg and bg:
        ratio = contrast(fg, bg)
        if ratio < 4.5:
            add("FAIL", "contrast", f"body text contrast {ratio:.2f}:1 is below WCAG AA 4.5:1")
        elif ratio < 7:
            add("INFO", "contrast", f"body text contrast {ratio:.2f}:1 (AA pass, below AAA 7:1)")
        else:
            add("INFO", "contrast", f"body text contrast {ratio:.2f}:1 (AAA)")
    else:
        add("WARN", "contrast", "could not resolve body color and background to compute contrast; check by eye")

    for sel, d in rs:
        fam = d.get("font-family")
        if fam:
            primary = fam.split(",")[0].strip().strip("'\"").lower()
            if primary in GENERIC_FONTS:
                add("WARN", "fonts", f"'{primary}' is the primary font for `{sel[:40]}`; pick a distinctive family")
    if re.search(r"gradient\([^)]*(purple|indigo|violet|" + PURPLE_HEX.pattern[1:] + r")", css, re.I):
        add("WARN", "gradient", "purple/indigo gradient detected; the classic AI-default look, use only if earned")
    shadows = sum(1 for c in s.classes if c in ("shadow-md", "shadow-lg"))
    rounded = sum(1 for c in s.classes if c == "rounded-lg")
    if shadows >= 3 or rounded >= 5:
        add("WARN", "tailwind", f"Tailwind defaults in heavy use (shadow-md/lg x{shadows}, rounded-lg x{rounded})")
    if not any("HERO:" in c for c in s.comments) and "HERO:" not in css:
        add("WARN", "hero", 'no "HERO: <memorable element>" comment; name the one thing people will remember')
    for url in sorted(set(s.external)):
        add("INFO", "external", f"loads {url}")
    return findings


def main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    args = [a for a in argv if not a.startswith("--")]
    if not args or "-h" in argv or "--help" in argv:
        print(__doc__)
        return 0 if ("-h" in argv or "--help" in argv) else 2
    try:
        text = Path(args[0]).read_text(encoding="utf-8-sig", errors="replace")
    except OSError as e:
        sys.stderr.write(f"cannot read {args[0]}: {e}\n")
        return 2
    findings = check(text, allow_lorem="--allow-lorem" in argv)
    fails = [f for f in findings if f["level"] == "FAIL"]
    if "--json" in argv:
        print(json.dumps({"file": args[0], "pass": not fails, "findings": findings}, indent=2))
    else:
        order = {"FAIL": 0, "WARN": 1, "INFO": 2}
        for f in sorted(findings, key=lambda f: order[f["level"]]):
            print(f"[{f['level']}] {f['check']}: {f['message']}")
        print("RESULT:", "PASS" if not fails else f"FAIL ({len(fails)})")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
