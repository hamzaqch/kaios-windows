---
name: webdesign
description: "Design and build distinctive web interfaces directly in code with a real aesthetic doctrine loaded (mirrored from Anthropic's open-source frontend-design skill, MIT): commit to a named register (editorial, brutalist, retro-futuristic, luxury, swiss, playful...), lock a type pair, palette and motion vocabulary, refuse the generic AI-default look, ship production-grade code, then verify it with a deterministic checker plus a real look at the rendered page. Outputs a single-file HTML page, a React/Tailwind, Astro or Vue component, or a diff against an existing app. Use when the user says web design, UI design, design a page, landing page, dashboard design, mockup, prototype, make it look good, polish the UI, redesign this, frontend design, design audit, or asks for a brutalist, editorial, retro, minimal or maximalist UI. NOT FOR logos and illustrations, report-style HTML of an analysis (use /html), or whiteboard diagrams (use /tldraw)."
argument-hint: "<what to design> [register] [output contract]"
license: MIT (see LICENSE.txt and References/FrontendDesignPhilosophy.md)
---
# Webdesign

Kai writes the design itself, directly in code, with the aesthetic doctrine in `References/FrontendDesignPhilosophy.md` loaded first. The doctrine exists because unguided model output converges on the same look (Inter on white, purple gradient hero, three feature cards, `shadow-md` everywhere). Naming a register and constraints before writing code is what breaks that convergence.

**Done looks like:** the files exist at the declared path; the register, type pair, palette and motion are stated in the reply; `tools/verify_design.py` reports no FAIL on single-file HTML output; the rendered page has been looked at (or the user has been told plainly that the visual check is theirs); and one memorable element is named.

## Routing

| Want | Workflow |
|---|---|
| Any design ask: new page, component, prototype, redesign, polish | `Workflows/DirectDesign.md` |

## Working inside an existing app

When the design is a sub-step of larger site work (a dashboard inside an app, a page in an existing site):
- Read the project first: framework, token or theme file, component folder, how styles are written.
- Deliver as edits to the existing code, not an isolated HTML file, and reuse the app's tokens and components.
- A full redesign that replaces existing UI needs an explicit yes from the user before you overwrite anything.

## Tool contract

```
python ~/.copilot/skills/webdesign/tools/verify_design.py <page.html> [--json] [--allow-lorem]
```

Exit 0 means no FAIL findings, 1 means at least one FAIL, 2 means the file could not be read. It checks viewport meta, placeholder text, reduced-motion handling, focus styles, body-text contrast of the declared palette, generic primary fonts, the purple-gradient tell, untouched Tailwind defaults and the HERO comment. It cannot see pixels.

## Gotchas

- **Skipping the doctrine read reverts output to AI defaults.** Read `References/FrontendDesignPhilosophy.md` at the start of every design task, even small ones.
- **An unnamed register drifts into "modern clean".** Print the `AESTHETIC:` line before writing markup.
- **Same register every time is the convergence failure.** Vary registers and light/dark across sessions unless the user's preferences or brand say otherwise.
- **Half-committed maximalism reads as clutter.** Whatever pole you pick, commit to it fully.
- **Web fonts:** a design page may load Google Fonts (unlike the offline `/html` artifacts), but say so and give a local fallback stack in `font-family`. Files opened from disk still load them when online.
- **Viewing the result on Windows:** `Start-Process "<file>.html"` opens it in the default browser. If the session has a browser or screenshot tool, use it and look at the capture before claiming anything about the visuals.
