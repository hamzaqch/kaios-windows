# Meadows' 12 Leverage Points

Donella Meadows, "Leverage Points: Places to Intervene in a System" (1999), expanded in *Thinking in Systems* (2008). Ordered from **least** leverage (12) to **most** (1), the reverse of how people instinctively attack a problem.

People fight hardest over level 12 and ignore levels 1-3. The strongest points are the least visible and the most resisted when threatened.

| # | Leverage point | Software example |
|---|---|---|
| 12 | Constants, parameters, numbers | Timeout 5s → 10s |
| 11 | Buffer sizes | Queue retention, cache size, team slack |
| 10 | Structure of material stocks and flows | Monolith ↔ services, org chart |
| 9 | Lengths of delays relative to rates of change | 5-min vs 1-hour p99 window |
| 8 | Strength of balancing loops | Autoscaler reaction speed |
| 7 | Gain of reinforcing loops | Onboarding speed compounding into mentoring |
| 6 | Structure of information flows | Engineers see their own code's error rate |
| 5 | Rules (incentives, punishments, constraints) | Two-approval merge rule |
| 4 | Power to self-organize | Teams restructure ownership without sign-off |
| 3 | Goals of the system | "Ship rate" → "user-reported quality" |
| 2 | Paradigm the system arises from | Dev and ops are one (DevOps) |
| 1 | Power to transcend paradigms | Holding "cloud is default" loosely |

---

### 12. Constants, parameters, numbers
Subsidies, taxes, standards, capacity limits, retry counts, SLA thresholds, quotas. "They rarely change behavior": they move where equilibrium sits without changing the generating dynamics. Useful only when the parameter is a threshold that triggers a structural effect (a rate limit that changes contention dynamics, a capacity small enough to force queueing). Raising a timeout doesn't change the latency distribution; it moves where failure surfaces.

### 11. Buffers: size of stabilizing stocks
Inventory, cash reserves, queue depth, cache size, team slack. Buffers stabilize but don't change dynamics; too large is expensive and sluggish, too small is fragile. Genuinely structural when the buffer is too small to absorb normal variation, or when placed between pipeline stages to decouple failure modes. Longer topic retention absorbs spikes without fixing producer/consumer imbalance.

### 10. Structure of material stocks and flows
Physical topology: pipelines, networks, service graphs, org charts, age structure. Real effect, but slow and expensive to change. When you do get to choose it (architecture, re-org, migration), choose deliberately; it will generate behavior for years. Rarely the right lever inside an existing system.

### 9. Lengths of delays
Perception, decision, action, and feedback delays. Delays cause oscillation, overshoot, and surprise; shortening a feedback delay fixes behavior no parameter can. Look here for any oscillation: deploy pipelines swinging between "ship everything" and "ship nothing", alerting oscillating between noisy and silent, bullwhip in supply chains, quarterly reviews vs weekly 1:1s.

### 8. Strength of balancing loops
The corrective force relative to the disturbance. Weak balancing loops let the system overshoot or lose control. For runaway dynamics or decay, find the balancing loop and ask why it isn't strong enough. An autoscaler with slow reaction loses to traffic growth: scale faster, predict, lower the trigger. Weakened market price signals (information asymmetry, externalities) are the same failure.

### 7. Gain of reinforcing loops
The speed and strength of self-amplifying loops. Slowing a bad runaway loop (tech-debt accretion, alert fatigue, wealth concentration, viral spread) is usually more powerful than strengthening the corrective loop; strengthening a good one (learning, adoption) compounds. Faster onboarding → faster contribution → faster mentoring of the next hires.

### 6. Structure of information flows
Who can see what. Behavior changes when information reaches the people whose behavior matters, with no rule or incentive change. Meadows' example: moving electric meters from the basement to the front hall cut consumption by about 30%. The Toxics Release Inventory reduced pollution without new regulation. Very common lever: show engineers their own production error rate, publish runbook success rates, status pages.

### 5. Rules of the system
Incentives, punishments, constraints, contracts, norms. "Power over the rules is real power." The lever when behavior is rational given current rules. A two-approval merge rule reshapes the whole review dynamic. Caveat: rules face policy resistance and get gamed unless aligned with underlying incentives.

### 4. Power to add, change, evolve, or self-organize structure
The system's capacity to reshape itself: learning, adaptation, restructuring. Self-organizing systems are resilient because they change their own rules. Teams that can shift ownership, split services, and change rituals without approval adapt faster. Destroying this capacity (removing diversity, concentrating power, locking in structure) is often done "for efficiency" and produces brittleness.

### 3. Goals of the system
What the system actually optimizes for, inferred from where resources flow, what metrics are watched, and what gets rewarded (not what people say). The goal decides how every lower lever is used; change it and everything realigns. The lever when a system optimizes the wrong thing: feature velocity when the need is trust, uptime when the need is experimentation.

### 2. Paradigm
The shared assumptions so fundamental they're invisible: "growth is progress", "hierarchy is accountability", "security is the security team's job", "software teams should ship fast". Paradigms produce the goals, rules, information flows, and structures below them. Slow to move, durable when moved (product → service, dev-writes/ops-runs → DevOps).

### 1. Power to transcend paradigms
Holding every paradigm loosely, as more or less useful rather than true, so you can choose the one that fits. For crises, pivots, fundamental re-imagining; rarely for routine problems. "Cloud is default" is a paradigm: for some workloads on-prem, serverless, or bare metal is right. Startup paradigm in growth mode, stability paradigm at scale.

---

## Selection rules

- **Prefer the highest level feasible** within the time and political budget. Don't spend cycles on parameters when a rule change is available.
- **Effective leverage = Meadows level × feasibility.** A level-2 change you can't execute is worth zero; a level-12 change you can make is worth something.
- **Bundle:** a low-level tactical change buys time; a high-level structural change fixes the generator.
- **Resistance rises with leverage.** Levels 2-3 threaten power and belief. Plan for the fight.
- **Second-order effects rise with leverage.** Level 12 rarely surprises; level 3 reshapes the downstream system; level 2 reshapes everything. Run a CausalLoop pass for any intervention at level 5 or above before committing.
- **"Just change the culture" is not an action.** Level 2 work still needs a concrete first move.
