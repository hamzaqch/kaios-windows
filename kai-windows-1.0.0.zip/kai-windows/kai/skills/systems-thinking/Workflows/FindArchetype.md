# FindArchetype

Match the observed behavior to one of the ten **systems archetypes**, then apply and adapt its canonical intervention. When the pattern is common, which it usually is, this is the fastest high-leverage workflow.

Use when the user names an archetype ("fixes that fail", "shifting the burden", "tragedy of the commons", "limits to growth", "escalation"), when "why does this keep happening" comes with a clear recurring pattern, or after CausalLoop to check whether the drawn loops fit a template.

The full archetype set (loop structure, behavior, recognition signs, examples, canonical interventions) and the recognition table are in `../Archetypes.md`. Read it before matching.

## Method

1. **Describe the behavior** in 2-4 sentences: what is happening, over what period, who is involved, what has been tried.
2. **Shortlist** with the recognition table in `../Archetypes.md`.
3. **Match on mechanism, not surface.** For each candidate, check that its loop structure (which R and B loops, where the delays sit) fits this system. Two archetypes can share symptoms and differ in structure. Draw this system's CLD and confirm it maps onto the archetype's loops, not just its wording.
4. **Check the delays.** Delays are part of most archetypes. If the timing doesn't fit, the archetype probably doesn't either.
5. **Apply and adapt** the canonical intervention: a concrete first move, a success measure, a re-evaluation date. Naming the archetype and stopping is a failure; the point is the fix.
6. **Negative test.** Does the intervention address the underlying loop rather than the symptom, and account for the delays? Is there any record of it helping in similar situations? If not, you've probably misidentified the archetype.
7. **No match:** build a CLD from scratch (`CausalLoop.md`). The behavior may combine two archetypes or be genuinely novel. Don't force a fit.

## Output

```
ARCHETYPE MATCH: [name]

BEHAVIOR:
[2-4 sentences]

WHY THIS ARCHETYPE:
- Structural signature: [loops and delays that match]
- Evidence: [observable pattern]
- Dynamic: [the R and B loops involved, in this system's terms]

CANONICAL INTERVENTION:
[from Archetypes.md]

ADAPTED TO CONTEXT:
- First move: [specific action]
- Measure of success: [how you'll know it works]
- Re-evaluate: [when]

RISK: [which other archetype this could be mistaken for, and what would distinguish them]
```

## Short example

Behavior: "Our test suite took 2 minutes three years ago and takes 20 now. Every time it crosses a threshold, we raise the CI timeout and the 'acceptable runtime' note in the README. Nobody runs tests locally any more."
Match: **Drifting Goals**. One balancing loop closes the gap by improving speed (hard, rarely used), the other by raising the acceptable runtime (easy, always used).
Adapted intervention: anchor the goal externally ("CI under 5 minutes by end of quarter"), chart historical runtime against the goal line, require approval above the team for any further timeout increase, and fund the work to parallelize the slowest suites.
Risk: could be mistaken for Growth and Underinvestment if the slowdown comes purely from test-count growth with no investment; the tell here is the goal being moved, not just capacity lagging.

## Common mistakes

- **Archetypes everywhere.** A forced match is worse than none; fall back to CausalLoop.
- **Label without fix.** Apply the intervention.
- **Ignoring delay structure.**
- **Skipping the CLD check.** Archetypes are CLD templates; verify against a drawn CLD.

Next: `FindLeverage.md` to rank the intervention options.
