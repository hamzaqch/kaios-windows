# ConceptMap

Build a **concept map**: a network of concepts joined by labeled relationships, answering one focus question. Causal loop diagrams model *dynamics*; concept maps model *relationships and meaning*: "what are the things, and how are they connected?" (Joseph Novak, Cornell, 1972, building on Ausubel's theory of meaningful learning.) The key invariant: **every link is a labeled proposition**, never a bare arrow.

Use for early domain exploration, onboarding material, architecture overviews, knowledge capture. Not for behavior over time (use `CausalLoop.md`), incident causation (use `/root-cause-analysis`), or pure hierarchy (use an outline).

## Parts

```
[CONCEPT A] ──"contains"──▶ [CONCEPT B]
    │
    │ "interacts with"
    ▼
[CONCEPT C] ──"depends on"──▶ [CONCEPT D]
```

- **Concepts:** nodes; nouns or noun phrases.
- **Links:** labeled edges naming the relationship.
- **Propositions:** concept + link + concept reads as a statement ("Concept A contains Concept B").
- **Cross-links:** links between different regions of the map. Usually the most valuable output.
- **Hierarchy:** general at the top, specific at the bottom. Helpful, not mandatory.

## Method

**Focus question.** One specific question, or the map becomes a bag of concepts. "How does authentication flow through our platform?" works. "What is authentication?" (too broad) and "Show me the auth architecture" (not a question) don't.

**Concepts.** 10-30 nouns at roughly one abstraction level (don't mix "cloud computing" with "HTTP header"), each concrete enough to have relationships ("good architecture" is too vague). Re-noun verbs: "Deployment", not "deploying".

**Hierarchy.** Arrange general to specific. If no hierarchy emerges, either the concepts really are one level (a flat map is fine) or you're missing organizing concepts. Add them.

**Labeled links.** Each link must read as a valid statement: "User session [uses] JWT token". The label is the whole value. Common labels:

```
contains, has, is a, is part of
uses, depends on, requires
produces, creates, results in
triggers, responds to, listens for
reads from, writes to
authenticates, authorizes, validates
owns, manages, monitors
extends, overrides, implements
precedes, follows, parallels
```

**Cross-links.** Look deliberately for links between distant regions. They reveal dependencies the hierarchy hides (e.g. "database connection pool [feeds back into] request timeout policy": pool exhaustion changes timeout behavior). A map with no cross-links has usually missed the interesting relationships.

**Review.** Answer the focus question aloud by walking the map. Every proposition reads as a grammatical statement; no orphan concepts; 10-30 concepts. Split larger maps into sub-maps by region.

## Output

```
CONCEPT MAP: [topic]

FOCUS QUESTION: [...]

CONCEPTS (general → specific): [C1], [C2], ..., [Cn]

HIERARCHY:
  [C1]
    ├─ [C2]
    │   └─ [C5]
    └─ [C3]
        └─ [C6]

PROPOSITIONS:
- [C1] → [contains] → [C2]
- [C2] → [uses] → [C5]

CROSS-LINKS:
- [C5] → [feeds back into] → [C3]: [what it reveals]

KEY INSIGHTS:
- [insight from each cross-link]
```

To render, use a Mermaid `flowchart TD` with the link label on each edge and cross-links styled dashed.

## Worked example: a customer-support queue

```
FOCUS QUESTION: How does a customer's problem move through our support operation,
and what decides how fast it gets resolved?

CONCEPTS (general → specific):
- Support operation (root)
- Intake channels, Ticket queue, Support team, Knowledge base, Product engineering
- Ticket, Priority level, SLA target, Routing rule, Tier-1 agent, Tier-2 specialist
- Macro (canned reply), Escalation, Bug report, CSAT survey, Help-center article

HIERARCHY:
  Support operation
    ├─ Intake channels ── Ticket
    ├─ Ticket queue ── Priority level, Routing rule, SLA target
    ├─ Support team ── Tier-1 agent, Tier-2 specialist
    ├─ Knowledge base ── Macro, Help-center article
    └─ Product engineering ── Bug report

PROPOSITIONS:
- Intake channels → [create] → Ticket
- Ticket → [is assigned] → Priority level
- Routing rule → [reads] → Priority level
- Routing rule → [sends tickets to] → Tier-1 agent
- Priority level → [sets] → SLA target
- Tier-1 agent → [answers with] → Macro
- Tier-1 agent → [raises] → Escalation
- Escalation → [is handled by] → Tier-2 specialist
- Tier-2 specialist → [files] → Bug report
- Bug report → [is triaged by] → Product engineering
- Resolved ticket → [triggers] → CSAT survey

CROSS-LINKS:
- Help-center article → [deflects] → Ticket   (knowledge base reaches back to intake)
- Bug report → [when fixed, retires] → Macro  (engineering reaches into the knowledge base)
- SLA target → [pressures] → Tier-1 agent → [toward closing with] → Macro
  (queue policy shapes agent behavior)
- CSAT survey → [rarely feeds] → Routing rule  (missing link: satisfaction data never changes routing)

KEY INSIGHTS:
- Resolution speed is set less by the support team than by two outside regions:
  help-center coverage (deflection at intake) and engineering's bug-fix rate
  (which decides how long workaround macros stay in use).
- The SLA cross-link shows a likely quality risk: time pressure pushes Tier-1
  toward macro replies, which can close tickets without solving them, and the
  reopened tickets return to the same queue.
- The missing CSAT → routing link is a structural gap worth turning into a
  CausalLoop question: "what happens to reopen rate if satisfaction data
  adjusts routing?"
```

The technique in the example: start from a focus question that names a flow and a quantity ("how fast"), pick concepts at one level, hang them on a shallow hierarchy, write every edge as a readable proposition, then hunt for edges between distant branches. The insights come almost entirely from the cross-links, including a link that is conspicuously absent.

## Common mistakes

- **Unlabeled arrows.** An unlabeled arrow just says "somehow related."
- **Too many concepts.** Beyond about 30 the map stops being readable; split it.
- **Mixed abstraction levels.** "System" and "semicolon" don't belong on one map.
- **No cross-links.** The hierarchy is scaffolding; cross-links are the insight.
- **Arrows meaning "causes."** That's a CLD; use `CausalLoop.md`.
- **Verbs as concepts.** Re-noun them.

## Which diagram

| Goal | Diagram |
|---|---|
| What things are and how they relate | Concept map |
| How behavior is generated over time | Causal loop diagram |
| Why something happened | `/root-cause-analysis` (Fishbone, Five Whys) |
| Hierarchical decomposition | Tree / outline |
| Sequential steps | Flowchart |
| State transitions | State diagram |

A concept map often feeds the others: its concepts and relationships become CLD variables and arrows, and it helps describe Layer 3 actors in an Iceberg analysis.
