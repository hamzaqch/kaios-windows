# CausalLoop

Build a **causal loop diagram (CLD)**: variables joined by polarity-labeled arrows, organized into reinforcing (R) and balancing (B) loops. A CLD shows what generates behavior and lets you simulate second- and third-order effects before committing to a change (Forrester, Meadows, Senge, Sterman).

Use for: mapping the dynamics behind a recurring behavior (often after Iceberg), previewing the consequences of a planned intervention, explaining counterintuitive dynamics (growth stalls, quality decays, fixes fail), or any problem where several variables interact with delays.

## Notation

```
A ──(+)──▶ B     A up → B up; A down → B down   (same direction)
A ──(−)──▶ B     A up → B down; A down → B up   (opposite direction)
A ══(±)══▶ B     same, with a DELAY (also written ||)

(R) Reinforcing: even number of (−) links, including zero. Amplifies.
(B) Balancing:   odd number of (−) links. Goal-seeking, stabilizes.
```

Polarity test: change A. Does B move the same way (+) or the opposite way (−)?

## Method

**Question.** Every CLD answers one question, or it sprawls. "Why does release velocity plateau past a certain team size?" "What happens if we double the rate limit?" "Why does tech debt accelerate though we pay some down every quarter?"

**Variables.** 5-15 quantities that rise or fall over time. Nouns, not verbs ("Team size", not "Hiring"); directional; observable or inferable. Include soft variables (trust, morale, perceived urgency, satisfaction). Drop them only if they really don't affect the dynamics, never because they're hard to measure. Fewer good variables beat exhaustive lists.

**Arrows.** Direct causation only: no correlation, and route A→C→B through C rather than drawing A→B. Assign polarity by the test. Mark delays where the effect takes much longer than the system's rhythm. Every arrow needs a one-sentence mechanism; if you can't state it, the arrow is wrong.

**Loops.** Trace cycles back to their start. Label R or B by counting (−) links. Name each loop for its dynamic, not its variables ("Success-to-success", "Coordination tax", "Capacity drift"). Unnamed loops go untracked.

**Dynamics.** For each loop: what a reinforcing loop amplifies and toward what limit; what goal a balancing loop seeks and what sets that goal; where the delays are and what they produce (oscillation, overshoot, slow response). Name the dominant loop now and the one that will dominate as variables change. Many behaviors flip from reinforcing-dominant (growth) to balancing-dominant (limits).

**Intervention.** Simulate the change on the diagram before recommending it: directly affected variable → first-order downstream (via which arrows) → second-order (loops now pull differently) → third-order (new equilibrium once delays play out). Every non-trivial intervention triggers at least one balancing loop; if you haven't found it, you haven't looked hard enough. Note side effects on variables you weren't targeting.

## Output

```
CAUSAL LOOP DIAGRAM: [topic]

QUESTION: [what this CLD answers]

VARIABLES: [v1], [v2], [v3], ...

ARROWS (source → target, polarity, delay?):
- [A] →(+) [B]   mechanism: [...]
- [B] →(−) [C] (delay)   mechanism: [...]

LOOPS:
- R1 "[name]": A → B → C → A (reinforcing). Dynamic: [...]
- B1 "[name]": A → D → E → A (balancing). Dynamic: [...]

DOMINANT LOOP: [driving behavior now]
EMERGING DOMINANT LOOP: [will dominate as the system changes]

INTERVENTION ANALYSIS:
- Proposed: [X]
- Intended effect: [Y]
- Pushback: [which loop resists, and how]
- Recommended: [attack the balancing loop directly, or accept the tradeoff]
```

## Worked example: the team growth paradox

```
QUESTION: Why does engineering velocity plateau past team size 12-15?

VARIABLES: Team size, Total output, Revenue, Hiring budget, Pending features,
Coordination cost per engineer, Per-engineer output, Onboarding load

ARROWS:
- Team size →(+) Total output
- Total output →(+) Revenue
- Revenue →(+) Hiring budget
- Hiring budget →(+) Team size  (delay: hiring pipeline)
- Pending features →(+) Hiring budget
- Team size →(+) Coordination cost per engineer
- Coordination cost →(−) Per-engineer output
- Per-engineer output →(+) Total output
- Team size →(+) Onboarding load
- Onboarding load →(−) Per-engineer output  (delay: ramp-up)

LOOPS:
- R1 "Success → hiring → output": Team size → Total output → Revenue → Hiring budget → Team size
- B1 "Coordination tax": Team size → Coordination cost → Per-engineer output → Total output
- B2 "Onboarding drag": Team size → Onboarding load → Per-engineer output → Total output (delayed)

DOMINANT LOOP: R1 early; B1 and B2 once the team passes ~12.

INTERVENTION ANALYSIS:
- Proposed: hire more engineers to ship more.
- Intended: Total output up.
- Pushback: coordination cost grows faster than output; output flattens or falls.
- Recommended: leave R1 alone (slowing hiring just slows everything). Attack B1:
  async docs, modular architecture, team topology that break the
  "team size → coordination cost" link.
```

This is the **Limits to Growth** archetype; see `FindArchetype.md`.

## Conventions

- Lay out horizontally where possible so loops form ovals. Put ↻R or B in each loop's center.
- Mark delays with a double line or `||`.
- Exogenous variables (no incoming arrows) get a distinct shape.
- Move to stock-and-flow notation (`../Foundation.md`) when the CLD can't decide between behaviors.
- To render: Mermaid `flowchart LR`, one node per variable, edge labels `+`, `−`, or `− ||`.

## Common mistakes

- **Too many variables.** Start with 5-7; add only if the loops fail to reproduce observed behavior.
- **Correlation drawn as causation.** Every arrow needs a mechanism.
- **Missing delays.** Oscillation or overshoot means a delay you didn't mark.
- **Only reinforcing loops.** Real systems always have balancing loops; find them.
- **A static snapshot.** The CLD generates behavior over time; it is not a state diagram.
- **Event causation instead of structural.** "The deploy caused the outage" is an event. Show why the deploy process keeps causing outages.

Next: if the diagram matches a template, `FindArchetype.md`; to choose where to push, `FindLeverage.md`.
