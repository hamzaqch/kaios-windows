# FindLeverage

Apply Meadows' **12 leverage points** to find where a small change gives a large, durable effect. Most proposed interventions cluster at the weak end (parameters, buffers): high effort, low return. Leverage rises as you move up the list, and so does resistance.

Run this after a CLD (`CausalLoop.md`) or an archetype match (`FindArchetype.md`), when choosing where to intervene. The full list with examples and selection rules is in `../LeveragePoints.md`. Read it first.

## Method

**State the system and its goal.** What you are changing, its current goal, the behavior you want. The goal is often implicit; infer it from where resources flow, which metrics get watched, what behavior gets rewarded. Make it explicit. Many interventions fail because they fight the system's real goal without realizing it.

**Generate candidates at several levels.** Usually 3-6. If every candidate sits at levels 11-12, generate more at levels 9 and above before ranking.

**Map each candidate to its Meadows level.**

**Rank by effective leverage = level × feasibility.** A level-2 change you can't execute is worth zero; a level-12 change you can push is worth something. Prefer the highest feasible level within the time and political budget. Bundle a low-level tactical change (buys time) with a high-level structural one (fixes the generator).

**Name second-order effects.** Higher leverage means bigger unintended consequences. For the chosen intervention: which variables shift, which loops strengthen or weaken, which archetypes might activate, what policy resistance to expect. For anything at level 5 or above, trace it through a CausalLoop pass before committing, and consider dispatching `@kai-reviewer` to red-team it.

## Output

```
LEVERAGE POINT ANALYSIS: [system]

SYSTEM GOAL (implicit): [...]
DESIRED BEHAVIOR: [...]

CANDIDATES:
- [A]: level [N], feasibility [H/M/L]
- [B]: level [N], feasibility [H/M/L]
- [C]: level [N], feasibility [H/M/L]

HIGHEST FEASIBLE LEVERAGE: [chosen]
- Meadows level: [N]
- Why feasible: [...]
- Why not higher: [why higher-level options aren't feasible now]

BUNDLED TACTICAL INTERVENTION: [if any, to buy time]

EXPECTED EFFECTS:
- First-order: [...]
- Second-order: [...]
- Third-order: [...]

RESISTANCE:
- Policy resistance from: [who, why]
- Paradigm clash: [for level 2-3, which belief is threatened]

MEASURE OF SUCCESS: [...]
RE-EVALUATE: [when]
```

## Worked example

```
SYSTEM: the team's code review process.
GOAL (implicit): maintain PR throughput (metric: merges per week).
DESIRED: same merge rate, higher defect detection.

CANDIDATES:
- [A] Require 2 reviewers instead of 1: level 5 (rule), feasibility M (political cost)
- [B] PR template requires a self-tagged risk level: level 6 (information flow), feasibility H
- [C] Change team goal from merge rate to defects caught per PR: level 3 (goal), feasibility L
- [D] Add a static analyzer for common defects: level 12 (parameter), feasibility H

EFFECTIVE LEVERAGE:
1. [C] level 3 × L = M  (transformative if achievable)
2. [A] level 5 × M = M
3. [B] level 6 × H = M
4. [D] level 12 × H = L  (easy, weak)

HIGHEST FEASIBLE: [B]. Nearly the effective leverage of [A] or [C] at far lower cost.
BUNDLED TACTICAL: [D], catching mechanical defects while [B] takes hold.

EXPECTED:
- First-order: reviewers see "risk: high" and spend longer on those PRs.
- Second-order: tagging calibrates as people learn what "high" means.
- Third-order: "risk" becomes shared team vocabulary.

RESISTANCE: people tag everything "low" to avoid scrutiny. Mitigation: publish the
distribution ("95% of PRs tagged low; is that accurate?").

MEASURE: escaped defects per PR before vs after; risk-tag distribution.
RE-EVALUATE: 8 weeks.
```

## Common mistakes

- **Only level 11-12 candidates.** Always generate at several levels.
- **Treating "hard" as "high leverage."** Infeasible high-level changes are worth zero.
- **Ignoring second-order effects.** They scale with leverage.
- **Skipping the goal analysis.** If you're fighting the implicit goal, no lower-level change will hold.
- **"Just change the culture."** Level 2 still needs a concrete first move.
