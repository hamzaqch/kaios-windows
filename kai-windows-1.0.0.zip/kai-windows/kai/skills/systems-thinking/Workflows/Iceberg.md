# Iceberg

Walk down from visible **events** to the **mental models** that produced them, then back up with an intervention at each layer. Most analysis stops at the top; durable fixes live in the bottom two layers. (Four-layer form: Michael Goodman; popularized in *The Fifth Discipline Fieldbook*.)

Use when the user asks "why does this keep happening", says "iceberg this", or when `/root-cause-analysis` postmortems keep finding the same pattern.

```
  LAYER 1: EVENTS          What happened?               (visible, reactive)
      | "Why did this happen?"
  LAYER 2: PATTERNS        What has happened over time?
      | "What's generating this pattern?"
  LAYER 3: STRUCTURES      What rules, incentives, feedback loops?
      | "What beliefs make this structure feel correct?"
  LAYER 4: MENTAL MODELS   What assumptions generate the structure?
```

## Method

**Layer 1: Event.** One specific sentence with date, time, scope. "14-minute outage of the payments service on 2026-04-12 at 23:51 UTC" beats "reliability issues."

**Layer 2: Pattern.** Has this shape happened before: over what window, under what conditions, frequency rising, flat, or falling, in adjacent systems too? Shapes: recurring (same shape, intermittent), escalating (worse each time), shifting (symptom moved, rhythm the same), triggered/seasonal (tied to a schedule, release, or team event). **No pattern means it's a single incident, not an iceberg**: hand off to `/root-cause-analysis`.

**Layer 3: Structure.** What generates the pattern? Name at least three candidates across: feedback loops, incentives, information/resource/authority flows, delays (the action-to-feedback gap, often the hidden cause), thresholds, ownership boundaries and gaps between them, codified rules, resource allocation. **Test: remove the symptom and leave the structure. Would a new symptom of the same shape appear elsewhere? If yes, that structure is the generator.**

**Layer 4: Mental model.** What belief makes the structure feel natural? These are invisible to their holders; they feel like "how things are." Probe: what would we have to believe for this structure to make sense? What does it treat as scarce vs abundant? Whom does it trust, whose voice does it amplify, what time horizon does it optimize? Common shapes: "we don't have time for X", "quality is QA's job", "moving fast beats moving carefully", "prevention isn't visible; fixing is."

**Intervene, walking back up.**
- Mental-model shift: highest leverage, hardest. What belief must change, who must see it differently, what evidence would shift it?
- Structural fix: changes the generator. Flip a loop's polarity, shorten a delay, re-cut incentives or boundaries.
- Event patch: fastest, lowest. Legitimate only when the structural fix it defers is named and scheduled. Never ship a patch that silently consents to recurrence.

If Layer 3 is a feedback loop worth drawing, continue with `CausalLoop.md`. If Layer 2 matches a known shape, continue with `FindArchetype.md`. When an ISA exists, write the structural findings into it as criteria about the structure, not only the symptom.

## Output

```
ICEBERG ANALYSIS: [topic]

EVENTS (Layer 1):
- [specific event], [related event] ...

PATTERN (Layer 2):
- Time window: [e.g. 3 recurrences in 6 weeks]
- Shape: [recurring / escalating / shifting / triggered]
- Trigger conditions: [what predicts it]

STRUCTURE (Layer 3):
- Primary generator: [loop / incentive / flow / delay / rule]
- Contributing structures: [...]
- Symptom-removal test: [would this structure produce another?]

MENTAL MODEL (Layer 4):
- Belief: [...]
- Held by: [...]
- Evidence that would shift it: [...]

INTERVENTIONS:
- Event patch (explicitly deferred): [...]
- Structural fix: [...]
- Mental-model shift: [...]

RECOMMENDED: [layer to target, given cost/benefit]
```

## Worked example

```
EVENT: p99 latency spike in checkout on 2026-04-11 caused cart abandonment.

PATTERN:
- 4 p99 spikes in checkout in 8 weeks, each fixed by cache warm-up or pod resize
- Frequency flat, not declining; all within 20 min of a deploy

STRUCTURE:
- Loop: deploy → cold cache → spike → ops response → warm-up → resolved. Detected only after users are hurt.
- Incentive: deploy velocity is measured; deploy safety is not (no post-deploy p99 SLO)
- Boundary: infra owns the cache, product owns checkout; nobody owns "deploy behavior of the cache"
- Delay: 6 minutes between cold cache and human response

MENTAL MODEL:
- Belief: "deploys are safe if tests pass", held by engineering leadership because CI is green
- Shift requires: one p99 chart overlaid with deploy markers

INTERVENTIONS:
- Event patch (deferred): manual warm-ups, but not only this
- Structural: post-deploy p99 gate that blocks traffic shift until warm; a named owner for deploy-time cache behavior
- Mental model: share the p99-vs-deploy chart; add "post-deploy stability" to the deploy definition of done

RECOMMENDED: structural (gate + ownership). Patches alone are consent to recurrence.
```

## Common mistakes

- **Stopping at Layer 2.** "It happens on deploys" is a pattern. Push to the loop or incentive.
- **Listing people as a structure.** Individuals are events; the structure is what the organization requires of them.
- **Confusing mental models with opinions.** Individual disagreement is noise. The mental model is what the structure itself assumes, which may differ from what anyone says.
- **A Layer 4 "hero intervention" with no first move.** "Change the culture" needs a concrete action.
- **Skipping the pattern check.** No pattern, no iceberg.
