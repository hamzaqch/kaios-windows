# Systems Thinking: Foundation

Theory behind the workflows. Load when you need depth.

## The Iceberg model, layer by layer

Observable events sit on top of patterns, which are produced by structures, which are anchored in mental models. Event-level interventions are weakest; mental-model interventions are most durable. The layers map onto Meadows' levels: events ≈ parameters (12), patterns expose feedback loops (6-8), structures encode rules and goals (3-5), mental models are paradigms (1-2).

| Layer | What it is | Posture | Diagnostic questions | Common mistake |
|---|---|---|---|---|
| 1. Events | A single observable incident | Reactive: firefight, relieve symptoms | What happened? When? To whom? | Treating events as causes; every event is downstream of structure |
| 2. Patterns | Trends, recurrences, cycles, escalating curves | Adaptive: anticipate, early warning | Have we been here before? What does the time series show? Where is it heading? | Matching the wrong archetype, e.g. reading a delayed balancing loop's oscillation as a reinforcing loop |
| 3. Structures | Feedback loops, information flows, incentives, constraints, decision rules, allocation formulas | Generative: redesign, new feedback | Which loops operate? Who gets what information when? What's rewarded? What delay sits between action and consequence? | Looking only at formal structure (org chart, policy) and missing informal structure (who actually talks to whom, what is actually rewarded) |
| 4. Mental models | Shared, rarely-stated assumptions and values that built the structure | Transformative: surface assumptions, dialogue | What would you have to believe for this structure to make sense? What's too obvious to question? Who benefits from the current model? | Trying to change models by argument alone; they shift when people meet anomalies the old model can't explain, or see a new model working |

## Feedback loops

**Balancing (B):** a closed causal chain with an **odd** number of negative links. Goal-seeking; resists deviation from a target (thermostat, immune response, market clearing). Undisturbed, it approaches equilibrium asymptotically; with a delay it oscillates; with multiple delays it can sustain oscillation or go unstable. Every balancing loop has a goal, explicit or implicit. Behavior is driven by the gap between goal and state; change the goal and you change the behavior.

**Reinforcing (R):** a closed chain with an **even** number of negative links (including zero). Amplifies whatever is happening: compound growth or compound collapse, until a balancing loop or external limit takes over.

## Stock-and-flow notation (Forrester)

CLDs show qualitative structure; stock-and-flow adds quantitative precision.

- **Stock:** an accumulation at a point in time (balance, population, inventory, trust). Drawn as a rectangle. Changes only through flows. Stocks create inertia and memory.
- **Inflow / outflow:** rates filling or draining a stock (hiring, attrition, sales, refunds). Drawn as pipes with valves.
- **Auxiliary variables:** intermediate calculations affecting flows. **Constants:** fixed parameters calibrated from data.

Key rule: **stocks cannot change instantly.** You cannot hire 500 engineers overnight or rebuild customer trust in a week. That is why systems have inertia. Use stock-and-flow when a CLD underdetermines the behavior.

## Unintended-consequence patterns

**Policy resistance.** Any intervention in a system with feedback changes the conditions that motivated it, and actors adjust to offset it (Sterman, *Business Dynamics*). Rent control lowers rents short term and reduces supply long term. The more precisely you target a metric, the more the system reorganizes to hit the metric while undermining the goal; Goodhart's Law is policy resistance at the measurement level.

**Accidental adversaries.** Two well-intentioned parties whose second-order effects on each other form a mutually damaging reinforcing loop. Counter by mapping the full causal structure, including second-order effects, and talking about unintended impacts before defensive responses start.

**Fixes that fail, cognitively.** Sterman (1989) showed that even trained managers systematically underestimate delays when running simulated systems. People are biased toward fixes that fail; explicit loop mapping is the countermeasure.

## Practitioners

- **Donella Meadows:** *Limits to Growth* (1972, co-author), *Thinking in Systems* (2008), "Leverage Points" (1999). Canonical framing of stocks, flows, loops, and leverage.
- **Peter Senge:** *The Fifth Discipline* (1990) and *Fieldbook* (1994). Joined system dynamics with organizational learning; codified the archetypes.
- **Jay Forrester:** *Industrial Dynamics* (1961). Invented system dynamics and stock-and-flow notation at MIT. Core claim: counterintuitive behavior is the predictable output of loop structure.
- **Russell Ackoff:** the "mess", an interconnected system of problems. Problems can be solved; messes must be **dissolved** by redesigning the system that generates them (interactive planning, idealized redesign).
- **Fritjof Capra:** *The Web of Life* (1996). Living systems as networks; relational over reductionist thinking.
- **Joseph Novak:** concept mapping (*Learning How to Learn*, 1984), grounded in Ausubel's theory of meaningful learning.
- **John Sterman:** *Business Dynamics* (2000), the modern system dynamics reference, and the research on why people reason badly about feedback and delay.

## When systems thinking is the wrong tool

- **Complicated, not complex.** "This query is slow" has a knowable cause-effect chain. Decompose and fix the bottleneck; no loops needed.
- **Speed is the only constraint.** During an acute outage, event-level firefighting is correct. Fix first, analyze after.
- **Clear (Cynefin "simple") domain.** Best practice exists and cause-effect is obvious; modeling wastes time.
- **No agreement on boundaries.** A CLD built on contested variable definitions gives false precision and hides the real disagreement. Resolve the definitions first.
- **No capacity to act structurally.** If structural or mental-model changes are politically impossible, naming them only produces frustration. Sometimes a parameter change is the right call given constraints; say so.

## Sources

Meadows, "Leverage Points" (1999) and *Thinking in Systems* (2008). Senge, *The Fifth Discipline* (1990). Braun, "The System Archetypes" (MIT, 2002). Novak & Cañas, "The Theory Underlying Concept Maps" (IHMC, 2008). Forrester, *Industrial Dynamics* (1961). Sterman, *Business Dynamics* (2000). Ackoff, *Re-Creating the Corporation* (1999). Capra, *The Web of Life* (1996).
