# RiskRegister workflow

Operate the persistent risk register (add, list, update, review, close) through the deterministic CLI.

## The tool

The register is a deterministic CLI: no model judgment in the data path. Data dir defaults to `~/.copilot/kai/MEMORY/SECURITY/THREATMODEL/`; override with `THREATMODEL_DATA_DIR`.

```powershell
$T = "$HOME/.copilot/skills/threat-model/Tools/risk_register.py"
python $T init                    # scaffold the data dir + empty register
python $T stats                   # posture snapshot
python $T list                    # open risks, highest score first
python $T review                  # risks overdue or missing a review date
python $T show R-001
python $T export                  # regenerate the RiskRegister.md view
```

Bash: `T="$HOME/.copilot/skills/threat-model/Tools/risk_register.py"` and `python3 "$T" <command>`. Add `--json` to `list`, `show`, `review`, `stats`, `add` and `update` for machine output.

## Intent-to-command mapping

| User says | Command |
|---|---|
| "add a risk", "log this risk" | `add --title … --threat … --likelihood N --impact N [--assets a,b --data-classes x,y --owner O --mitigation M (repeatable) --response REF --review-by DATE --notes N]` |
| "what are our risks", "show the register" | `list` (add `--all` to include closed, `--level Critical` to filter, `--status S`) |
| "run a risk review", "what's overdue" | `review` |
| "update / rescore R-001" | `update R-001 [--likelihood N --impact N --status S --add-mitigation M --owner O --review-by DATE --assets a,b --data-classes x,y]` |
| "accept R-001" | `update R-001 --status accepted --notes "accepted by <owner>: <rationale>"` |
| "close / retire R-001" | `close R-001 --reason "…"` |
| "posture snapshot", "how many criticals" | `stats` |

Statuses: `open` · `mitigating` · `accepted` · `closed`. Dates: `YYYY-MM-DD`.

## Scoring reference

`score = likelihood(1-5) × impact(1-5)` → Low 1-4 · Medium 5-9 · High 10-14 · Critical 15-25. See `CompromiseScenario.md` for the impact and likelihood anchors.

## Constraints (safety gates)

- **The JSON store is the system of record.** `RiskRegister.md` is a generated view; never hand-edit it, the next write overwrites it. Change data only through the CLI.
- **No secret values.** Credential references by env-var name only. The CLI refuses text that looks like a token, key, private key or `password=` assignment (exit 2); rephrase with the variable name.
- **Every risk gets a `review_by`.** A register nobody reviews manufactures false assurance; run `review` on a cadence and re-date what you touch.
- **Accepting a risk is a decision, not a delete.** Use `--status accepted` with a rationale in `--notes`, and keep it visible.

## Review cadence

When running a review: pull `review`, walk each due risk (still valid? mitigated? accept?), update its status and push `review_by` forward. Surface any Critical or High with no owner or no mitigation (`stats` counts both: `unowned_high_or_critical`, `unmitigated_high_or_critical`).

## Close

Report what changed (added, updated, closed IDs), the current Critical and High counts from `stats`, and anything overdue that still needs a decision.
