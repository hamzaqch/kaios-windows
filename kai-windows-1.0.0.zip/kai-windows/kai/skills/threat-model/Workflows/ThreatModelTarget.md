# ThreatModelTarget workflow

Threat model one target (an app, a service, a data flow, or the whole estate) end to end.

## Step 0: Sufficiency check

Need the target and its trust boundary. A broad target ("the whole estate") is valid; the model becomes a portfolio pass over the top data-bearing assets. Ambiguity that changes scope → one flag, then proceed.

## Ideal deliverable

A threat model for the target covering: **what it is and its trust boundaries → what data crosses those boundaries → who would attack it and why → the realistic threats (STRIDE as the checklist: spoofing, tampering, repudiation, information disclosure, denial of service, elevation of privilege) → existing controls → gaps → prioritized risks in the register.** Written to `Models/<target-slug>.md` in the data dir; risks landed with scores.

This workflow composes the other two: use **SensitiveDataMap** to establish what data the target holds, and **CompromiseScenario** for each high-value component. ThreatModelTarget is the wrapper that ties data + scenarios + controls into one prioritized picture.

## Method

- **Draw the boundary:** what's inside the target, what it trusts, what trusts it (from configs, IaC, network rules, auth settings, and what the user tells you).
- **Draw the data flows:** where data enters, where it's stored, where it leaves. A simple text diagram in the doc is enough.
- **Enumerate threats per element and per boundary crossing.** STRIDE per element keeps it honest:

  | Element | S | T | R | I | D | E |
  |---|---|---|---|---|---|---|
  | external entity (users, partners) | ✓ | | ✓ | | | |
  | process (service, worker, function) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
  | data store | | ✓ | ✓ | ✓ | ✓ | |
  | data flow | | ✓ | | ✓ | ✓ | |

- **For each credible threat, decide:** existing control adequate (note the control and its evidence), needs mitigation, or accept. Needs mitigation or accept → a register entry with likelihood × impact.
- **Rank by score.** Critical and High get a named owner and a `review_by`.

## Output format

```markdown
# Threat Model: {target}
> {date} · Coverage: {sources used} · Not visible: {list}

## Scope and trust boundaries
## Data flows
## Attackers and motives
## Threats (STRIDE)
| ID | Element / crossing | STRIDE | Threat | Existing control (evidence) | Disposition | Register |
|---|---|---|---|---|---|---|
## Gaps
## Prioritized risks
| Register ID | Level | Score | Risk | Owner | Review by |
|---|---|---|---|---|---|
## Deep dives
- Scenarios/<asset>.md
```

## Constraints

- Read-only analysis. No exploitation, no scanning, no destructive action.
- No secret values anywhere. Credential references by name only.
- All artifacts to the data dir (`THREATMODEL_DATA_DIR`).
- Don't invent inventory; if coverage is user-enumerated or config-derived, say so.

## Close

Report the target's trust boundaries, the top threats by score, which are covered vs open, and the register IDs created. Point to the scenario docs for the deep dives.
