# SensitiveDataMap workflow

Produce a classified map of which assets hold sensitive data, written to the private data dir.

## Step 0: Sufficiency check

If the scope is unclear (whole estate vs one app vs one provider) and the choice changes the output, add one ambiguity flag and proceed with "whole estate, from what the user names plus the configs I can read." `proceed` accepts.

## Ideal deliverable

`EstateDataMap.md` in the data dir (`~/.copilot/kai/MEMORY/SECURITY/THREATMODEL/` unless `THREATMODEL_DATA_DIR` says otherwise) where **every data-bearing asset is tagged with the data classes it holds and why**, and **every unclassified asset is listed explicitly as unclassified: never omitted, never assumed clean.** The map is the input to impact scoring in scenarios and the register.

Data classes (extend in `PREFERENCES.md`): `credentials` · `pii` · `financial` · `health` · `customer-data` · `source-private` · `internal-only` · `public`.

## Inputs (current-state evidence)

Build the inventory from evidence, per the SKILL.md inventory order:

1. What the user names.
2. Read-only repo and config inspection. Useful starting points:
   ```powershell
   Get-ChildItem -Recurse -File -Include *.tf,*.bicep,*.yaml,*.yml,*.toml,*.json,.env.example -ErrorAction SilentlyContinue |
     Where-Object { $_.FullName -notmatch '\\node_modules\\|\\.git\\' } | Select-Object -ExpandProperty FullName
   ```
   (bash: `find . -type f \( -name '*.tf' -o -name '*.bicep' -o -name '*.y*ml' -o -name '*.toml' -o -name '.env.example' \) -not -path '*/node_modules/*' -not -path '*/.git/*'`)
   Then `view` the hits: data stores (databases, buckets, KV/caches, queues), anything holding credentials (secret references, CI secrets by name, deploy keys), and what each service binds to.
3. Read-only provider list/describe commands the user already has, if they agree.

**Data stores and anything holding credentials are classified FIRST.** They anchor impact scoring.

Without full coverage, state in the output that coverage is user-enumerated / config-derived, not complete, and list what config cannot see (vendor OAuth grants, SSH keys, browser sessions, password managers).

## Output format

```markdown
# Estate Data Map
> Generated {date}. Coverage: {user-enumerated | config-derived from <repos> | provider-listed: <providers>}. Not visible to this method: {list}.

## Data stores
| Asset | Kind | Data classes | Evidence (why) |
|---|---|---|---|

## Credential holders
| Asset | Credentials held (names only) | Reaches |
|---|---|---|

## Other data-bearing assets
| Asset | Kind | Data classes | Evidence |
|---|---|---|---|

## Unclassified (follow up)
| Asset | Kind | Why it couldn't be classified |
|---|---|---|
```

## Constraints

- **No secret values** in the output. Reference credential stores by name or key only.
- **Unclassified is a category, not a gap.** An asset you can't classify from evidence is `unclassified`, surfaced for follow-up.
- Write only to the data dir. Never into the skill folder or the user's repos.
- Read-only everywhere else.

## Close

Report the count per data class, the highest-sensitivity assets, and the unclassified list. Offer to run **CompromiseScenario** on the top data-bearing assets, and to land standing risks in the register.
