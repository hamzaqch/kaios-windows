# CompromiseScenario workflow

Answer "what happens if asset X gets hacked" with real blast-radius evidence, and land the resulting risks in the register.

## Step 0: Sufficiency check

Need one concrete asset (an app, a service, a domain, a worker, a database, an account). If none is given and it can't be inferred, ask which asset. Otherwise proceed.

## Ideal deliverable

A scenario doc `Scenarios/<asset-slug>.md` in the data dir that a responder could act on, containing:

1. **Asset & trust**: what it is, what data it holds (from `EstateDataMap.md` or fresh classification), what it can REACH (credentials, service bindings, deploy keys: one hop of trust minimum).
2. **Blast radius**: what depends on it and what it owns, from config evidence, treated as derived evidence.
3. **Compromise walk**: plausible entry, what the attacker reads, writes and pivots to, worst realistic outcome.
4. **Exposure**: the concrete data classes exposed and roughly how many records or systems.
5. **Detection**: what signal would catch this (logs, alerts, anomaly detection), and whether that signal exists today.
6. **Response**: containment steps, credential rotation references (point at the user's incident-response runbook if `PREFERENCES.md` names one; don't duplicate it), and recovery.
7. **Residual risk**: what stays exposed even after the planned response.

## Blast radius (from evidence)

Work out both directions, read-only:

- **Inbound (what relies on X):** callers, DNS records and routes pointing at it, services that bind to it, CI jobs that deploy through it, users who log in through it. Search configs and IaC for its name, hostname, resource ID and binding names (`view` the hits; in PowerShell, `Select-String -Path <files> -Pattern '<name>'`; in bash, `grep -rn`).
- **Outbound (what X owns or would orphan):** resources it creates or manages, data it is the only copy of, schedules and webhooks it runs.
- **Credentials X would leak:** every secret reference in its config, CI secrets available to its pipelines, tokens in its environment (names only), deploy keys, cloud role or service principal it runs as and that role's permissions.
- **Data stores X can reach:** every database, bucket, KV store, queue or API with data that its bindings or connection settings point at.

The credentials and data-store lists together are step 1's "one hop of trust." Do both before scoring impact: a worker with no data of its own routinely inherits a 5 through its bindings.

**When one asset holds more than one compromise-tier credential class, that concentration is its own finding.** Two credential classes reaching two different trust domains from one asset collapses a boundary. Write it up as a distinct risk instead of folding it into the asset's main scenario score, because the mitigation is different (split the credentials, not rotate them).

**Config evidence is derived, not authoritative.** For a high-stakes scenario, confirm the critical edges in the provider's own console or API before treating the blast radius as complete. Name what config cannot see (vendor-only OAuth grants, SSH keys, browser sessions, password managers) as part of the scenario, not as an omission.

## Impact scoring (feeds the register)

Impact (1-5) is anchored to what the compromise EXPOSES plus what it REACHES, not to the asset's size:

- 5: credentials to many systems, customer data at scale, or financial/health PII
- 4: credentials to one data-bearing system, or a private data store
- 3: internal-only data, or write access to a public surface
- 2: limited internal exposure
- 1: public-only data, no pivot

Likelihood (1-5) from exposure: public URL, auth boundary strength, patch and credential hygiene, existing detection.

## Land the risks

For each real risk the scenario surfaces:

```powershell
python "$HOME/.copilot/skills/threat-model/Tools/risk_register.py" add `
  --title "<short risk>" --threat "<threat>" `
  --assets "<asset>" --data-classes "<classes>" `
  --likelihood <1-5> --impact <1-5> `
  --response "Scenarios/<asset-slug>.md" --review-by <YYYY-MM-DD> `
  --mitigation "<control>"
```

(In bash, replace the backtick line continuations with `\`.)

## Constraints

- **Read-only.** Model the compromise; never execute an exploit, scan or destructive action from a threat-model run. Offensive testing is a separate, explicitly authorized activity.
- No secret values in the doc or the register (the CLI refuses obvious ones; you catch the rest).
- Scenario docs and register entries go to the data dir only.

## Close

Summarize the worst realistic outcome, the top exposed data classes, whether detection exists today, and the risks landed (IDs + scores). Flag any Critical risk for immediate attention.
