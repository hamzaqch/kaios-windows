---
name: threat-model
description: "Defensive threat modeling and risk management for systems you own: map where sensitive data lives, run compromise scenarios (what a hacked asset exposes, its blast radius, how you'd detect and respond), threat model an app or service end to end with STRIDE, and keep a persistent risk register with likelihood x impact scoring, owners, mitigations and review dates through a deterministic CLI. All data stays in private Kai memory; the skill folder holds code only. Read-only analysis. Use when the user says threat model, threat modeling, risk register, risk assessment, what if X got hacked, compromise scenario, blast radius, sensitive data map, where is our sensitive data, data classification, risk review, add a risk, accept a risk, or security risk posture. Not for active pentesting or exploitation, world-scale futures stress-testing of ideas (use the world-threat-model skill), executing incident response, or a quick one-shot STRIDE pattern with no register (use /fabric)."
argument-hint: "<target: app | service | asset | 'the estate'> or 'risk review'"
---

# Threat model

Threat modeling for the systems you actually run. Three moves: classify where sensitive data lives, simulate compromise of the assets that hold it, and keep the resulting risks in a register that gets reviewed instead of forgotten.

## Data/code separation (safety gate)

**This skill folder is code. It never holds data.**

- Every artifact a workflow produces (scenario docs, data maps, register entries) is written to the private data directory, never into this skill folder.
- Default data dir: `~/.copilot/kai/MEMORY/SECURITY/THREATMODEL/`. Override with the `THREATMODEL_DATA_DIR` environment variable.
- `Tools/risk_register.py` structurally refuses any data dir inside a `skills` folder.
- Credentials are referenced by env-var NAME only, never values. The CLI refuses text that looks like a live token, key or password; no secrets anywhere in threat-model output.

```
~/.copilot/kai/MEMORY/SECURITY/THREATMODEL/
  risk-register.json   system of record (CLI only)
  RiskRegister.md      generated view
  EstateDataMap.md     from SensitiveDataMap
  Scenarios/<asset>.md from CompromiseScenario
  Models/<target>.md   from ThreatModelTarget
  PREFERENCES.md       optional: data locations, extra data classes, incident-runbook pointers
```

## Workflow routing

| Workflow | Trigger | File |
|----------|---------|------|
| **SensitiveDataMap** | "where is our sensitive data", "data classification", "which assets hold sensitive data" | `Workflows/SensitiveDataMap.md` |
| **CompromiseScenario** | "what if X got hacked", "compromise scenario", "blast radius of X" | `Workflows/CompromiseScenario.md` |
| **ThreatModelTarget** | "threat model X", "threat model the estate", "risk assessment of X" | `Workflows/ThreatModelTarget.md` |
| **RiskRegister** | "risk register", "add a risk", "risk review", "accept risk", "close risk" | `Workflows/RiskRegister.md` |

If `PREFERENCES.md` exists in the data dir, read it first: it can list where data lives, add data classes, and point at the user's incident-response runbooks.

## The register CLI

```powershell
$T = "$HOME/.copilot/skills/threat-model/Tools/risk_register.py"
python $T init
python $T add --title "<short risk>" --threat "<threat>" --likelihood 3 --impact 4 --assets "a,b" --data-classes "credentials" --owner "<name>" --mitigation "<control>" --review-by 2026-12-31
python $T list            # open risks, highest score first (--all, --status S, --level L, --json)
python $T review          # overdue or missing a review date
python $T stats           # posture snapshot
```

Bash: `T="$HOME/.copilot/skills/threat-model/Tools/risk_register.py"; python3 "$T" list`. Full command reference: `Workflows/RiskRegister.md`.

## Current-state inventory (no asset graph needed)

Kai doesn't ship an asset-graph database. Workflows build the inventory from evidence, in this order, and say which sources they used:

1. **What the user names** (apps, domains, databases, buckets, repos, SaaS accounts).
2. **Repo and config inspection** (read-only): infrastructure-as-code (Terraform, Bicep/ARM, CloudFormation, Pulumi), deploy configs (`wrangler.toml`, `serverless.yml`, `docker-compose.yml`, Kubernetes manifests, CI workflow files), `.env.example` variable NAMES, connection-string keys, service bindings, OAuth app registrations.
3. **Provider CLIs the user already has, read-only** (for example `az resource list`, `aws ... describe/list`, `gcloud ... list`, `gh repo list`, `wrangler ... list`). Run only list/describe commands, and only after saying which ones.

Never invent an inventory. When coverage is user-enumerated rather than complete, the output says so. Name what config can't see: vendor-only OAuth grants, SSH keys, browser sessions, password managers, personal devices.

**"One hop of trust" without a graph:** for each asset, list (a) the credentials it holds (env-var names, secrets-manager keys, deploy keys, tokens in CI) and what each reaches, and (b) the data stores it binds to or connects to. That pair is what the asset can REACH, and it drives impact scoring.

## Risk scoring

`score = likelihood (1-5) × impact (1-5)` → **Low** 1-4 · **Medium** 5-9 · **High** 10-14 · **Critical** 15-25.

Impact is anchored to data classes and blast radius, not vibes: an asset whose compromise exposes credentials or customer data starts at impact 4+. Likelihood is anchored to exposure (public URL, auth boundary, patch state, credential hygiene). Anchors: `Workflows/CompromiseScenario.md`.

## Running on Copilot

- Read configs with `view`; list files and run read-only provider commands with `powershell` (or `bash`). Writes go only to the data dir, plus register changes through the CLI.
- For a large estate, inspect in parallel: one `task` call per repo or provider, each returning assets, credentials-by-name, data stores and bindings; you merge, classify and score.
- Get a second look on high-stakes models: a `task` call to `@kai-reviewer` with the scenario doc, asking what the blast radius misses.

## Gotchas

- **The register markdown is a generated view.** The JSON store is the system of record; change data through the CLI, never by hand-editing `RiskRegister.md`. The next write overwrites it.
- **Unclassified ≠ safe.** An asset with no sensitive-data tag is *unclassified*, never *clean*. Absence of classification is not evidence of absence of data. SensitiveDataMap output lists unclassified assets explicitly.
- **Config-derived blast radius is evidence, not authority.** Before treating a blast radius as complete for a high-stakes decision, confirm the critical edges against the provider's own console or API; config lags reality.
- **Scenario impact includes what the asset can REACH, not just what it stores.** A box with no data but with credentials or bindings to data-bearing systems inherits their impact. Walk the trust hop (credentials + data stores) before scoring.
- **Credential concentration is its own finding.** An asset holding two credential classes that each reach a different trust domain is worse than the two risks added together, because it collapses a boundary that was supposed to exist. Write it up as a separate risk; the fix is to split the credentials, not rotate them.
- **Don't let the register rot.** Every risk gets a `review_by` date at creation; `review` lists overdue ones. A register nobody reviews manufactures false assurance.
- **Read-only.** Model the compromise; never run an exploit, scanner or destructive command from a threat-model run.

## Examples

**Example 1: sensitive data sweep**
```
User: "Which of our assets have sensitive data?"
→ SensitiveDataMap: inventory from the user + repo/IaC configs, classify each data-bearing asset
→ Writes EstateDataMap.md to the data dir
→ Returns the classified map + the explicit unclassified list
```

**Example 2: compromise scenario**
```
User: "What happens if our analytics worker gets popped?"
→ CompromiseScenario: trust hop (credentials + bindings), blast radius, data exposed,
  attacker next steps, detection signals, response plan
→ Scenario doc to the data dir; risks added to the register with scores
```

**Example 3: risk review**
```
User: "Run a risk review"
→ RiskRegister: overdue + open risks by score, walk each (mitigate / accept / close), push review dates
```
