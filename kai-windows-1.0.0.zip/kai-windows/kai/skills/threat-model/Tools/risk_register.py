#!/usr/bin/env python3
"""risk_register.py - deterministic risk register CLI for the threat-model skill.

Code is in the skill folder; data is private and lives in Kai memory:
  default  <KAI_HOME>/MEMORY/SECURITY/THREATMODEL/
  override THREATMODEL_DATA_DIR
KAI_HOME resolves from the KAI_HOME env var, else <COPILOT_HOME>/kai, else
~/.copilot/kai. A data dir inside any 'skills' folder is refused (exit 2).

Store: risk-register.json (system of record). RiskRegister.md is a generated view.
No secret values are ever stored: credential references by env-var NAME only.
Text that looks like a live credential is refused (exit 2).

Commands:
  init                                    scaffold the data dir + empty register
  add --title T --threat T [--assets a,b] [--data-classes x,y]
      --likelihood 1-5 --impact 1-5 [--owner O] [--mitigation M]...
      [--response REF] [--review-by YYYY-MM-DD] [--notes N] [--status S]
  list [--status S] [--level L] [--all] [--json]
  show <id> [--json]
  update <id> [--likelihood N] [--impact N] [--status S] [--owner O] [--assets a,b] [--data-classes x,y]
      [--add-mitigation M]... [--response REF] [--review-by D] [--notes N] [--title T] [--threat T]
  close <id> --reason R
  review [--json]                         risks overdue / missing a review date
  stats [--json]
  export                                  regenerate the RiskRegister.md view

Python 3.8+ standard library only.
"""
import argparse
import datetime as dt
import json
import os
import re
import sys
import tempfile
from pathlib import Path

STATUSES = ("open", "mitigating", "accepted", "closed")
LEVELS = ("Critical", "High", "Medium", "Low")

# High-confidence credential shapes. A match means "this looks like a secret value".
SECRET_PATTERNS = [
    ("GitHub token", re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b")),
    ("AWS access key id", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("API secret key", re.compile(r"\bsk-(?:[A-Za-z0-9_-]{8,}-)?[A-Za-z0-9_-]{20,}\b")),
    ("Slack token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b")),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b")),
    ("private key block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("JSON web token", re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}")),
    ("inline credential assignment",
     re.compile(r"(?i)\b(?:password|passwd|secret|token|api[_-]?key)\s*[=:]\s*['\"]?([^\s'\"]{8,})")),
]

# A value that is a variable REFERENCE (the doctrine: credentials by env-var NAME) is not a secret:
# GITHUB_TOKEN, $GITHUB_TOKEN, ${API_KEY}, %API_KEY%, $env:API_KEY, <redacted>, ***.
ENV_REF_RE = re.compile(r"^(?:\$env:|\$\{?|%)?[A-Z][A-Z0-9_]*(?:\}|%)?[.,;)]*$|^<[^>]*>$|^\*+$")


class CliError(Exception):
    def __init__(self, msg, code=1):
        Exception.__init__(self, msg)
        self.code = code


# ---------------------------------------------------------------- scoring

def level_for(score):
    if score >= 15:
        return "Critical"
    if score >= 10:
        return "High"
    if score >= 5:
        return "Medium"
    return "Low"


def score_risk(likelihood, impact):
    for name, v in (("likelihood", likelihood), ("impact", impact)):
        if not isinstance(v, int) or isinstance(v, bool) or v < 1 or v > 5:
            raise CliError("{} must be an integer 1-5, got {}".format(name, v))
    s = likelihood * impact
    return s, level_for(s)


def to_int(value, name):
    try:
        f = float(value)
    except (TypeError, ValueError):
        raise CliError("{} must be an integer 1-5, got {}".format(name, value))
    if f != int(f):
        raise CliError("{} must be an integer 1-5, got {}".format(name, value))
    return int(f)


def find_secret(text):
    for label, rx in SECRET_PATTERNS:
        for m in rx.finditer(text or ""):
            if m.groups() and m.group(1) and ENV_REF_RE.match(m.group(1)):
                continue  # names a variable, does not contain its value
            return label
    return None


def guard_secrets(fields):
    for name, value in fields.items():
        values = value if isinstance(value, list) else [value]
        for v in values:
            label = find_secret(v)
            if label:
                raise CliError("refused: --{} looks like it contains a secret value ({}). Reference credentials by "
                               "env-var NAME only, never the value.".format(name, label), 2)


# ---------------------------------------------------------------- paths / store

def kai_home():
    env = os.environ.get("KAI_HOME")
    if env:
        return Path(env).expanduser()
    ch = os.environ.get("COPILOT_HOME")
    if ch:
        return Path(ch).expanduser() / "kai"
    return Path.home() / ".copilot" / "kai"


def resolve_data_dir():
    env = os.environ.get("THREATMODEL_DATA_DIR")
    d = Path(env).expanduser() if env else kai_home() / "MEMORY" / "SECURITY" / "THREATMODEL"
    d = d.resolve()
    if any(part.lower() == "skills" for part in d.parts):
        raise CliError("data dir {} is inside a skills/ path - code and data stay separate. Set "
                       "THREATMODEL_DATA_DIR outside the skill tree.".format(d), 2)
    return d


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def today():
    return dt.date.today().isoformat()


def store_path(d):
    return d / "risk-register.json"


def load_store(d):
    p = store_path(d)
    if not p.exists():
        return {"version": 1, "updated": now(), "risks": []}
    try:
        with p.open("r", encoding="utf-8-sig") as fh:
            s = json.load(fh)
    except ValueError as exc:
        raise CliError("{} is not valid JSON ({}); fix or restore it".format(p, exc))
    if not isinstance(s, dict) or s.get("version") != 1:
        raise CliError("unsupported store version {}".format(s.get("version") if isinstance(s, dict) else "?"))
    return s


def save_store(d, store):
    d.mkdir(parents=True, exist_ok=True)
    store["updated"] = now()
    fd, tmp = tempfile.mkstemp(prefix=".risk-register-", suffix=".json", dir=str(d))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(store, fh, indent=2, ensure_ascii=False)
            fh.write("\n")
        os.replace(tmp, str(store_path(d)))
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def next_id(store):
    mx = 0
    for r in store["risks"]:
        m = re.match(r"^R-(\d+)$", r.get("id", ""))
        if m:
            mx = max(mx, int(m.group(1)))
    return "R-{:03d}".format(mx + 1)


def find_risk(store, rid):
    for r in store["risks"]:
        if r["id"].lower() == (rid or "").lower():
            return r
    raise CliError("no risk {}".format(rid))


def split_list(values):
    out = []
    for v in values or []:
        out.extend(s.strip() for s in v.split(","))
    return [s for s in out if s]


def check_date(value, name="review-by"):
    if value:
        try:
            dt.date.fromisoformat(value)
        except ValueError:
            raise CliError("--{} must be YYYY-MM-DD, got {}".format(name, value))
    return value


def check_status(value):
    if value not in STATUSES:
        raise CliError("status must be one of {}".format("|".join(STATUSES)))
    return value


# ---------------------------------------------------------------- rendering

def line(r):
    return "{}  [{:<8}] {:>2}  {:<10} review:{}  {}".format(r["id"], r["level"], r["score"], r["status"],
                                                          r.get("review_by") or "-", r["title"])


def detail(r):
    mit = ("\n" + "\n".join("    - " + m for m in r["mitigations"])) if r["mitigations"] else " -"
    rows = [
        "{}: {}".format(r["id"], r["title"]),
        "  level: {} (score {} = likelihood {} x impact {})   status: {}   owner: {}".format(
            r["level"], r["score"], r["likelihood"], r["impact"], r["status"], r.get("owner") or "-"),
        "  threat: {}".format(r["threat"]),
        "  assets: {}".format(", ".join(r["assets"]) or "-"),
        "  data classes: {}".format(", ".join(r["data_classes"]) or "-"),
        "  mitigations:{}".format(mit),
        "  response: {}".format(r.get("response") or "-"),
        "  review by: {}   created: {}   updated: {}".format(r.get("review_by") or "-", r["created"][:10],
                                                              r["updated"][:10]),
    ]
    if r.get("notes"):
        rows.append("  notes: {}".format(r["notes"]))
    return "\n".join(rows)


def export_markdown(d, store):
    open_ = sorted([r for r in store["risks"] if r["status"] != "closed"], key=lambda r: -r["score"])
    closed = sorted([r for r in store["risks"] if r["status"] == "closed"], key=lambda r: r["updated"], reverse=True)

    def row(r):
        return "| {} | {} | {} | {} | {} | {} | {} | {} | {} |".format(
            r["id"], r["level"], r["score"], r["status"], r["title"].replace("|", "/"), ", ".join(r["assets"]),
            ", ".join(r["data_classes"]), r.get("owner") or "-", r.get("review_by") or "-")
    header = ("| ID | Level | Score | Status | Risk | Assets | Data classes | Owner | Review by |\n"
              "|---|---|---|---|---|---|---|---|---|")
    md = ["# Risk Register", "",
          "> GENERATED by threat-model/Tools/risk_register.py - edit via the CLI, not here. "
          "Source of record: risk-register.json. Updated: {}".format(store["updated"]), "",
          "## Open ({})".format(len(open_)), "", header] + [row(r) for r in open_] + \
         ["", "## Closed ({})".format(len(closed)), "", header] + [row(r) for r in closed] + \
         ["", "## Detail", ""] + ["```\n" + detail(r) + "\n```\n" for r in open_]
    d.mkdir(parents=True, exist_ok=True)
    p = d / "RiskRegister.md"
    p.write_text("\n".join(md), encoding="utf-8")
    return p


def persist(d, store):
    save_store(d, store)
    export_markdown(d, store)


def out(obj, as_json, text):
    print(json.dumps(obj, indent=2, ensure_ascii=False) if as_json else text)


# ---------------------------------------------------------------- commands

def cmd_init(d, a):
    (d / "Scenarios").mkdir(parents=True, exist_ok=True)
    store = load_store(d)
    persist(d, store)
    print("Initialized {} ({} risks)".format(d, len(store["risks"])))


def cmd_add(d, a):
    guard_secrets({"title": a.title, "threat": a.threat, "assets": a.assets or [], "data-classes": a.data_classes or [],
                   "owner": a.owner or "", "mitigation": a.mitigation or [], "response": a.response or "",
                   "notes": a.notes or ""})
    store = load_store(d)
    likelihood, impact = to_int(a.likelihood, "likelihood"), to_int(a.impact, "impact")
    s, lvl = score_risk(likelihood, impact)
    t = now()
    r = {
        "id": next_id(store), "title": a.title, "threat": a.threat,
        "assets": split_list(a.assets), "data_classes": split_list(a.data_classes),
        "likelihood": likelihood, "impact": impact, "score": s, "level": lvl,
        "status": check_status(a.status or "open"), "owner": a.owner or "",
        "mitigations": list(a.mitigation or []), "response": a.response or "", "notes": a.notes or "",
        "created": t, "updated": t, "review_by": check_date(a.review_by or ""),
        "history": [{"ts": t, "event": "created"}],
    }
    store["risks"].append(r)
    persist(d, store)
    out(r, a.json, line(r))


def cmd_list(d, a):
    rs = load_store(d)["risks"]
    if not a.all and not a.status:
        rs = [r for r in rs if r["status"] != "closed"]
    if a.status:
        rs = [r for r in rs if r["status"] == a.status]
    if a.level:
        rs = [r for r in rs if r["level"].lower() == a.level.lower()]
    rs = sorted(rs, key=lambda r: -r["score"])
    out(rs, a.json, "\n".join(line(r) for r in rs) or "(no risks)")


def cmd_show(d, a):
    r = find_risk(load_store(d), a.id)
    out(r, a.json, detail(r))


def cmd_update(d, a):
    guard_secrets({k: v for k, v in (("title", a.title), ("threat", a.threat), ("owner", a.owner),
                                     ("response", a.response), ("notes", a.notes),
                                     ("add-mitigation", a.add_mitigation or []), ("assets", a.assets or []),
                                     ("data-classes", a.data_classes or [])) if v is not None})
    store = load_store(d)
    r = find_risk(store, a.id)
    changes = []
    for key, attr in (("title", "title"), ("threat", "threat"), ("owner", "owner"), ("response", "response"),
                      ("notes", "notes"), ("review_by", "review_by")):
        v = getattr(a, attr)
        if v is not None:
            r[key] = check_date(v) if key == "review_by" else v
            changes.append(key.replace("_", "-"))
    if a.status:
        r["status"] = check_status(a.status)
        changes.append("status=" + a.status)
    if a.likelihood is not None or a.impact is not None:
        lk = to_int(a.likelihood, "likelihood") if a.likelihood is not None else r["likelihood"]
        im = to_int(a.impact, "impact") if a.impact is not None else r["impact"]
        s, lvl = score_risk(lk, im)
        r.update({"likelihood": lk, "impact": im, "score": s, "level": lvl})
        changes.append("rescored={}".format(s))
    for m in a.add_mitigation or []:
        r["mitigations"].append(m)
        changes.append("mitigation+")
    if split_list(a.assets):
        r["assets"] = split_list(a.assets)
        changes.append("assets")
    if split_list(a.data_classes):
        r["data_classes"] = split_list(a.data_classes)
        changes.append("data-classes")
    t = now()
    r["updated"] = t
    r["history"].append({"ts": t, "event": "updated: " + (", ".join(changes) or "no-op")})
    persist(d, store)
    out(r, a.json, line(r))


def cmd_close(d, a):
    if not a.reason:
        raise CliError("--reason is required to close a risk")
    guard_secrets({"reason": a.reason})
    store = load_store(d)
    r = find_risk(store, a.id)
    t = now()
    r["status"] = "closed"
    r["updated"] = t
    r["history"].append({"ts": t, "event": "closed: " + a.reason})
    persist(d, store)
    print(line(r))


def due_for_review(store, ref=None):
    ref = ref or today()
    due = [r for r in store["risks"] if r["status"] != "closed" and (not r.get("review_by") or r["review_by"] <= ref)]
    return sorted(due, key=lambda r: -r["score"])


def cmd_review(d, a):
    due = due_for_review(load_store(d))
    text = "\n".join(line(r) + ("" if r.get("review_by") else "  (no review date)") for r in due)
    out(due, a.json, text or "(nothing due for review)")


def compute_stats(store, d):
    open_ = [r for r in store["risks"] if r["status"] != "closed"]
    return {
        "total": len(store["risks"]), "open": len(open_),
        "byLevel": {lvl: sum(1 for r in open_ if r["level"] == lvl) for lvl in LEVELS},
        "byStatus": {s: sum(1 for r in store["risks"] if r["status"] == s) for s in STATUSES},
        "overdue_review": len(due_for_review(store)),
        "unowned_high_or_critical": sum(1 for r in open_ if r["level"] in ("Critical", "High") and not r.get("owner")),
        "unmitigated_high_or_critical": sum(1 for r in open_ if r["level"] in ("Critical", "High")
                                            and not r["mitigations"]),
        "updated": store["updated"], "data_dir": str(d),
    }


def cmd_stats(d, a):
    st = compute_stats(load_store(d), d)
    out(st, a.json, "\n".join("{}: {}".format(k, json.dumps(v) if isinstance(v, dict) else v) for k, v in st.items()))


def cmd_export(d, a):
    print("Wrote {}".format(export_markdown(d, load_store(d))))


def build_parser():
    ap = argparse.ArgumentParser(description="Deterministic risk register (data in Kai memory).")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("init")
    p = sub.add_parser("add")
    p.add_argument("--title", required=True)
    p.add_argument("--threat", required=True)
    p.add_argument("--assets", action="append")
    p.add_argument("--data-classes", action="append")
    p.add_argument("--likelihood", required=True)
    p.add_argument("--impact", required=True)
    p.add_argument("--owner")
    p.add_argument("--mitigation", action="append")
    p.add_argument("--response")
    p.add_argument("--review-by")
    p.add_argument("--notes")
    p.add_argument("--status")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("list")
    p.add_argument("--status")
    p.add_argument("--level")
    p.add_argument("--all", action="store_true")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("show")
    p.add_argument("id")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("update")
    p.add_argument("id")
    for f in ("likelihood", "impact", "status", "owner", "response", "review-by", "notes", "title", "threat"):
        p.add_argument("--" + f)
    p.add_argument("--add-mitigation", action="append")
    p.add_argument("--assets", action="append")
    p.add_argument("--data-classes", action="append")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("close")
    p.add_argument("id")
    p.add_argument("--reason")
    for name in ("review", "stats"):
        p = sub.add_parser(name)
        p.add_argument("--json", action="store_true")
    sub.add_parser("export")
    return ap


COMMANDS = {"init": cmd_init, "add": cmd_add, "list": cmd_list, "show": cmd_show, "update": cmd_update,
            "close": cmd_close, "review": cmd_review, "stats": cmd_stats, "export": cmd_export}


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    ap = build_parser()
    args = ap.parse_args(argv)
    try:
        d = resolve_data_dir()
        if args.cmd is None:
            ap.print_help()
            print("\ndata dir: {}".format(d))
            return 0
        COMMANDS[args.cmd](d, args)
        return 0
    except CliError as exc:
        print("ERROR: {}".format(exc), file=sys.stderr)
        return exc.code


if __name__ == "__main__":
    sys.exit(main())
