---
name: algorithm
description: Run the Kai Algorithm on substantial work. Write done down as an ISA of falsifiable claims, climb toward it, close claims only on tool evidence, and learn at the close. Use when a task needs building, verifying or articulating, spans several steps or files, touches security or architecture, or when the user says go heavy, think deeply, do it properly, or run the algorithm.
argument-hint: "<the task, in the user's words>"
---
# Kai Algorithm

The doctrine is `~/.copilot/kai/ALGORITHM.md`. **Read it in full before the first step of a run.** It is an outcome contract: 16 claims that must be true when the run is done. How to get there and how much to spend are yours to judge. This skill gives the tool contracts that make those claims cheap to satisfy; it does not script the thinking.

## The ideal state of a run

- The user's goal sits verbatim in an ISA (`principal_stated_goal`) that existed before building, with claims that each name their falsifying probe, at least one Anti-claim, and an Antecedent when the goal is experiential.
- Every claim closed on tool evidence of the right modality (`~/.copilot/kai/RULES/Verification.md`), classes were swept, and every explicit ask was met, skipped with a reason, or surfaced.
- The ISA at the close reflects everything the run discovered, `phase: complete` with a mechanical `progress: N/N`, and the run's trail holds only what stays useful.
- Spend matched the task: easy things fast, hard things earned agents, reviews and time. The user's plain-language steer outranked judgment.

## Tool contracts

| Need | Command |
|---|---|
| Start a task ISA | `/isa` (Scaffold workflow), or `python ~/.copilot/kai/bin/kai.py isa new <slug> "<verbatim goal>"` |
| Start a project ISA | `python ~/.copilot/kai/bin/kai.py isa new <name> "<goal>" --project <repo-root>`, or `/isa` Seed for an existing repo |
| Mechanical completeness gate | `python ~/.copilot/skills/isa/Tools/isa_tool.py check <isa> [--substance substantial] [--experiential]` |
| Mechanical progress value | `python ~/.copilot/skills/isa/Tools/isa_tool.py progress <isa>` |
| What can be worked now / in parallel | `python ~/.copilot/skills/isa/Tools/isa_tool.py frontier <isa>` (`claim` / `release --id <ID> --session <session-id>` when sessions share an ISA) |
| Explicit-ask audit (claim 10) | `python ~/.copilot/skills/isa/Tools/isa_tool.py asklog <isa> --ask "<ask>" --status met\|skipped\|surfaced\|failed` |
| Reflection (at learn) | `python ~/.copilot/skills/isa/Tools/isa_tool.py reflect <isa> --reflection "<what a smarter run would have done>" --session <session-id>` |
| Lesson / knowledge | `python ~/.copilot/kai/bin/kai.py learn "<lesson>"` · `python ~/.copilot/kai/bin/kai.py memory add "<title>" "<body>"` |
| Independent second look | a fresh, non-forked `@kai-reviewer` carrying the ISA path and the verbatim goal (steps and evidence to return, never the expected result) |
| Design pass (security / authority / architecture) | design natively in this session; `@kai-architect` for research legs; `/first-principles`, `/red-team`, `/council` when they would change the answer |

## Gotchas

- **One task, one ISA, scoped to its folder.** Start each task with `python ~/.copilot/kai/bin/kai.py isa new <slug> "<verbatim goal>"` and use the path it prints (it adds `-2`, `-3` when the name is taken). Never open a task ISA by guessing its name. Resume only the ISAs the session context lists as started in this folder. Edit the ISA in its own `apply_patch`, never in the same patch as project files (Kai pre-approves writes to its memory folder, but only when the patch touches nothing else).
- **The phase bracket is minimal.** Write `marking` while articulating, `climbing` on the wall, `complete` at the close (`learn` on reopen). Never walk stations. `progress:` is always `closed/total`, never `true`.
- **Echo hook lines, never compute them.** When a hook injects a `⚙️ SYSTEM` line or a `════ Kai | Algorithm | <icon> <Label> ════` strip, render it verbatim once. No injected strip means no strip.
- **A forked subagent is the builder.** It defends its own code. Second looks run fresh.
- **Fog is not a claim.** Questions you can't yet state precisely go in `## Not yet specified`; that section must be empty at `phase: complete`.
- **Sweep-shaped asks enumerate at plan time.** The search output is the claim list.
- **Trivial work skips the ceremony.** A one-line answer needs no ISA. A small mechanical change may write a minimal Goal + Claims ISA directly.
