---
name: first-principles
description: "Physics-first reasoning: deconstruct a problem into its irreducible parts and real values, classify every stated constraint as a hard constraint (physics/reality), soft constraint (policy/choice), or unvalidated assumption, then reconstruct the optimal solution from the hard constraints alone. Outputs a parts breakdown, a constraint table, and a rebuilt solution. Use when the user says first principles, fundamental truths, challenge assumptions, is this a real constraint, rebuild from scratch, start over, physics first, question everything, why does this cost so much, we have always done it this way, or reasoning by analogy. Also use when a cost, requirement, or architecture is being accepted as fixed without evidence. Not for structural feedback-loop analysis."
---

# First Principles

Most reasoning is reasoning by analogy: "how did we solve something similar, what do others do," then copy it with tweaks. That inherits everyone else's assumptions and treats policy and convention as if they were laws of physics, so you optimize the suitcase instead of inventing wheels. First principles forces the split between what is actually immutable and what is merely inherited, then rebuilds from only the parts that can't change.

## The three steps

| Step | Question | Workflow |
|------|----------|----------|
| **DECONSTRUCT** | What is this actually made of, and what does each part really cost? | `Workflows/Deconstruct.md` |
| **CHALLENGE** | Is each constraint a law of physics, or a choice someone made? | `Workflows/Challenge.md` |
| **RECONSTRUCT** | Knowing only the fundamentals, what would we build? | `Workflows/Reconstruct.md` |

Run all three in order for a full analysis. Run one alone when that's all the request needs: Challenge before accepting requirements, Deconstruct when costs or complexity look fixed, Reconstruct when the hard constraints are already known.

## Constraint classification (the core move)

| Type | Definition | Test | Example | Can change? |
|------|------------|------|---------|-------------|
| **HARD** | Physics, math, reality | Would violating this break a law of nature? | "Data can't travel faster than light" | No |
| **SOFT** | Policy, choice, convention | Could a decision-maker change this? | "We always use REST APIs" | Yes |
| **ASSUMPTION** | Unvalidated belief | Has this been tested? What is the evidence? | "Users won't accept that UX" | Maybe false |

Only hard constraints are truly immutable. Soft constraints and assumptions get challenged.

## Load-bearing rules

- **Market prices and industry best practices are not fundamental truths.** "Batteries cost $600/kWh" or "hosting costs $10K/month" are convention. Deconstruct to material or compute cost before accepting them.
- **Decompose to axioms, not just simpler components.** The value is in the irreducible elements.
- **Challenge inherited assumptions specifically**, especially the hidden ones nobody stated ("of course we need a database").
- **Optimize function over form**: what you're trying to accomplish, not how it's traditionally done.
- **Rebuild, don't patch.** When the assumptions are wrong, start from the hard constraints instead of fixing the inherited form. Cross-domain solutions often apply.
- **This is analysis.** "Analyze" means this skill; "fix" means do the work directly.

## Example

**Problem:** "Cloud hosting costs $10,000/month. That's just what it costs."

- **Deconstruct:** What are we paying for? Compute, storage, bandwidth, managed services.
- **Challenge:** Is managed Kubernetes a hard requirement? Is this region required? The $10K is a market price, not a fundamental cost.
- **Reconstruct:** Actual compute need is $2,000. The other $8,000 is convenience we're choosing to pay for.

## Output format

```markdown
## First Principles Analysis: [Topic]

### Deconstruction
- **Constituent Parts**: [fundamental elements]
- **Actual Values**: [real costs/metrics, not market prices]

### Constraint Classification
| Constraint | Type | Evidence | Challenge |
|------------|------|----------|-----------|
| [X] | Hard/Soft/Assumption | [why] | [what if removed?] |

### Reconstruction
- **Fundamental Truths**: [only the hard constraints]
- **Optimal Solution**: [built from fundamentals]
- **Form vs Function**: [are we optimizing the right thing?]

### Key Insight
[One sentence: what assumption was limiting us?]
```

## Use from other skills

- **red-team** runs Deconstruct to break an argument into parts and Challenge to find "hard" constraints that are actually soft. The most damaging critiques target those.
- Planning and design work (for example via `@kai-architect`) runs Challenge on non-functional requirements and technology choices before accepting them.
- Implementation work stuck in a local maximum runs Deconstruct, then Reconstruct, to escape it.

Framework attribution: the physics-first method popularized by Elon Musk, as documented in public interviews and commentary.
