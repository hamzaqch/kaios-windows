# Reconstruct

Build the optimal solution from scratch using only the fundamental truths and hard constraints found by Deconstruct and Challenge.

**Use when:** after Deconstruct and Challenge; existing solutions are clearly suboptimal; you need to escape a local maximum; you want genuinely different alternatives to the conventional approach. Can run standalone when the hard constraints are already known.

## Core principle

> "If we knew nothing about how this is currently done, and only knew the fundamental truths, what would we build?"

Optimize **function** (what you're trying to accomplish), not **form** (how it's traditionally done).

## What a done reconstruction shows

- **Only the hard constraints stated**: physics, math, verified facts, truly immutable requirements. Soft constraints, assumptions, and "how it's always been done" are excluded.
- **Function defined as outcome, not method**: "persist and retrieve user data reliably," not "we need a database"; "deploy and scale components independently," not "we need microservices."
- **3+ blank-slate approaches**, generated without filtering for feasibility, each checked against: satisfies the hard constraints, achieves the function, simpler than current. The best one maximizes simplicity.
- **Cross-domain synthesis**: an analogous problem solved in an unrelated field, applied here. (The snowmobile: tank treads + boat motor + bicycle seat = a new category.)
- **An explicit delta** vs. the current approach: what's eliminated (complexity that wasn't fundamental), what's new, and what was actually correct all along.

## Output template

```markdown
## Reconstruction: [Subject]

### Hard Constraints Only
1. [Immutable constraint]

### Function to Optimize
[Outcome, not method]

### Blank Slate Solutions
**Option A: [Name]**
- Approach:
- How it satisfies constraints:
- Pros:
- Cons:
(Options B, C, ... same shape)

### Cross-Domain Insights
- From [field]: [applicable concept]

### Recommended Solution
**[Option X]** because [reasoning]

### Comparison to Current Approach
| Aspect | Current | Reconstructed | Delta |
|--------|---------|---------------|-------|
| Complexity | | | |
| Cost | | | |
| Performance | | | |
| Flexibility | | | |

### What We're Eliminating
- [Thing that wasn't fundamental]

### What We're Adding
- [New approach from first principles]

### Implementation Path
1. [First step toward the reconstructed solution]
```

## Worked example: file storage for a web app

**Hard constraints:** durably persist bytes (data survives power loss); retrievable by identifier (needs an addressing scheme); handle N bytes total (known data volume).

**Function:** durably store and retrieve files for a web application.

**Blank-slate options:**
- **A. Object storage:** flat namespace, HTTP API. Scales without limit and needs no servers; costs latency and eventual consistency.
- **B. SQLite + backups:** single-file database with blobs, periodic backup to cloud. Dead simple, ACID, fast reads; single-machine limit.
- **C. Content-addressed storage:** hash-based addressing, dedup, distributed. Integrity verification and cacheable everywhere; more complex, no in-place updates.

**Cross-domain:** from Git, content addressing is excellent for integrity; from CDNs, edge caching solves latency rather than origin storage; from databases, sometimes ACID matters more than scale.

**Recommendation:** B for most web apps. Most applications never exceed one machine; reconstruct toward A or C only when you actually hit limits.

| Aspect | Current (object store + CDN) | Reconstructed (SQLite) | Delta |
|--------|------------------------------|------------------------|-------|
| Complexity | 3 services | 1 file | Much simpler |
| Cost | $500/mo | ~$5/mo backup | ~99% lower |
| Performance | 50ms p50 | 1ms p50 | ~50x faster |
| Flexibility | High | Medium | Slightly less |

**Eliminated:** storage IAM config, CDN cache invalidation, network latency on every file op, about $495/month. **Added:** a backup script, size monitoring, a documented migration path for when scale is real.

## Common reconstruction patterns

**"Do we even need this?"** The rebuilt solution often deletes whole components:
- Message queue → direct function calls at this scale
- Kubernetes → one server handles the load
- SPA framework → server-rendered HTML

**"Different technology, same function":**
- Web app → CLI tool (technical users)
- Mobile app → PWA (no native features needed)
- Custom solution → spreadsheet (if that's sufficient)

**"Combine steps":** removing soft constraints lets separate steps merge:
- Microservices → modular monolith
- ETL pipeline → query on read (if volume permits)
- Async workflow → synchronous (if latency isn't critical)
