# Challenge

Systematically challenge every stated constraint and assumption, classifying each as HARD (physics), SOFT (choice), or ASSUMPTION (unvalidated).

**Use when:** after Deconstruct, to see what's actually fixed; requirements feel overly restrictive; "we can't do X" is stated without evidence; adversarial analysis (red-team); before major architecture or strategy decisions.

## The core question

For every stated constraint:

> "Is this a law of physics, or is it a choice someone made?"

If it's a choice, it can be changed.

## Classify every constraint

Gather everything presented as a constraint: requirements, "we have to..." statements, best practices, budget and timeline limits, policy. Classify each:

| Type | Definition | Test | Examples |
|------|------------|------|----------|
| **HARD** | Physics/math/reality | Would violating this break laws of nature? | Speed of light, thermodynamics, gravity |
| **SOFT** | Policy/choice/convention | Could a decision-maker change this? | "We use this cloud vendor", "REST APIs only", budget limits |
| **ASSUMPTION** | Unvalidated belief | Has this been tested? What's the evidence? | "Users won't accept that", "Too expensive" |

A done Challenge has three properties:

- Every SOFT constraint is traced to **who decided it, why, and whether the original reason still holds**. Every ASSUMPTION is paired with its evidence and **a test that could disprove it**.
- The **"remove it" test** is applied to each non-hard constraint: if removing it unlocks significant value, it's worth challenging.
- **Hidden constraints** are surfaced: the implicit ones so assumed they were never stated ("of course we need a database," "obviously this needs auth"). These are the most dangerous.

## Output template

```markdown
## Constraint Analysis: [Subject]

### All Stated Constraints
1. [Constraint 1]
2. [Constraint 2]

### HARD Constraints (Physics/Reality)
| Constraint | Why It's Hard | Cannot Be Changed Because |
|------------|---------------|---------------------------|

### SOFT Constraints (Policy/Choice)
| Constraint | Who Decided | Original Reason | Still Valid? | If Removed? |
|------------|-------------|-----------------|--------------|-------------|

### ASSUMPTIONS (Unvalidated)
| Assumption | Evidence | Counter-Evidence | Test To Validate |
|------------|----------|------------------|------------------|

### Hidden Constraints Found
- [Implicit assumption that was never stated]

### Constraints Worth Challenging
1. **[Constraint]**: [why challenge it, what becomes possible]

### Recommended Actions
- [ ] Validate assumption: [X] by [method]
- [ ] Challenge soft constraint: [Y] with [stakeholder]
- [ ] Accept hard constraint: [Z] and design around it
```

## Worked example: "enterprise software requirements"

Stated: 10,000 concurrent users; 99.99% uptime; SAP integration; SOC 2 audit; approved vendor list; 24/7 support; IE11 support.

**HARD:** none. Not one of these is physics. All are choices.

**SOFT:**

| Constraint | Who Decided | Original Reason | Still Valid? | If Removed? |
|------------|-------------|-----------------|--------------|-------------|
| 10k concurrent | Capacity planning | Peak load estimate | Maybe: check usage | Right-size infrastructure |
| 99.99% uptime | SLA template | Standard enterprise SLA | Maybe: check need | 99.9% is ~10x cheaper |
| SAP integration | Finance | Existing ERP | Yes, scope negotiable | Simpler integration |
| SOC 2 | Security policy | Customer requirement | Yes, scope matters | Focus on relevant controls |
| Approved vendors | Procurement | Risk management | Questionable | Better/cheaper options |
| 24/7 support | Sales promise | Customer expectation | Check contract | Business hours may suffice |
| IE11 support | Legacy policy | Old corporate standard | No: IE11 is dead | Modern stack, ~30% less effort |

**ASSUMPTIONS:**

| Assumption | Evidence | Counter-Evidence | Test |
|------------|----------|------------------|------|
| "Need 10k concurrent" | Capacity doc | Actual peak: 847 | Check logs |
| "Customers require 99.99%" | Sales said so | No SLA penalties ever paid | Review contracts |
| "Must support IE11" | 2019 policy | IE11 end-of-life, 0.1% traffic | Check analytics |

**Worth challenging:** IE11 (removes ~30% of frontend complexity); 10k concurrent (actual peak 847); 99.99% uptime (99.9% likely enough at a 10x cost difference); approved vendor list (may exclude better options for no real risk reduction).

## Typical targets

- red-team: stated security controls, business-model assumptions.
- Security review: "the firewall protects us," assumed trust boundaries.
- Design and planning: non-functional requirements, technology choices.

## Next

Flow to **Reconstruct** to build using only the hard constraints, or return the constraint analysis to the requester for a decision.
