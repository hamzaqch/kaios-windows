# Deconstruct

Break a problem, system, or cost into its fundamental constituent parts and irreducible truths.

**Use when:** starting any first-principles analysis; a problem seems intractable; costs or complexity seem fixed; an inherited solution feels wrong but you can't say why.

## What a done deconstruction shows

Take the subject apart until you hit elements that can't be decomposed further, then separate what's fundamental from what's inherited.

- Start from the **stated** components (what the market or industry says it's made of) and drill each into its **actual** constituents: material inputs, minimum viable version, raw cost.
- Isolate the **fundamental truths**: laws of physics, mathematical certainties, empirically verified facts, irreducible requirements. Industry best practices, "how it's always been done," market prices, and conventional wisdom are not fundamental truths.
- **Map the gap** between stated cost/complexity and actual fundamental cost. That gap is where the leverage is.

The non-obvious move: **a market price is not a fundamental cost.** "Battery pack = $600/kWh" deconstructs to about $80/kWh of commodity materials. Roughly 87% of the price is assembly and margin, not physics.

## Output template

```markdown
## Deconstruction: [Subject]

### What We're Told
[Common description of the subject]

### Stated Components
1. [Component 1]
2. [Component 2]

### Actual Constituents
**[Component 1]**:
- Actual parts: [list]
- Real cost/value: [amount]
- Insight: [what differs from the stated version]

### Fundamental Truths (Irreducible)
1. [Truth: cannot be decomposed further]
2. [Truth: physics/math/verified fact]
3. [Truth: actual hard requirement]

### Key Gaps
| Stated | Actual | Gap |
|--------|--------|-----|
| [X costs $Y] | [Materials cost $Z] | [$Y-Z is not fundamental] |

### Implications
- [What this means for our approach]
- [What becomes possible now]
```

## Worked example: rocket launch costs

**What we're told:** "Launching a rocket to orbit costs $65 million because aerospace is expensive."

**Actual constituents:**
- **Vehicle:** aluminum alloys, titanium, copper, carbon fiber. Commodity cost is about 2% of a typical rocket price, so 98% of vehicle cost is not materials.
- **Fuel:** liquid oxygen and RP-1 kerosene, about $200,000 per launch. Negligible.
- **Launch operations:** pad, personnel, range safety. Variable, but not fundamentally $60M+; most of it is amortized development.
- **"Aerospace-grade" engineering:** the real requirement is reliability and the physics of orbit, not gold-plating. Much of "aerospace-grade" is convention.

**Fundamental truths:**
1. Must achieve about 9.4 km/s delta-v to reach orbit (physics).
2. Must survive aerodynamic and thermal loads (physics).
3. Must carry the payload mass (requirement).
4. Propellant mass ratio is governed by the rocket equation (physics).

**Gaps:**

| Stated | Actual | Gap |
|--------|--------|-----|
| Vehicle: $50M | Materials: $1M | $49M is not fundamental |
| "Rockets are expensive" | Physics doesn't require $65M | Convention, not constraint |

**Implications:** rockets can be built for dramatically less by starting from materials; each "aerospace-grade" practice should be challenged individually; vertical integration recaptures the margin. This is the reasoning behind SpaceX.

## Next

Flow to **Challenge** to classify each constraint, then **Reconstruct** to build from the fundamentals.
