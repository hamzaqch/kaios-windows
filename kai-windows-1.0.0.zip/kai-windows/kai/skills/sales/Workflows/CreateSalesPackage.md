# Create sales package

**Full pipeline: transform product documentation into a sales narrative + visual + talking points.**

---

## Steps (execute in order)

```
PRODUCT DOCUMENTATION
        ↓
[1] STORY EXPLANATION — extract the narrative arc (StoryExplanation.md)
        ↓
[2] EMOTIONAL REGISTER — match to an emotion from the register table
        ↓
[3] VISUAL CONCEPT — derive a scene from narrative + emotion
        ↓
[4] VISUAL ASSET — image brief (+ render if a generator is available)
        ↓
[5] COMPILE — narrative + visual + talking points + script
```

---

## Step 1: Extract the narrative

Follow `StoryExplanation.md` (in this skill's folder) at **24-point length** for the documentation.

Focus on:
- What's the REAL value proposition?
- Why does this MATTER to the customer?
- What problem does this SOLVE?
- What's the transformation (before → after)?

**Output:** an 8-24 point story explanation capturing the value proposition.

For a large documentation set, read it in parallel: one `task` call per document group, each returning the problem, the transformation, the proof points (with where they appear) and any numbers, then write the story yourself from the merged notes.

---

## Step 2: Identify the emotional register

| Value proposition type | Emotional register | Warm:Cool |
|------------------------|-------------------|-----------|
| **Solves painful problem** | HOPE / POSSIBILITY | 80:20 |
| **Prevents disaster/risk** | URGENCY / WARNING | 60:40 |
| **Enables new capabilities** | WONDER / DISCOVERY | 40:60 |
| **Saves time/effort** | DETERMINATION / EFFORT | 70:30 |
| **Deep expertise/insight** | CONTEMPLATION | 50:50 |
| **Team/collaboration** | CONNECTION | 90:10 |
| **Replaces legacy/old way** | MELANCHOLY (for old) + HOPE (for new) | 60:40 |

**Output:** the selected register with its specific vocabulary.

---

## Step 3: Derive the visual concept

### Key questions

1. **What are the CONCRETE SUBJECTS?**
   - Extract specific nouns from the value proposition
   - Human figure? AI/robot figure? Both?
   - What objects represent the product or outcome?

2. **What's the VISUAL METAPHOR?**
   - What scene captures the transformation?
   - What shows the value in action?
   - What would make someone "get it" instantly?

3. **What's the COMPOSITION?**
   - Minimalist with breathing space
   - Centered subjects floating in empty space
   - Few elements, each intentional

### Scene construction template

```
VALUE PROPOSITION: [one-sentence summary of what matters]
CONCRETE SUBJECTS: [specific nouns that MUST appear visually]
VISUAL METAPHOR: [what scene captures this value?]
EMOTIONAL REGISTER: [from Step 2]
WARM:COOL RATIO: [from the table]
```

**Output:** a specific visual scene that captures the value proposition.

---

## Step 4: Create the visual asset

Run `Workflows/CreateVisual.md` Steps 4-6 with the concept from Step 3: write the charcoal-sketch image brief, render it if an image generator is available, and validate any rendered image by looking at it.

**Output:** `image-brief-<product>.md`, plus a transparent PNG when one was rendered and validated.

---

## Step 5: Compile the package

Write `sales-package-<product>.md` (current working directory unless the user names a place):

```markdown
# Sales Package: [Product/Feature Name]

## Sales Narrative

[8-24 point story explanation from Step 1]

## Visual Asset

[image path, or "Image brief: image-brief-<product>.md (not rendered; no image generator available)"]

## Key Talking Points

1. [First major value point]
2. [Second major value point]
3. [Third major value point]

## Emotional Hook

**Register:** [emotional register used]
**Core Message:** [one sentence that captures the feeling]

## Script Snippet

"[2-3 sentence elevator pitch version of the narrative]"

## Proof to Gather

- [claims that need a number, customer story or demo before external use; omit the section if none]
```

---

## Validation checklist

Before delivering:

- [ ] **Narrative captures VALUE**: why it matters, beyond features
- [ ] **Visual matches the narrative**: someone could connect them
- [ ] **Emotional register consistent** across narrative and visual
- [ ] **Talking points actionable**: the sales team can use them immediately
- [ ] **Script is natural**: sounds like something you'd actually say
- [ ] **No invented facts**: every claim traces to the docs or the user
- [ ] **Files read back**: the package (and brief) exist where you said

---

## Example execution

**Input:** documentation for an AI code review tool

**Step 1 (narrative):**
1. Code review is broken; PRs get rubber-stamped
2. Junior devs miss subtle bugs; seniors don't have time
3. This tool understands your codebase like a ten-year veteran
4. It catches the issues that slip through human review
5. It understands your patterns, beyond simple pattern matching
6. It learns your specific conventions and flags deviations
7. It fits the existing workflow, with no context switching
8. Result: fewer production bugs, faster reviews, happier teams

**Step 2:** WONDER / DISCOVERY (40:60 warm:cool): "it actually understands"

**Step 3:**
- VALUE: AI that understands code like a senior engineer
- SUBJECTS: a human developer and an AI figure, both examining code
- METAPHOR: two figures producing the same insight; you can't tell who caught the bug
- COMPOSITION: minimalist, centered, code/output flowing between them

**Step 4:** image brief for a charcoal sketch of the human and AI examining the same output

**Step 5:** the complete package with narrative, visual, talking points and script

---

**The workflow: story explanation → emotion → visual concept → visual asset → compile**
