# Create sales narrative

**Transform product documentation into a compelling sales narrative.**

---

## Purpose

Takes technical documentation, product specs or feature descriptions and produces a story explanation focused on VALUE: why this matters to the customer, not just what it does.

---

## Process

### Step 1: Gather input

Accept any of:
- Product documentation
- Feature specifications
- Technical descriptions
- Marketing copy (to improve)
- A URL to a product page (web fetch it)

### Step 2: Extract the narrative with the story-explanation method

Follow `StoryExplanation.md` (in this skill's folder) at **24-point length** for the input.

Frame the analysis around:
- What PROBLEM does this solve?
- What's the TRANSFORMATION (before → after)?
- Why should the customer CARE?
- What's the FEELING they get from using it?

### Step 3: Refine for sales

Shape the story explanation into a sales-ready narrative:

1. **Lead with the pain point**: what problem are they facing?
2. **Introduce the transformation**: what changes with this product?
3. **Prove the value**: concrete benefits, not features
4. **Create urgency**: why now? What's the cost of waiting?
5. **End with the outcome**: what does success look like?

Trim to the strongest 8-24 points.

### Step 4: Generate talking points

Extract 3-5 key talking points:
- Each a standalone value statement
- Memorable, quotable
- Tied to a specific customer outcome

### Step 5: Write a script snippet

A 2-3 sentence elevator pitch:
- Natural, conversational
- Something a salesperson would actually say
- Captures the core value in 30 seconds

---

## Output format

```markdown
# Sales Narrative: [Product/Feature Name]

## The Story

[8-24 point narrative, first person, conversational]

## Key Talking Points

1. [First value statement]
2. [Second value statement]
3. [Third value statement]

## Elevator Pitch

"[2-3 sentence script]"

## Pain Point Summary

**Problem:** [one sentence describing the pain]
**Solution:** [one sentence describing the transformation]
**Outcome:** [one sentence describing success]

## Proof to Gather (if any)

- [claims in the narrative that need a number, customer story or demo before external use]
```

---

## Quality checklist

- [ ] **Focuses on VALUE**, not features
- [ ] **Customer-centric**: their problem, their outcome
- [ ] **Conversational**: sounds natural when spoken
- [ ] **Specific**: no generic marketing speak
- [ ] **Actionable**: the sales team can use it immediately
- [ ] **Honest**: every fact traces to the docs; missing proof is listed, never invented

---

**The goal:** a narrative so clear that the sales team knows exactly what to say and why it matters.
