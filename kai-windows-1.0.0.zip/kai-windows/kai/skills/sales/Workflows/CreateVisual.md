# Create sales visual

**Create a charcoal-sketch visual for an existing sales narrative: a complete image brief, rendered if an image generator is available.**

---

## Purpose

Takes a sales narrative or value proposition and creates a matching visual: a charcoal gestural sketch that captures the emotional core of the value proposition.

---

## Process

### Step 1: Gather input

Requires:
- A sales narrative OR a value proposition summary
- Target emotional response (optional; derive it if not provided)

### Step 2: Identify the emotional register

If not provided, derive it from the narrative:

| Value proposition type | Emotional register | Warm:Cool |
|------------------------|-------------------|-----------|
| **Solves painful problem** | HOPE / POSSIBILITY | 80:20 |
| **Prevents disaster/risk** | URGENCY / WARNING | 60:40 |
| **Enables new capabilities** | WONDER / DISCOVERY | 40:60 |
| **Saves time/effort** | DETERMINATION / EFFORT | 70:30 |
| **Deep expertise/insight** | CONTEMPLATION | 50:50 |
| **Team/collaboration** | CONNECTION | 90:10 |
| **Replaces legacy/old way** | MELANCHOLY (for old) + HOPE (for new) | 60:40 |

### Step 3: Derive the visual concept

1. **What are the CONCRETE SUBJECTS?**
   - Human figure? AI/robot figure? Both?
   - What objects represent the product or outcome?
   - What's physically present in the scene?

2. **What's the VISUAL METAPHOR?**
   - What scene captures the transformation?
   - What would make someone "get it" instantly?
   - What's the single image that tells the story?

3. **What's the COMPOSITION?**
   - Minimalist with breathing space
   - Centered subjects floating in empty space
   - Few elements, each intentional

```
VALUE PROPOSITION: [one-sentence summary of what matters]
CONCRETE SUBJECTS: [specific nouns that MUST appear]
VISUAL METAPHOR: [the scene that captures this value]
EMOTIONAL REGISTER: [from Step 2]
WARM:COOL RATIO: [from the table]
```

### Step 4: Write the image brief

Fill in this prompt. Choose an artist reference that fits the register (for example a master of loose architectural or figure sketching).

```
Sophisticated charcoal architectural sketch. [ARTIST REFERENCE] influence.

EMOTIONAL REGISTER: [from Step 2]

SCENE:
[visual concept from Step 3]

MINIMALIST COMPOSITION:
- Subject(s) CENTERED in the frame
- Empty/negative space around — NO filled-in backgrounds
- Clean, gallery-worthy simplicity
- Supporting objects that serve the narrative (gestural, minimal)

CONCRETE SUBJECTS:
[list the specific subjects that MUST appear]

HUMAN FIGURE — GESTURAL ABSTRACTED SKETCH:
- MULTIPLE OVERLAPPING LINES suggesting the form
- Quick, confident, ENERGETIC gestural marks
- Burnt Sienna (#8B4513) WASH accent touches

[If an AI/tech figure:]
ROBOT/TECH FIGURE — GESTURAL ANGULAR SKETCH:
- Angular rigid gestural marks
- Deep Purple (#4A148C) WASH accent touches

LINEWORK:
- Loose charcoal/graphite pencil strokes
- Visible hatching and gestural marks
- NOT clean vectors, NOT smooth

COLOR — CHARCOAL DOMINANT:
- CHARCOAL AND GRAY DOMINANT — 85%
- Sienna accents on human elements
- Purple accents on tech elements
- Background is EMPTY — white/cream negative space
- Transparent background

CRITICAL:
- MINIMALIST composition
- Visual captures the VALUE PROPOSITION
- Gallery-worthy gestural sketch aesthetic

Sign "Kai" small in charcoal bottom right.
NO other text.
```

**Render settings to pass along:** square (1:1), high resolution (about 2K), background removed / transparent PNG.

Save the brief as `image-brief-<product>.md` (concept block from Step 3 + the filled prompt + render settings).

### Step 5: Render (only if a generator is available)

- If the user has an image generator available in this session (a tool, a connected app, or an API they've set up and told you how to call), send it the filled prompt with the render settings and save the PNG next to the brief.
- If none is available, stop at the brief and say so in one line: the user can paste it into any image generator.
- If the generator can't remove backgrounds, note that the transparent background is a post-processing step.

### Step 6: Validate (when an image was rendered)

Open the image and check:
- [ ] Visual matches the narrative emotionally
- [ ] Concrete subjects are visible
- [ ] Minimalist composition with empty space
- [ ] Charcoal sketch aesthetic (no clean vectors)
- [ ] Transparent background
- [ ] Someone could connect the visual to the value proposition

**If validation fails:** adjust the prompt (subjects, metaphor or composition) and regenerate. Report "verified" only after you've looked at the final image.

---

## Output

- `image-brief-<product>.md`, always
- A PNG with a transparent background, charcoal gestural sketch, when a generator was available and the image passed validation
- Ready for sales decks, presentations, collateral

---

**The goal:** a visual that makes the value proposition instantly graspable.
