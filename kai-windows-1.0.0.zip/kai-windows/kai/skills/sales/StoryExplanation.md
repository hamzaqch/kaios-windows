# Story explanation: the narrative engine

The sales workflows start by turning documentation into a **story explanation**: a numbered list of short, first-person, conversational points that tells the story of why the thing matters. The original pipeline called a separate story-explanation skill for this; here is the method itself.

## Shape

- **8-24 numbered points.** Default 24 for a full package, 8-12 when the user wants it tight. Each point is one or two sentences.
- **First person, conversational.** "Here's the thing about code review..." reads like someone who knows the product explaining it over coffee. Never a press release.
- **One arc.** The points run in order and build: each follows from the last. Someone who reads only the points, top to bottom, gets the whole story.

## The arc

Walk the material through these beats. Not every beat needs the same number of points; the pain and the transformation usually deserve the most.

1. **The world before**: the situation the customer lives in today. Concrete, recognizable.
2. **The pain**: what's broken, what it costs, who feels it. Name it specifically ("PRs get rubber-stamped on Friday afternoons"), never generically ("inefficiencies").
3. **Why the usual fixes fail**: what people try, and why it doesn't stick. This is where the reader nods.
4. **The turn**: the one insight or capability that changes the game. The product enters here, not before.
5. **How it works, in plain words**: just enough mechanism to be believable. Features appear only as proof of the turn.
6. **The transformation**: before → after, in the customer's terms. Time saved, risk avoided, a feeling changed.
7. **Proof**: a number, an example, a scenario. Use only what the documentation supports; never invent customers, metrics or quotes.
8. **Why now**: the cost of waiting.
9. **The outcome**: what success looks like a few months in.

## Rules

- **Value over features.** Every feature mentioned has to answer "so what?" in the same point.
- **Specific over generic.** A real detail from the docs beats an adjective. Cut "powerful", "seamless", "robust", "cutting-edge" on sight.
- **Their problem, their outcome.** The customer is the subject of most sentences; the product is the means.
- **Spoken rhythm.** Mix short and long points. Read it aloud; if it sounds like a brochure, rewrite.
- **No invented facts.** If the docs don't give a number, describe the effect without one, and list what proof the sales team should gather.

## Example (8 points, from docs for an AI code review tool)

1. Code review is broken in most teams. PRs get rubber-stamped because everyone's busy.
2. Juniors miss the subtle bugs, and seniors don't have the hours to catch them.
3. Linters help with style, but they don't understand what your code is trying to do.
4. This tool reads your codebase the way a ten-year veteran would.
5. It catches the issues that slip past a tired human reviewer at 5pm.
6. It learns your team's conventions and flags the places you broke them.
7. It sits inside the review you already do, so nobody has to switch tools.
8. The result is fewer production bugs, faster reviews, and seniors who get their afternoons back.
