---
name: sales
description: "Turns product documentation into a sales-ready package: a first-person story explanation of the value proposition (8-24 points), key talking points, an elevator pitch, an emotional register, and a ready-to-run image brief for a charcoal gestural sketch that conveys the concept. Use when the user says sales, proposal, pitch, pitch deck story, value proposition, sales narrative, sales deck, sales package, turn this into a pitch, create a sales story, sales materials, product pitch, transform docs to sales, or sales script. Not for offer-construction frameworks or voice-of-customer mining, standalone diagrams or illustrations, or platform social posts."
argument-hint: "<product docs | url | file> [package|narrative|visual]"
---

# Sales

## What it does

Turns product documentation into a sales-ready package: a story narrative that captures the value proposition, a visual concept for a charcoal gestural sketch that conveys it, and clear talking points. It reads the real value out of technical docs and reframes it as something a sales team can actually use in a pitch.

## The problem

Product docs explain what a thing does. Sales needs to explain why it matters, and the gap between the two is where most pitches die. Hand a sales team a feature list and they read off bullet points; the buyer feels nothing and forgets it. The translation from "here's what it does" to "here's the story you'll remember" usually takes a writer and a designer and a few days, so it doesn't happen, and the product gets sold flat. This skill does that translation: it pulls the narrative arc out of the docs, finds the emotional register, and produces the narrative plus a matching visual brief tied directly to what's being sold.

## How it works

```
PRODUCT DOCUMENTATION
        ↓
[1] STORY EXPLANATION — extract the narrative arc (what's the real value?)
        ↓
[2] EMOTIONAL REGISTER — what feeling should this evoke? (wonder, determination, hope...)
        ↓
[3] VISUAL CONCEPT — derive a scene from narrative + emotion
        ↓
[4] ASSETS — narrative package + image brief (+ image, if the user has a generator)
        ↓
SALES-READY OUTPUT
```

It produces three things: **sales narratives** (story explanations that capture the value proposition), **visual assets** (a charcoal-sketch image brief, rendered if the user has an image tool), and **scripts** (clear, succinct messaging tied to what you're selling). The narrative engine is `StoryExplanation.md` in this folder.

## Workflow routing

| Workflow | Trigger | File |
|----------|---------|------|
| **CreateSalesPackage** | full package: "create a sales package", docs in → narrative + visual + talking points out | `Workflows/CreateSalesPackage.md` |
| **CreateNarrative** | narrative only: "turn this into a pitch", "create a sales story", technical docs → compelling narrative | `Workflows/CreateNarrative.md` |
| **CreateVisual** | visual only: "create a visual for this sales story", a charcoal sketch for an existing narrative | `Workflows/CreateVisual.md` |

## Output format

### Sales narrative
- 8-24 point story explanation
- First person, conversational
- Captures "why this matters", not just "what it does"
- Ready for sales scripts, presentations, pitches

### Visual asset
- Charcoal gestural sketch aesthetic
- Minimalist composition with breathing space
- Transparent background for versatility
- Captures the emotional core of the value proposition

## Running on Copilot

- Docs from a URL: web fetch. From files: `view` each one. From a folder: list it, then read the product overview, feature docs and any customer-facing pages first.
- Save the finished package as a markdown file where the user wants it (default: `sales-package-<product>.md` in the current working directory) and show it in the reply.
- **Image generation is not built in.** Kai ships no image service. The visual step always produces the complete image brief (`image-brief-<product>.md`); if the user has an image generator (a tool, an app, or an API they've configured), hand it that brief and save the result next to the package. Never claim an image exists unless you generated and saw it.

## Example

**Input:** technical documentation for an AI code review tool

**Output:**
- **Narrative:** "Code review is broken in most teams. PRs get rubber-stamped because everyone's busy. This tool reads your codebase the way a ten-year veteran would..."
- **Visual brief:** gestural sketch of a human developer and an AI figure examining the same code output
- **Talking points:**
  1. Reads code like a senior engineer, beyond pattern matching
  2. Catches what tired humans miss in PR review
  3. Learns your team's specific conventions

**The goal:** sales teams get materials that are tightly tied to what they're selling: clear, succinct and effective.

## Gotchas

- **Charcoal sketch is the visual style for sales assets.** Don't switch styles unless the user asks.
- **Pitches tell a STORY, not a feature list.** The narrative arc matters more than bullet points.
- **No invented proof.** Customers, metrics, quotes and logos come from the docs or the user, never from you. Where proof is missing, say what the team should gather.
- **Not for offer-construction or pricing frameworks** (value equations, "irresistible offer" design). This skill tells the story of an existing product.
