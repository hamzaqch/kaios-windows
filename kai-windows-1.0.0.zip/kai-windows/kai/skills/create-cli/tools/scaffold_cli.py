"""scaffold_cli.py - generate a complete, working Python stdlib CLI (Tier 1 or Tier 2). Stdlib only.

  python scaffold_cli.py new <name> --dir <parent dir> [--tier 1|2] [--description "<one line>"]
                         [--commands list,get,create] [--env-var API_TOKEN] [--base-url https://api.example.com]
                         [--force]
  python scaffold_cli.py tiers            explain the tiers

Tier 1: one file (<name>.py) with argparse sub-commands, config loading, an HTTP client
        (when --base-url is given), JSON/text output and exit codes. 2-10 commands.
Tier 2: a package (<module>/cli.py, config.py, client.py, output.py, commands/<cmd>.py) for
        10+ commands, grouped commands, or several contributors.
Both:   a Windows <name>.cmd shim, README.md, QUICKSTART.md, .env.example (with --env-var),
        and a unittest suite that passes as generated.

Generated commands are real: with --base-url each command calls GET <base>/<command> with
--param key=value query pairs; without it each command reads a file or stdin and reports on it.
Kai then replaces those bodies with the actual logic. Exit codes: 0 ok, 1 error, 2 usage.
"""
import keyword
import re
import sys
from pathlib import Path

VERSION = "1.0.0"


class UsageError(Exception):
    pass


def ident(name):
    s = re.sub(r"[^0-9a-zA-Z]+", "_", name).strip("_").lower()
    if not s or s[0].isdigit() or keyword.iskeyword(s):
        s = "cmd_" + s
    return s


# ---------------------------------------------------------------- shared code fragments

CONFIG_CODE = '''
def config_paths():
    """Where a .env file may live, first match wins."""
    here = Path(__file__).resolve().parent
    paths = [here / ".env", Path.cwd() / ".env"]
    appdata = os.environ.get("APPDATA")
    if appdata:
        paths.append(Path(appdata) / "__NAME__" / ".env")
    paths.append(Path.home() / ".config" / "__NAME__" / ".env")
    unique = []
    for p in paths:
        if p not in unique:
            unique.append(p)
    return unique


def read_env_file(path):
    values = {}
    try:
        for line in Path(path).read_text(encoding="utf-8-sig").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)  # split once: values may contain '='
            values[key.strip()] = value.strip().strip('"').strip("'")
    except OSError:
        pass
    return values


def load_config(require_secret=True):
    """Environment first, then the first .env file that defines the variable."""
    cfg = {"base_url": os.environ.get("__ENVPREFIX___BASE_URL", DEFAULTS["base_url"]),
           "timeout": float(os.environ.get("__ENVPREFIX___TIMEOUT", DEFAULTS["timeout"]))}
    secret_name = DEFAULTS["secret_env"]
    if secret_name:
        secret = os.environ.get(secret_name)
        if not secret:
            for p in config_paths():
                secret = read_env_file(p).get(secret_name)
                if secret:
                    break
        if not secret and require_secret:
            raise CliError(f"{secret_name} is not set. Set it in the environment or in one of: "
                           + ", ".join(str(p) for p in config_paths()))
        cfg["secret"] = secret
    return cfg
'''

CLIENT_CODE = '''
def api_get(cfg, path, params=None, retries=3):
    """GET <base_url>/<path> -> parsed JSON. Retries 429/5xx with backoff; raises CliError otherwise."""
    url = cfg["base_url"].rstrip("/") + "/" + path.lstrip("/")
    if params:
        url += "?" + urllib.parse.urlencode(params)
    headers = {"Accept": "application/json", "User-Agent": "__NAME__/" + VERSION}
    if cfg.get("secret"):
        headers["Authorization"] = "Bearer " + cfg["secret"]
    for attempt in range(retries + 1):
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=cfg["timeout"]) as resp:
                body = resp.read().decode("utf-8", "replace")
                return json.loads(body) if body.strip() else {}
        except urllib.error.HTTPError as e:
            if e.code in (429, 500, 502, 503, 504) and attempt < retries:
                time.sleep(min(2 ** attempt, 8))
                continue
            detail = e.read(500).decode("utf-8", "replace") if hasattr(e, "read") else ""
            raise CliError(f"HTTP {e.code} from {url}: {detail.strip()[:200]}")
        except urllib.error.URLError as e:
            if attempt < retries:
                time.sleep(min(2 ** attempt, 8))
                continue
            raise CliError(f"cannot reach {url}: {e.reason}")
        except ValueError:
            raise CliError(f"{url} did not return JSON")
    raise CliError(f"giving up on {url}")
'''

OUTPUT_CODE = '''
def emit(data, fmt="json", quiet=False):
    """JSON to stdout by default (pipes to jq); text is a readable key: value rendering."""
    if quiet:
        return
    if fmt == "text":
        if isinstance(data, dict):
            for k, v in data.items():
                print(f"{k}: {v if not isinstance(v, (dict, list)) else json.dumps(v, ensure_ascii=False)}")
        elif isinstance(data, list):
            for item in data:
                print(json.dumps(item, ensure_ascii=False) if isinstance(item, (dict, list)) else item)
        else:
            print(data)
    else:
        print(json.dumps(data, indent=2, ensure_ascii=False))


def parse_params(pairs):
    out = {}
    for p in pairs or []:
        if "=" not in p:
            raise CliError(f"--param expects key=value (got {p!r})")
        k, v = p.split("=", 1)
        out[k.strip()] = v
    return out
'''


def command_body_api(cmd):
    return f'''    """{cmd}: GET <base_url>/{cmd} with --param query pairs."""
    params = parse_params(args.param)
    if args.dry_run:
        return {{"command": "{cmd}", "dry_run": True, "path": "/{cmd}", "params": params}}
    return api_get(load_config(), "/{cmd}", params)
'''


def command_body_file(cmd):
    return f'''    """{cmd}: read a file (or stdin with '-') and report on it. Replace with the real logic."""
    if args.input == "-":
        text = sys.stdin.buffer.read().decode("utf-8-sig", "replace")  # not the ANSI code page
    else:
        path = Path(args.input)
        if not path.is_file():
            raise CliError(f"input file not found: {{path}}")
        text = path.read_text(encoding="utf-8", errors="replace")
    result = {{"command": "{cmd}", "input": args.input, "lines": len(text.splitlines()),
              "words": len(text.split()), "bytes": len(text.encode("utf-8"))}}
    if args.dry_run:
        result["dry_run"] = True
    return result
'''


def add_args_api():
    return '    p.add_argument("--param", action="append", metavar="KEY=VALUE", help="query parameter (repeatable)")\n'


def add_args_file():
    return '    p.add_argument("input", help="input file path, or - for stdin")\n'


# ---------------------------------------------------------------- tier 1

TIER1 = '''"""__NAME__ - __DESC__

Usage:
  python __FILE__ <command> [options]
  python __FILE__ --help

Output is JSON on stdout (use --format text for humans); errors go to stderr.
Exit codes: 0 success, 1 runtime error, 2 usage error.
"""
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

VERSION = "__VERSION__"
DEFAULTS = {"base_url": "__BASEURL__", "timeout": 30, "secret_env": "__SECRET__"}


class CliError(Exception):
    """An expected failure: printed as one line on stderr, exit code 1."""

__CONFIG__
__CLIENT__
__OUTPUT__

# ---------------------------------------------------------------- commands
__COMMANDS__

# ---------------------------------------------------------------- entry point

def build_parser():
    parser = argparse.ArgumentParser(prog="__NAME__", description="__DESC__")
    parser.add_argument("--version", action="version", version="__NAME__ " + VERSION)
    parser.add_argument("--format", choices=["json", "text"], default="json", help="output format (default json)")
    parser.add_argument("--quiet", action="store_true", help="print nothing on success")
    parser.add_argument("--verbose", action="store_true", help="print diagnostics to stderr")
    parser.add_argument("--dry-run", action="store_true", help="show what would happen without doing it")
    # the same global flags also work after the command ("tool list --format text")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--format", choices=["json", "text"], default=argparse.SUPPRESS, help="output format")
    common.add_argument("--quiet", action="store_true", default=argparse.SUPPRESS, help="print nothing on success")
    common.add_argument("--verbose", action="store_true", default=argparse.SUPPRESS, help="diagnostics to stderr")
    common.add_argument("--dry-run", action="store_true", default=argparse.SUPPRESS, help="do not act, show intent")
    sub = parser.add_subparsers(dest="command", metavar="<command>")
    sub.required = True
__PARSERS__
    return parser


def main(argv=None):
    try:  # JSON is emitted with ensure_ascii=False; legacy Windows consoles default to an ANSI code page
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        result = args.func(args)
        emit(result, args.format, args.quiet)
        return 0
    except CliError as e:
        sys.stderr.write(f"error: {e}\\n")
        return 1
    except KeyboardInterrupt:
        sys.stderr.write("interrupted\\n")
        return 130


if __name__ == "__main__":
    sys.exit(main())
'''


def tier1_commands(cmds, api):
    funcs, parsers = [], []
    for c in cmds:
        fn = f"cmd_{ident(c)}" if not ident(c).startswith("cmd_") else ident(c)
        body = command_body_api(c) if api else command_body_file(c)
        funcs.append(f"\ndef {fn}(args):\n{body}")
        parsers.append(f'    p = sub.add_parser("{c}", help="{c} command", parents=[common])\n'
                       + (add_args_api() if api else add_args_file())
                       + f"    p.set_defaults(func={fn})\n")
    return "\n".join(funcs), "".join(parsers)


# ---------------------------------------------------------------- tier 2

T2_INIT = '"""__NAME__ package."""\n__version__ = "__VERSION__"\n'
T2_MAIN = 'import sys\n\nfrom .cli import main\n\nsys.exit(main())\n'
T2_ERRORS = 'class CliError(Exception):\n    """An expected failure: printed as one line on stderr, exit code 1."""\n'
T2_CONFIG = ('import os\nfrom pathlib import Path\n\nfrom .errors import CliError\n\n'
             'DEFAULTS = {"base_url": "__BASEURL__", "timeout": 30, "secret_env": "__SECRET__"}\n' + CONFIG_CODE)
T2_CLIENT = ('import json\nimport time\nimport urllib.error\nimport urllib.parse\nimport urllib.request\n\n'
             'from . import __version__ as VERSION\nfrom .errors import CliError\n' + CLIENT_CODE)
T2_OUTPUT = 'import json\n\nfrom .errors import CliError\n' + OUTPUT_CODE
T2_CLI = '''"""__NAME__ - __DESC__

Exit codes: 0 success, 1 runtime error, 2 usage error.
"""
import argparse
import sys

from . import __version__
from .commands import COMMANDS
from .errors import CliError
from .output import emit


def build_parser():
    parser = argparse.ArgumentParser(prog="__NAME__", description="__DESC__")
    parser.add_argument("--version", action="version", version="__NAME__ " + __version__)
    parser.add_argument("--format", choices=["json", "text"], default="json", help="output format (default json)")
    parser.add_argument("--quiet", action="store_true", help="print nothing on success")
    parser.add_argument("--verbose", action="store_true", help="print diagnostics to stderr")
    parser.add_argument("--dry-run", action="store_true", help="show what would happen without doing it")
    # the same global flags also work after the command ("tool list --format text")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--format", choices=["json", "text"], default=argparse.SUPPRESS, help="output format")
    common.add_argument("--quiet", action="store_true", default=argparse.SUPPRESS, help="print nothing on success")
    common.add_argument("--verbose", action="store_true", default=argparse.SUPPRESS, help="diagnostics to stderr")
    common.add_argument("--dry-run", action="store_true", default=argparse.SUPPRESS, help="do not act, show intent")
    sub = parser.add_subparsers(dest="command", metavar="<command>")
    sub.required = True
    for name, module in COMMANDS.items():
        p = sub.add_parser(name, help=module.HELP, parents=[common])
        module.add_arguments(p)
        p.set_defaults(func=module.run)
    return parser


def main(argv=None):
    try:  # JSON is emitted with ensure_ascii=False; legacy Windows consoles default to an ANSI code page
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass
    args = build_parser().parse_args(argv)
    try:
        emit(args.func(args), args.format, args.quiet)
        return 0
    except CliError as e:
        sys.stderr.write(f"error: {e}\\n")
        return 1
    except KeyboardInterrupt:
        sys.stderr.write("interrupted\\n")
        return 130
'''


def t2_command_module(cmd, api):
    imports = ("from ..client import api_get\nfrom ..config import load_config\nfrom ..output import parse_params\n"
               if api else "import sys\nfrom pathlib import Path\n\nfrom ..errors import CliError\n")
    add = add_args_api() if api else add_args_file()
    body = command_body_api(cmd) if api else command_body_file(cmd)
    return (f'"""The `{cmd}` command."""\n{imports}\nHELP = "{cmd} command"\n\n\n'
            f"def add_arguments(p):\n{add}\n\ndef run(args):\n{body}")


# ---------------------------------------------------------------- docs + tests

README = '''# __NAME__

__DESC__

A Python 3.8+ command-line tool with no third-party dependencies. Output is JSON on stdout so it composes
with other tools; errors go to stderr; exit codes are meaningful.

## Install

Nothing to install beyond Python. Put this folder on your PATH (Windows uses `__NAME__.cmd`), or run
`python __RUN__ --help`.

## Commands

| Command | What it does |
|---|---|
__CMDTABLE__

Global flags (before or after the command): `--format json|text`, `--quiet`, `--verbose`, `--dry-run`; plus `--version`.

## Configuration

__CONFIGDOC__

## Exit codes

| Code | Meaning |
|---|---|
| 0 | success |
| 1 | runtime error (message on stderr) |
| 2 | usage error (bad flags or arguments) |

## Design

- Deterministic: the same input gives the same output.
- Single responsibility: __DESC_LOWER__
- Composable: JSON output pipes into `ConvertFrom-Json`, `jq`, or another script.
- Tested: `python -m unittest discover -s tests`.
'''

QUICKSTART = '''# __NAME__ quickstart

```powershell
python __RUN__ --help
__EXAMPLES__
```

Parse the JSON in PowerShell:

```powershell
python __RUN__ __FIRST__ __FIRSTARG__ | ConvertFrom-Json
```

Run the tests:

```powershell
python -m unittest discover -s tests
```
'''

TEST = '''import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout, redirect_stderr
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
__IMPORT__


def run(argv):
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        try:
            code = main(argv)
        except SystemExit as e:
            code = e.code
    return code, out.getvalue(), err.getvalue()


class CliTests(unittest.TestCase):
    def test_help_and_version(self):
        self.assertEqual(run(["--help"])[0], 0)
        code, out, _ = run(["--version"])
        self.assertEqual(code, 0)
        self.assertIn("__VERSION__", out)

    def test_usage_error_exit_code(self):
        self.assertEqual(run([])[0], 2)
        self.assertEqual(run(["no-such-command"])[0], 2)

    def test_every_command_dry_run(self):
__DRYRUN__

    def test_module_entry_point(self):
        r = subprocess.run([sys.executable] + __ENTRY__ + ["--version"], cwd=str(ROOT),
                           capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 0, r.stderr)


if __name__ == "__main__":
    unittest.main()
'''


def dryrun_tests(cmds, api):
    lines = []
    if api:
        for c in cmds:
            lines += [f'        code, out, err = run(["--dry-run", "{c}", "--param", "q=1"])',
                      "        self.assertEqual(code, 0, err)",
                      f'        self.assertEqual(json.loads(out)["path"], "/{c}")']
        lines += [f'        code, out, err = run(["{cmds[0]}", "--dry-run", "--format", "json"])',
                  "        self.assertEqual(code, 0, err)",
                  "        self.assertTrue(json.loads(out)[\"dry_run\"])"]
    else:
        lines += ["        with tempfile.TemporaryDirectory() as d:",
                  '            f = Path(d, "in.txt")',
                  '            f.write_text("one two\\nthree\\n", encoding="utf-8")']
        for c in cmds:
            lines += [f'            code, out, err = run(["{c}", str(f)])',
                      "            self.assertEqual(code, 0, err)",
                      '            self.assertEqual(json.loads(out)["words"], 3)']
        lines += [f'            self.assertEqual(run(["{cmds[0]}", str(Path(d, "missing.txt"))])[0], 1)']
    return "\n".join(lines)


# ---------------------------------------------------------------- generator

def generate(name, parent, tier=1, desc=None, cmds=None, env_var=None, base_url=None, force=False):
    if not re.match(r"^[a-z][a-z0-9-]{1,40}$", name):
        raise UsageError("name must be lowercase kebab-case, 2-41 chars, starting with a letter (e.g. ghcli, md-tools)")
    cmds = cmds or (["list", "get"] if base_url else ["stats"])
    for c in cmds:
        if not re.match(r"^[a-z][a-z0-9-]*$", c):
            raise UsageError(f"command names must be lowercase kebab-case (got {c!r})")
    if len(set(cmds)) != len(cmds):
        raise UsageError("duplicate command names")
    if env_var and not re.match(r"^[A-Z][A-Z0-9_]*$", env_var):
        raise UsageError("--env-var must be UPPER_SNAKE_CASE")
    if base_url and not re.match(r"^https?://", base_url):
        raise UsageError("--base-url must start with http:// or https://")
    desc = (desc or f"Command-line tool for {name}").replace('"', "'").replace("\\", "/").strip()
    root = Path(parent) / name
    if root.exists() and any(root.iterdir()) and not force:
        raise UsageError(f"{root} exists and is not empty (pass --force to overwrite generated files)")
    api = bool(base_url)
    mod = ident(name)
    prefix = mod.upper()
    subs = {"__NAME__": name, "__DESC__": desc, "__VERSION__": VERSION, "__BASEURL__": base_url or "",
            "__SECRET__": env_var or "", "__ENVPREFIX__": prefix}

    def fill(t):
        for k, v in subs.items():
            t = t.replace(k, v)
        return t

    files = {}
    if tier == 1:
        funcs, parsers = tier1_commands(cmds, api)
        code = TIER1.replace("__CONFIG__", CONFIG_CODE).replace("__CLIENT__", CLIENT_CODE if api else "") \
            .replace("__OUTPUT__", OUTPUT_CODE).replace("__COMMANDS__", funcs).replace("__PARSERS__", parsers.rstrip("\n"))
        files[f"{mod}.py"] = fill(code.replace("__FILE__", f"{mod}.py"))
        run_target, entry, imp = f"{mod}.py", f'["{mod}.py"]', f"from {mod} import main  # noqa: E402"
        shim_target = f'"%~dp0{mod}.py"'
    elif tier == 2:
        files[f"{mod}/__init__.py"] = fill(T2_INIT)
        files[f"{mod}/__main__.py"] = T2_MAIN
        files[f"{mod}/errors.py"] = T2_ERRORS
        files[f"{mod}/config.py"] = fill(T2_CONFIG)
        if api:
            files[f"{mod}/client.py"] = fill(T2_CLIENT)
        files[f"{mod}/output.py"] = T2_OUTPUT
        files[f"{mod}/cli.py"] = fill(T2_CLI)
        reg = ["from . import " + ", ".join(ident(c) for c in cmds), "",
               "COMMANDS = {" + ", ".join(f'"{c}": {ident(c)}' for c in cmds) + "}"]
        files[f"{mod}/commands/__init__.py"] = '"""Command registry: add a module here to add a command."""\n' + "\n".join(reg) + "\n"
        for c in cmds:
            files[f"{mod}/commands/{ident(c)}.py"] = fill(t2_command_module(c, api))
        run_target, entry, imp = f"-m {mod}", f'["-m", "{mod}"]', f"from {mod}.cli import main  # noqa: E402"
        shim_target = f"-m {mod}"
    else:
        raise UsageError("--tier must be 1 or 2")

    if tier == 2:
        files[f"{name}.cmd"] = f'@echo off\r\npushd "%~dp0" >nul\r\npython -m {mod} %*\r\nset rc=%ERRORLEVEL%\r\npopd >nul\r\nexit /b %rc%\r\n'
    else:
        files[f"{name}.cmd"] = f"@echo off\r\npython {shim_target} %*\r\n"
    first_arg = "--param q=1" if api else "notes.txt"
    files["README.md"] = fill(README).replace("__RUN__", run_target).replace(
        "__CMDTABLE__", "\n".join(f"| `{c}` | " + (f"GET `/{c}` on the API" if api else "reads a file or stdin and reports on it")
                                  + " |" for c in cmds)).replace(
        "__CONFIGDOC__", (f"Set `{env_var}` in the environment, or put `{env_var}=...` in a `.env` file next to the tool, "
                          f"in the working directory, in `%APPDATA%\\{name}\\.env`, or in `~/.config/{name}/.env`. "
                          if env_var else "No secrets needed. ") + (f"Override the API base URL with `{prefix}_BASE_URL` "
                          f"(default `{base_url}`) and the timeout with `{prefix}_TIMEOUT`." if api else "")).replace(
        "__DESC_LOWER__", desc[0].lower() + desc[1:])
    files["QUICKSTART.md"] = fill(QUICKSTART).replace("__RUN__", run_target).replace(
        "__EXAMPLES__", "\n".join(f"python {run_target} {c} {first_arg}" for c in cmds)).replace(
        "__FIRST__", cmds[0]).replace("__FIRSTARG__", first_arg)
    if env_var:
        files[".env.example"] = f"# Copy to .env and fill in. Never commit the real .env.\n{env_var}=\n"
        files[".gitignore"] = ".env\n__pycache__/\n"
    files[f"tests/test_{mod}.py"] = fill(TEST).replace("__IMPORT__", imp).replace(
        "__DRYRUN__", dryrun_tests(cmds, api)).replace("__ENTRY__", entry)

    written = []
    for rel, content in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8", newline="") as fh:  # keep CRLF in .cmd files as written
            fh.write(content)
        written.append(str(p))
    return root, written


def opt(args, name, default=None):
    if name in args:
        i = args.index(name)
        if i + 1 >= len(args):
            raise UsageError(f"{name} needs a value")
        return args[i + 1]
    return default


def main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 0
    if argv[0] == "tiers":
        middle = __doc__.split("Tier 1:", 1)[1].split("Generated commands", 1)[0]
        print("Tier 1:" + middle.rstrip())
        return 0
    if argv[0] != "new" or len(argv) < 2 or argv[1].startswith("--"):
        sys.stderr.write("usage: scaffold_cli.py new <name> --dir <parent> [--tier 1|2] ...\n")
        return 2
    try:
        tier = int(opt(argv, "--tier", "1"))
        cmds = [c.strip() for c in (opt(argv, "--commands") or "").split(",") if c.strip()] or None
        root, written = generate(argv[1], opt(argv, "--dir", "."), tier, opt(argv, "--description"), cmds,
                                 opt(argv, "--env-var"), opt(argv, "--base-url"), "--force" in argv)
    except (UsageError, ValueError) as e:
        sys.stderr.write(f"{e}\n")
        return 2
    print(f"created {root} (tier {tier}, {len(written)} files)")
    for w in written:
        print(f"  {w}")
    print(f"next: cd {root} ; python -m unittest discover -s tests")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
