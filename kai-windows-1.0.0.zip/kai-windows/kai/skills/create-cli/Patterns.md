# CLI patterns

The patterns every generated CLI follows. The scaffold implements all of them; keep them when implementing commands.

## 1. Configuration: environment, then .env, never hard-coded

Look up a secret in the environment first, then in the first `.env` that defines it: next to the tool, the working directory, `%APPDATA%\<name>\.env`, `~/.config/<name>/.env`. Split each line on the first `=` only, because base64 keys contain `=`. When it is missing, the error names the variable and every place searched, never a value.

```python
key, value = line.split("=", 1)
```

## 2. One error type for expected failures

```python
class CliError(Exception):
    """An expected failure: printed as one line on stderr, exit code 1."""
```

Commands raise `CliError("input file not found: notes.md")`; `main` turns it into `error: ...` on stderr and exit 1. Unexpected exceptions keep their traceback, because they are bugs and the traceback is the bug report.

## 3. Commands return data; one function prints

```python
def cmd_list(args):
    items = api_get(load_config(), "/items", {"limit": args.limit})
    return [{"id": i["id"], "name": i["name"]} for i in items]
```

`emit(result, args.format, args.quiet)` is the only printer, so `--format text`, `--quiet` and tests work for every command for free.

## 4. HTTP with urllib, retries and real errors

`api_get` builds the URL with `urllib.parse.urlencode`, sends `Accept: application/json`, a User-Agent and a bearer token when configured, retries 429 and 5xx with exponential backoff (capped at 8 seconds), and raises `CliError` with the status and the first 200 characters of the body otherwise. Add `api_post` beside it with the same shape when needed:

```python
data = json.dumps(payload).encode("utf-8")
req = urllib.request.Request(url, data=data, method="POST",
                             headers={**headers, "Content-Type": "application/json"})
```

## 5. Arguments with argparse sub-commands

- Global flags on the main parser: `--format`, `--quiet`, `--verbose`, `--dry-run`, `--version`.
- One sub-parser per command with its own arguments; `set_defaults(func=...)` routes to the handler.
- Validate value types in argparse (`type=int`, `choices=[...]`) so bad input fails as a usage error (exit 2) before any work happens.
- Positive-number guard for limits: `type=lambda s: int(s) if int(s) > 0 else parser.error("--limit must be positive")`.

## 6. Help text that teaches

Every command has a one-line `help=`; the main parser's `description` says what the tool is for. Put a short examples block in `epilog` with `formatter_class=argparse.RawDescriptionHelpFormatter` when the usage isn't obvious.

## 7. Exit codes

| Code | Meaning |
|---|---|
| 0 | success |
| 1 | runtime error (`CliError`) |
| 2 | usage error (argparse) |
| 130 | interrupted (Ctrl+C) |

## 8. Files and encodings

`pathlib.Path` everywhere; read and write with `encoding="utf-8"` (read `utf-8-sig` when files may come from Windows editors that add a BOM); accept `-` for stdin; write outputs atomically (write a temp file, then `os.replace`) when overwriting user files.

## 9. Progress and verbosity

Progress and diagnostics go to stderr, only with `--verbose`, so stdout stays clean JSON for pipes.

```python
if args.verbose:
    sys.stderr.write(f"fetched page {n}\n")
```

## 10. Tests

`unittest` only. Call `main([...])` directly with stdout/stderr redirected, catch `SystemExit` for argparse paths, mock the network by replacing `api_get`, and use `tempfile.TemporaryDirectory()` for files. One happy path and one failure path per command, plus `--help`, `--version` and a usage error.

## Checklist

- [ ] Every command returns data and raises `CliError` for expected failures
- [ ] Secrets only from environment or `.env`, never printed
- [ ] JSON on stdout, diagnostics on stderr
- [ ] Exit codes 0 / 1 / 2
- [ ] `--dry-run` honored by anything that writes or sends
- [ ] Tests green, network mocked
- [ ] README, QUICKSTART and `--help` agree
