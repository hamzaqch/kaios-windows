# Framework comparison

Why generated CLIs use `argparse`, and when something else would earn its dependency.

| | argparse (Tier 1 and 2) | click | typer |
|---|---|---|---|
| Install | none, in the standard library | `pip install click` | `pip install typer` (pulls in click) |
| Sub-commands | `add_subparsers`, nested parsers for groups | `@group` / `@command` decorators | type-hinted functions |
| Help text | generated; customizable with formatters | generated, nicer defaults | generated from docstrings and type hints |
| Validation | `type=`, `choices=`, custom callables | parameter types, callbacks | type hints |
| Testing | call `main(argv)` directly | `CliRunner` | `CliRunner` |
| Shell completion | not built in | built in | built in |
| Runs on a fresh Windows box with only Python | yes | no | no |

## The default: argparse

Kai's environment guarantees Python and nothing else. A CLI that needs `pip install` before its first run fails exactly when someone tries it on a new machine, behind a proxy, or in a locked-down corporate environment. argparse covers everything most tools need: sub-commands, typed flags, generated help, usage errors with exit code 2.

## When a framework is worth it

Only when the user explicitly accepts the dependency, and one of these is real:
- **Shell completion is a requirement** (a tool used dozens of times a day by many people).
- **A very large command surface** (30+ commands in deep groups) where decorators keep the code navigable.
- **The project already depends on it**, so it adds nothing new.

Then generate the Tier 2 layout anyway (the separation into `config`, `client`, `output` and `commands` carries over unchanged) and swap only `cli.py` for the framework's entry point. Pin the version in a `requirements.txt` and say in the README that `pip install -r requirements.txt` is required.

## Not covered here

Enterprise plugin systems (installable third-party command packs, auto-update, telemetry) are a different class of product. If someone needs that scale, recommend a dedicated framework and design session rather than stretching this scaffold.
