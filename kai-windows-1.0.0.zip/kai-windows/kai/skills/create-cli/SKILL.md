---
name: create-cli
description: "Generate production-ready Python command-line tools with zero third-party dependencies (Python 3.8+ standard library only, Windows-friendly): argparse sub-commands, config from environment or .env, a retrying urllib HTTP client for API wrappers, JSON output that pipes into ConvertFrom-Json or jq, meaningful exit codes, a Windows .cmd shim, README and QUICKSTART, and a passing unittest suite. Two tiers: a single file for 2-10 commands (default), a package with one module per command for larger tools. Also adds commands to an existing CLI and upgrades a single-file CLI to a package. Use when the user says create a CLI, build a command-line tool, make a script into a proper tool, wrap this API in a CLI, I keep typing this command, add a command to my CLI, or turn this into a package. NOT FOR Kai skills (use /create-skill) or one-off throwaway scripts."
argument-hint: "<what the CLI does> [commands] [API base URL]"
---
# CreateCLI

People rebuild the same CLI arc over and over: a quick script, then error handling, then help text, then config, then tests, then docs. This skill produces the finished shape in one pass, at the tier the job needs, using only the Python standard library so it runs anywhere Kai runs.

**Done looks like:** the CLI folder exists with working commands (real logic, not placeholders), `python -m unittest discover -s tests` passes in it, `--help` documents every command and flag, JSON goes to stdout and errors to stderr, exit codes are 0/1/2, and the README explains configuration. The reply shows the path, the commands and one real example run.

## Routing

| Workflow | Trigger | File |
|---|---|---|
| CreateCli | new CLI from scratch | `Workflows/CreateCli.md` |
| AddCommand | add a command to an existing CLI | `Workflows/AddCommand.md` |
| UpgradeTier | single-file CLI has outgrown one file | `Workflows/UpgradeTier.md` |

References: `Patterns.md` (the code patterns every generated CLI follows), `FrameworkComparison.md` (why argparse, and when a third-party framework would be worth it).

## Tool contract

```
python ~/.copilot/skills/create-cli/tools/scaffold_cli.py new <name> --dir <parent> [--tier 1|2] [--description "..."] [--commands a,b,c] [--env-var API_TOKEN] [--base-url https://api.example.com] [--force]
```

The scaffold writes a complete, tested skeleton: with `--base-url` every command performs a real `GET <base>/<command>`; without it every command reads a file or stdin and reports on it. Kai then replaces each command body with the actual logic and extends the tests to match. The generated suite passes before any edits, so a failing test after an edit points at the edit.

## Tiers

| Tier | Shape | Use when |
|---|---|---|
| 1 (default, most CLIs) | one `<name>.py` | 2-10 commands, simple flags, an API wrapper, a file processor |
| 2 | package: `cli.py`, `config.py`, `client.py`, `output.py`, `commands/<cmd>.py` | 10+ commands, grouped commands, shared client logic across many commands, several contributors |
| 3 (reference only) | a third-party framework (click, typer) | only when the user explicitly accepts a pip dependency; see `FrameworkComparison.md` |

If nothing in the request needs Tier 2, use Tier 1.

## Gotchas

- **Stdlib only.** No `requests`, `click` or `rich` unless the user explicitly accepts a pip install; Kai's environment assumes none is available.
- **Never print secrets.** Config errors name the variable and where it was looked for, never its value. `.env` is git-ignored by the scaffold.
- **Windows first.** Paths via `pathlib`, files read and written as UTF-8, the `.cmd` shim for PATH use, and examples in PowerShell syntax. `print` of non-ASCII on old consoles is handled by `sys.stdout.reconfigure(encoding="utf-8")` where output may contain it.
- **`argparse` exits with code 2 on usage errors by raising `SystemExit`.** Tests that call `main()` directly must catch `SystemExit` (the generated tests do).
- **Location:** generate where the user says; default to their current project, never inside `~/.copilot/` unless the tool is meant to be part of Kai.
