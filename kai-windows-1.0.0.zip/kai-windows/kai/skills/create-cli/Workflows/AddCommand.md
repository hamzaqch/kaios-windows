# AddCommand

Add one command to an existing CLI without breaking the others.

1. **Locate and read** the CLI: the entry file (Tier 1) or `cli.py` plus `commands/` (Tier 2), its tests, README and QUICKSTART. Run the existing tests first so you know the baseline is green.
2. **Match the existing style**: argument names, output shape (dict vs list, field naming), error messages, how the client is called. A new command that looks foreign is a defect.
3. **Implement**
   - Tier 1: a `cmd_<name>(args)` function in the commands section, plus a `sub.add_parser("<name>", ...)` block with its arguments and `set_defaults(func=cmd_<name>)`.
   - Tier 2: a new `commands/<name>.py` with `HELP`, `add_arguments(p)` and `run(args)`, then register it in `commands/__init__.py`.
   - Return data, raise `CliError` for expected failures, honor `--dry-run` if it writes or sends.
4. **Test**: a happy-path and a failure-path test, network mocked. The whole suite must stay green.
5. **Document**: add the command to `--help` (its `help=` string), the README commands table, and QUICKSTART if it is a common entry point.
6. **Version**: bump the patch or minor version (`VERSION` in Tier 1, `__version__` in Tier 2) and mention the new command in the README if it keeps a changelog.

Hand off with the suite's summary line and one example run of the new command.
