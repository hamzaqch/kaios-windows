# UpgradeTier

Move a Tier 1 single-file CLI to the Tier 2 package layout when it has outgrown one file.

## When it's worth it

- 10+ commands, or commands that naturally group (`repo list`, `repo create`, `issue list`).
- Several commands share non-trivial client or parsing logic.
- More than one person edits it, and the single file causes merge conflicts.

If none of these hold, don't upgrade; a long single file that is easy to read beats a package with nothing to separate.

## Steps

1. Run the existing tests and record every command's `--help` output and one example output. These are the compatibility baseline.
2. Scaffold the target layout next to it: `scaffold_cli.py new <name>-next --dir <tmp> --tier 2 --commands <same list> [--env-var ...] [--base-url ...]`, and use its structure as the template.
3. Move code, don't rewrite it:
   - config loading to `config.py`, the HTTP client to `client.py`, `emit`/`parse_params` to `output.py`, `CliError` to `errors.py`
   - each `cmd_<name>` to `commands/<name>.py` as `run(args)`, with its parser arguments in `add_arguments(p)`
   - register each command in `commands/__init__.py`
4. For command groups, give `cli.py` a nested sub-parser per group (`repo` with `list`/`create` beneath it) and keep the old flat names as aliases for one version if users have scripts that call them.
5. Keep the external contract identical: command names, flags, JSON field names, exit codes. Anything that must change is a breaking change; bump the major version and list it in the README under "Breaking changes".
6. Move the tests, point imports at the package, and add a test that compares each command's `--help` against the baseline from step 1.
7. Update the `.cmd` shim to `python -m <module> %*` (run from the CLI folder) and the README/QUICKSTART run lines.

Done when the full suite passes, every baseline command produces the same output shape, and the old single file is removed (or left as a thin wrapper that calls the package's `main`).
