# CreateCli

Generate a complete Python stdlib CLI from a description.

## 1. Gather requirements

Extract from the request, asking only for what can't be inferred (one short message, at most three questions):
- **Name**: lowercase kebab-case (`ghcli`, `md-tools`).
- **Purpose**: one sentence.
- **Commands**: each with its arguments and what it returns.
- **API** (if wrapping one): base URL, auth method, the env var holding the secret.
- **Behavioral flags** beyond the built-in `--format`, `--quiet`, `--verbose`, `--dry-run`: modes (`--fast`/`--thorough`), limits (`--limit N`), resource choices (`--model`), post-processing switches. Sensible defaults so the common case needs no flags.
- **Location**: the user's path, else the current project.

## 2. Pick the tier

```
10+ commands, command groups, or several contributors?  -> Tier 2
otherwise                                                -> Tier 1
```

## 3. Scaffold

```
python ~/.copilot/skills/create-cli/tools/scaffold_cli.py new <name> --dir <parent> --tier <1|2> --description "<purpose>" --commands <a,b,c> [--env-var <VAR>] [--base-url <url>]
```

Then run its tests once to confirm the skeleton is green: `python -m unittest discover -s tests` inside the new folder.

## 4. Implement each command

Replace each generated command body with the real logic, following `../Patterns.md`:
- Validate inputs first and raise `CliError("<what is wrong and how to fix it>")` for expected failures.
- For APIs: use `api_get` (or add `api_post` beside it using the same retry and error handling), map response fields into a clean result dict or list, and include only what a caller needs.
- Return data; never print inside a command. `emit` owns output so `--format` and `--quiet` keep working.
- Add the per-command flags with `p.add_argument(...)` in the parser section (Tier 1) or the module's `add_arguments` (Tier 2).
- Honor `--dry-run` for anything that writes or sends.

## 5. Tests

Extend the generated test file: at least one test per command covering the happy path and one failure path. Mock network calls by replacing `api_get` (Tier 1: `module.api_get = fake`; Tier 2: patch `<pkg>.commands.<cmd>.api_get`) so tests never hit the network. Run the suite until green.

## 6. Docs

Update `README.md` (commands table, configuration, examples with real output shape) and `QUICKSTART.md` (the three or four commands a new user runs first, in PowerShell syntax). `--help` text must match.

## 7. Verify and hand off

- `python -m unittest discover -s tests` passes (paste the final summary line).
- `python <name>.py --help` (Tier 1) or `python -m <module> --help` (Tier 2) lists every command.
- One real example run with its output (use `--dry-run` if the real call needs credentials the session doesn't have, and say so).
- Reply with the folder path, the command list, and how to put it on PATH (the `.cmd` shim).
