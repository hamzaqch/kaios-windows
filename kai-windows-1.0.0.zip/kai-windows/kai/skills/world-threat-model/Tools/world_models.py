#!/usr/bin/env python3
"""world_models.py - deterministic helpers for the world-threat-model skill.

Models are data, so they live in Kai memory, never in the skill folder:
  default  <KAI_HOME>/MEMORY/RESEARCH/WorldModels/
  override WORLDMODELS_DIR
KAI_HOME resolves from the KAI_HOME env var, else <COPILOT_HOME>/kai, else
~/.copilot/kai.

Commands:
  path                                print the models directory
  init                                create the directory and Scenarios/
  status  [--json]                    inventory: horizon, last_updated, version, confidence, freshness
  check   [--json]                    exit 1 if any horizon model is missing (TestIdea gate); warns on age
  validate <horizon|file> [--json]    check a model against ModelTemplate.md (sections, word counts, frontmatter)
  excerpt <horizon> [--words N]       first N words of the model's Executive Summary
  index   [--note "what changed"]     regenerate INDEX.md from model frontmatter, appending to Update History

Python 3.8+ standard library only.
"""
import argparse
import datetime as dt
import json
import os
import re
import sys
from pathlib import Path

HORIZONS = ["6-month", "1-year", "2-year", "3-year", "5-year", "7-year",
            "10-year", "15-year", "20-year", "30-year", "50-year"]

def _label(h):
    n, unit = h.split("-")
    return "{} {}".format(n, unit if n == "1" else unit + "s")


LABELS = {h: _label(h) for h in HORIZONS}

# (section name, minimum words) from ModelTemplate.md
SECTIONS = [
    ("Executive Summary", 300),
    ("Geopolitics & Power Dynamics", 600),
    ("Technology & AI Trajectory", 800),
    ("Economics & Markets", 600),
    ("Society, Culture & Demographics", 500),
    ("Environment & Climate", 500),
    ("Security & Conflict", 500),
    ("Wildcards & Black Swans", 400),
    ("Confidence Assessment & Key Uncertainties", 300),
]
MIN_TOTAL = 4000
REQUIRED_FM = ("horizon", "last_updated", "version", "confidence")
CONFIDENCE = ("high", "medium", "low")

HEADING_RE = re.compile(r"^(#{1,6})\s+(.*?)\s*$")
WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9'%.,-]*")


# ---------------------------------------------------------------- paths

def kai_home():
    env = os.environ.get("KAI_HOME")
    if env:
        return Path(env).expanduser()
    ch = os.environ.get("COPILOT_HOME")
    if ch:
        return Path(ch).expanduser() / "kai"
    return Path.home() / ".copilot" / "kai"


def models_dir():
    env = os.environ.get("WORLDMODELS_DIR")
    d = Path(env).expanduser() if env else kai_home() / "MEMORY" / "RESEARCH" / "WorldModels"
    return d.resolve()


# ---------------------------------------------------------------- parsing

def parse_frontmatter(text):
    """Return (dict, body). Minimal YAML: 'key: value' lines between leading --- fences."""
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text
    fm = {}
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            return fm, "\n".join(lines[i + 1:])
        m = re.match(r"^\s*([A-Za-z_][\w-]*)\s*:\s*(.*?)\s*$", lines[i])
        if m:
            val = m.group(2)
            if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
                val = val[1:-1]
            fm[m.group(1)] = val
    return {}, text


def norm(s):
    s = s.lower().replace("&", "and")
    s = re.sub(r"\(.*?\)", " ", s)          # drop "(~300 words)"
    s = re.sub(r"^\s*\d+[.)]\s*", "", s)    # drop "1. "
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def split_sections(body):
    """Map normalized heading -> section text (until the next heading of same or higher level)."""
    out = {}
    lines = body.splitlines()
    heads = [(i, len(m.group(1)), m.group(2)) for i, m in
             ((i, HEADING_RE.match(l)) for i, l in enumerate(lines)) if m]
    for k, (i, level, title) in enumerate(heads):
        end = len(lines)
        for j, lvl, _ in heads[k + 1:]:
            if lvl <= level:
                end = j
                break
        out.setdefault(norm(title), "\n".join(lines[i + 1:end]))
    return out


def count_words(text):
    return len(WORD_RE.findall(text))


def find_section(sections, name):
    target = norm(name)
    if target in sections:
        return sections[target]
    for key, val in sections.items():
        if key.startswith(target) or target in key:
            return val
    return None


def parse_date(value):
    try:
        return dt.date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def freshness(last_updated, ref=None):
    """Return (tier, days). Tiers per ViewModels: Fresh <7, Current 7-30, Aging 30-90, Stale >90."""
    d = parse_date(last_updated) if last_updated else None
    if d is None:
        return "Unknown", None
    days = ((ref or dt.date.today()) - d).days
    if days < 7:
        tier = "Fresh"
    elif days <= 30:
        tier = "Current"
    elif days <= 90:
        tier = "Aging"
    else:
        tier = "Stale"
    return tier, days


ICON = {"Fresh": "🟢", "Current": "🟡", "Aging": "🟠", "Stale": "🔴", "Unknown": "⚪", "Missing": "⛔"}


# ---------------------------------------------------------------- operations

def read_text(path):
    """Read a model file tolerantly: strips a UTF-8 BOM (Notepad / PowerShell 5.1), never raises on bad bytes."""
    return path.read_text(encoding="utf-8-sig", errors="replace")


def model_file(d, horizon):
    return d / "{}.md".format(horizon)


def read_model(path):
    fm, body = parse_frontmatter(read_text(path))
    return fm, body


def inventory(d, ref=None):
    rows = []
    for h in HORIZONS:
        p = model_file(d, h)
        if not p.exists():
            rows.append({"horizon": h, "label": LABELS[h], "file": p.name, "exists": False,
                         "last_updated": "", "version": "", "confidence": "", "freshness": "Missing", "age_days": None})
            continue
        fm, _ = read_model(p)
        tier, days = freshness(fm.get("last_updated"), ref)
        rows.append({"horizon": h, "label": LABELS[h], "file": p.name, "exists": True,
                     "last_updated": fm.get("last_updated", ""), "version": fm.get("version", ""),
                     "confidence": fm.get("confidence", ""), "freshness": tier, "age_days": days})
    return rows


def scenarios(d):
    sd = d / "Scenarios"
    return sorted(p.name for p in sd.glob("*.md")) if sd.exists() else []


def validate_text(text, horizon_hint=None):
    fm, body = parse_frontmatter(text)
    problems, warnings, report = [], [], []
    for k in REQUIRED_FM:
        if not fm.get(k):
            problems.append("frontmatter missing '{}'".format(k))
    if fm.get("horizon") and fm["horizon"] not in HORIZONS:
        problems.append("horizon '{}' is not one of {}".format(fm["horizon"], ", ".join(HORIZONS)))
    if horizon_hint and fm.get("horizon") and fm["horizon"] != horizon_hint:
        problems.append("file is {}.md but frontmatter says horizon: {}".format(horizon_hint, fm["horizon"]))
    if fm.get("last_updated") and parse_date(fm["last_updated"]) is None:
        problems.append("last_updated '{}' is not YYYY-MM-DD".format(fm["last_updated"]))
    if fm.get("version") and not str(fm["version"]).isdigit():
        problems.append("version '{}' is not an integer".format(fm["version"]))
    if fm.get("confidence") and fm["confidence"].lower() not in CONFIDENCE:
        problems.append("confidence '{}' is not high|medium|low".format(fm["confidence"]))
    if not fm.get("confidence_note"):
        warnings.append("frontmatter has no confidence_note")
    sections = split_sections(body)
    total = 0
    for name, minimum in SECTIONS:
        sec = find_section(sections, name)
        if sec is None:
            problems.append("missing section: {}".format(name))
            report.append({"section": name, "words": 0, "minimum": minimum, "ok": False})
            continue
        w = count_words(sec)
        total += w
        ok = w >= minimum
        if not ok:
            problems.append("{}: {} words (minimum {})".format(name, w, minimum))
        report.append({"section": name, "words": w, "minimum": minimum, "ok": ok})
    if total < MIN_TOTAL:
        problems.append("total {} words across required sections (minimum {})".format(total, MIN_TOTAL))
    wild = find_section(sections, "Wildcards & Black Swans") or ""
    if wild and not re.search(r"\d+(\.\d+)?\s*%|probabilit", wild, re.I):
        warnings.append("Wildcards section has no probability estimates")
    return {"ok": not problems, "problems": problems, "warnings": warnings, "sections": report,
            "total_words": total, "frontmatter": fm}


def render_index(d, rows, note=None, today=None):
    today = today or dt.date.today().isoformat()
    idx = d / "INDEX.md"
    history = []
    if idx.exists():
        text = read_text(idx)
        m = re.search(r"^## Update History\s*$(.*)", text, re.M | re.S)
        if m:
            history = [l for l in m.group(1).strip().splitlines() if l.strip().startswith("-")]
    if note:
        history.insert(0, "- {}: {}".format(today, note))
    dates = [r["last_updated"] for r in rows if r["exists"] and r["last_updated"]]
    complete = all(r["exists"] for r in rows)
    lines = ["# World Threat Models — Index", "",
             "> Regenerated by world_models.py from each model's frontmatter. Add history with `index --note`.", "",
             "Last full update: {}".format(min(dates) if complete and dates else "incomplete ({} of {} models)".format(
                 sum(r["exists"] for r in rows), len(rows))), "",
             "| Horizon | File | Last Updated | Version | Confidence | Freshness |",
             "|---------|------|-------------|---------|------------|-----------|"]
    for r in rows:
        lines.append("| {} | {} | {} | {} | {} | {} {} |".format(
            r["label"], r["file"], r["last_updated"] or "—", r["version"] or "—", r["confidence"] or "—",
            ICON[r["freshness"]], r["freshness"]))
    sc = scenarios(d)
    if sc:
        lines += ["", "## Scenarios", ""] + ["- Scenarios/{}".format(s) for s in sc]
    lines += ["", "## Update History", ""] + (history or ["- (none yet)"])
    d.mkdir(parents=True, exist_ok=True)
    idx.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return idx


def excerpt(text, words=60):
    _, body = parse_frontmatter(text)
    sec = find_section(split_sections(body), "Executive Summary")
    if not sec:
        return ""
    toks = " ".join(sec.split()).split(" ")
    return " ".join(toks[:words]) + (" ..." if len(toks) > words else "")


# ---------------------------------------------------------------- CLI

def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description="World threat model helpers (data in Kai memory).")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("path")
    sub.add_parser("init")
    for name in ("status", "check"):
        p = sub.add_parser(name)
        p.add_argument("--json", action="store_true")
    p = sub.add_parser("validate")
    p.add_argument("target", help="a horizon (e.g. 5-year) or a path to a model file")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("excerpt")
    p.add_argument("horizon")
    p.add_argument("--words", type=int, default=60)
    p = sub.add_parser("index")
    p.add_argument("--note")
    args = ap.parse_args(argv)
    d = models_dir()

    if args.cmd in (None, "path"):
        print(d)
        return 0
    if args.cmd == "init":
        (d / "Scenarios").mkdir(parents=True, exist_ok=True)
        print("ready: {}".format(d))
        return 0
    if args.cmd in ("status", "check"):
        rows = inventory(d)
        missing = [r["horizon"] for r in rows if not r["exists"]]
        aging = [r["horizon"] for r in rows if r["freshness"] in ("Aging", "Stale", "Unknown")]
        stale = [r["horizon"] for r in rows if r["freshness"] == "Stale"]
        if args.json:
            print(json.dumps({"dir": str(d), "models": rows, "missing": missing, "aging": aging,
                              "stale": stale, "scenarios": scenarios(d)}, indent=2, ensure_ascii=False))
        else:
            print("World models: {}".format(d))
            print("| Horizon | Last Updated | Version | Confidence | Freshness |")
            print("|---|---|---|---|---|")
            for r in rows:
                print("| {} | {} | {} | {} | {} |".format(r["label"], r["last_updated"] or "-", r["version"] or "-",
                                                     (r["confidence"] or "-").upper(), r["freshness"]))
            if scenarios(d):
                print("Scenarios: " + ", ".join(scenarios(d)))
        if args.cmd == "check":
            if missing:
                print("World models incomplete ({} missing: {}). Run the UpdateModels workflow first."
                      .format(len(missing), ", ".join(missing)), file=sys.stderr)
                return 1
            if stale:
                print("WARNING: stale (>90 days): {}. Recommend an update; warn prominently in the output header."
                      .format(", ".join(stale)), file=sys.stderr)
            elif aging:
                print("note: older than 30 days: {}. Proceeding is fine; mention it.".format(", ".join(aging)),
                      file=sys.stderr)
        return 0
    if args.cmd == "validate":
        hint = None
        p = Path(args.target)
        if args.target in HORIZONS:
            hint, p = args.target, model_file(d, args.target)
        if not p.exists():
            print("error: no model at {}".format(p), file=sys.stderr)
            return 2
        res = validate_text(read_text(p), hint or (p.stem if p.stem in HORIZONS else None))
        if args.json:
            print(json.dumps(res, indent=2, ensure_ascii=False))
        else:
            for s in res["sections"]:
                print("{} {:<44} {:>5} / {}".format("ok  " if s["ok"] else "FAIL", s["section"], s["words"], s["minimum"]))
            print("total words: {} (minimum {})".format(res["total_words"], MIN_TOTAL))
            for w in res["warnings"]:
                print("warn: " + w)
            for pr in res["problems"]:
                print("problem: " + pr)
            print("RESULT: " + ("PASS" if res["ok"] else "FAIL"))
        return 0 if res["ok"] else 1
    if args.cmd == "excerpt":
        p = model_file(d, args.horizon)
        if not p.exists():
            print("error: no model at {}".format(p), file=sys.stderr)
            return 2
        print(excerpt(read_text(p), args.words))
        return 0
    if args.cmd == "index":
        path = render_index(d, inventory(d), args.note)
        print("wrote {}".format(path))
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
