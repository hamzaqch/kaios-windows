---
workflow: UpdateModels
mode: loop-compatible
---

# Update world models

Create or refresh world model documents using deep research and any analysis the user provides.

## When to use

- "update world models", "refresh models", "new analysis for the models"
- The user provides new information or analysis to incorporate
- Models are stale (over 30 days since last update)
- First use (no models exist yet)

`$W` below is `"$HOME/.copilot/skills/world-threat-model/Tools/world_models.py"`.

## Steps

### Step 0: Check existing state

```powershell
python $W init      # ensures the folder exists
python $W status    # which models exist, their dates, versions, freshness
```

Decide: full creation vs targeted update vs single horizon.

### Step 1: Determine scope

**Full creation** (no models, or the user says "rebuild all"): create all 11 from scratch, in parallel batches.

**Targeted update** (models exist):
- The user provided analysis → incorporate it into the relevant horizons.
- Routine refresh → research what changed since each model's `last_updated`; update only affected models.

**Single horizon** ("update the 5-year model"): research and update only that one.

### Step 2: Research current state

For each model being created or updated:

1. Run the `/research` method (Standard for a targeted update, Extensive for full creation) with: "Current global state and projections for the {HORIZON} timeframe: geopolitics, AI/technology trajectory, economics, society, environment, security. Focus on developments since {last_updated or 'baseline'}."
   - Near-term (6mo-3yr): current events, immediate trends, specific forecasts
   - Mid-term (5-10yr): trend trajectories, structural shifts, emerging patterns
   - Long-term (15-50yr): megatrends, demographic forces, technological paradigm shifts
2. If the user provided analysis, treat it as the primary source and research as support.
3. **Parallel execution** for multiple models: issue `task` calls to `@kai-researcher` together, in batches:
   - Near-term batch: 6mo, 1yr, 2yr, 3yr (4 calls)
   - Mid-term batch: 5yr, 7yr, 10yr (3 calls)
   - Long-term batch: 15yr, 20yr, 30yr, 50yr (4 calls)

   Use the subagent brief template below. Each subagent returns the complete model document as markdown; you write the files (subagents never write into Kai memory directly).

### Step 3: Write the model documents

For each model, following `ModelTemplate.md`:

1. Frontmatter: `horizon`, `last_updated` (today, YYYY-MM-DD), `version` (previous + 1, or 1), `confidence` (high|medium|low), `confidence_note`.
2. All 9 required sections at or above their minimum word counts.
3. Hedging language for predictions.
4. Specific data points, named entities, reasoning for every trend.
5. Wildcards with probability estimates.

Save to `<models dir>/{horizon}.md` (the folder `python $W path` prints). For an update, read the existing file first and carry forward what still holds.

### Step 4: Validate each model

```powershell
python $W validate {horizon}
```

Fix and re-validate until it prints `RESULT: PASS` (all sections present, each at its minimum, 4,000+ words, valid frontmatter). Don't report a model as done on a FAIL.

### Step 5: Regenerate the index

```powershell
python $W index --note "{what was updated and why}"
python $W status
```

The index table comes from each model's frontmatter; the note is prepended to Update History.

### Step 6: Report

How many horizons were created or refreshed, the validation result for each, the headline changes, and anything still stale.

## Subagent brief template (parallel model creation)

```
CONTEXT: You are creating a world threat model for the {HORIZON} time horizon.
The current date is {TODAY}. This model will be used to test ideas, strategies,
and investments against projected future world states.

TASK: Write a comprehensive world model document following this template:
{INSERT ModelTemplate.md CONTENT}

REQUIREMENTS:
- Minimum 4,000 words across all sections, and every section at or above its minimum
- Use hedging language for predictions ("likely," "projected," "if trends continue")
- Be specific: name countries, companies, technologies; cite numbers where possible
- Near-term models: heavier on current data extrapolation
- Long-term models: focus on structural forces and megatrends
- Include at least 4 wildcards with probability estimates
- Rate your overall confidence and explain why

RESEARCH: Use web search and web fetch to find current data, forecasts and analysis
for this {HORIZON} timeframe across all sections (geopolitics, technology, economics,
society, environment, security). Cite sources inline.

OUTPUT: Return the complete model document in markdown, following the template exactly,
with frontmatter: horizon: {HORIZON}, last_updated: {TODAY}, version: {N}, confidence, confidence_note.
Return the document text only; do not write any files.
```

## Integration points

| Skill / tool | Purpose |
|-------|---------|
| `/research` | Primary data gathering for model content |
| web search / web fetch | Current events and projections |
| `world_models.py validate` | Deterministic template compliance gate |

## State management (loop compatibility)

- Models on disk are the state.
- Step 0 reads existing state to decide what needs updating.
- Each model is independently updatable.
- `INDEX.md` tracks aggregate state and is regenerated, never hand-edited (except Update History notes via `--note`).
