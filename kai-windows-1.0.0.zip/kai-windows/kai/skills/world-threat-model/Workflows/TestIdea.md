---
workflow: TestIdea
mode: single-run
---

# Test an idea against the world threat models

Test any idea, strategy, investment, brand or concept against all 11 persistent world models to assess viability across time horizons.

## When to use

- "test this idea", "how will this hold up", "test my strategy", "stress test this"
- The user provides an idea, strategy or investment and wants temporal viability analysis
- The user wants to understand when an idea breaks or thrives

`$W` below is `"$HOME/.copilot/skills/world-threat-model/Tools/world_models.py"`.

## Tier detection

- **"fast"** or **"quick"** → Fast
- **"deep"**, **"thorough"** or **"comprehensive"** → Deep
- No modifier → Standard (default)

## Steps

### Step 0: Validate the models exist

```powershell
python $W check
```

- Exit 1 (models missing): say "World models incomplete. Run 'update world models' first." and offer to run **UpdateModels** now. Don't fabricate the missing horizons.
- Warning about >30 days: proceed and mention it.
- Warning about >90 days (stale): proceed, put a prominent staleness warning in the output header, and recommend an update.

Also list `Scenarios/` (shown by `python $W status`); any scenario files are extra lenses for the test.

### Step 1: Decompose the idea

Before hitting it with world models:

1. **State the idea** in 1-2 sentences.
2. **Identify the core assumptions** it relies on (market conditions, technology state, cultural norms, regulatory environment, competitive landscape).
3. **Identify success dependencies**: what must remain true for this to work?

**Standard and Deep:** run the `/first-principles` method on the assumptions and classify each:
- **Hard constraints** (physics, demographics, math)
- **Soft constraints** (policy, regulation, cultural norms)
- **Assumptions** (unvalidated beliefs the idea depends on)

### Step 2: Run against the world models

Model files live in `python $W path`.

#### Fast tier (~2 min)

You do it in one pass:
1. Read all 11 models (the Executive Summary and Wildcards of each is enough for Fast).
2. For each horizon: verdict (🟢/🟡/🔴) + 2-3 bullets.
3. Write the Executive Verdict.
4. Output with the abbreviated format from `OutputFormat.md`.

#### Standard tier (~10 min)

1. Issue 11 `task` calls together in one turn, one per horizon. Each brief contains: the idea statement, the assumption list from Step 1, the full path of ONE model file, and the per-horizon section of `OutputFormat.md`. Each subagent:
   - reads its ONE world model document
   - analyzes the idea against that horizon
   - tests each assumption against the horizon's conditions
   - returns: Verdict, Confidence, Key Factors, Analysis, Assumptions Tested
2. When all return, run the `/red-team` method across the per-horizon results ("Attack this idea across all time horizons. Here are the per-horizon analyses: ..."), with critique personas as parallel `task` calls to `@kai-reviewer`. Extract the strongest attack vector and steelman per horizon.
3. Write the Cross-Horizon Synthesis.
4. Output with the full format from `OutputFormat.md`.

#### Deep tier (up to 1 hr)

1. **First-principles** (if not done in Step 1): the full deconstruct → challenge → reconstruct cycle on the idea.
2. **Research refresh:** for each horizon, a quick `/research` pass (or a `task` call to `@kai-researcher`) on recent developments that bear on THIS idea.
3. **Parallel horizon analysis:** as Standard, with the research findings added to each brief and a deeper analysis requested.
4. **Red-team (full):** the complete ParallelAnalysis from `/red-team` across all horizons.
5. **Council:** the `/council` debate: "Debate the viability of {idea} across time horizons from 6 months to 50 years. Consider: {per-horizon results}". Extract the Council Deliberation section.
6. Synthesize everything.
7. Output with the complete format from `OutputFormat.md` (all sections).

### Step 3: Format the output

Use `OutputFormat.md` (in this skill's folder). Make sure:
- Each horizon has its own clearly separated section
- Verdicts use the same emoji indicators throughout
- Confidence reflects model confidence × analysis certainty
- Adversarial findings are tied to the specific horizon's conditions
- The header's "Models Last Updated" is the date of the oldest model used

### Step 4: Close

End with the executive verdict in one sentence and the single most important adaptation. Offer to save the analysis to `~/.copilot/kai/MEMORY/RESEARCH/WorldModels/Tests/<date>-<idea-slug>.md` if the user wants to revisit it.

## Integration points

| Skill | Tier | Purpose |
|-------|------|---------|
| `/first-principles` | Standard, Deep | Decompose the idea's assumptions before testing |
| `/red-team` | Standard, Deep | Adversarial attack across horizons |
| `/council` | Deep | Multi-perspective debate on viability |
| `/research` | Deep | Refresh horizon-relevant current events |

## Error handling

- A horizon subagent fails: continue with the rest; mark that horizon "not analyzed" in the output.
- A skill pass fails: degrade gracefully (for example skip the Council section) and say so in the footer.
- Models stale (>90 days): prominent warning in the header; recommend **UpdateModels**.
