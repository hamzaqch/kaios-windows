---
workflow: ViewModels
mode: single-run
---

# View world models

Read and display the current state of the world threat models. Read-only.

## When to use

- "view world models", "show models", "current models", "model status"
- The user wants to know what's in the current models
- Checking model freshness before a TestIdea run

`$W` below is `"$HOME/.copilot/skills/world-threat-model/Tools/world_models.py"`.

## Steps

### Step 1: Read the inventory

```powershell
python $W status
```

If every horizon shows ⛔ Missing: "No world models found. Run 'update world models' to create them." and stop.

### Step 2: Determine view scope

**Overview** (default, no horizon named):
- The status table (horizons, dates, versions, confidence, freshness)
- A 2-3 sentence Executive Summary excerpt per model: `python $W excerpt <horizon> --words 60`, then trim to the strongest 2-3 sentences
- Flag every model older than 30 days

**Single horizon** ("show me the 5-year model"):
- Read and present the full model document for that horizon, all sections

**Comparison** ("compare near-term vs long-term"):
- Side-by-side key themes from the selected horizons
- Highlight where short-term and long-term trends conflict

### Step 3: Staleness

The CLI computes freshness from each model's `last_updated`:
- **< 7 days**: 🟢 Fresh
- **7-30 days**: 🟡 Current
- **30-90 days**: 🟠 Aging, recommend a refresh
- **> 90 days**: 🔴 Stale, strongly recommend an update

### Step 4: Output

```markdown
# 🌍 World Threat Model Status

| Horizon | Last Updated | Version | Confidence | Freshness |
|---------|-------------|---------|------------|-----------|
| 6 months | YYYY-MM-DD | N | HIGH | 🟢 Fresh |
| 1 year | YYYY-MM-DD | N | MEDIUM | 🟡 Current |
| ... | ... | ... | ... | ... |

## Summaries

### 6-Month Horizon
{2-3 sentence executive summary excerpt}

### 1-Year Horizon
{2-3 sentence executive summary excerpt}

...

## Recommendations
- {models needing a refresh}
- {notable changes since the last update, from INDEX.md Update History}
```

## Integration points

None. This workflow only reads.
