# TestSkill

Find out whether a skill actually improves results, by running realistic prompts with and without it and comparing.

## Done looks like

- 2 to 4 test prompts, approved by the user, that are realistic (what a person would actually type, with concrete details like file names and context), substantive (hard enough that a skill could help), and diverse (covering different parts of the skill's job).
- For each prompt, a with-skill output and a baseline output produced independently, plus a short note from each run on the approach taken.
- A per-prompt verdict: helped significantly, helped marginally, no meaningful difference, or baseline was better, each with specific reasons drawn from the outputs.
- A recommendation: ship, improve (hand to `ImproveSkill.md` with the evidence), or reconsider whether the skill is needed at all.

## Constraints

- **Runs must be independent.** Use the `task` tool, or dispatch to `@kai-engineer` for build-style skills and `@kai-researcher` for research-style skills. Each with-skill run gets the skill's `SKILL.md` path and the prompt, and is told to read the skill first and follow it. Each baseline run gets only the prompt and is told not to read any skill files. Launch the pairs in parallel. Ask every run to return its output plus a few lines on its approach and the tools it used.
- **Judge with a fresh eye.** For anything beyond an obvious difference, hand both outputs, unlabeled and in random order, to `@kai-reviewer` with the skill's done-state as the rubric, and ask which better meets it and why. The run that produced an output never grades it.
- **Keep a held-out prompt.** When iterating with `ImproveSkill.md`, hold at least one prompt back from the improvement loop and test on it at the end. A skill tuned to pass its own test set proves nothing.
- **Bad prompts give useless results.** "Format this data" tests nothing. "I have a CSV in my Downloads with revenue in column C and costs in D; add a margin column and flag anything under 15%" tests something.
- **Ask for the user's read.** Which outputs did they prefer, what did the skill get wrong, what should it do differently. Silence on a test means it was fine.
- **Keep iterations comparable.** Re-run the same prompts after each improvement and compare against both the baseline and the previous iteration.
