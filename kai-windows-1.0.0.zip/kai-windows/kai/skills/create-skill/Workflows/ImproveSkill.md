# ImproveSkill

Revise a skill based on test results, user feedback or observed failures. This is the revision half of the test loop with `TestSkill.md`.

## Done looks like

- Each piece of feedback is traced to a root cause, and the edit addresses that cause, not the symptom.
- The revised skill follows `../AuthoringStandard.md`, passes `ValidateSkill.md`, and shows improvement when `TestSkill.md` is re-run, including on a held-out prompt.
- Any failure a future run would repeat is recorded in `## Gotchas`.

## Diagnosis

| Symptom | Usual cause | Fix |
|---|---|---|
| Output wrong or off-target | Done-state vague or missing | Rewrite the outcome as something testable |
| Output compliant but lifeless | Rigid rules without reasons | Replace rules with the why behind them |
| Runs slow, wander, or do busywork | Step choreography the model doesn't need | Cut the steps; keep outcome + constraints |
| Missed a case | Real gap in coverage | Add the constraint, or a gotcha if it was an observed failure |
| Every test run wrote the same helper | Repeated work not bundled | Add the helper as a supporting file or documented command |
| Didn't trigger, or triggered wrongly | Description, not body | Go to `OptimizeDescription.md` |

## Constraints

- **Read the evidence first**: the skill, the test outputs and the run notes showing how the model actually used the skill. Where it skipped or rushed through instructions, those instructions are probably dead weight.
- **Louder is not better.** If an instruction isn't working, adding MUST or CRITICAL rarely helps. Reframe it with the reason it matters.
- **Generalize.** A fix that only helps the test prompts is overfitting. Ask what pattern produced the failure and fix that.
- **Cut while you're there.** Apply the test "would a smarter model make this unnecessary?" to every line you touch. Removing a rule is often the improvement.
- **Reorganizing files doesn't fix weak instructions.** Change structure only when structure is the problem.

When the edits are made, return to `TestSkill.md` and re-run the same prompts against the new version.
