# CanonicalizeSkill

Restructure an existing skill so it matches Kai's skill format, without changing what the skill does.

## Done means

- **Folder and name:** the folder is lowercase kebab-case (`my-skill`), and the frontmatter `name` equals the folder name exactly.
- **Frontmatter:** `description` is one paragraph of 1024 characters or fewer. It says what the skill does, then gives `Use when ...` triggers, and `NOT FOR ...` when a neighbouring skill could be confused with it. Optional fields (`argument-hint`, `user-invocable`, `disable-model-invocation`, `allowed-tools`) appear only when they are used.
- **Layout is at most two levels deep:**
  - `SKILL.md`
  - TitleCase reference docs (`Methodology.md`)
  - `Workflows/<TitleCase>.md`
  - `tools/*.py` (Python 3.8+ stdlib only)
  - `tests/test_*.py`
  - `Templates/`

  Never nest a folder inside `Workflows/` or `tools/`.
- **Routing:** `SKILL.md` has a `## Workflow Routing` table. It maps each trigger phrase to `Workflows/<File>.md`, and every file named in it exists.
- **Copilot runtime only:** tools are referenced the way Copilot sees them. Custom agents are `@kai-<name>`, and skills are `/<name>`. Helper scripts run with `python` or PowerShell 5.1, and their tests pass under `python -m unittest discover -s tests`.
- **Ideal-state prompting:** workflows state what done looks like and keep only the four legitimate kinds of HOW: safety gates, verified gotchas, tool contracts, and output formats. Cut any step-by-step choreography a capable model wouldn't need.
- **Behaviour preserved:** every capability, trigger and output format the skill had before still exists afterwards. Record what changed in the skill's own notes and in the user's ISA.

## Constraints

- Back up first: `Copy-Item -Recurse <skill> "$env:USERPROFILE\.copilot\kai\MEMORY\STATE\skill-backups\<name>-<date>"` (or `cp -r` on other systems). Backups never go inside `skills/`.
- Renames need a reference sweep. Search every skill, agent and `copilot-instructions.md` for the old name, and fix each reference in the same run.
- Finish with the ValidateSkill workflow. The skill must load (`copilot skill list` shows it) and `python ~/.copilot/kai/bin/kai.py doctor --docs` must report no problems.
