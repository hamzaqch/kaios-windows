# CreateSkill

Produce a new skill that passes `ValidateSkill.md` and is ready for `TestSkill.md`.

## Done looks like

- A folder `~/.copilot/kai/skills/<kebab-name>/` (or `.github/skills/<kebab-name>/` for a project skill) containing `SKILL.md`, plus supporting files and `Workflows/` only where they carry real method content.
- Frontmatter with exactly `name` (equal to the folder name) and `description` (under 1024 characters, `Use when ...` triggers, a `NOT FOR` clause if a neighboring skill shares vocabulary). See `../AuthoringStandard.md` for the description shape.
- A body written in ideal-state style: the done-state as testable outcomes, constraints with reasons, tools, and only keep-class procedure.
- Every file referenced from `SKILL.md` exists, and every workflow file is referenced from `SKILL.md`.
- The skill passes the personal-data check in `ValidateSkill.md`.

## Constraints

- **Pin the skill's job before writing.** You need three answers: what outcome does it produce, what would a user say to get it, and what does it do that the model wouldn't do well unaided. If the request leaves these unclear, ask at most three questions. If the third answer is "nothing", say so: a skill that only narrates reasoning the model already does is not worth adding.
- **Check for collisions first.** Read the names and descriptions of existing skills (Kai's skills folder, plus any `.github/skills/` in the current repo). If an existing skill already owns this job, extend it with `UpdateSkill.md` instead.
- **Pick the shape from the job.** A reference skill (an API's quirks, a library's edge cases) is mostly gotchas. A process skill (deploy, release) needs safety gates and exact tool contracts. A judgment skill (review, analysis) needs a sharp done-state and very little procedure.
- **Names:** folder and `name` in kebab-case, short and specific (`release-notes`, not `notes` or `release-notes-generator-skill`). Workflow and supporting files get clear TitleCase names that say what they do (`Workflows/DraftNotes.md`, `ApiQuirks.md`).
- **Write generic content.** No real names, emails, hostnames, credentials or absolute home-directory paths in the skill. Anything user-specific is something the skill asks for or reads from a location the user configures.
- **Don't create empty structure.** No empty `Workflows/` folder, no placeholder files, no sections with nothing in them.

## Hand-off

When the files are written, run `ValidateSkill.md` against them and report the result. Then offer `TestSkill.md` (does it beat a baseline?) and `OptimizeDescription.md` (does it trigger reliably?).
