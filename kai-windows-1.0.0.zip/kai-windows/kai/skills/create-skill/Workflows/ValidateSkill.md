# ValidateSkill

Check a skill against Kai's spec and report COMPLIANT or NON-COMPLIANT with a concrete fix for each failure. When the user asks to fix or clean up the skill, apply the fixes too, then re-run the checklist.

## Checklist

### Frontmatter
- [ ] Exactly two fields: `name` and `description`. No `version`, `triggers`, `workflows` or other keys.
- [ ] `name` matches the folder name exactly, and is lowercase letters, digits and hyphens only.
- [ ] `description` is a single paragraph (no `|` block scalar), under 1024 characters measured, not estimated.
- [ ] `description` states what the skill produces and contains `Use when ...` followed by concrete phrases a user would actually say.
- [ ] If another skill shares vocabulary, `description` has a `NOT FOR ...` clause naming that territory.

### Structure
- [ ] `SKILL.md` sits at the skill root.
- [ ] At most one subfolder level: `Workflows/<Name>.md` is fine; `Workflows/Group/<Name>.md` is not. Flatten nested files by folding the group into the filename (`Workflows/CompanyDueDiligence.md`).
- [ ] Supporting reference files sit in the skill root, not in `Docs/`, `Context/` or `Resources/` folders.
- [ ] Workflow and supporting files have clear TitleCase names; no backups, scratch files or empty folders inside the skill.

### Routing
- [ ] Every file in `Workflows/` has an entry in the `SKILL.md` routing table.
- [ ] Every path referenced from `SKILL.md` (workflows and supporting files) exists, with matching case.
- [ ] There is one routing table, not two that disagree.

### Content (see `../AuthoringStandard.md`)
- [ ] `SKILL.md` is a lean router: purpose, done-state, routing, gotchas. Long method detail lives in workflows or supporting files.
- [ ] Open-ended cognitive work is expressed as outcomes and constraints, not numbered step choreography.
- [ ] Every procedural line passes the test "would a smarter model make this unnecessary?" or belongs to a keep-class (safety gate, verified gotcha, tool contract, output-format contract).
- [ ] No emphasis-only lines (`MANDATORY`, `CRITICAL`, restated rules).
- [ ] Gotchas, where present, describe real observed failures, not hypotheticals.

### Personal data and secrets
- [ ] No personal or private data in any file in the skill.

Check this with a plain text search across every file in the skill folder, not by reading and eyeballing. Search for:

- the user's name, handle and any other names from the conversation that aren't public citations;
- email addresses (a pattern like `[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}`);
- absolute home-directory paths: Windows `C:\Users\<name>\`, macOS `/Users/<name>/`, and the Linux equivalent under the root home folder;
- hostnames, internal IPs and private repository URLs;
- credential shapes: `api_key`, `token`, `secret`, `password`, `Bearer `, and long random-looking strings.

On Windows, `Select-String -Path <skill>\* -Recurse -Pattern '<regex>'` in PowerShell (or `rg -i '<regex>' <skill>`) does it; elsewhere `grep -rniE '<regex>' <skill>`. Any hit fails the check unless it is clearly a placeholder (`<name>`, `user@example.com`) or generic English. Fix by replacing the value with a placeholder or by having the skill ask for it at run time. Environment variable names are fine; values never are.

## Report shape

```
<skill-name>: COMPLIANT | NON-COMPLIANT
Failures:
- <check>: <what's wrong> -> <fix>
Personal-data search: <patterns run> -> <hits or "clean">
```
