# OptimizeDescription

Make a skill's description trigger on the prompts it should and stay quiet on the ones it shouldn't, measured before and after.

## Done looks like

- An eval set of about 20 realistic queries, roughly half should-trigger and half should-not, reviewed by the user.
- A measured accuracy for the current description and for the rewrite, with false negatives, false positives and inconsistent verdicts listed by query.
- A final description under 1024 characters, shown to the user before it is written into `SKILL.md`.

## Building the eval set

- **Should-trigger queries** vary phrasing: formal and casual, with and without the skill's own vocabulary, uncommon jobs the skill handles, and cases where it competes with a neighbor and should win.
- **Should-not-trigger queries** are near misses: same keywords or domain, but a different job, or a job another skill owns. "Write a fibonacci function" as a negative for a release-notes skill tests nothing; "update CHANGELOG.md with this fix" tests something.
- **Realistic means specific**: concrete file names, context, mixed lengths, the occasional typo. Show the set to the user so they can drop unrealistic queries, add cases they've hit, and flip labels they disagree with.

Example pair for a `release-notes` skill:

```json
[
  {"query": "can you turn everything we merged since v2.3 into notes I can paste into the GitHub release", "should_trigger": true},
  {"query": "add a line to CHANGELOG.md for the auth timeout fix", "should_trigger": false}
]
```

## Measuring

Collect the `name` and `description` of every skill the model would see (Kai's skills folder plus any repo `.github/skills/`), so the test reflects real competition. Then use the `task` tool, or dispatch to `@kai-reviewer`, with one batched prompt containing all the name/description pairs and all queries, asking for exactly this output:

```json
[{"query": "...", "verdict": "TRIGGER: <skill-name>"}, {"query": "...", "verdict": "NO_TRIGGER"}]
```

Run the batch twice in parallel. A should-trigger query is correct only if the target skill fired; a should-not query is correct if nothing fired or a different, appropriate skill did. Flag any query where the two runs disagree; inconsistency means the description sits on a boundary for that intent.

## Rewriting

- **False negatives**: the description is missing that intent. Add the phrasing people actually use, not a synonym of one already there.
- **False positives**: the description is too broad or overlaps a neighbor. Narrow what the skill claims to produce, and add or sharpen the `NOT FOR` clause.
- **Confusion with a named skill**: fix both sides. Each description's `NOT FOR` should point at the other.
- Follow the shape in `../AuthoringStandard.md`, and re-measure length after every edit.

Re-run the same eval set on the rewrite. Stop at roughly 85% or better, or after three rounds, since more rounds start fitting the description to the eval set. If accuracy drops, revert and try a different angle. Report before and after:

```
Before: <n>%  false negatives: <queries>  false positives: <queries>
After:  <n>%  false negatives: <queries>  false positives: <queries>
```

Simple one-step prompts may not trigger any skill even with a perfect description, because the model just answers them. That is expected; keep eval queries substantive enough that a skill would genuinely help.
