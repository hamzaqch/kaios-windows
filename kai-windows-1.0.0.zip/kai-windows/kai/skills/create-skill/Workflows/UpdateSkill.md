# UpdateSkill

Change an existing skill (add a workflow or supporting file, revise triggers, rename) and leave it as valid as it was before, or more so.

## Done looks like

- The requested change is made, and the skill still passes every check in `ValidateSkill.md`.
- New workflow files are listed in the `SKILL.md` routing table; removed ones are gone from it; no reference points at a missing file.
- New content follows `../AuthoringStandard.md`. Don't match the old style if the old style is choreography.
- If the description changed, its length is re-measured and still under 1024 characters.

## Constraints

- **Read the whole skill before editing it**: `SKILL.md`, every workflow, every supporting file. Changes that ignore an existing gotcha or duplicate an existing workflow are the common failure here.
- **Renames touch everything at once.** Renaming a skill means renaming the folder, the `name` field, and every place another skill or doc refers to `/<old-name>`. Search for the old name across the skills folder before calling it done. A rename changes the slash command users type, so confirm it with the user before doing it.
- **Removing a workflow or narrowing triggers changes behavior users rely on.** Confirm before doing either.
- **A new workflow earns its own file only if it has distinct method content.** If it is a variation on an existing one, extend that file.
- **Trigger changes go through measurement.** After a meaningful description change, offer `OptimizeDescription.md` to confirm it didn't trade one set of misses for another.

Finish by running `ValidateSkill.md` and reporting what changed.
