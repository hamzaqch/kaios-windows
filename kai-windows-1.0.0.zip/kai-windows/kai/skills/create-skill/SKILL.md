---
name: create-skill
description: "Create, edit, validate, test and improve Agent Skills for GitHub Copilot: scaffolds a SKILL.md with correct name and description frontmatter, adds workflows and supporting files, checks structure and personal-data hygiene, measures whether a skill triggers on the right prompts, and rewrites weak skill bodies in ideal-state style. Use when the user says create a skill, new skill, make a skill for X, build a skill, scaffold a skill, add a workflow to a skill, edit or update or rename a skill, fix skill frontmatter, validate a skill, check a skill, clean up a skill's structure, test a skill, does this skill work, improve a skill, skill output is weak, optimize a skill description, skill not triggering, skill fires too often, or skill overtriggering. NOT FOR writing custom agent profiles, general prompt engineering for one-off prompts, or building standalone CLI tools."
---
# Kai create-skill

Owns the whole lifecycle of a skill: **structure** (create, update, validate) and **effectiveness** (test, improve, optimize the description). A skill is done when it triggers on the prompts it should, stays quiet on the ones it shouldn't, measurably beats a no-skill baseline, and passes the checklist in `Workflows/ValidateSkill.md`.

Before writing or rewriting any skill body, read `AuthoringStandard.md`. It is the standard every workflow here holds output to, and the standard this skill itself follows.

## The spec Kai targets

- A skill is a folder whose name is the skill's kebab-case slash-command name: `~/.copilot/kai/skills/<kebab-name>/` (Windows: `%USERPROFILE%\.copilot\kai\skills\<kebab-name>\`). Project-scoped skills can also live in a repository's `.github/skills/<kebab-name>/`.
- `SKILL.md` frontmatter has exactly two fields: `name` (identical to the folder name; lowercase letters, digits and hyphens) and `description` (one paragraph, under 1024 characters, containing `Use when ...` followed by concrete trigger phrases). Nothing else is required, so add nothing else.
- Optional: supporting `.md` files in the skill root, and one `Workflows/` folder one level deep. Nothing nests deeper.

## Workflow routing

| Workflow | Trigger | File |
|---|---|---|
| CreateSkill | "create a skill", "new skill", "make a skill for X" | `Workflows/CreateSkill.md` |
| UpdateSkill | "add a workflow", "edit/update/rename a skill", "change the triggers" | `Workflows/UpdateSkill.md` |
| ValidateSkill | "validate", "check this skill", "fix the structure", "clean up this skill" | `Workflows/ValidateSkill.md` |
| CanonicalizeSkill | "canonicalize", "restructure this skill", "bring this skill up to standard", "migrate a skill from another tool" | `Workflows/CanonicalizeSkill.md` |
| TestSkill | "test this skill", "does this skill help", "skill not working" | `Workflows/TestSkill.md` |
| ImproveSkill | "improve this skill", "output is weak/too rigid/too verbose" | `Workflows/ImproveSkill.md` |
| OptimizeDescription | "not triggering", "fires too often", "optimize the description" | `Workflows/OptimizeDescription.md` |

Natural chain for a new skill: CreateSkill, then ValidateSkill, then TestSkill and OptimizeDescription, looping through ImproveSkill until results hold.

## Gotchas

- **The description is the only thing loaded before invocation.** A strong body behind a vague description never runs. Spend real effort on the description, and re-measure its length after every edit; 1024 characters is a hard cap.
- **`name` must match the folder exactly.** A mismatch (`CreateSkill` folder, `create-skill` name, or a stray capital) means the skill silently fails to register or registers under the wrong slash command.
- **Simple one-step prompts often don't trigger any skill**, because the model just answers them. Trigger tests that use trivial prompts under-report how well a description works; use substantive, realistic prompts.
- **Reading these workflows and imitating them by hand still counts as using the skill.** Hold the result to the same checklist; don't skip validation because the skill "looks fine".

## Examples

```
User: "Make a skill for drafting release notes from merged PRs"
-> CreateSkill: pin the done-state, pick the kebab name release-notes, write
   name + description + an ideal-state body, run ValidateSkill, then offer TestSkill.

User: "My deploy-check skill never fires when I say 'is prod healthy'"
-> OptimizeDescription: build a should/shouldn't-trigger set, measure the current
   description with a task call, rewrite with the missing intents and a NOT FOR
   clause, re-measure, show before/after.

User: "The code-review skill output is a wall of rules nobody reads"
-> ImproveSkill: diagnose over-specified choreography, cut to outcomes + constraints
   + keep-classes, then TestSkill against the previous version.
```
