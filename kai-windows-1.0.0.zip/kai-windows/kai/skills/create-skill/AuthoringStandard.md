# Authoring standard

The standard for every skill body, workflow and description Kai writes. Every workflow in this skill checks output against it.

## Write the ideal state, not the choreography

A skill body says three things:

1. **WHAT done looks like**, as testable outcomes. "The report lists every failing check with its file and line, and nothing that passed" can be verified. "Be thorough" cannot.
2. **CONSTRAINTS**: what must or must not happen, and why.
3. **TOOLS**: what is available and how to call it when the call itself is non-obvious.

Then trust the model with HOW. Numbered step-lists that walk a capable model through open-ended thinking ("Step 1: understand the request. Step 2: consider alternatives...") are scaffolding. They cap what a strong model would do on its own, they get followed rigidly where judgment was needed, and they rot as models improve.

### The four keep-classes

Some HOW does belong in a skill. Procedural lines are legitimate when they are one of these:

| Keep-class | What it is | Example |
|---|---|---|
| **Safety gate** | A check that must happen before an irreversible or outward-facing action | "Show the diff and get a yes before force-pushing." |
| **Verified gotcha** | A failure that actually happened and that the model will repeat without being told | "The export API returns 200 with an empty body when the token is expired; check the body length." |
| **Tool contract** | The exact invocation of a tool whose flags, ordering or quirks can't be guessed | "Call the migration tool with `--dry-run` first; it has no undo." |
| **Output-format contract** | A shape something downstream parses or a reader depends on | "Return a JSON array of `{query, verdict}` and nothing else." |

**The test for any procedural line:** would a smarter model make this rule unnecessary? Yes means cut it. No means it is a keep-class; keep it, and say why.

### Writing rules that follow from this

- **Don't state the obvious.** Keep only what changes the model's default behavior. If it would do the right thing untold, the line is noise.
- **Explain the why.** "Lead with the finding; readers decide in the first ten seconds whether to keep reading" adapts to new situations. "ALWAYS use 3 bullets" produces compliant, lifeless output.
- **Say it once.** `MANDATORY`, `CRITICAL`, all caps and a third restatement add volume, not constraint. Delete any line whose only content is emphasis on a rule stated elsewhere. "Best practices" and "tips" sections tend to collect this filler.
- **Generalize, don't overfit.** Fix the pattern behind a failure, not the specific test prompt that exposed it.
- **Match freedom to fragility.** A database migration needs exact commands; a code review needs direction and a done-state.
- **Keep it lean.** `SKILL.md` is a router: what the skill is for, the done-state, the routing table, gotchas. Full method detail lives in `Workflows/` or in supporting `.md` files in the skill root, which the model reads when it needs them. If `SKILL.md` passes a few hundred lines, move detail out.

### Gotchas sections

A `## Gotchas` section is where verified-gotcha lines live, and it is usually the highest-value part of a mature skill. Add an entry every time the skill fails in a way a future run would repeat. A new skill with no known failures can omit the section rather than carry a placeholder.

## Writing the description

The description is read by the model, not a human, and it is the only part of the skill loaded before the model decides whether to invoke it. Shape:

```
<What it does, in one or two sentences, naming its concrete outputs>. Use when <the user says / the task involves> <trigger phrase>, <trigger phrase>, <trigger phrase>, ... NOT FOR <adjacent task> (use /<other-skill>), <adjacent task>.
```

- **Triggers are things people actually say**, including casual and indirect phrasings: "is prod healthy", "why is the site slow", not just "health check".
- **Lean slightly pushy.** Models undertrigger more often than they overtrigger. Name the situations where the skill helps even if the user wouldn't name it.
- **Use `NOT FOR` to settle collisions.** When two skills share vocabulary, each one's `NOT FOR` clause names the other's territory. For example a `release-notes` skill: `NOT FOR changelog file maintenance (use /changelog) or marketing announcements.`
- **Stay under 1024 characters total.** Spend the budget on distinct intents, not synonyms of the same one.

Signals to watch after shipping: **undertriggering** shows up as the user invoking the skill by slash command after it should have fired on its own. **Overtriggering** shows up as the skill loading for unrelated work, or the user asking for it to stop.
