---
name: cs
description: "Shortcut for /context-search: search prior work (task ISAs, project ISAs, session logs, past Copilot sessions) to ground a request in what was already done, or browse previous sessions on a topic or date phrase. Use when the user types /cs, cs <topic>, or asks to search prior work, what did we do about X, find that session, pick up where we left off. NOT FOR curated knowledge notes (use /cortex) or the web (use /research)."
argument-hint: "<topic or date phrase>"
---
# cs: context-search shortcut

Thin alias. Read `$HOME/.copilot/skills/context-search/SKILL.md` and follow it with the same arguments. Its core command is:

```
python "$HOME/.copilot/skills/cortex/tools/cortex.py" recall "<arguments>" --limit 10
```

If no arguments were given, the topic defaults to what this conversation is about; on a fresh session with no topic, ask for one in one line.
