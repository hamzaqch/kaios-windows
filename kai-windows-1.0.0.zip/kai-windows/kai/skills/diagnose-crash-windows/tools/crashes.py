"""diagnose-crash-windows: read-only crash evidence from the Windows event logs, Windows Error
Reporting and dump folders. Stdlib Python 3.8+ driving Windows PowerShell 5.1 (Get-WinEvent).
Event properties come back raw and all parsing happens here, so the logic is testable off Windows.

    python crashes.py list    [--days 7] [--app NAME] [--limit 30] [--json]   app crashes, hangs, .NET failures
    python crashes.py system  [--days 30] [--json]      blue screens, unexpected restarts, GPU resets, hardware/disk errors
    python crashes.py summary [--days 30] [--json]      crashes grouped by app + module + code, with counts and dates
    python crashes.py wer     [--limit 20] [--app NAME] [--json]   Windows Error Reporting reports on disk
    python crashes.py dumps   [--json]                  minidumps, MEMORY.DMP and per-app LocalDumps settings
    python crashes.py code    <hex>                     explain an exception or bugcheck code

Read-only: nothing here deletes reports or dumps, changes WER settings or restarts anything.
Exit codes: 0 ok, 1 collection failed, 2 usage.
"""
import argparse
import base64
import datetime as _dt
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

EXCEPTION_CODES = {
    0xC0000005: ("ACCESS_VIOLATION", "read, write or execute at an invalid address: a bug (null or dangling pointer) or memory corruption, sometimes from injected third-party code"),
    0xC0000006: ("IN_PAGE_ERROR", "a page could not be read from disk or the network: storage, network share or failing drive, not the app's logic"),
    0xC0000017: ("NO_MEMORY", "an allocation failed: check commit charge and leaks"),
    0xC000001D: ("ILLEGAL_INSTRUCTION", "executed an invalid instruction: corruption, or a binary built for CPU features this machine lacks"),
    0xC0000094: ("INTEGER_DIVIDE_BY_ZERO", "integer division by zero: an app bug"),
    0xC0000096: ("PRIVILEGED_INSTRUCTION", "executed a privileged instruction: corruption or a bad jump"),
    0xC00000FD: ("STACK_OVERFLOW", "the thread ran out of stack: runaway recursion or a huge stack allocation"),
    0xC000012D: ("COMMITMENT_LIMIT", "the system commit limit was reached: out of virtual memory (RAM plus page file)"),
    0xC0000135: ("DLL_NOT_FOUND", "a required DLL is missing: reinstall the app or its runtime (VC++ redistributable, .NET)"),
    0xC0000142: ("DLL_INIT_FAILED", "a DLL failed to initialise: often a broken runtime, a desktop-heap limit, or security software interfering"),
    0xC0000194: ("POSSIBLE_DEADLOCK", "a critical-section wait timed out: a deadlock"),
    0xC0000374: ("HEAP_CORRUPTION", "the heap manager detected corruption: the bug happened earlier than the crash; reproduce under Application Verifier or page heap"),
    0xC0000409: ("STACK_BUFFER_OVERRUN / FAIL_FAST", "a fast-fail: either a /GS stack-cookie check or a deliberate __fastfail (abort, std::terminate, invalid parameter). Read the faulting module and any accompanying event"),
    0xC0000417: ("INVALID_CRT_PARAMETER", "the C runtime rejected an argument: an app bug"),
    0xC0000420: ("ASSERTION_FAILURE", "an assertion fired"),
    0xC0000602: ("FAIL_FAST_EXCEPTION", "a deliberate fail-fast: the code chose to terminate"),
    0xC06D007E: ("DELAYLOAD_MODULE_NOT_FOUND", "a delay-loaded DLL is missing"),
    0xE0434352: (".NET CLR EXCEPTION", "an unhandled .NET exception: the .NET Runtime event 1026 next to it has the exception type and stack"),
    0xE06D7363: ("C++ EXCEPTION", "an uncaught MSVC C++ exception (throw with no catch)"),
    0x80000003: ("BREAKPOINT", "a hard-coded breakpoint or assert: usually deliberate, the code hit a 'should never happen' path"),
    0x40000015: ("FATAL_APP_EXIT", "abort() or a fatal-exit call: the program chose to quit"),
    0xC000041D: ("FATAL_USER_CALLBACK_EXCEPTION", "an exception escaped a window-procedure or kernel callback"),
}

BUGCHECKS = {
    0x0A: ("IRQL_NOT_LESS_OR_EQUAL", "a driver touched pageable memory at too high an IRQL: driver bug, sometimes RAM"),
    0x19: ("BAD_POOL_HEADER", "kernel pool corruption: a driver bug"),
    0x1A: ("MEMORY_MANAGEMENT", "memory manager corruption: RAM (test it) or a driver"),
    0x1E: ("KMODE_EXCEPTION_NOT_HANDLED", "a kernel-mode exception nobody caught: driver"),
    0x3B: ("SYSTEM_SERVICE_EXCEPTION", "an exception in a system call: driver, often GPU or security software"),
    0x4E: ("PFN_LIST_CORRUPT", "page-frame database corruption: RAM or driver"),
    0x50: ("PAGE_FAULT_IN_NONPAGED_AREA", "invalid kernel memory reference: driver, RAM or antivirus filter"),
    0x77: ("KERNEL_STACK_INPAGE_ERROR", "kernel stack page couldn't be read: storage"),
    0x7A: ("KERNEL_DATA_INPAGE_ERROR", "kernel data page couldn't be read: storage, cable or failing drive"),
    0x7E: ("SYSTEM_THREAD_EXCEPTION_NOT_HANDLED", "a system thread threw: driver named in the dump"),
    0x9F: ("DRIVER_POWER_STATE_FAILURE", "a driver hung during sleep, wake or power transition"),
    0xC2: ("BAD_POOL_CALLER", "a driver misused the pool allocator"),
    0xC4: ("DRIVER_VERIFIER_DETECTED_VIOLATION", "Driver Verifier caught a driver; it is on and doing its job"),
    0xD1: ("DRIVER_IRQL_NOT_LESS_OR_EQUAL", "a driver accessed bad memory at high IRQL: often network, storage or GPU drivers"),
    0xEA: ("THREAD_STUCK_IN_DEVICE_DRIVER", "a GPU driver spun forever"),
    0xEF: ("CRITICAL_PROCESS_DIED", "a critical system process exited: disk corruption, malware, or a bad update"),
    0x101: ("CLOCK_WATCHDOG_TIMEOUT", "a CPU core stopped responding: overclock, CPU, firmware or hypervisor issue"),
    0x116: ("VIDEO_TDR_FAILURE", "the GPU didn't recover from a reset: GPU driver, overclock, heat or power"),
    0x117: ("VIDEO_TDR_TIMEOUT_DETECTED", "a GPU reset was recorded (live dump, no crash)"),
    0x124: ("WHEA_UNCORRECTABLE_ERROR", "the hardware reported a fatal error: CPU, RAM, PCIe device, overclock, heat or power"),
    0x133: ("DPC_WATCHDOG_VIOLATION", "a driver ran too long at DPC level: storage (often SSD firmware/AHCI/NVMe drivers) or network"),
    0x139: ("KERNEL_SECURITY_CHECK_FAILURE", "kernel corruption detected: driver or RAM"),
    0x141: ("VIDEO_ENGINE_TIMEOUT_DETECTED", "a GPU engine timed out (live dump)"),
    0x1001: ("(live kernel event)", "a non-fatal kernel report"),
}

MODULE_HINTS = [
    (r"^ntdll\.dll$", "ntdll: the crash surfaced in Windows' loader/heap code; with HEAP_CORRUPTION it is the app's bug, detected late"),
    (r"^kernelbase\.dll$", "KERNELBASE: usually an exception the program raised and never caught (C++, .NET or RaiseException)"),
    (r"^ucrtbase\.dll$|^msvcr\d+\.dll$|^vcruntime\d+\.dll$|^msvcp\d+\.dll$", "C runtime: the program called abort(), terminate() or hit an invalid parameter"),
    (r"^(clr|coreclr|clrjit)\.dll$", ".NET runtime: read the .NET Runtime event 1026 for the managed exception"),
    (r"^(nvwgf2umx|nvwgf2um|nvoglv64|nvd3dumx|nvldumdx|nvcuda|nvlddmkm)", "NVIDIA graphics driver: update or clean-reinstall the GPU driver; check for overclocks"),
    (r"^(atio6axx|atidxx64|amdxx64|amdxc64|aticfx64|atiumd)", "AMD graphics driver: update or clean-reinstall the GPU driver"),
    (r"^(igd10iumd|igd12umd|ig\d+icd|igc64|igdumdim)", "Intel graphics driver: update the GPU driver (OEM or Intel)"),
    (r"^(d3d11|d3d12|dxgi|d3d9)\.dll$", "Direct3D runtime: usually the GPU driver or the app's rendering code underneath"),
    (r"^(rtsshooks64|rtsshooks|gameoverlayrenderer64|gameoverlayrenderer|nvspcap64|discordhook64|overlay64|obs-graphics-hook)", "a third-party overlay or capture hook injected into the process: test with the overlay disabled"),
    (r"^unknown$", "unknown module: execution jumped to an address with no module (corruption, or code from an unloaded plugin)"),
]

APP_PROVIDERS = {"Application Error", "Application Hang", "Windows Error Reporting", ".NET Runtime"}

PS_EVENTS = r"""
$ErrorActionPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false } catch {}
$start = (Get-Date).AddDays(-__DAYS__)
function Pack($e) {
  $msg = $e.Message
  if ($msg -and $msg.Length -gt 1500) { $msg = $msg.Substring(0, 1500) }
  [ordered]@{ time = $e.TimeCreated.ToString('o'); log = $e.LogName; id = $e.Id; provider = $e.ProviderName; level = $e.Level; props = @($e.Properties | ForEach-Object { [string]$_.Value }); message = $msg }
}
$out = [ordered]@{ events = @() }
__QUERIES__
ConvertTo-Json -InputObject $out -Depth 5 -Compress
"""

QUERY_APP = r"""
$out.events += @(Get-WinEvent -FilterHashtable @{ LogName = 'Application'; Id = 1000, 1001, 1002, 1026; StartTime = $start } -MaxEvents 400 | ForEach-Object { Pack $_ })
"""

QUERY_SYSTEM = r"""
$out.events += @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 41, 1001, 6008, 4101; StartTime = $start } -MaxEvents 300 | ForEach-Object { Pack $_ })
$out.events += @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-WHEA-Logger'; StartTime = $start } -MaxEvents 100 | ForEach-Object { Pack $_ })
$out.events += @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'disk', 'Ntfs', 'stornvme', 'storahci', 'volmgr'; Level = 1, 2, 3; StartTime = $start } -MaxEvents 100 | ForEach-Object { Pack $_ })
"""


class CollectError(Exception):
    pass


# ---------------------------------------------------------------------------
# Collection
# ---------------------------------------------------------------------------

def powershell_exe():
    for name in ("powershell", "powershell.exe", "pwsh"):
        p = shutil.which(name)
        if p:
            return p
    return None


def build_events_script(days, app=True, system=False):
    queries = (QUERY_APP if app else "") + (QUERY_SYSTEM if system else "")
    return PS_EVENTS.replace("__DAYS__", str(int(days))).replace("__QUERIES__", queries)


def run_ps(script, timeout=90):
    exe = powershell_exe()
    if not exe:
        raise CollectError("Windows PowerShell not found; this skill runs on Windows (PowerShell 5.1)")
    encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    try:
        r = subprocess.run([exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-EncodedCommand", encoded], capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise CollectError("PowerShell timed out after %ss" % timeout)
    except OSError as e:
        raise CollectError("could not start PowerShell: %s" % e)
    raw = r.stdout.decode("utf-8", errors="replace").strip()
    start = raw.find("{")
    if start < 0:
        raise CollectError("PowerShell returned no JSON (exit %s): %s"
                           % (r.returncode, r.stderr.decode("utf-8", errors="replace").strip()[:300]))
    try:
        return json.loads(raw[start:])
    except ValueError as e:
        raise CollectError("could not parse PowerShell output: %s" % e)


def fetch_events(days, app=True, system=False, runner=None):
    runner = runner or run_ps
    data = runner(build_events_script(days, app, system), 90)
    ev = data.get("events") if isinstance(data, dict) else None
    if ev is None:
        return []
    return ev if isinstance(ev, list) else [ev]


# ---------------------------------------------------------------------------
# Parsing (pure)
# ---------------------------------------------------------------------------

def parse_hex(s):
    if s is None:
        return None
    s = str(s).strip().lower()
    if not s:
        return None
    try:
        if s.startswith("0x"):
            return int(s, 16)
        if re.fullmatch(r"[0-9a-f]+", s) and re.search(r"[a-f]", s):
            return int(s, 16)
        if re.fullmatch(r"\d+", s):
            # Event 1000 writes exception codes as bare hex digits ("c0000005", "80000003").
            return int(s, 16) if len(s) == 8 else int(s)
        return None
    except ValueError:
        return None


def explain_code(code):
    if code is None:
        return None
    if code in EXCEPTION_CODES:
        name, why = EXCEPTION_CODES[code]
        return {"code": "0x%08X" % code, "name": name, "meaning": why, "kind": "exception"}
    if code in BUGCHECKS:
        name, why = BUGCHECKS[code]
        return {"code": "0x%X" % code, "name": name, "meaning": why, "kind": "bugcheck"}
    if code & 0xFFFF0000 == 0x10000000 and (code & 0xFFFF) in BUGCHECKS:
        name, why = BUGCHECKS[code & 0xFFFF]
        return {"code": "0x%X" % code, "name": name + " (variant)", "meaning": why, "kind": "bugcheck"}
    return {"code": "0x%X" % code, "name": "unknown", "meaning": "not in the local table; search the exact code", "kind": "unknown"}


def parse_code_arg(s):
    """Codes typed by people are hex, with or without 0x ("124", "0x9F", "c0000005")."""
    s = (s or "").strip().lower()
    if s.startswith("0x"):
        s = s[2:]
    try:
        return int(s, 16) if s else None
    except ValueError:
        return None


def module_hint(module):
    m = (module or "").strip().lower()
    for pat, hint in MODULE_HINTS:
        if re.search(pat, m):
            return hint
    return None


def prop(props, i):
    return props[i] if props and len(props) > i and props[i] not in ("", None) else None


def parse_app_event(e):
    props = e.get("props") or []
    if not isinstance(props, list):
        props = [props]
    pid_, provider, msg = e.get("id"), e.get("provider") or "", e.get("message") or ""
    base = {"time": e.get("time"), "event_id": pid_, "provider": provider}
    if provider == "Application Error" and pid_ == 1000:
        code = parse_hex(prop(props, 6))
        return dict(base, kind="crash", app=prop(props, 0), app_version=prop(props, 1),
                    module=prop(props, 3), module_version=prop(props, 4), code=code,
                    code_info=explain_code(code), offset=prop(props, 7), pid=parse_hex(prop(props, 8)),
                    app_path=prop(props, 10), module_path=prop(props, 11), report_id=prop(props, 12),
                    package=prop(props, 13), module_hint=module_hint(prop(props, 3)))
    if provider == "Application Hang" and pid_ == 1002:
        return dict(base, kind="hang", app=prop(props, 0), app_version=prop(props, 1),
                    app_path=prop(props, 5), code=None, module=None)
    if provider == ".NET Runtime" and pid_ == 1026:
        app = re.search(r"Application:\s*(\S+)", msg)
        exc = re.search(r"Exception Info:\s*([\w.`]+)", msg)
        return dict(base, kind="dotnet", app=app.group(1) if app else None,
                    exception=exc.group(1) if exc else None, code=0xE0434352,
                    code_info=explain_code(0xE0434352), module=None,
                    detail=msg[:600])
    if provider == "Windows Error Reporting" and pid_ == 1001:
        event_name = prop(props, 2)
        p = [prop(props, i) for i in range(5, 15)]
        rec = dict(base, kind="wer", bucket=prop(props, 0), wer_event=event_name, app=p[0], module=None, code=None)
        if event_name in ("APPCRASH", "BEX", "BEX64"):
            rec["module"] = p[3]
            code = parse_hex(p[6])
            rec.update(code=code, code_info=explain_code(code), module_hint=module_hint(p[3]))
        return rec
    return None


def parse_system_event(e):
    props = e.get("props") or []
    if not isinstance(props, list):
        props = [props]
    eid, provider, msg = e.get("id"), e.get("provider") or "", e.get("message") or ""
    base = {"time": e.get("time"), "event_id": eid, "provider": provider}
    if eid == 41 and "Kernel-Power" in provider:
        bc = parse_hex(prop(props, 0)) if prop(props, 0) not in (None, "0") else 0
        if prop(props, 0) and re.fullmatch(r"\d+", str(prop(props, 0))):
            bc = int(prop(props, 0))  # Kernel-Power writes the bugcheck code in decimal
        rec = dict(base, kind="unexpected_restart", bugcheck=bc)
        rec["meaning"] = ("the system restarted without a clean shutdown and no bugcheck was recorded: power loss, "
                          "a hard hang, the power button held down, PSU or overheating") if not bc else \
            "restart after a bugcheck (blue screen) 0x%X" % bc
        if bc:
            rec["code_info"] = explain_code(bc)
        return rec
    if eid == 1001 and ("SystemErrorReporting" in provider or "BugCheck" in provider):
        text = prop(props, 0) or msg
        m = re.search(r"0x([0-9a-fA-F]+)\s*\(([^)]*)\)", text or "")
        code = int(m.group(1), 16) if m else None
        dump = prop(props, 1)
        return dict(base, kind="bugcheck", code=code, code_info=explain_code(code),
                    params=m.group(2) if m else None, dump=dump)
    if eid == 6008:
        return dict(base, kind="unexpected_shutdown", meaning="the previous shutdown was unexpected")
    if eid == 4101:
        m = re.search(r"[Dd]isplay driver (\S+) stopped responding", msg)
        drv = (m.group(1) if m else prop(props, 0))
        return dict(base, kind="gpu_reset", driver=drv,
                    meaning="the GPU stopped responding and Windows reset it (TDR): driver, overclock, heat or power")
    if "WHEA" in provider:
        return dict(base, kind="hardware_error", meaning="hardware error reported by the CPU, memory or a PCIe device",
                    detail=msg[:300])
    if provider in ("disk", "Ntfs", "stornvme", "storahci", "volmgr"):
        return dict(base, kind="storage_error", meaning="storage or file-system error", detail=msg[:300])
    return None


def parse_time(t):
    """Event times from PowerShell's ToString('o'): 7 fractional digits and an offset or Z."""
    if not t:
        return None
    t = str(t).strip().replace("Z", "+00:00")
    t = re.sub(r"(\.\d{6})\d+", r"\1", t)
    try:
        d = _dt.datetime.fromisoformat(t)
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=_dt.timezone.utc)


DEDUPE_WINDOW_S = 120


def _wer_twin_kind(r):
    ev = (r.get("wer_event") or "")
    if ev in ("APPCRASH", "BEX", "BEX64"):
        return "crash"
    if ev.lower().startswith(("apphang", "moapphang")):
        return "hang"
    return None


def app_crashes(events, app=None):
    rows = [r for r in (parse_app_event(e) for e in events if e.get("provider") in APP_PROVIDERS) if r]
    # Prefer the Application Error / Application Hang record: drop a WER 1001 report when the
    # same app has a crash (or hang) record within 2 minutes of it, since that is the same event.
    primary = {}
    for r in rows:
        if r["kind"] in ("crash", "hang"):
            primary.setdefault(((r.get("app") or "").lower(), r["kind"]), []).append(parse_time(r.get("time")))
    out = []
    for r in rows:
        if r["kind"] == "wer":
            twin = _wer_twin_kind(r)
            times = primary.get(((r.get("app") or "").lower(), twin), []) if twin else []
            t = parse_time(r.get("time"))
            if t is not None and any(x is not None and abs((x - t).total_seconds()) <= DEDUPE_WINDOW_S
                                     for x in times):
                continue
        if app and app.lower() not in (r.get("app") or "").lower():
            continue
        out.append(r)
    out.sort(key=lambda r: parse_time(r.get("time")) or _dt.datetime.min.replace(tzinfo=_dt.timezone.utc),
             reverse=True)
    return out


def system_events(events):
    rows = [r for r in (parse_system_event(e) for e in events if e.get("log", "System") == "System") if r]
    rows.sort(key=lambda r: r.get("time") or "", reverse=True)
    return rows


def summarize(crashes):
    groups = {}
    for r in crashes:
        key = ((r.get("app") or "?").lower(), (r.get("module") or "-").lower(), r.get("code"), r["kind"])
        g = groups.setdefault(key, {"app": r.get("app") or "?", "module": r.get("module"), "kind": r["kind"],
                                    "code": None if r.get("code") is None else "0x%08X" % r["code"],
                                    "code_name": (r.get("code_info") or {}).get("name"),
                                    "count": 0, "first": r.get("time"), "last": r.get("time"),
                                    "versions": set(), "hint": r.get("module_hint")})
        g["count"] += 1
        t = r.get("time") or ""
        if t and (not g["first"] or t < g["first"]):
            g["first"] = t
        if t and (not g["last"] or t > g["last"]):
            g["last"] = t
        if r.get("app_version"):
            g["versions"].add(r["app_version"])
    out = []
    for g in groups.values():
        g["versions"] = sorted(g["versions"])
        out.append(g)
    out.sort(key=lambda g: g["last"] or "", reverse=True)
    out.sort(key=lambda g: -g["count"])
    return out


def pattern_notes(crashes, sysrows):
    notes = []
    apps = {(r.get("app") or "").lower() for r in crashes if r["kind"] in ("crash", "wer")}
    modules = {}
    for r in crashes:
        if r.get("module"):
            modules.setdefault(r["module"].lower(), set()).add((r.get("app") or "").lower())
    for mod, users in modules.items():
        if len(users) >= 3:
            notes.append("module %s appears in crashes of %d different apps: suspect that shared component (driver, runtime or injected hook), not the apps" % (mod, len(users)))
    if len(apps) >= 5:
        notes.append("%d different apps crashed: look for a common cause (RAM, GPU driver, security software, overclock) before blaming each app" % len(apps))
    kinds = [r["kind"] for r in sysrows]
    if kinds.count("gpu_reset") >= 2:
        notes.append("%d GPU resets (event 4101): GPU driver, overclock, heat or power" % kinds.count("gpu_reset"))
    if "hardware_error" in kinds:
        notes.append("WHEA hardware errors are present: treat crashes as possibly hardware (RAM, CPU, PCIe, overclock) until ruled out")
    if "storage_error" in kinds:
        notes.append("storage errors are present: check the drive's health (SMART) and cables before chasing software")
    if kinds.count("unexpected_restart") >= 2 and not any(r.get("bugcheck") for r in sysrows if r["kind"] == "unexpected_restart"):
        notes.append("repeated restarts with no bugcheck: power delivery, overheating or a hard hang, not a classic blue screen")
    return notes


# ---------------------------------------------------------------------------
# WER reports and dumps (direct file reads, no PowerShell)
# ---------------------------------------------------------------------------

def read_wer_file(path):
    raw = Path(path).read_bytes()
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        text = raw.decode("utf-16", errors="replace")
    else:
        text = raw.decode("utf-8-sig", errors="replace")
    return parse_wer_text(text)


def parse_wer_text(text):
    kv = {}
    for line in text.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            kv[k.strip()] = v.strip()
    sig = {}
    for k, v in kv.items():
        m = re.fullmatch(r"Sig\[(\d+)\]\.Name", k)
        if m:
            sig[v] = kv.get("Sig[%s].Value" % m.group(1))
    rec = {"event_type": kv.get("EventType"), "friendly": kv.get("FriendlyEventName"),
           "app": sig.get("Application Name") or kv.get("AppName"),
           "app_version": sig.get("Application Version"),
           "module": sig.get("Fault Module Name"), "module_version": sig.get("Fault Module Version"),
           "code_raw": sig.get("Exception Code"), "offset": sig.get("Exception Offset"),
           "app_path": kv.get("AppPath"), "signature": sig}
    code = parse_hex(rec["code_raw"])
    rec["code"] = code
    rec["code_info"] = explain_code(code) if code is not None else None
    rec["module_hint"] = module_hint(rec["module"])
    ft = kv.get("EventTime")
    if ft and ft.isdigit():
        try:
            rec["time"] = (_dt.datetime(1601, 1, 1, tzinfo=_dt.timezone.utc)
                           + _dt.timedelta(microseconds=int(ft) // 10)).isoformat()
        except (OverflowError, ValueError):
            rec["time"] = None
    return rec


def wer_roots():
    roots = []
    pd = os.environ.get("ProgramData") or os.environ.get("PROGRAMDATA")
    la = os.environ.get("LOCALAPPDATA")
    for base in (pd, la):
        if base:
            for sub in ("ReportArchive", "ReportQueue"):
                roots.append(Path(base) / "Microsoft" / "Windows" / "WER" / sub)
    return roots


def wer_reports(roots=None, limit=20, app=None):
    out = []
    for root in roots if roots is not None else wer_roots():
        try:
            dirs = [d for d in root.iterdir() if d.is_dir()]
        except OSError:
            continue
        for d in dirs:
            f = d / "Report.wer"
            if not f.exists():
                continue
            try:
                rec = read_wer_file(f)
                rec["folder"] = str(d)
                rec["mtime"] = f.stat().st_mtime
                rec["files"] = sorted(p.name for p in d.iterdir() if p.is_file())[:20]
            except OSError:
                continue
            if app and app.lower() not in (rec.get("app") or "").lower():
                continue
            out.append(rec)
    out.sort(key=lambda r: r["mtime"], reverse=True)
    return out[:limit]


def dump_inventory():
    sysroot = Path(os.environ.get("SystemRoot") or os.environ.get("SYSTEMROOT") or r"C:\Windows")
    res = {"minidumps": [], "memory_dmp": None, "local_dumps_dir": None}
    md = sysroot / "Minidump"
    try:
        for f in sorted(md.glob("*.dmp"), key=lambda p: p.stat().st_mtime, reverse=True)[:20]:
            st = f.stat()
            res["minidumps"].append({"file": str(f), "kb": round(st.st_size / 1024),
                                     "time": _dt.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds")})
    except OSError as e:
        res["minidumps_error"] = "cannot read %s (%s); an elevated shell may be needed" % (md, e.__class__.__name__)
    full = sysroot / "MEMORY.DMP"
    try:
        if full.exists():
            st = full.stat()
            res["memory_dmp"] = {"file": str(full), "mb": round(st.st_size / 1048576),
                                 "time": _dt.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds")}
    except OSError:
        pass
    la = os.environ.get("LOCALAPPDATA")
    if la:
        d = Path(la) / "CrashDumps"
        if d.exists():
            res["local_dumps_dir"] = {"dir": str(d), "files": sorted(p.name for p in d.glob("*.dmp"))[:20]}
    try:
        import winreg  # noqa: F401  (Windows only)
        res["local_dumps_configured"] = local_dumps_configured()
    except ImportError:
        res["local_dumps_configured"] = None
    return res


def local_dumps_configured():
    import winreg
    key = r"SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps"
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key) as k:
            apps, i = [], 0
            while True:
                try:
                    apps.append(winreg.EnumKey(k, i))
                    i += 1
                except OSError:
                    break
            return {"enabled": True, "per_app": apps}
    except OSError:
        return {"enabled": False, "per_app": []}


# ---------------------------------------------------------------------------
# Rendering and CLI
# ---------------------------------------------------------------------------

def fmt_code(r):
    ci = r.get("code_info")
    return "%s %s" % (ci["code"], ci["name"]) if ci else "-"


def render_list(rows):
    if not rows:
        return "no application crashes, hangs or .NET failures in the window"
    lines = []
    for r in rows:
        t = (r.get("time") or "")[:19].replace("T", " ")
        if r["kind"] == "crash":
            lines.append("%s CRASH  %s %s  module %s  %s" % (t, r.get("app"), r.get("app_version") or "", r.get("module"), fmt_code(r)))
            if r.get("module_hint"):
                lines.append("        hint: %s" % r["module_hint"])
        elif r["kind"] == "hang":
            lines.append("%s HANG   %s %s" % (t, r.get("app"), r.get("app_version") or ""))
        elif r["kind"] == "dotnet":
            lines.append("%s .NET   %s  %s" % (t, r.get("app"), r.get("exception") or ""))
        else:
            lines.append("%s WER    %s %s  %s" % (t, r.get("wer_event"), r.get("app") or "", fmt_code(r) if r.get("code") is not None else ""))
    return "\n".join(lines)


def render_system(rows, notes):
    lines = []
    if not rows:
        lines.append("no blue screens, unexpected restarts, GPU resets, hardware or storage errors in the window")
    for r in rows:
        t = (r.get("time") or "")[:19].replace("T", " ")
        if r["kind"] == "bugcheck":
            lines.append("%s BLUE SCREEN %s  dump: %s" % (t, fmt_code(r), r.get("dump") or "-"))
            if r.get("code_info"):
                lines.append("        %s" % r["code_info"]["meaning"])
        elif r["kind"] == "gpu_reset":
            lines.append("%s GPU RESET   driver %s" % (t, r.get("driver")))
        else:
            lines.append("%s %-11s %s" % (t, r["kind"].upper().replace("_", " ")[:11], r.get("meaning") or ""))
    for n in notes:
        lines.append("PATTERN: %s" % n)
    return "\n".join(lines)


def _utf8_stdio():
    """Windows consoles and pipes default to a legacy code page; never crash on a CJK name or an emoji."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            pass


def main(argv=None):
    _utf8_stdio()
    p = argparse.ArgumentParser(prog="crashes.py", description="Windows crash evidence (read-only)")
    sub = p.add_subparsers(dest="cmd")
    for name in ("list", "system", "summary"):
        s = sub.add_parser(name)
        s.add_argument("--days", type=int, default=7 if name == "list" else 30)
        s.add_argument("--app")
        s.add_argument("--limit", type=int, default=30)
        s.add_argument("--json", action="store_true")
    w = sub.add_parser("wer")
    w.add_argument("--limit", type=int, default=20)
    w.add_argument("--app")
    w.add_argument("--json", action="store_true")
    d = sub.add_parser("dumps")
    d.add_argument("--json", action="store_true")
    c = sub.add_parser("code")
    c.add_argument("hex")
    ns = p.parse_args(argv)
    if not ns.cmd:
        p.print_help()
        return 2
    if ns.cmd == "code":
        info = explain_code(parse_code_arg(ns.hex))
        if not info:
            print("could not read %r as a code" % ns.hex, file=sys.stderr)
            return 2
        print("%s %s: %s" % (info["code"], info["name"], info["meaning"]))
        return 0
    if ns.cmd == "wer":
        rows = wer_reports(limit=ns.limit, app=ns.app)
        if ns.json:
            print(json.dumps(rows, indent=2, ensure_ascii=False))
        elif not rows:
            print("no Windows Error Reporting reports found on disk")
        else:
            for r in rows:
                print("%s %s %s module %s %s" % ((r.get("time") or "")[:19], r.get("event_type"), r.get("app"),
                                                r.get("module") or "-", fmt_code(r)))
                print("        %s" % r["folder"])
        return 0
    if ns.cmd == "dumps":
        inv = dump_inventory()
        print(json.dumps(inv, indent=2, ensure_ascii=False))
        return 0
    if not 1 <= ns.days <= 365:
        print("--days must be 1-365", file=sys.stderr)
        return 2
    try:
        events = fetch_events(ns.days, app=ns.cmd in ("list", "summary"), system=ns.cmd in ("system", "summary"))
    except CollectError as e:
        print("crashes: %s" % e, file=sys.stderr)
        return 1
    crashes = app_crashes(events, ns.app)
    sysrows = system_events(events) if ns.cmd != "list" else []
    if ns.cmd == "list":
        rows = crashes[:ns.limit]
        print(json.dumps(rows, indent=2, ensure_ascii=False) if ns.json else render_list(rows))
    elif ns.cmd == "system":
        notes = pattern_notes([], sysrows)
        if ns.json:
            print(json.dumps({"events": sysrows[:ns.limit], "patterns": notes}, indent=2, ensure_ascii=False))
        else:
            print(render_system(sysrows[:ns.limit], notes))
    else:
        groups = summarize(crashes)
        notes = pattern_notes(crashes, sysrows)
        counts = {}
        for r in sysrows:
            counts[r["kind"]] = counts.get(r["kind"], 0) + 1
        if ns.json:
            print(json.dumps({"days": ns.days, "groups": groups[:ns.limit], "system": counts, "patterns": notes},
                             indent=2, ensure_ascii=False))
        else:
            print("Last %d days: %d app crash/hang records in %d groups; system: %s"
                  % (ns.days, len(crashes), len(groups), ", ".join("%s %d" % kv for kv in sorted(counts.items())) or "clean"))
            for g in groups[:ns.limit]:
                print("  %3dx %-6s %-28s module %-22s %s  last %s" % (g["count"], g["kind"], g["app"][:28], (g["module"] or "-")[:22],
                                                                   g["code_name"] or "", (g["last"] or "")[:10]))
            for n in notes:
                print("PATTERN: %s" % n)
    return 0


if __name__ == "__main__":
    sys.exit(main())
