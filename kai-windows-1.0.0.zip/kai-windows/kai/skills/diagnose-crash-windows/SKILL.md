---
name: diagnose-crash-windows
description: "Diagnose why a program crashed, hung or vanished on Windows 11, or why the PC blue-screened or restarted on its own, from the evidence Windows already keeps: Application Error, Application Hang and .NET Runtime events, Windows Error Reporting reports, Kernel-Power 41 and BugCheck events, GPU resets (event 4101), WHEA hardware and disk errors, minidumps and MEMORY.DMP, symbolized with WinDbg or cdb against the Microsoft symbol server when available. Use when the user says X crashed, X keeps crashing, X closes by itself, X stopped working, not responding, blue screen, BSOD, PC restarted by itself, random reboots, exception code 0xc0000005, faulting module, dump file, why did X crash. NOT FOR slowness without crashes (use /windows-vitals), crashes inside code the user is actively debugging in an IDE, or Linux and macOS."
argument-hint: "[app name | 'blue screen' | exception code]"
---
# Diagnosing a crash on Windows

Work from evidence. The goal is an honest account of what happened, not a plausible story.

Tool: `python "$HOME/.copilot/skills/diagnose-crash-windows/tools/crashes.py"` (stdlib Python driving Windows PowerShell 5.1). It is read-only: it never deletes reports or dumps and never changes Windows Error Reporting settings.

## Establish the facts

Start broad, then narrow:

```
crashes.py summary --days 30      # crashes grouped by app + module + code, plus system events and patterns
crashes.py list --app <name>      # every crash, hang and .NET failure for one app, newest first
crashes.py system --days 30       # blue screens, unexpected restarts, GPU resets, WHEA and disk errors
crashes.py wer --app <name>       # Windows Error Reporting folders on disk (often hold a .hdmp or .mdmp)
crashes.py dumps                  # C:\Windows\Minidump, MEMORY.DMP, %LOCALAPPDATA%\CrashDumps, LocalDumps config
crashes.py code c0000409          # what an exception or bugcheck code means
```

From an app crash record, note: the **app and version**, the **faulting module and version**, the **exception code**, and the **offset**. The faulting module is where the crash surfaced, not necessarily who caused it.

`summary` shows whether this is a one-off or a pattern. One app crashing in one module is different from five apps crashing together, which points at something shared (a GPU driver, security software, RAM, an overclock).

## Rule out the boring causes first

- **Memory:** `/windows-vitals memory`. A process killed by exhausted commit (codes `0xC0000017`, `0xC000012D`, or a crash right as commit hit the limit) isn't a bug in that process.
- **Storage:** `0xC0000006` in an app or bugchecks `0x7A`/`0x77`, plus `disk` or `Ntfs` errors in `system`, mean the drive or a network share failed to deliver a page. Check drive health before chasing software.
- **Hardware:** WHEA errors or bugcheck `0x124` mean the hardware reported a fault. Remove overclocks and XMP/EXPO memory profiles as a test before blaming code.
- **Power and heat:** repeated Kernel-Power 41 with bugcheck 0 means the machine lost power or hard-hung. No blue screen was ever drawn. Think power supply, overheating, or a held power button.

## Correlate against the timeline

The crash timestamp is the most underused piece of evidence. Compare it with:
- **Updates:** `Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 10`, the app's own update history, and the driver date in Device Manager. A crash that starts right after an update points at the update.
- **Events around it:** the System and Application logs a few minutes either side (`Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=$t.AddMinutes(-5); EndTime=$t.AddMinutes(1)}`).
- **What the user was doing:** a file opened, a device plugged in, a monitor woken, a game launched. The command line and the file being worked on often explain the whole thing.
- **Reliability Monitor** (`perfmon /rel`) shows the same history on a timeline the user can read with you.

## Read the whole dump, not just the top frame

When a dump exists (a WER folder's `.hdmp`/`.mdmp`, a LocalDumps `.dmp`, or a minidump for blue screens) and WinDbg (`winget install Microsoft.WinDbg`) or `cdb` from the Debugging Tools for Windows is installed:

```
cdb -z "<dump>" -y "srv*$env:LOCALAPPDATA\symbols*https://msdl.microsoft.com/download/symbols" -c "!analyze -v; ~*kb 20; lm; q"
```

- `!analyze -v` gives the faulting frame, the exception record and the bucket.
- `~*kb` shows every thread's stack. Other threads reveal what work was in flight: an image decode, a plugin load, a GPU submission, a network read.
- `lm` lists loaded modules. Third-party code in the process (overlays, capture hooks, shell extensions, antivirus DLLs) is a common crash source. Flag it, but don't blame it without evidence that it is on the crashing stack.
- For blue screens, open the minidump the same way. `!analyze -v` names the driver it suspects; check that driver's date and version.

Microsoft publishes symbols for Windows binaries; most third-party apps publish none. When frames stay unresolved, say so. **Never invent function names to fill the gap.** An unsymbolized stack still has shape: which module each frame belongs to, and whether it was a UI thread, a worker or a callback.

If there is no dump and the crash repeats, the user can turn on per-app full dumps (Windows Error Reporting `LocalDumps`, an elevated registry change under `HKLM\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps\<app>.exe` with `DumpType` 2). Describe it and let the user decide; this skill does not make that change.

## Dumps hold secrets

A dump is a copy of the process's memory: passwords, tokens, open documents. Copy one only to a fresh folder under `$env:TEMP`, never to a shared or synced location (OneDrive, a repo, a network share), delete your copies when done, and never upload a dump anywhere without the user's explicit say-so.

## Report

1. What crashed, and what it was doing at the time.
2. The most likely mechanism, separating clearly what the evidence **proves** (event fields, dump frames) from what you are **inferring**.
3. Whether it is a one-off or a pattern, with counts and dates from `summary`.
4. What to try next, cheapest first: update or roll back the named driver or app, disable the named overlay, test RAM (Windows Memory Diagnostic or MemTest86), check the drive, collect a full dump for the next occurrence.

## Reporting a bug upstream

When the evidence points at a specific app or driver and the user wants to report it:
- Report to the component that owns the faulting code: the app's issue tracker for its own module, the GPU vendor for a graphics driver module, Microsoft Feedback Hub (Win+F) for a Windows component.
- Include: app and module versions, exception code and offset, the `!analyze -v` bucket if you have it, Windows build (`winver`), steps to reproduce, and how often it happens.
- **Never attach a dump publicly.** Offer it privately only if the maintainer asks and the user agrees, after considering what it may contain.
- Draft the report for the user to send; don't file it yourself.

## Gotchas

- **Event 1000 writes exception codes as bare hex (`c0000005`); Kernel-Power 41 writes bugcheck codes in decimal (`159` is `0x9F`).** The tool converts both; don't reconvert by hand.
- **`0xC0000409` is not always a buffer overrun.** Modern runtimes use the same fast-fail path for `abort()`, `std::terminate` and invalid parameters. Read the module and any .NET or app log before calling it memory corruption.
- **`0xE0434352` is a .NET exception.** The real error is in the `.NET Runtime` event 1026 next to it, which `list` shows.
- **Heap corruption is detected late.** `ntdll.dll` with `0xC0000374` is where the heap noticed, not where the bug wrote.
- **Event messages are localized; event properties aren't.** The tool parses properties, so it works on any display language. The `.NET` exception name is read from the message, which is English-only.
- **The Minidump folder may need an elevated shell to read.** `dumps` says so instead of reporting none.
- **Hangs (event 1002, WER `MoAppHang`) aren't crashes.** The app stopped responding and was closed; look for deadlocks, blocking I/O or a slow network path, not a bad pointer.
