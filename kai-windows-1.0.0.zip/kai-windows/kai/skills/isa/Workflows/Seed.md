# Seed Workflow

Bootstrap a draft project ISA from an existing repository: its README, manifests, structure, recent commits and any spec-shaped files. Use it when a project predates the ISA and needs to come into the system without inventing fiction.

## When to invoke

- At the start of a non-trivial Algorithm run on a project with no `<project>/ISA.md`.
- The user directly when onboarding a project: "seed an ISA for <repo-path>".
- Lazy seeding: a project's first real task triggers Seed before any other workflow.

## Inputs

| Input | Required | Description |
|---|---|---|
| project_path | yes | Repository root, where `ISA.md` will be written |
| name | no | Project name; defaults to the folder name |
| depth | no | Default: the substantial-grade project minimum. A fully fleshed deepest-grade draft only when asked |
| dry_run | no | Default false. True prints the proposed ISA instead of writing it |

## Output

A new `<project_path>/ISA.md` with draft content sourced from the repository, plus a report:

```yaml
status: created | dry_run | exists
path: <project_path>/ISA.md
sources_consulted: [README.md, pyproject.toml, last 30 git commits, docs/SPEC.md]
sections_drafted: [Problem, Vision, Out of Scope, Constraints, Goal, Features, Test Strategy]
sections_skipped: [Principles, Learning, Verification]   # left for the user to author
claim_count: 18
review_required: true
```

## Step 1: Refuse if an ISA already exists

If `<project_path>/ISA.md` exists, stop with `status: exists`. Seed never overwrites; deepen an existing ISA with Interview or Scaffold.

## Step 2: Inventory the repository

Read, in this order:

1. `README.md`: the primary signal for Vision, Goal and sometimes Problem.
2. The package manifest (`pyproject.toml`, `package.json`, `Cargo.toml`, `go.mod`, `*.csproj`…): name, description, dependencies (these inform Constraints: runtime, frameworks).
3. Build and deploy config (CI workflows, Dockerfiles, deploy manifests, compiler configs): more Constraints (runtime, deploy target).
4. The last 30 commits (`git log --oneline -30`): what's actively being built, which informs Features.
5. Spec-shaped files: `PRD.md`, `SPEC.md`, `requirements.md`, `acceptance.*`, `docs/`. These become source material; cite them in Decisions.
6. The top-level folder structure: candidate features (auth/, ui/, api/…).

## Step 3: Draft Problem

Lift a "Why" or "Motivation" section if the README has one. Otherwise infer from the intro: what does this solve that wasn't solved before? 1–3 sentences.

## Step 4: Draft Vision

Lift the README's headline pitch and any "what it's like to use" prose. If the README is dry, leave Vision out and list it in the review reminder ("author Vision: what does euphoric surprise look like for this project?"). Never invent it.

## Step 5: Draft Out of Scope

Mine "not", "out of scope", "we don't", "non-goals" in the README and spec files. If nothing is found, leave the section out and list it in the review reminder.

## Step 6: Draft Constraints

From manifests and config: runtime (a Python version, a Node version, Windows-only), frameworks, deploy targets, dependency rules (zero dependencies, pinned versions).

## Step 7: Draft Goal

If the project has a clear deliverable (a CLI, a site, an app), state it in 1–3 sentences. Otherwise lift the README headline.

## Step 8: Draft claims from tests and acceptance criteria

- If the repo has tests, walk the test names; each is a candidate claim source. Convert to atomic claims and apply the Splitting Test.
- If there's an acceptance file or checklist, port each entry to a claim.
- With **no test suite or acceptance file**, draft 6–10 conservative claims covering build, type-check or lint, and the most obvious functional outcomes from the README. Leave them `[ ]` and add a Decisions row: "Claims ISC-1..N seeded from the README; to be refined by the user."

Always include at least one anti-claim derived from Out of Scope.

## Step 9: Draft Test Strategy

For each claim with an obvious probe (the build command, the test command, a lint run), write the row. Claims without an obvious probe stay listed in the review reminder rather than getting an invented probe.

## Step 10: Draft Features

Group claims into `### F<n> · <name>` blocks from the top-level folders and recent commit themes, each with a one-line `Why:` drawn from the README. Put build, deploy and security invariants in `F0 · Cross-cutting`. Add `(after: ID)` edges only where ordering is obvious from the code.

## Step 11: Skip author-driven sections

Principles, Learning and Verification are author-driven: leave them out (empty sections never appear). Add a final Decisions row: "Seed-generated draft. Run the isa Interview workflow to fill Principles, refine Vision and Goal, and audit the claims."

## Step 12: Write the file

```yaml
---
project: <name>
task: "Project ISA — <name>"
phase: marking
progress: 0/<claim-count>
started: <ISO 8601>
updated: <ISO 8601>
---
```

## Step 13: Surface the review reminder

Report `review_required: true`. Seed produces a **draft**; a human pass is required before the ISA is treated as authoritative, and the first Algorithm run on the project should run Interview to refine it.

## What Seed does NOT do

- **Invent fiction.** An empty README means an empty Vision. Never fabricate to make the document look complete.
- **Score its own output.** Seed produces a draft; Interview produces depth.
- **Run CheckCompleteness.** A seeded ISA is explicitly partial and would fail by design.
- **Commit.** Seed writes the file; the user decides when to commit.

## Failure modes

- **No README:** stop with an error. Seed needs at least one prose source; the user can write a stub README or run Scaffold from a prompt instead.
- **A very large history:** when `git rev-list --count HEAD` is over 5000, sample the latest 100 commits for features rather than walking everything.
- **An existing ISA:** `status: exists`; suggest Interview.
