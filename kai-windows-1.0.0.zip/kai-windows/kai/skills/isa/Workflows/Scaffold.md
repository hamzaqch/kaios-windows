# Scaffold Workflow

Generate a fresh ISA from a prompt: a populated file at the right home, with the sections the work's substance requires. Substance is judged from the work, never declared as a label.

## When to invoke

- At the start of an Algorithm run on substantial work: "scaffold an ISA from: <user message>".
- The user directly: `/isa scaffold <prompt>`.
- Ephemeral feature mode: "extract feature <name> as an ephemeral file from <master-isa-path>".

## Inputs

| Input | Required | Description |
|---|---|---|
| prompt | yes | The user's request, verbatim or distilled (the verbatim part is preserved, see step 2) |
| substance | no | A depth steer from the caller (trivial / substantial / deepest, or plain language like "go heavy"); default is judged from the prompt |
| project | no | A repo root: the ISA goes to `<project>/ISA.md` (extended, never overwritten). Otherwise a task ISA |
| ephemeral_feature | no | Produce a feature slice instead of a full ISA |

## Output

- `<project-root>/ISA.md` when `project` is given (an existing project ISA is read and extended).
- `~/.copilot/kai/MEMORY/WORK/<slug>/ISA.md` otherwise, slug `YYYYMMDD-short-kebab` (`python ~/.copilot/kai/bin/kai.py isa new <slug> "<verbatim goal>"` creates the folder and a starter file).
- `<master-dir>/_ephemeral/<F-id>-<feature>.md` in ephemeral mode (for a task ISA that is `MEMORY/WORK/<slug>/_ephemeral/`).

## Step 1: Pick a template

Read `~/.copilot/skills/isa/Examples/canonical-isa.md` for section headers and tone. For a trivial task read `minimal-isa.md`; for experiential work read `experiential-isa.md`.

## Step 2: Preserve the stated goal, then derive

**The rule:** populate `principal_stated_goal` (frontmatter) AND the first quoted sentence of `## Goal` verbatim, from the same byte-for-byte literal, BEFORE producing any derived section. Derivation (Out of Scope, Constraints, Principles, the rest of the Goal, the claims) follows, anchored to it. If detection doesn't fire, preservation is a no-op.

### 2a: Detect and preserve the literal

| # | Signal | Pattern | Examples |
|---|---|---|---|
| 1 | Named metric + threshold | a quantitative target | "get p95 latency under 200ms" · "open rate above 35%" |
| 2 | Explicit outcome assertion | "I want X" / "achieve X" / "do this" | "I want the dashboard showing all four time horizons" |
| 3 | Completion condition | "until X" / "such that X" | "refactor until tests pass" |
| 4 | Structural or design directive | an explicit verb-object on the system | "unify three skills into one" |

- **Fail-closed minimum-content rule:** a candidate under 6 tokens, or with no propositional content ("make it good", "refactor this"), becomes `principal_stated_goal: null`, and the candidate is logged in a Decisions row. Better silent than anchoring against useless text.
- **Multi-literal:** the first candidate wins; the others become derived Constraints noted `derived_from: principal_stated_goal compound`.

When detection fires and the rule passes:

```yaml
principal_stated_goal: "the verbatim user quote, byte-for-byte"
principal_stated_goal_source: prompt   # prompt | conversation | explicit-revision
principal_stated_goal_signal: <1-4>
principal_stated_goal_locked: <ISO 8601>
```

Copy the quote into `## Goal` as its first sentence, in quotes.

### 2b: Derive the residue

- Explicit wants beyond the literal → Vision and the derived Goal prose.
- Explicit not-wants → Out of Scope.
- Implied not-wants (from the domain or context) → Out of Scope.
- Constraints implied by the domain → Constraints.
- Principles implied by the user's stated preferences ("Your rules" in `copilot-instructions.md`, earlier answers in this conversation) → Principles.

Derived content is anchored to the preserved literal through the `anchors_to` column of Test Strategy.

## Step 3: Ambiguity check

One rule: **could I be wrong about what done means?**

If materially ambiguous (the goal supports two or more readings that lead to materially different builds, or required content can't be scaffolded without speculation): on substantial work ask up to 3 targeted questions; on trivial work prepend `⚠️ Picking X over Y because R; redirect if wrong.` Skip the check in ephemeral mode.

**Question mechanics.** Use Copilot's `ask_user` tool, one question per call, with your recommended answer first. If `ask_user` is unavailable (non-interactive runs), send one message:

```
I have N questions before I scaffold this. The goal is clear on X but underdetermined on Y.
Say `proceed` to scaffold on reasoned defaults; otherwise answer one at a time:

1. <Q1>
2. <Q2>
3. <Q3>
```

Pick from this shape library by which section is thinnest:

| Thinnest section | Question shape |
|---|---|
| Vision / Goal | "When this is done, what do you feel? What would make it a 9 or 10?" |
| Out of Scope | "What would be tempting to add but would distract from the core?" |
| Constraints | "What mandates or things-that-must-not-change bound this?" |
| Test Strategy | "How will you know it worked? What check would prove the goal landed?" |
| Goal (sparse) | "In one sentence, what's the smallest version of this that still counts as done?" |
| Features | "What are the major work units? What can run in parallel?" |
| Principles | "What truths must this respect regardless of how it's built?" |

At most 3 questions. Write each answer into the ISA before asking the next, so the document fills as the user answers. Stop early after two contentless answers in a row or when the user says done.

**`proceed`** is a whole-message match only (trimmed, case-insensitive). "I want to proceed with X" is an answer, not the override. When the user says `proceed`: add a Decisions row `YYYY-MM-DD HH:MM: ambiguity check fired, user said proceed — reasoned defaults: <named defaults>`, set `context_sufficient: false`, and surface the accepted defaults in Verification as a known risk.

| Path | `context_sufficient` | `interview_invoked` |
|---|---|---|
| No material ambiguity | true | false |
| Questions asked and answered | true | true |
| Questions asked, user said `proceed` | false | true |
| Trivial-path flag prepended | false | false |

**Re-check later:** when late information (a premortem result, a mid-build discovery) would have changed the Goal, Vision or Out of Scope had it been known at scaffold, re-run the rule and log a Decisions row naming the shift. It never blocks.

## Step 4: Frontmatter

```yaml
---
task: "imperative, at most 60 characters"
slug: YYYYMMDD-short-kebab
project: <name>            # only for a project ISA
phase: marking
progress: 0/<claim-count>
started: <ISO 8601>
updated: <ISO 8601>
principal_stated_goal: "verbatim quote"      # only when detection fired + min-content passed
principal_stated_goal_source: prompt
principal_stated_goal_signal: 2
principal_stated_goal_locked: <ISO 8601>
context_sufficient: true
interview_invoked: false
---
```

(If `kai.py isa new` wrote a starter with `phase: observe` or `progress: true`, replace them with `marking` and a real `0/N`, rename `created:` to `started:`, replace the `<claim>` / `<check>` placeholders, and delete every heading it left empty: `isa_tool.py check` fails placeholders and flags empty sections.)

## Step 5: Write the sections the substance requires

| Substance | Required sections |
|---|---|
| Trivial (mechanical, single probe, minutes) | Goal, Claims (flat) |
| Substantial (multi-claim build, real blast radius) | Problem, Vision, Out of Scope, Constraints, Goal, Features (or flat Claims), Test Strategy |
| Deepest (frontier multi-component work) | everything above plus Principles, Decisions, Learning (as content appears) and an Interview before building |

Empty sections never appear. Dependencies and Bridge Criteria only with cross-ISA links; Not yet specified only with fog; Language only after a term has actually been confused. **Project ISA override:** a `<project>/ISA.md` gets at least substantial structure regardless of the task's size.

**Claims layout, pick ONE:**

- **Flat `## Claims`** when the work has no distinct features (most task ISAs). IDs `ISC-N` or short `C1`; anti-claims carry `Anti:` inline or live in `## Anti-claims`.
- **`## Features` blocks** when it does (most project ISAs). Each feature is `### F<n> · <name>` + a one-line `Why:` + its claims nested under it. `F0 · Cross-cutting` holds spanning claims. IDs are global and stable across the whole ISA. Write a `Why:` that says what the name and claims don't.

```markdown
### F1 · Billing
Why: a visitor becomes a paying subscriber and can cancel on their own, without support.

- [ ] ISC-12: Checkout creates a payment session with server-side pricing.
- [ ] ISC-13: Anti: a replayed webhook never double-charges (idempotent on event ID).
```

**No changelog section, ever.** `git log -- <isa-path>` is the change record. The conjectured/refuted/learned trail goes in `## Learning`, written only when understanding changes. Closed claims get one-line provenance stubs in `## Verification`.

**Test Strategy:** one row per leaf claim, positional columns `isc | type | check | threshold | tool | anchors_to` (plus optional `severity`, `tier`). `type` from the vocabulary in `ISA_FORMAT.md` (`test`, `property`, `mutation`, `shell`, `http`, `screenshot`, `eval`, `manual`). Place probes by the seam rule. High-blast claims (secrets, auth, user data, money, public pushes, production deploys) name a deterministic probe.

## Step 6: Hold fog as fog

Surface named in Vision or Goal whose shape is genuinely unknown does NOT get speculative claims. Write each question into `## Not yet specified` as precisely as it can be stated now: `- fog: <question> — <what must resolve before it sharpens>`. Graduation test: statable with a nameable falsifier → a claim (even if blocked); statable but not probe-able → fog; beyond the vision → Out of Scope. Coverage is assessed at the close, not here. Omit the section when there's no fog.

## Step 7: Splitting Test on every claim

| Split when… |
|---|
| "and" / "with" joins two verifiable things |
| part A can pass while part B fails |
| "all" / "every" / "complete" appears: enumerate it |
| it crosses UI / API / data / logic: one claim per boundary |
| it changes a shared symbol: one claim per consumer |
| you can't name the probe |

## Step 8: Anti-claims

Ask: **what must NOT happen?** At least one anti-claim, usually derived from Out of Scope and regression concerns. On substantial work prefer universal form (a property over the failure pattern, not one instance).

## Step 9: Antecedent, when the goal is experiential

Art, design, writing, anything that has to land: at least one `Antecedent:` claim naming a precondition that reliably produces the target experience.

## Step 10: Pre-build probe run

Run the deterministic probes for any claim that might already hold. A probe that passes now means the claim was already true (delete or sharpen it) or the probe can't fail (fix it). Not for `manual` claims.

## Step 11: Check completeness

Substantial or deeper: run `Workflows/CheckCompleteness.md` (its mechanical part is `python ~/.copilot/skills/isa/Tools/isa_tool.py check <path>`) and fill any hard gap before returning. A trivial minimal ISA notes its shape check inline instead.

## Step 12: Return the path

Print the absolute path of the ISA. Then set `phase: climbing` when the build starts.

## Ephemeral feature mode

**Deterministic path (preferred):** `python ~/.copilot/kai/bin/kai.py isa excerpt <master-isa> <F-id> [--out PATH]`. It slices the feature block with its claim IDs unchanged into `<master-dir>/_ephemeral/<F-id>-<name>.md`, stamps the `<!-- KAI:EPHEMERAL derived-from: <master> feature: <F-id> created: <ts> -->` header that Reconcile requires, and refuses to overwrite without `--force`. Then add, by hand, only the read-only context the worker needs (steps 3 and 5 below).

Manual path (when the master isn't in feature mode, or the excerpt needs extra context):

1. Read the master ISA.
2. Find the feature block `### F<n> · <name>` matching the requested feature.
3. Extract: `## Vision` and `## Goal` (read-only context); the `## Constraints` relevant to this feature; that block's claims with their IDs unchanged; the matching Test Strategy rows; optionally the Decisions rows that mention those IDs; and an empty `## Verification`.
4. Write it next to the master, at `<master-dir>/_ephemeral/<F-id>-<feature>.md`, with this exact first line (the marker `kai.py isa reconcile` keys on):
   `<!-- KAI:EPHEMERAL derived-from: <absolute master-isa-path> feature: <F-id> -->`
   The ephemeral is a derived view: never hand-edit the master from it; Reconcile merges it back.
5. Hand the path to the worker (a `task` subagent, a `copilot -p` process, a fresh session) with the instruction to close claims only on evidence and record one-line Verification stubs.

## Failure modes

- **Substance mismatch:** the caller says "trivial" but the request is clearly deep multi-component work (or the reverse). Surface it. The user's explicit call outranks judgment, but the break is never silent.
- **Missing required section:** CheckCompleteness blocks the return until it is filled.
- **Coverage gap:** a subsystem named in Vision or Goal has no container claim. Decompose it, hold it as fog when its shape is genuinely unknown, or record a deliberate omission in Decisions. Never split to hit a number. Fog must be empty at `phase: complete`.
- **ID collision in ephemeral mode:** the feature's claim IDs don't exist in the master. Abort and surface it: that's a master ISA error.
