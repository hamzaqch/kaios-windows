# Interview Workflow

Adaptive question-and-answer that fills in or deepens an existing ISA's prose sections. Use it when the prompt alone didn't carry enough signal for a strong ISA, or when the user wants to deliberately deepen one.

Interview FILLS a known structure. To discover a structure that doesn't exist yet, use Grill.

## When to invoke

- From Scaffold's ambiguity check on substantial work (at most 3 targeted questions, `proceed` override, each answer written back immediately).
- After Scaffold on deepest-grade work: required before building.
- After CheckCompleteness reports gaps.
- The user directly: "interview me on <isa-path>", or on one section: "interview me on the Vision of <isa-path>".

## Inputs

| Input | Required | Description |
|---|---|---|
| isa_path | yes | The ISA to deepen |
| section | no | Only interview this section; otherwise walk every thin section |
| max_questions | no | Default 8 |

## Step 1: Read the ISA

Load it and classify each section as populated, thin or missing.

## Step 2: Build the question queue

Walk sections in priority order, asking only where the content is thin or missing.

| Section | Questions (when thin) |
|---|---|
| Problem | "What's broken right now?" / "Who feels it most?" / "What does the broken state cost?" |
| Vision | "When this is done, what do you feel?" / "What would make you tell someone else about it?" |
| Out of Scope | "What would be tempting to add but would distract from the core?" / "Which scope calls do you want locked so they don't drift?" |
| Principles | "What truths must this respect regardless of implementation?" / "What would you tell a future maintainer about how to think?" |
| Constraints | "What mandates bound the solution space?" / "What do you never want anyone to try?" |
| Goal | "In one or two sentences, what is the verifiable done state?" |
| Claims | "Walk me through the test that would prove ISC-N." / "Is this one binary probe, or should it split?" |
| Test Strategy | "How would you actually verify ISC-N? Which command or check?" |
| Features | "What units would you split this into?" / "What can run in parallel? What blocks the critical path?" |

## Step 3: Ask one question at a time

Use Copilot's `ask_user` tool when it is available: one question per call, your recommended answer as the first option, the real alternatives after it (the user can always type their own). Otherwise ask in plain text, one question per message. Conversational, never "Question 1 of 8". Lead with the most foundational question. Reuse the user's own words from earlier answers.

## Step 4: Write back after every answer

Immediately edit the ISA section with the answer (append or replace as appropriate, preserving prior content). The user should feel the document filling as they answer.

## Step 5: Stop conditions

- Every section the work's substance requires is populated beyond thin.
- `max_questions` reached.
- The user says "that's enough", "skip the rest" or "done".
- Two answers in a row add no signal ("I don't know", "skip").

If the user is rushed, drop to the core (Problem, Goal, Claims, Test Strategy) and note the rest as "fill in later" in Remaining Work.

## Step 6: Final completeness pass

Run `Workflows/CheckCompleteness.md`. Surface remaining gaps but don't block: the user can iterate later.

## Failure modes

- **The user leaves mid-interview:** the partial fill is still valuable. Save it and add a Decisions row: `interview paused at <section> — N answered, M skipped`.
- **Answers contradict the ISA:** the new answer is canonical. Log the change with a `refined:` Decisions row.
- **Answers stay aspirational:** push once: "what would a test that proves that look like?" If the user can't say, the claim isn't hard to vary yet; hold it as fog and note it in Decisions.
