# Append Workflow

The canonical writer for the three append-only sections of an ISA: `## Decisions`, `## Learning` and `## Verification`. The conjectured/refuted/learned format is easy to mangle with free-form editing, so this workflow owns each entry's shape. It also enforces two conventions: the ISA carries **no changelog section** (`git log -- <isa-path>` is the change record), and each Verification entry is a **one-line provenance stub**, never a retained paragraph.

## When to invoke

- Whenever a non-obvious decision is made: "append decision to <isa>: <text>".
- At learn, when understanding changed: "append learning to <isa>: <conjecture> / <refutation> / <learning> / <criterion now>".
- When a claim's probe passes: "append verification to <isa>: <ID> <probe type> <provenance>".
- The user directly, adding an entry by hand.

## Entry types

### Decision

```
- YYYY-MM-DD HH:MM: <decision text>
- YYYY-MM-DD HH:MM: refined: <what was refined and why>
- YYYY-MM-DD HH:MM: ❌ DEAD END: Tried <X>. It failed because <Y> (don't retry).
- YYYY-MM-DD HH:MM: [arch] <a structure, contract or convention other tasks must follow>
```

Inputs: `text` (required), `kind` (optional: `decision` | `refined` | `dead-end` | `arch`). Use `refined:` when the decision changes the Goal or restructures the claim set; use `[arch]` only when work in *other* tasks must conform to it.

### Learning (the four-piece entry)

```
- YYYY-MM-DD | conjectured: <what we believed>
  refuted by: <evidence that broke the belief>
  learned: <what the evidence taught us>
  criterion now: <which claim was added, changed or dropped as a result>
```

All four pieces are required. **A partial entry is refused:** if one is missing, it's a Decision, not a Learning entry. Surface the missing piece and ask.

### Verification

```
- <ID>: <probe type> — <one-line provenance: commit hash | test name | probe ref>
```

Inputs: `id` (required, must exist in the claims), `probe_type` (required), `provenance` (required, one line). Refuse a multi-line paragraph and ask for the stub.

## Step 1: Resolve the target

Read the ISA and find the target section. If it doesn't exist, create it in its canonical position: Decisions after Test Strategy / Features, Learning after Decisions, Verification after Learning (and before Remaining Work). Never create a `## Changelog`.

## Step 2: Validate the entry

| Type | Required | Refuse if… |
|---|---|---|
| Decision | text, timestamp | text is empty |
| Learning | conjectured, refuted by, learned, criterion now, date | any of the four is missing |
| Verification | id, probe type, provenance | the ID isn't a claim in this ISA, provenance is empty, or provenance is a paragraph |

On refusal, write nothing and surface what's missing. Silently writing partial entries defeats the point.

## Step 3: Format

Use the schemas exactly. Learning uses the four-line indented form; Verification is exactly one line.

## Step 4: Append

Edit the ISA: append to the end of the target section, preserving earlier entries, and set `updated:` to now.

## Step 5: Update progress (Verification only)

When a Verification entry belongs to a claim still marked `[ ]`, flip it to `[x]` and set `progress:` to the mechanical value (`python ~/.copilot/skills/isa/Tools/isa_tool.py progress <isa>`). If the work is in a git repo, commit now so the stub can carry the hash.

## Step 6: Return

Print the exact appended text and the path.

## Why this workflow exists

Without a canonical writer the Learning trail degrades three ways: free-form prose creep ("we changed our minds about X"), half-entries (a conjecture and a new criterion with no refuting evidence between them), and format drift between projects that breaks searching across them. Append is the gate. Reconcile calls it for every entry it merges, so a merge can't smuggle in malformed entries or evidence paragraphs either.

## Failure modes

- **Concurrent edits:** Append reads, picks a position, then writes; an edit in between can land at a stale offset. Serialize structural edits to an ISA.
- **Malformed file:** if the canonical position is ambiguous, abort and surface the structural problem.
- **Unknown ID on Verification:** refuse. This is the same ID-stability contract Reconcile relies on.
