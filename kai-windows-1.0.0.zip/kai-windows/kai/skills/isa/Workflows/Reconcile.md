# Reconcile Workflow

A deterministic merge of an ephemeral feature file back into its master ISA, keyed on stable claim IDs. Without it, feature work done in isolated contexts drifts from the master and recreates the "code drifts from spec" problem the ISA exists to solve.

## When to invoke

- A worker (a `task` subagent, a parallel `copilot -p` process, a fresh session) finished work on an ephemeral feature file.
- At the learn step of an Algorithm run that fanned out features.
- The user directly: "reconcile <ephemeral-path> into <master-path>".

## Inputs

| Input | Required | Description |
|---|---|---|
| ephemeral_path | yes | `<master-dir>/_ephemeral/<F-id>-<feature>.md` |
| master_path | no | The master ISA it was derived from; defaults to the `derived-from:` path in the header |
| dry_run | no | Default false. True reports the planned changes without writing |

## Output

```yaml
status: applied | dry_run | aborted
ephemeral: <path>
master: <path>
applied:
  claims_checked: [ISC-12, ISC-13, ISC-14]   # flipped to [x] in the master
  verification_added: 3                      # one-line provenance stubs appended
  decisions_added: 2
  learning_added: 1
archived_to: MEMORY/WORK/<slug>/_ephemeral/.archive/<feature>-YYYY-MM-DD.md
errors:
  - claim: ISC-99
    reason: not present in master; the ephemeral references an unknown ID
```

## The deterministic path

`python ~/.copilot/kai/bin/kai.py isa reconcile <ephemeral> [<master>] [--dry-run] [--keep]` performs Steps 1–9 mechanically: it reads the master path from the ephemeral's header, aborts on any ID the master doesn't hold, flips `[ ]` to `[x]`, appends new Verification stubs and the tagged Decisions / Learning rows, recomputes `progress:`, archives the ephemeral under `_ephemeral/.archive/`, and prints the JSON report. Prefer it. Afterwards, read the master back and run `isa_tool.py check <master>`: the tool merges lines, it does not judge them, so collapse any evidence paragraph to a stub. **Gotcha:** the tool merges bullet lines only, so a four-piece Learning entry arrives as its first line (`conjectured:`) alone; copy the `refuted by:` / `learned:` / `criterion now:` lines under it by hand, or the master now holds a partial entry the Append workflow would refuse. Walk the steps below by hand only when the ephemeral lacks the `KAI:EPHEMERAL` header.

## Step 1: Read both files

Load the ephemeral and the master. Confirm the ephemeral's first line is the canonical marker (`<!-- KAI:EPHEMERAL derived-from: <master> feature: <F-id> ... -->`); abort if not. Reconcile only merges what Scaffold's ephemeral mode produced.

## Step 2: Build the ID merge plan

For each claim in the ephemeral:

- `[x]` in the ephemeral and `[ ]` in the master → stage the flip.
- `[x]` in both → no-op.
- `[ ]` in the ephemeral → no-op (not completed there).
- ID present in the ephemeral but not the master → ERROR: ID-stability violation.
- ID renumbered (sequence gap, shifted tombstone) → ERROR: ID-stability violation.

## Step 3: Stage Verification entries

Every flipped claim needs an entry in the ephemeral's `## Verification`. Stage each for the master's `## Verification` as a **one-line provenance stub** (commit hash, test name, probe ref). If the worker wrote a paragraph, collapse it to the stub first; the proof lives in git and CI.

## Step 4: Stage Decisions entries

Append the ephemeral's Decisions rows to the master's `## Decisions`, prefixed `[from <feature>]:`, timestamps preserved.

## Step 5: Stage Learning entries

Append any new four-piece Learning entries to the master's `## Learning`, prefixed `[surfaced in <feature>]:`. There is no changelog to merge; git is the change record.

## Step 6: Update master frontmatter

- `progress: M/N` recomputed (`python ~/.copilot/skills/isa/Tools/isa_tool.py progress <master>` after the flips).
- `updated:` set to now.
- `phase:` left alone. The close is the run's transition, not Reconcile's.

## Step 7: Apply or dry-run

`dry_run: true` → emit the YAML and stop. Otherwise apply in this order, all through the Append workflow's validation (so the merge can't smuggle in malformed entries or evidence paragraphs):

1. master frontmatter;
2. claim checkmarks;
3. `## Verification` (append);
4. `## Decisions` (append);
5. `## Learning` (append).

## Step 8: Archive the ephemeral

Move it to `<ephemeral-dir>/.archive/<feature>-YYYY-MM-DD.md` (`Move-Item` / `mv`). The archive is permanent, kept for forensics. If the worker held per-claim locks, release them: `isa_tool.py release <master> --id <ID> --session <worker-session>`.

## Step 9: Emit the report

Print the YAML report.

## Conflict resolution

There are no conflicts to resolve. An ID exists in the master and the merge is mechanical, or it doesn't and the merge aborts. If the ephemeral made structural changes (split ISC-7 into ISC-7.1 / ISC-7.2), those go into the master by a separate edit BEFORE Reconcile runs; Reconcile never invents IDs. If the ephemeral is stale relative to the master, abort and surface the divergence: the user decides whether to re-extract or back-port.

## Failure modes

- **ID-stability violation:** abort. Don't silently drop the entry. The master is the source of truth; the ephemeral cannot mint IDs.
- **Missing canonical marker:** abort.
- **Verification entry missing for a flipped claim:** soft warning. The flip stands, but missing evidence violates the verification doctrine; surface it so the run's verify step catches it.
- **Master edited during the merge:** Reconcile is single-threaded by design. A second run sees the new state and reports "already checked", which is correct.

## Idempotency

Running Reconcile twice on the same ephemeral and master changes nothing after the first run and reports zero applied changes. Safe to retry.
