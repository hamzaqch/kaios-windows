# CheckCompleteness Workflow

Score an existing ISA against the substance-scaled completeness gate and return a structured pass/fail plus a gap report. The bar is judged from the work's substance, not a declared label.

Two layers: the **mechanical** subset is `python ~/.copilot/skills/isa/Tools/isa_tool.py check <path>` (deterministic, the same gate `ext/isa_gates.py` runs at close); the **semantic** checks below (coverage, granularity, artifact presence, goal fidelity) are yours to judge. Run the tool first, then the judgment pass.

## When to invoke

- After Scaffold: confirm the ISA meets the gate for the work's substance.
- Before the close: confirm it's still complete after any structural change.
- The user directly: "check completeness of <isa-path>".
- From the Scaffold or Interview workflows.

## Inputs

| Input | Required | Description |
|---|---|---|
| isa_path | yes | The ISA to score |
| substance | no | `trivial` / `substantial` / `deepest`; default judged from the Goal and Vision's scope and blast radius (`isa_tool.py check --substance`) |
| strict | no | Default true. False downgrades hard gaps to warnings (used mid-interview) |

## Output

```yaml
status: pass | fail
substance: substantial
required_sections:
  Problem: present
  Vision: present
  Out of Scope: missing
  Principles: present
  Constraints: present
  Dependencies: absent       # conditional: required only with cross-ISA links
  Goal: present
  Claims: present            # `## Claims`, legacy `## Criteria`, or `## Features` blocks
  Bridge Criteria: absent    # conditional
  Test Strategy: present
  Decisions: present
  Learning: missing
  Verification: empty        # `## Verification` or `## Log`; acceptable until claims start closing
gaps:
  - section: Out of Scope
    severity: hard
    reason: required for substantial work, missing entirely
isc_quality:
  total: 24
  coverage_gaps: 0              # Vision/Goal subsystems with no container claim
  granularity_violations: 0
  anti_claims: 2
  antecedent_present: true
  test_strategy_orphans: 0      # leaf claims with no probe
  id_stability_violations: 0
  backlog: 5                    # unchecked claims + unchecked Remaining Work (advisory)
```

## Step 1: Run the mechanical gate

`python ~/.copilot/skills/isa/Tools/isa_tool.py check <path> --json [--substance S] [--experiential]`. Every `hard` finding is a hard gap in your report.

## Step 2: Look up the gate for the substance

| Substance | Required sections |
|---|---|
| Trivial | Goal, Claims |
| Substantial | Problem, Vision, Out of Scope, Constraints, Goal, Claims (flat or Features), Test Strategy |
| Deepest | the above plus Principles, Decisions, Learning, and the Interview workflow ran before building |

A `<project>/ISA.md` always scores at substantial or above. Report the override when it applies.

## Step 3: Classify each required section

| Classification | Test |
|---|---|
| `present` | heading exists and the body has content. Length is not graded; one sentence can be exactly right |
| `missing` | no heading |
| `empty` | heading with a blank body; acceptable only for Verification/Log before claims start closing |

## Step 4: Audit claim quality

Walk every claim (`## Claims`, legacy `## Criteria`, `## Features` blocks; `ISC-N` and short IDs both count; a `## Anti-claims` section counts toward anti-claims):

- **Granularity:** each leaf names (or clearly implies) a single binary probe. Compound "and/with" claims fail.
- **Coverage:** every subsystem named in Vision or Goal has a container claim decomposed until each leaf is one probe. A subsystem with no container is a gap UNLESS it's held as fog and the ISA isn't yet at `phase: complete`. **At `phase: complete`, a non-empty `## Not yet specified` is a HARD fail.** Speculative claims written at scaffold to cover fog-shaped surface are themselves a quality failure (they have no honest probe). Never split to hit a number.
- **Backlog (advisory, never a gate):** unchecked claims plus unchecked `## Remaining Work` items. Report its size; never fail on it. Unchecked claims stay in the claims section.
- **Anti-claims (HARD on substantial and above):** at least one (`Anti:` prefix, an `A`-prefixed short ID, or a `## Anti-claims` entry). This check is the teeth: anti-claims were skipped in most ISAs until something enforced them.
- **Test Strategy coverage (HARD on substantial and above):** every leaf claim has a Test Strategy row (or an inline `Probe:`) naming its probe. Trivial ISAs with inline probes are fine.
- **Antecedent:** an experiential goal has at least one `Antecedent:` claim.
- **ID stability:** unique IDs, no collisions, no renumbering gaps. Tombstones are valid.
- **No changelog section:** a `## Changelog` holding narrative entries is a HARD fail (git is the changelog). One holding the conjectured/refuted/learned trail is a SOFT warning: rename it `## Learning`.
- **Evidence collapsed:** each Verification entry for a closed claim is a one-line stub. A retained paragraph is a soft fail (collapse it).
- **Anchoring:** when `principal_stated_goal` is set, every Test Strategy row has an `anchors_to` value (`literal`, `derived: <sub-claim>`, `cross: <slug>`). An orphan is a hard fail.

## Step 5: Goal-signal consistency (only when the key `principal_stated_goal` exists)

- `principal_stated_goal_signal` is set but the literal is empty or null → hard fail: "the detector fired but the literal wasn't preserved".
- The literal is set but under 6 tokens or contentless → hard fail: "should have been null".

## Step 6: Artifact presence (deepest work, only when `principal_stated_goal` exists)

For every `[x]` claim that asserts a named design surface ("the proposal includes X", "a table of Y appears"), find that surface in the ISA body. Asserted but absent → hard fail: the ISA must contain its own design surface, not point at chat context. That is its system-of-record identity.

## Legacy keys are inert

Old density/divergence/acknowledgment frontmatter keys and the retired `effort`, `effort_source` and `mode` keys are never graded: presence is never a failure and values are never validated. The only ambiguity-check keys graded are `context_sufficient` and `interview_invoked`.

## Step 7: Compose the report

Emit the YAML above. `status: pass` only with zero hard gaps. `strict: false` downgrades hard to warnings.

## Step 8: Block the close on hard gaps

Run before the close, hard gaps block `phase: complete`. Fill them first.

## Severity table

| Gap | Trivial | Substantial | Deepest |
|---|---|---|---|
| Goal missing | hard | hard | hard |
| Claims missing | hard | hard | hard |
| Problem / Vision / Out of Scope / Constraints / Test Strategy missing | — | hard | hard |
| Principles / Decisions / Learning missing | — | — | hard |
| Flat Claims and Features both present | hard | hard | hard |
| `## Changelog` with narrative entries | hard | hard | hard |
| Verification entry kept as a paragraph | soft | soft | soft |
| Interview not run before building | — | — | hard |
| Zero anti-claims | soft | hard | hard |
| Leaf claim with no probe | soft | hard | hard |
| Antecedent missing (experiential) | hard | hard | hard |
| ID-stability violation | hard | hard | hard |
| Coverage gap | — | hard | hard |
| Non-empty fog at `phase: complete` | hard | hard | hard |
| `progress` not a mechanical M/N at `phase: complete` | hard | hard | hard |
| Granularity violation | hard | hard | hard |
| Anchoring violation (goal set) | hard | hard | hard |
| Goal-signal mismatch | hard | hard | hard |
| Artifact-presence violation | — | — | hard |
| `context_sufficient` missing | — | soft | soft |

## Failure modes

- **Frontmatter missing or malformed:** abort with an explicit error. `phase` and `progress` are non-negotiable; `slug` and `task` may be derived from the folder name and the H1.
- **A project ISA scored as trivial:** override to substantial and say so.
- **Claim parsing fails:** treat as zero claims and surface the parse error.
