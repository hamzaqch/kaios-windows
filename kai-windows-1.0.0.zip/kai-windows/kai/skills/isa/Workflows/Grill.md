# Grill Workflow

A relentless, checkpointed discovery interview that interrogates a half-formed idea until its shape is clear, then hands off to Scaffold to build the ISA. Where Interview FILLS a known ISA structure, Grill DISCOVERS a structure that doesn't exist yet. User-invoked and exploratory; never automatic inside an Algorithm run.

## When to invoke

- The user directly: "grill me on <topic>", `/isa grill <topic>`.
- Before Scaffold, when the idea is too unformed to scaffold a strong ISA.
- To refresh a spec: "grill me again on <slug>, here are new findings."

NOT for filling an existing ISA's thin sections; that's Interview.

## Inputs

| Input | Required | Description |
|---|---|---|
| topic | yes | The idea, plan or decision to interrogate |
| slug | no | The work folder to use; derived from the topic if absent (`YYYYMMDD-short-kebab`) |
| max_questions | no | Default 12 |

## Step 1: Establish the work folder

Use `~/.copilot/kai/MEMORY/WORK/<slug>/`, the same folder Scaffold writes the ISA to, so the handoff stays together. Use it even when the grill starts from another repo's working directory; it is never project-relative. Create `grill.md` there with three sections: **Shape & Key Decisions**, **Q&A Log**, **Open Flags**. This file is the checkpoint target.

## Step 2: Shape check (only if the category is unclear)

If it's unclear what *kind* of thing this is (a skill, a hook, a CLI, a document, a service…), propose 2–3 candidate shapes and ask discriminating questions to prune to one before walking the tree. Skip it when the shape is obvious.

## Step 3: Walk the design tree

Resolve dependencies in order: never a leaf before its parent. For each decision:

- Ask one question at a time with Copilot's `ask_user` tool: one question per call, never batched. Put your recommended answer first, marked "(Recommended)", alongside the real alternatives, so the user confirms or overrides in one step; they can always type their own answer. Use a free-text question only when the answer space genuinely won't bound into options.
- Never a bare open ask: always lead with where you'd land and why.
- Explore instead of asking when the answer is discoverable: search and read the code or files first, and ask only what they can't answer.
- On a low-confidence or high-stakes call, add a one-line strongest objection to your own recommendation before the user answers.

## Step 4: Checkpoint after every turn

Immediately write to `grill.md`: append the Q&A pair to the Q&A Log, promote settled decisions into Shape & Key Decisions, and record anything that needs outside input under Open Flags. This survives context degradation in long sessions.

## Step 5: Pre-mortem into draft claims

Before closing, run one failure pass: "imagine this shipped and failed: what went wrong?" Turn each failure mode into a draft binary claim under Shape & Key Decisions. This is what makes the resulting ISA hard to vary.

## Step 6: Stop conditions

Stop when the shape is clear enough to scaffold, when `max_questions` is reached, or after two consecutive low-signal answers ("I don't know", "skip").

## Step 7: Handoff

Offer, in order:

1. Hand the shape to Scaffold, targeting the same work folder: run `Workflows/Scaffold.md` with the Shape & Key Decisions and the draft claims from `grill.md` as its prompt.
2. Record each Open Flag where it will be seen: as fog in the new ISA's `## Not yet specified` if it's in scope, or in `## Remaining Work` if it's follow-up.
3. If the grill changed how a skill should behave, update that skill (use `/create-skill` for skill edits).

## Output format (`grill.md`)

```markdown
# Grill: <topic>

## Shape & Key Decisions
- <settled decision> — <rationale>
- Claim: <binary criterion from the pre-mortem>

## Q&A Log
### Q1: <question>
**Recommended:** <recommendation>  **Answer:** <user's answer>

## Open Flags
- [ ] <unknown> — needs <who or what>
```

## Failure modes

- **The user leaves mid-grill:** the partial `grill.md` is still valuable; add an Open Flag noting where it paused.
- **Answers stay aspirational:** push for the concrete ("what would prove that?"). If they can't say, log an Open Flag, not a settled decision.
- **The topic is already well formed:** say so and go straight to Scaffold. Don't manufacture questions to reach `max_questions`.

## Interaction with Scaffold

Scaffold has no grill mode: the handoff IS the `grill.md` content passed as Scaffold's prompt. Scaffold's goal detection preserves the stated goal from that prompt and derives Vision, Out of Scope, Constraints and Principles, and the draft claims carry into the ISA's claims section. Grill's value is front-loading discovery so Scaffold's input is already hard to vary.
