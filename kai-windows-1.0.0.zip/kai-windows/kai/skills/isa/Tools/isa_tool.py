"""isa_tool — deterministic reader for Kai ISAs (Ideal State Artifacts). Stdlib only.

The tool never writes an ISA. The AI is the sole writer; this only reads, scores,
and keeps central lock / log state under the Kai home.

  python isa_tool.py check <isa> [--substance trivial|substantial|deepest] [--experiential] [--json]
  python isa_tool.py progress <isa>                  computed M/N (closed / total claims)
  python isa_tool.py ascent <isa>                    the derived ascent strip for this ISA
  python isa_tool.py frontier <isa> [--json]         takeable claims (open, blockers resolved, unlocked)
  python isa_tool.py status <isa> [--json]           takeable / taken / blocked / closed / stale locks
  python isa_tool.py validate <isa>                  dependency-edge integrity only
  python isa_tool.py claim <isa> --id C4 --session S [--ttl-hours 2]
  python isa_tool.py release <isa> --id C4 --session S [--force]
  python isa_tool.py asklog <isa> --ask "<ask>" --status met|skipped|surfaced|failed [--note "..."]
  python isa_tool.py reflect <isa> --reflection "<what a smarter run would have done>" [--session S]

Exit codes: 0 ok / complete, 1 incomplete or invalid, 2 refused (claim held, blocked, closed) or usage.
"""
import argparse
import datetime as _dt
import hashlib
import json
import os
import re
import sys
from pathlib import Path

# ------------------------------------------------------------------ locations

def kai_home():
    env = os.environ.get("KAI_HOME")
    if env:
        return Path(env)
    ch = os.environ.get("COPILOT_HOME")
    return (Path(ch) if ch else Path.home() / ".copilot") / "kai"


def now_iso():
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")

# ------------------------------------------------------------------ vocabulary

# Lifecycle bracket. Current values first; the retired station names parse forever.
PHASE_TO_ASCENT = {
    "marking": "marking", "scoping": "marking", "starting": "marking",
    "climbing": "ascending", "learn": "cairn", "complete": "cairn",
    "observe": "marking", "think": "marking", "plan": "marking",
    "build": "ascending", "execute": "ascending", "verify": "anchoring",
}
ASCENT = {
    "traverse": ("🥾", "Traverse"), "marking": ("📐", "Marking"), "ascending": ("🧗", "Ascending"),
    "anchoring": ("⚓", "Anchoring"), "camped": ("⛺", "Camped"), "cairn": ("🪨", "Cairn"),
}
TYPE_CLASS = {
    # deterministic: a tool says no
    "test": "deterministic", "property": "deterministic", "shell": "deterministic",
    "http": "deterministic", "screenshot": "deterministic", "mutation": "deterministic",
    # legacy / alias spellings
    "bash": "deterministic", "powershell": "deterministic", "curl": "deterministic",
    "unit-test": "deterministic",
    "pytest": "deterministic", "unittest": "deterministic", "sql": "deterministic",
    # judged: a rubric-bound model says no
    "eval": "judged",
    # attested: the user says no
    "manual": "attested",
}
SEVERITIES = {"critical", "normal", ""}
TIERS = {"deep", "fast", ""}
CLAIM_SECTIONS = ("claims", "criteria", "isc criteria", "features", "anti-claims", "bridge criteria")
DISPLAY = {"goal": "Goal", "problem": "Problem", "vision": "Vision", "out of scope": "Out of Scope",
           "constraints": "Constraints", "test strategy": "Test Strategy", "principles": "Principles",
           "decisions": "Decisions", "learning": "Learning", "language": "Language",
           "dependencies": "Dependencies", "not yet specified": "Not yet specified",
           "bridge criteria": "Bridge Criteria"}
SECTION_ALIASES = {"criteria": "claims", "isc criteria": "claims", "log": "verification"}

ID_PAT = r"[A-Z][A-Z0-9]*(?:[-.][A-Z0-9]+)*"
CLAIM_LINE = re.compile(r"^(?P<indent>\s*)[-*]\s*\[(?P<mark>[ xX])\]\s*(?:\*\*)?(?P<id>" + ID_PAT +
                        r")(?:\*\*)?(?P<sep>\s*[:—–]\s*|\s+-\s+|\s+|\.\s*)(?P<text>.*)$")
PLACEHOLDER = re.compile(r"<(?:claim|what must not happen|check|exact tool[^<>]*)>", re.I)
EDGE_RE = re.compile(r"\(after:\s*([^)]*)\)\s*\.?\s*$", re.I)
BACKTICK_RE = re.compile(r"`[^`]*`")

# ------------------------------------------------------------------ parsing

def split_frontmatter(text):
    fm, body = {}, text
    m = re.match(r"^﻿?---\s*\n(.*?)\n---\s*(?:\n|$)", text, re.S)
    if m:
        body = text[m.end():]
        for line in m.group(1).splitlines():
            if not line.strip() or line.startswith((" ", "\t", "#")) or ":" not in line:
                continue
            k, v = line.split(":", 1)
            v = re.sub(r"\s+#.*$", "", v.strip()) if not v.strip().startswith(('"', "'")) else v.strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
                v = v[1:-1]
            fm[k.strip()] = v
    return fm, body


def split_sections(body):
    """Ordered list of (name_lower, heading, text) for every '## ' heading."""
    out, cur, buf = [], None, []
    for line in body.splitlines():
        m = re.match(r"^##\s+(.+?)\s*#*\s*$", line)
        if m and not line.startswith("###"):
            if cur:
                out.append((cur.lower(), cur, "\n".join(buf)))
            cur, buf = m.group(1).strip(), []
        elif cur is not None:
            buf.append(line)
    if cur:
        out.append((cur.lower(), cur, "\n".join(buf)))
    return out


def canonical(name):
    return SECTION_ALIASES.get(name, name)


def parse_claims(sections):
    claims = []
    for name, _heading, text in sections:
        if name not in CLAIM_SECTIONS:
            continue
        feature = None
        for raw in text.splitlines():
            fm = re.match(r"^###\s+(F\d+)\b", raw)
            if fm:
                feature = fm.group(1)
                continue
            m = CLAIM_LINE.match(raw)
            if not m:
                continue
            cid, sep, body = m.group("id"), m.group("sep"), m.group("text").strip()
            if sep.strip() == "" and not re.search(r"\d", cid):
                continue  # "- [ ] Fog thing" is not a claim
            visible = BACKTICK_RE.sub("", body)
            edge = EDGE_RE.search(visible)
            after = [e.strip() for e in edge.group(1).split(",") if e.strip()] if edge else []
            low = body.lower()
            claims.append({
                "id": cid, "checked": m.group("mark").lower() == "x", "text": body,
                "section": canonical(name), "feature": feature, "indent": len(m.group("indent").expandtabs(4)),
                "anti": low.startswith("anti:") or name == "anti-claims" or bool(re.match(r"^A\d", cid)),
                "antecedent": low.startswith("antecedent:"),
                "dropped": "[dropped" in low or body.startswith("~~") or low.startswith("dropped"),
                "inline_probe": bool(re.search(r"\bprobe\s*:", body, re.I)) or "(probe" in low,
                "after": after,
            })
    ids = [c["id"] for c in claims]
    for c in claims:
        c["leaf"] = not any(o.startswith(c["id"] + ".") for o in ids if o != c["id"])
    return claims


def split_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|") and not line.endswith("\\|"):
        line = line[:-1]
    cells, cur, i = [], [], 0
    while i < len(line):
        ch = line[i]
        if ch == "\\" and i + 1 < len(line) and line[i + 1] == "|":
            cur.append("|")
            i += 2
            continue
        if ch == "|":
            cells.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
        i += 1
    cells.append("".join(cur).strip())
    return cells


def parse_test_strategy(sections):
    """Positional contract: id | type | check | threshold | tool | anchors_to | severity | tier."""
    rows = []
    for name, _h, text in sections:
        if name != "test strategy":
            continue
        for line in text.splitlines():
            if not line.strip().startswith("|"):
                continue
            cells = split_row(line)
            if not cells or set("".join(cells)) <= set("-: "):
                continue
            if cells[0].strip("` *").lower() in ("isc", "claim", "id", "criterion"):
                continue
            cells += [""] * (8 - len(cells))
            tool = cells[4]
            if len(tool) >= 2 and tool.startswith("`") and tool.endswith("`"):
                tool = tool[1:-1]
            rows.append({"id": cells[0].strip("` *"), "type": cells[1].strip("` ").lower(), "check": cells[2],
                         "threshold": cells[3], "tool": tool, "anchors_to": cells[5],
                         "severity": cells[6].strip().lower(), "tier": cells[7].strip().lower()})
    return rows


FENCE_RE = re.compile(r"^\s*(`{3,}|~{3,})")


def strip_fences(body):
    """Blank every line inside a fenced code block (fence lines included); line count preserved."""
    out, fence = [], None
    for line in body.splitlines():
        m = FENCE_RE.match(line)
        if fence is None and m:
            fence = m.group(1)[0] * 3
            out.append("")
        elif fence is not None:
            if line.strip().startswith(fence):
                fence = None
            out.append("")
        else:
            out.append(line)
    return "\n".join(out)


def load(path):
    text = Path(path).read_text(encoding="utf-8-sig")
    fm, body = split_frontmatter(text)
    body = re.sub(r"<!--.*?-->", "", body, flags=re.S)  # comments are never content
    body = strip_fences(body)  # quoted markdown inside ``` fences is never structure
    sections = split_sections(body)
    claims = parse_claims(sections)
    return {"path": str(path), "frontmatter": fm, "sections": sections, "claims": claims,
            "rows": parse_test_strategy(sections), "has_frontmatter": text.lstrip("﻿").startswith("---")}


def section(isa, *names):
    for n, _h, t in isa["sections"]:
        if canonical(n) in names or n in names:
            return t
    return None


def counted(isa):
    """Claims that count toward progress: non-dropped leaves."""
    return [c for c in isa["claims"] if c["leaf"] and not c["dropped"]]


def progress(isa):
    cs = counted(isa)
    return sum(1 for c in cs if c["checked"]), len(cs)

# ------------------------------------------------------------------ ascent

def derive_ascent(phase, closed, total, tracked=True, active=True):
    bracket = PHASE_TO_ASCENT.get((phase or "").strip().lower())
    if bracket == "cairn":
        return "cairn"
    if not tracked:
        return "traverse" if active else "idle"
    if not active:
        return "camped"
    if total > 0 and closed >= total:
        return "cairn"
    if total == 0:
        return "marking"
    return bracket if bracket in ("marking", "ascending", "anchoring") else "ascending"


def ascent_strip(state):
    icon, label = ASCENT.get(state, ("", "Idle"))
    return f"════ Kai | Algorithm | {icon} {label} ════"

# ------------------------------------------------------------------ edges

def edge_problems(isa):
    claims = isa["claims"]
    ids = [c["id"] for c in claims]
    known = set(ids)
    probs = []
    seen = set()
    for i in ids:
        if i in seen:
            probs.append(f"duplicate claim ID {i}")
        seen.add(i)
    graph = {}
    for c in claims:
        deps = []
        for d in c["after"]:
            if d == c["id"]:
                probs.append(f"{c['id']} depends on itself")
            elif d not in known:
                probs.append(f"{c['id']} depends on unknown ID {d}")
            elif d in deps:
                probs.append(f"{c['id']} lists {d} twice")
            else:
                deps.append(d)
        graph[c["id"]] = deps
    color = {}

    def visit(n, stack):
        color[n] = 1
        for d in graph.get(n, []):
            if color.get(d) == 1:
                probs.append("cycle: " + " -> ".join(stack + [n, d]))
            elif not color.get(d):
                visit(d, stack + [n])
        color[n] = 2

    for n in graph:
        if not color.get(n):
            visit(n, [])
    return probs

# ------------------------------------------------------------------ check

def substance_of(isa, requested):
    if requested:
        return requested
    p = Path(isa["path"])
    if p.name == "ISA.md" and "WORK" not in [x.upper() for x in p.parts[:-1]]:
        return "substantial"  # project ISA override
    if any((section(isa, n) or "").strip() for n in ("features", "problem", "vision")):
        return "substantial"
    return "trivial"


def check(isa, requested=None, experiential=False):
    """Returns (findings, substance). finding = (severity, label, detail); severity hard|soft|ok."""
    out = []
    add = lambda sev, label, detail="": out.append((sev, label, detail))
    fm = isa["frontmatter"]
    sub = substance_of(isa, requested)
    full = sub in ("substantial", "deepest")
    phase = (fm.get("phase") or "").strip().lower()
    complete = phase == "complete"

    if not isa["has_frontmatter"]:
        add("hard", "frontmatter present", "no --- block")
    if not phase:
        add("hard", "phase set", "missing")
    elif phase not in PHASE_TO_ASCENT:
        add("hard", "phase is a known lifecycle value", phase)
    else:
        add("ok", "phase", phase)

    closed, total = progress(isa)
    prog = (fm.get("progress") or "").strip()
    m = re.match(r"^(\d+)\s*/\s*(\d+)$", prog)
    if not prog:
        add("hard" if complete else "soft", "progress set", f"missing; computed {closed}/{total}")
    elif not m:
        add("hard" if complete else "soft", "progress is a mechanical M/N count", f"'{prog}'; computed {closed}/{total}")
    elif (int(m.group(1)), int(m.group(2))) != (closed, total):
        add("hard" if complete else "soft", "progress matches the claims", f"says {prog}, computed {closed}/{total}")
    else:
        add("ok", "progress", prog)

    goal = fm.get("principal_stated_goal")
    if goal is not None:
        g = goal.strip()
        if g and g.lower() not in ("null", "~", '""'):
            if len(g.split()) < 6:
                add("hard", "stated goal passes minimum-content rule", "under 6 tokens: should be null")
            else:
                add("ok", "stated goal preserved verbatim")
        elif fm.get("principal_stated_goal_signal"):
            add("hard", "stated goal captured", "a signal was recorded but the literal is null")

    required = ["goal"]
    if full:
        required += ["problem", "vision", "out of scope", "constraints", "test strategy"]
    if sub == "deepest":
        required += ["principles", "decisions", "learning"]
    for name in required:
        body = section(isa, name)
        if body is None:
            add("hard", f"## {DISPLAY.get(name, name)} present", f"required for {sub} work")
        elif not body.strip():
            add("hard", f"## {DISPLAY.get(name, name)} has content", "empty section")
    has_claims, has_features = section(isa, "claims") is not None, section(isa, "features") is not None
    if has_claims and has_features:
        add("hard", "flat Claims OR Features blocks, never both", "both present")
    if not isa["claims"]:
        add("hard", "at least one claim", "none parsed")
    else:
        add("ok", "claims", f"{len(isa['claims'])} parsed, {total} counted")
    stubs = [c["id"] for c in isa["claims"] if PLACEHOLDER.search(BACKTICK_RE.sub("", c["text"]))]
    if stubs:
        add("hard", "claims are filled in (no template placeholders)", ", ".join(stubs[:12]))

    for name in ("problem", "vision", "out of scope", "language", "principles", "constraints",
                 "dependencies", "not yet specified", "bridge criteria", "decisions", "learning"):
        body = section(isa, name)
        if body is not None and not body.strip():
            add("soft", f"## {DISPLAY.get(name, name)} not left empty", "empty sections never appear; remove it")

    cl = section(isa, "changelog")
    if cl is not None:
        if "conjectured" in cl.lower():
            add("soft", "no ## Changelog section", "holds the C/R/L trail: rename it ## Learning")
        else:
            add("hard", "no ## Changelog section", "git is the changelog; the ISA keeps Decisions + Learning")

    live = [c for c in isa["claims"] if not c["dropped"]]
    anti = [c for c in live if c["anti"]]
    if not anti:
        add("hard" if full else "soft", "at least one anti-claim", "none")
    else:
        add("ok", "anti-claims", str(len(anti)))
    if experiential and not any(c["antecedent"] for c in live):
        add("hard", "antecedent present (experiential goal)", "none")

    row_ids = {r["id"] for r in isa["rows"]}
    orphans = [c["id"] for c in live if c["leaf"] and c["id"] not in row_ids and not c["inline_probe"]]
    if orphans:
        add("hard" if full else "soft", "every leaf claim names its probe", ", ".join(orphans[:12]))
    elif live:
        add("ok", "every leaf claim names its probe")

    known = {c["id"] for c in isa["claims"]}
    for r in isa["rows"]:
        if r["id"] and r["id"] not in known:
            add("soft", "Test Strategy row keys a real claim", r["id"])
        if r["type"] and r["type"] not in TYPE_CLASS:
            add("soft", "Test Strategy type is in the vocabulary", f"{r['id']}: {r['type']}")
        if r["severity"] not in SEVERITIES:
            add("soft", "severity is critical or blank", f"{r['id']}: '{r['severity']}' dropped")
        if r["tier"] not in TIERS:
            add("soft", "tier is deep or blank", f"{r['id']}: '{r['tier']}'")
    if goal and goal.strip().lower() not in ("null", "~", '""', ""):
        unanchored = [r["id"] for r in isa["rows"] if not r["anchors_to"].strip()]
        if unanchored:
            add("hard", "every Test Strategy row has anchors_to", ", ".join(unanchored[:12]))

    for p in edge_problems(isa):
        add("hard", "IDs and edges are valid", p)

    fog = section(isa, "not yet specified")
    if complete and fog is not None and fog.strip():
        add("hard", "fog is empty at phase: complete", "graduate or kill each entry via Decisions")

    ver = section(isa, "verification")
    if ver:
        paras = [l for l in ver.splitlines() if l.strip() and not re.match(r"^\s*[-*]\s", l)
                 and not l.strip().startswith("<!--")]
        if paras:
            add("soft", "Verification holds one-line provenance stubs", f"{len(paras)} non-stub line(s)")

    if full and "context_sufficient" not in fm:
        add("soft", "context_sufficient recorded", "outcome of the ambiguity check")
    return out, sub


def print_check(isa, findings, sub, as_json):
    hard = [f for f in findings if f[0] == "hard"]
    if as_json:
        print(json.dumps({"path": isa["path"], "substance": sub, "status": "fail" if hard else "pass",
                          "findings": [{"severity": s, "check": l, "detail": d} for s, l, d in findings]},
                         ensure_ascii=False, indent=2))
    else:
        mark = {"ok": "OK", "hard": "!!", "soft": "~~"}
        print(f"ISA check ({sub}): {isa['path']}")
        for s, l, d in findings:
            print(f"  [{mark[s]}] {l}{(' - ' + d) if d else ''}")
        c, t = progress(isa)
        print(f"{c}/{t} claims closed")
        print("RESULT:", "INCOMPLETE" if hard else "COMPLETE")
    return 1 if hard else 0

# ------------------------------------------------------------------ locks / frontier

def lock_dir(isa_path):
    real = os.path.normcase(os.path.realpath(str(isa_path)))
    return kai_home() / "MEMORY" / "STATE" / "isa-locks" / hashlib.sha1(real.encode("utf-8")).hexdigest()


def read_lock(p):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def lock_age_hours(info, lock_path=None):
    """Age from the lock's own timestamp; a lock still being written (empty or unparsable)
    falls back to the file's mtime so it is never mistaken for a stale one."""
    try:
        ts = _dt.datetime.fromisoformat(info["ts"])
        if ts.tzinfo is None:
            ts = ts.astimezone()
        return (_dt.datetime.now().astimezone() - ts).total_seconds() / 3600
    except Exception:
        pass
    if lock_path is not None:
        try:
            return max(0.0, (_dt.datetime.now().timestamp() - os.path.getmtime(str(lock_path))) / 3600)
        except OSError:
            pass
    return 1e9


def lock_file(isa_path, cid):
    return lock_dir(isa_path) / (re.sub(r"[^A-Za-z0-9_.-]", "_", cid) + ".lock")


def partition(isa, ttl):
    by = {c["id"]: c for c in isa["claims"]}
    resolved = lambda i: i in by and (by[i]["checked"] or by[i]["dropped"])
    res = {"takeable": [], "taken": [], "blocked": [], "closed": [], "stale": []}
    for c in isa["claims"]:
        if not c["leaf"] and not c["after"]:
            continue
        if c["checked"] or c["dropped"]:
            res["closed"].append(c["id"])
            continue
        waiting = [d for d in c["after"] if not resolved(d)]
        if waiting:
            res["blocked"].append({"id": c["id"], "on": waiting})
            continue
        lf = lock_file(isa["path"], c["id"])
        if lf.exists():
            info = read_lock(lf)
            if lock_age_hours(info, lf) <= ttl:
                res["taken"].append({"id": c["id"], "by": info.get("session")})
                continue
            res["stale"].append({"id": c["id"], "by": info.get("session")})
        res["takeable"].append(c["id"])
    return res


def cmd_claim(isa, cid, session, ttl):
    by = {c["id"]: c for c in isa["claims"]}
    c = by.get(cid)
    if not c:
        print(f"refused: unknown claim {cid}")
        return 2
    if c["checked"] or c["dropped"]:
        print(f"refused: {cid} is closed")
        return 2
    waiting = [d for d in c["after"] if not (d in by and (by[d]["checked"] or by[d]["dropped"]))]
    if waiting:
        print(f"refused: {cid} is blocked on {', '.join(waiting)}")
        return 2
    lf = lock_file(isa["path"], cid)
    lf.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps({"session": session, "ts": now_iso(), "isa": isa["path"], "id": cid})
    for _attempt in range(2):
        try:
            fd = os.open(str(lf), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(payload)
            print(f"claimed {cid}" + (" (stale lock taken)" if _attempt else ""))
            return 0
        except FileExistsError:
            info = read_lock(lf)
            if info.get("session") == session:
                tmp = lf.with_name(lf.name + f".{os.getpid()}.tmp")
                tmp.write_text(payload, encoding="utf-8")
                os.replace(str(tmp), str(lf))
                print(f"claimed {cid} (heartbeat)")
                return 0
            if lock_age_hours(info, lf) <= ttl:
                print(f"refused: {cid} held by {info.get('session')}")
                return 2
            # Stale: move it aside atomically. Only one contender's rename can succeed, because
            # the source vanishes; the winner then retries the exclusive create.
            grave = lf.with_name(lf.name + f".stale.{os.getpid()}.{_dt.datetime.now().timestamp():.6f}")
            try:
                os.rename(str(lf), str(grave))
            except OSError:
                pass  # another session moved it first; fall through to retry the exclusive create
            else:
                moved = read_lock(grave)
                if moved.get("ts") != info.get("ts") and lock_age_hours(moved, grave) <= ttl:
                    # We moved a lock a faster session had just written: put it back and refuse.
                    try:
                        os.rename(str(grave), str(lf))
                    except OSError:
                        pass
                    print(f"refused: {cid} held by {moved.get('session')}")
                    return 2
                try:
                    grave.unlink()
                except OSError:
                    pass
    info = read_lock(lf)
    print(f"refused: {cid} held by {info.get('session')}")
    return 2


def cmd_release(isa, cid, session, force):
    lf = lock_file(isa["path"], cid)
    if not lf.exists():
        print(f"no lock on {cid}")
        return 0
    info = read_lock(lf)
    if info.get("session") != session and not force:
        print(f"refused: {cid} held by {info.get('session')} (use --force)")
        return 2
    try:
        lf.unlink()
    except FileNotFoundError:
        pass
    print(f"released {cid}")
    return 0

# ------------------------------------------------------------------ logs

def append_jsonl(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def slug_of(isa):
    return isa["frontmatter"].get("slug") or Path(isa["path"]).parent.name


def cmd_asklog(isa, ask, status, note):
    if status not in ("met", "skipped", "surfaced", "failed"):
        print("status must be met|skipped|surfaced|failed")
        return 2
    append_jsonl(kai_home() / "MEMORY" / "OBSERVABILITY" / "ask-fidelity.jsonl",
                 {"ts": now_iso(), "isa": slug_of(isa), "ask": ask, "status": status, "note": note})
    print(("✗ " if status == "failed" else "✓ ") + f"{status}: {ask}")
    return 1 if status == "failed" else 0


def _int(v, default):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return default


def cmd_reflect(isa, reflection, session):
    c, t = progress(isa)
    fm = isa["frontmatter"]
    rec = {"ts": now_iso(), "session": session, "isa": slug_of(isa), "path": isa["path"],
           "phase": fm.get("phase"), "closed": c, "total": t, "iteration": _int(fm.get("iteration"), 1),
           "anti_claims": sum(1 for x in isa["claims"] if x["anti"] and not x["dropped"]),
           "decisions": len([l for l in (section(isa, "decisions") or "").splitlines() if l.strip().startswith("-")]),
           "reflection": reflection}
    append_jsonl(kai_home() / "MEMORY" / "LEARNING" / "REFLECTIONS" / "algorithm-reflections.jsonl", rec)
    print(f"reflection recorded for {rec['isa']} ({c}/{t})")
    return 0

# ------------------------------------------------------------------ main

def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(prog="isa_tool", description=__doc__.split("\n")[0])
    ap.add_argument("cmd", choices=["check", "progress", "ascent", "frontier", "status", "validate",
                                    "claim", "release", "asklog", "reflect"])
    ap.add_argument("isa")
    ap.add_argument("--substance", choices=["trivial", "substantial", "deepest"])
    ap.add_argument("--experiential", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--id")
    ap.add_argument("--session", default="")
    ap.add_argument("--ttl-hours", type=float, default=2.0)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--ask")
    ap.add_argument("--status")
    ap.add_argument("--note", default="")
    ap.add_argument("--reflection")
    a = ap.parse_args(argv)
    try:
        isa = load(a.isa)
    except (OSError, UnicodeDecodeError) as exc:
        print(f"cannot read {a.isa}: {exc}")
        return 2

    if a.cmd == "check":
        findings, sub = check(isa, a.substance, a.experiential)
        return print_check(isa, findings, sub, a.json)
    if a.cmd == "progress":
        c, t = progress(isa)
        print(f"{c}/{t}")
        return 0
    if a.cmd == "ascent":
        c, t = progress(isa)
        print(ascent_strip(derive_ascent(isa["frontmatter"].get("phase"), c, t)))
        return 0
    if a.cmd == "validate":
        probs = edge_problems(isa)
        for p in probs:
            print("  [!!] " + p)
        print("RESULT:", "INVALID" if probs else "VALID")
        return 1 if probs else 0
    if a.cmd in ("frontier", "status"):
        probs = edge_problems(isa)
        res = partition(isa, a.ttl_hours)
        if a.json:
            print(json.dumps(res if a.cmd == "status" else
                             {"takeable": res["takeable"], "taken": len(res["taken"]), "blocked": len(res["blocked"])},
                             ensure_ascii=False, indent=2))
        elif a.cmd == "frontier":
            print("takeable: " + (", ".join(res["takeable"]) or "none"))
            print(f"taken: {len(res['taken'])} · blocked: {len(res['blocked'])} · closed: {len(res['closed'])}")
        else:
            print("takeable: " + (", ".join(res["takeable"]) or "none"))
            for t in res["taken"]:
                print(f"taken:    {t['id']} by {t['by']}")
            for b in res["blocked"]:
                print(f"blocked:  {b['id']} on {', '.join(b['on'])}")
            for s in res["stale"]:
                print(f"stale:    {s['id']} (was {s['by']})")
            print("closed:   " + (", ".join(res["closed"]) or "none"))
        for p in probs:
            print("  [!!] " + p, file=sys.stderr)
        return 1 if probs else 0
    if a.cmd in ("claim", "release"):
        if not a.id or not a.session:
            print("--id and --session (the harness session ID, never a shared label) are required")
            return 2
        return cmd_claim(isa, a.id, a.session, a.ttl_hours) if a.cmd == "claim" else \
            cmd_release(isa, a.id, a.session, a.force)
    if a.cmd == "asklog":
        if not a.ask or not a.status:
            print("--ask and --status are required")
            return 2
        return cmd_asklog(isa, a.ask, a.status, a.note)
    if a.cmd == "reflect":
        if not a.reflection:
            print("--reflection is required")
            return 2
        return cmd_reflect(isa, a.reflection, a.session)
    return 2


if __name__ == "__main__":
    sys.exit(main())
