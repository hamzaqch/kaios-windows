---
name: isa
description: Owns the Ideal State Artifact (ISA), the one file that states what done means as falsifiable claims. Scaffolds a new ISA from a prompt, interviews to deepen thin sections, grills a half-formed idea into shape, checks completeness, reconciles ephemeral feature files back to the master, seeds a project ISA from an existing repo, and appends decisions, learning and verification. Use when the user says ISA, ISC, ideal state, spec this, what does done look like, grill me, interview me, check completeness, resume a task, fog, or not yet specified.
argument-hint: "scaffold | interview | grill | check | reconcile | seed | append  <path or prompt>"
---
# ISA: Ideal State Artifact

The ISA is the single document that articulates done for anything whose ideal state is being pursued: a project, an application, a library, infrastructure, a work session, a piece of writing, a decision. It is five things at once: the ideal-state articulation, the test harness, the build verification, the done condition and the system of record. This skill owns the workflows that create and refine ISAs, and the example library.

Every ISA shares one meta-ideal-state above its specific one: **euphoric surprise in the human using the system.** `## Vision` is where that general target takes specific shape for this work, so every ISA climbs toward two summits at once.

**The format spec is `~/.copilot/kai/ISA_FORMAT.md`. It wins on any contradiction with this skill.** Read it before writing an ISA by hand.

## The seventeen-section body (fixed order; sections appear only when populated)

| # | Section | Purpose |
|---|---------|---------|
| 1 | `## Problem` | What is broken or missing right now |
| 2 | `## Vision` | What euphoric surprise looks like: a concrete scene, 1–5 sentences |
| 3 | `## Out of Scope` | Anti-vision, declared in prose |
| 4 | `## Language` | Ubiquitous language; a term enters only after it caused a confusion (project ISAs) |
| 5 | `## Principles` | Truths the work must respect regardless of implementation |
| 6 | `## Constraints` | Immovable mandates that bound the solution space |
| 7 | `## Dependencies` | `requires: <slug> — <contract>` lines (only in ISA hierarchies) |
| 8 | `## Goal` | The hard-to-vary spine, 1–3 sentences, opening with the verbatim goal |
| 9 | `## Claims` | Flat claims when the work has no distinct features |
| 10 | `## Not yet specified` | Fog: `- fog: <question> — <what must resolve>`; empty at close |
| 11 | `## Bridge Criteria` | Cross-ISA seam claims (only with siblings) |
| 12 | `## Test Strategy` | `isc \| type \| check \| threshold \| tool \| anchors_to \| severity \| tier` |
| 13 | `## Features` | `### F<n> · <name>` + `Why:` + its claims (instead of flat Claims) |
| 14 | `## Decisions` | Timestamped, dead ends included, `refined:` for restructures |
| 15 | `## Learning` | conjectured / refuted by / learned / criterion now (not a changelog) |
| 16 | `## Verification` | One-line provenance stub per closed claim (or `## Log`) |
| 17 | `## Remaining Work` | Owed work that was never a claim of this run; advisory |

**Completeness gate (substance-scaled):** trivial = Goal + Claims; substantial = Problem, Vision, Out of Scope, Constraints, Goal, Claims or Features, Test Strategy; deepest = all of that plus Principles, Decisions, Learning and an Interview before building. Any `<project>/ISA.md` is at least substantial. Full detail and the mechanical subset: `ISA_FORMAT.md` § Completeness Gate.

**Three guardrails, by who they bind:** Principles bind the *thinking*; Constraints bind the *solution space*; Out of Scope binds the *vision*; Anti-claims bind the *test surface* (they are how the first three become probe-able).

## Workflow routing

Match the verb in the request. When ambiguous, default to Scaffold for a new ISA and CheckCompleteness for an audit.

| Verb / intent | Workflow |
|---|---|
| scaffold, create, generate, new ISA from this prompt, extract a feature as an ephemeral file | `Workflows/Scaffold.md` |
| interview me, fill in the ISA, deepen, ask me questions | `Workflows/Interview.md` |
| grill me, grill, discovery interview, figure out the shape | `Workflows/Grill.md` |
| check, audit, score this ISA, is it complete? | `Workflows/CheckCompleteness.md` |
| reconcile, merge the feature file back, ephemeral to master | `Workflows/Reconcile.md` |
| seed, bootstrap from this repo, draft an ISA from existing code | `Workflows/Seed.md` |
| append a decision, a learning entry, a verification stub | `Workflows/Append.md` |

When running a workflow, say so in one line: `Running the **<Workflow>** workflow in the **isa** skill to <action>...`

## Tools

`python ~/.copilot/skills/isa/Tools/isa_tool.py <cmd> <isa>` (stdlib only, never writes the ISA):

| Command | Does |
|---|---|
| `check [--substance S] [--experiential] [--json]` | mechanical completeness gate; exit 1 on any hard finding |
| `progress` | the mechanical `M/N` for the `progress:` field |
| `ascent` | the derived `════ Kai \| Algorithm \| <icon> <Label> ════` strip |
| `frontier` / `status` / `validate` | dependency edges: takeable claims, the full partition, edge integrity |
| `claim` / `release --id <ID> --session <session-id>` | per-claim locks for concurrent sessions |
| `asklog --ask "<ask>" --status met\|skipped\|surfaced\|failed` | explicit-ask audit line (Algorithm claim 10) |
| `reflect --reflection "<text>"` | reflection record at learn |

Also: `python ~/.copilot/kai/bin/kai.py isa new|list|excerpt|reconcile` (`isa new` scaffolds a starter; `excerpt` / `reconcile` are the deterministic ephemeral round trip). For the completeness gate use `isa_tool.py check`, not the older `kai.py isa check`.

## Gotchas

Each entry is a non-obvious failure that has bitten real ISA work.

- **ID stability is the cornerstone of Reconcile: never renumber.** A split of `ISC-7` keeps `ISC-7` as the parent and adds `ISC-7.1`, `ISC-7.2`. A dropped claim leaves a tombstone (`- [ ] ISC-N: [DROPPED — see Decisions YYYY-MM-DD]`). Renumbering breaks ephemeral merges silently; it looks like "the worker's checkmarks didn't land".
- **Ephemeral files are derived views, never sources of truth.** `kai.py isa excerpt <master> <F-id>` writes the slice to `<master-dir>/_ephemeral/` with the `KAI:EPHEMERAL` header; workers operate on it; `kai.py isa reconcile <ephemeral>` merges back by ID. Hand-editing the master from an ephemeral file is forbidden.
- **The changelog is git.** The ISA never carries a `## Changelog`; `git log -- <isa-path>` is the change record. The conjectured/refuted/learned trail lives in `## Learning`.
- **The `## Learning` format is non-negotiable.** All four pieces (`conjectured`, `refuted by`, `learned`, `criterion now`) in that order. Missing one makes it a Decision, and Append refuses it.
- **Evidence collapses on close.** A closed claim's Verification entry is one line (commit hash, test name, probe ref), never a paragraph.
- **Project ISAs are always at least substantial.** One trivial task on a project must not downgrade its structure.
- **Empty sections never appear.** The body is a capacity, not a requirement. Length is never graded; a one-sentence section can be exactly right.
- **Anti-claims come from Out of Scope plus regression concerns.** At least one on every real build; missing is a hard failure on substantial work.
- **Experiential goals need an `Antecedent:` claim:** the precondition that reliably produces the feeling. Verifiable goals (build, deploy, schema) don't.
- **Reconcile is deterministic: there are no conflicts to resolve.** An ID exists in the master (mechanical merge) or it doesn't (abort). Structural changes go into the master by a separate edit first.
- **Feature blocks contain their claims.** `### F<n> · <name>` + one `Why:` line that says what the name and claims don't + the claims nested under it; `F0 · Cross-cutting` for spanning claims. IDs stay global. Flat Claims OR Features, never both.
- **Features are vertical slices.** Each cuts end to end to a verifiable increment. The one exception is a wide sweep, sequenced expand → migrate in verifiable batches → contract.
- **Fog is not a claim.** Can you *state* the question precisely now? Statable with a falsifier → a claim (even if blocked); statable but not probe-able → fog; beyond the vision → Out of Scope. Fog must be empty at `phase: complete`.
- **Test Strategy keeps its positional columns.** `isc | type | check | threshold | tool | anchors_to`, then optional `severity`, `tier`. Drop `threshold` only by leaving the cell empty; deleting the column shifts `anchors_to` and the anchor check misfires on rows that visibly carry an anchor. Escape literal pipes as `\|`.
- **Probes follow the seam rule.** Attach at the highest boundary that exercises the claim, agreed before building, never internals.
- **A design question's cheapest probe is a throwaway prototype.** Disposable, out of the main line; only the decision folds back.
- **Ordering edges are a trailing `(after: ID, ID)`, and optional forever.** Only where ordering is real. Backticked mentions and mid-line parentheticals don't bind; dropped blockers count as resolved.
- **Prefer red before build.** A runnable probe should fail before the build and pass after. Screenshot and manual probes are exempt.

## Examples

`Examples/` holds reference ISAs in the current format. Read the closest one before scaffolding, copy its section headers, then populate.

| File | Shows |
|---|---|
| `Examples/canonical-isa.md` | A substantial project ISA in feature mode: every guardrail, Test Strategy with anchors and severity, real Decisions and Learning |
| `Examples/minimal-isa.md` | A trivial task: Goal + Claims, inline probes |
| `Examples/experiential-isa.md` | An essay: antecedents, attested and judged claims, fog that graduates |

## Relationship to the Algorithm

The Algorithm (`~/.copilot/kai/ALGORITHM.md`, `/algorithm`) invokes this skill to scaffold, check, extract and reconcile. This skill doesn't run the Algorithm; it owns the artifact the Algorithm operates on, and it works the same whether called by the Algorithm or directly by the user.
