---
task: "Add a --no-color flag to the dump CLI"
slug: 20260428-no-color-flag
phase: complete
progress: 4/4
started: 2026-04-28T21:15:00Z
updated: 2026-04-28T21:31:00Z
---

<!-- Fictitious teaching example. A trivial task: Goal + Claims only, probes inline. Every other section is absent because nothing earned it. -->

## Goal

`dump` strips ANSI color codes when given `--no-color`, or when the `NO_COLOR` environment variable is set (the no-color.org convention), and keeps color by default on a terminal.

## Claims

- [x] C1: `dump --no-color` output contains zero ANSI escape sequences. Probe: `dump --no-color | rg -c "\x1b\["` prints nothing / exits 1.
- [x] C2: `NO_COLOR=1 dump` output contains zero ANSI escape sequences. Probe: same search with the env var set.
- [x] C3: Default `dump` on a terminal still emits color. Probe: run under a pseudo-terminal and count escapes ≥ 1.
- [x] C4: Anti: `--no-color` writes nothing new to stderr. Probe: `dump --no-color 2>&1 >/dev/null` is empty.

## Verification

- C1: shell — escape count 0, commit e41b2d0
- C2: shell — escape count 0, commit e41b2d0
- C3: shell — 38 escapes under pty, commit e41b2d0
- C4: shell — stderr empty, commit e41b2d0

<!--
Why C4 matters: a sloppy implementation that prints "color disabled" to stderr would pass C1 and C2 while breaking the silent-by-default expectation. The anti-claim is what catches it.
-->
