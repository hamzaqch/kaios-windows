---
task: "Write a 1500-word essay arguing that slow software is a design choice"
slug: 20260510-slow-software-essay
phase: climbing
progress: 4/9
started: 2026-05-10T14:00:00Z
updated: 2026-05-12T09:20:00Z
principal_stated_goal: "write an essay that makes a working developer stop and rethink why their tools feel slow"
principal_stated_goal_source: prompt
principal_stated_goal_signal: 2
principal_stated_goal_locked: 2026-05-10T14:00:00Z
context_sufficient: true
interview_invoked: true
---

<!-- Fictitious teaching example of an experiential ISA: the goal is a reaction in a reader, so antecedents carry the weight and the verifier mix skews judged and attested. -->

## Problem

Developers treat slowness as weather: something that happens to their tools. Most essays on it are benchmarks or rants, and neither changes how a reader sees their own setup.

## Vision

A developer reads it on a lunch break, gets to the third section, opens a terminal, and times the command they run fifty times a day. They send the essay to a teammate with one line: "we chose this."

## Out of Scope

- No benchmarks tables or language wars.
- No product recommendations.
- Not a history of computing performance.

## Principles

- One idea, held all the way through; no survey.
- Every claim about speed is grounded in something the reader can try in under a minute.

## Constraints

- 1,400–1,600 words.
- Plain language: passes the writing-style backstop (`~/.copilot/kai/RULES/WritingStyle.md`).

## Goal

"write an essay that makes a working developer stop and rethink why their tools feel slow." Done means a 1,500-word essay with one thesis (slowness is chosen, by defaults and by tolerance), one try-it-now moment, and a close that hands the reader a decision rather than a summary.

## Claims

- [x] ISC-1: Antecedent: the opening scene is a delay the reader has personally sat through.
- [x] ISC-2: Antecedent: a try-it-now moment appears before the midpoint.
- [ ] ISC-3: The thesis is stated in one sentence in the first 150 words.
- [x] ISC-4: The essay runs 1,400–1,600 words.
- [x] ISC-5: Anti: no paragraph contains a benchmark table or a language comparison.
- [ ] ISC-6: Anti: zero banned constructions from the writing-style backstop.
- [ ] ISC-7: The close ends on a decision the reader can make, not a recap.
- [ ] ISC-8: Two of three test readers say they would time a command after reading.
- [ ] ISC-9: A rubric-bound reviewer rates the thesis as held throughout in 3 of 3 samples (after: ISC-3).

## Test Strategy

| isc | type | check | threshold | tool | anchors_to | severity | tier |
|-----|------|-------|-----------|------|------------|----------|------|
| ISC-1 | manual | the opening delay is recognizable | user says yes | user reads the first paragraph | literal | | |
| ISC-2 | shell | a runnable command appears before the midpoint | position < 50% | `python scripts/first_code_position.py essay.md` | literal | | |
| ISC-3 | eval | thesis present, one sentence, first 150 words | 3/3 | rubric review by a fresh `@kai-reviewer` | literal | | |
| ISC-4 | shell | word count | 1400–1600 | `python -c "print(len(open('essay.md',encoding='utf-8').read().split()))"` | derived: length | | |
| ISC-5 | shell | no tables or language comparisons | 0 matches | `rg -c "^\|" essay.md` | derived: out-of-scope | | |
| ISC-6 | shell | banned-construction sweep | 0 matches | `python scripts/style_sweep.py essay.md` | derived: voice | | |
| ISC-7 | manual | the close hands over a decision | user says yes | user reads the last paragraph | literal | | |
| ISC-8 | manual | test-reader reaction | 2 of 3 | three readers asked one question afterwards | literal | | |
| ISC-9 | eval | thesis held throughout | pass^3 | rubric review, 3 fresh samples | literal | | deep |

## Decisions

- 2026-05-10 15:10: Chose "slowness is chosen" over "slowness is expensive", because cost arguments invite benchmarks, which are out of scope.
- 2026-05-11 10:00: ❌ DEAD END: Opened with a statistic about developer hours lost. Test reader skimmed past it. Replaced with a personal-delay scene (ISC-1).
- 2026-05-12 09:00: refined: the fog about the ending graduated into ISC-7 once the draft showed a recap close falling flat.

## Learning

- 2026-05-11 | conjectured: a striking statistic is the strongest hook for a developer audience
  refuted by: the first test reader skipped the opening paragraph entirely
  learned: for this goal the hook has to be a felt experience, not a number
  criterion now: ISC-1 became an antecedent about a delay the reader has sat through

## Verification

- ISC-1: manual — user confirmed 2026-05-11
- ISC-2: shell — first command at 31%, draft 3
- ISC-4: shell — 1,512 words, draft 3
- ISC-5: shell — 0 matches, draft 3
