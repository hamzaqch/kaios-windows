---
task: "Build BeanLine, a peer-to-peer green-coffee lot marketplace"
slug: 20260201-beanline-v1
project: BeanLine
phase: climbing
progress: 14/30
started: 2026-02-01T17:00:00Z
updated: 2026-04-25T03:14:00Z
principal_stated_goal: "I want a marketplace where small roasters can sell 5 to 50kg green coffee lots to verified buyers with escrow, for under 8% all-in fees"
principal_stated_goal_source: prompt
principal_stated_goal_signal: 2
principal_stated_goal_locked: 2026-02-01T17:00:00Z
context_sufficient: true
interview_invoked: true
---

<!-- Fictitious teaching example. "BeanLine" and beanline.example.com (an RFC 2606 reserved domain) are invented; any resemblance to real products is coincidental. -->

## Problem

Small-batch roasters with 5–50kg green-coffee lots and home roasters with surplus have no good place to find each other. General marketplaces don't handle food-safe shipping, charge consumer fees that eat the margin on a 5kg lot, and offer no trust signal for "was this stored properly?" Most lots get sold at a once-a-year festival or composted. The supply exists; the connective tissue doesn't.

## Vision

A verified roaster lists a Colombian lot on Wednesday with origin, process, harvest date, moisture and tasting notes. A small café three states away finds it by region and process, pays into escrow, and on Friday scans the QR handoff card on the box to confirm condition, which releases payment. No festival, no haggling, no DM back-and-forth.

## Out of Scope

- No retail-bag pricing. Minimum lot is 5kg; below that the economics break for both sides.
- No futures or pre-harvest contracts. Existing physical lots only.
- No roasted coffee. Green only; roasted freshness collides with shipping time.
- No multi-currency in v1.
- No social graph: no follow, friend or DM. Messaging is per listing.
- No mobile native apps. Web plus installable PWA.

## Language

**Lot**: one listing of a single green coffee, 5–50kg, with one origin and one process.
_Avoid_: bag, order (an order is a purchase of a lot; a bag is retail, which is out of scope).

## Principles

- Buyer trust beats catalog size: 200 verified lots beat 20,000 open ones with one fraud incident.
- The handoff card is the product, not the website: a clean receipt flow is what makes the next listing land.
- Roaster economics are non-negotiable: under 8% all-in or it doesn't beat festival sales.
- Human curation beats algorithmic personalization at this scale.

## Constraints

- Server-rendered web app on one edge platform with its managed SQL store and object storage; no third-party hosting in the user path.
- Magic-link email auth only in v1. Roaster and buyer verification by manual review of submitted business proof.
- A hosted payment processor's marketplace/escrow product; no home-grown payments.
- All-in fees ≤ 8% (processor fees + BeanLine margin ≤ 5.1%).
- ≤ 100KB gzipped JavaScript on the listing page.
- p95 cold load on cellular ≤ 1s for browse, ≤ 1.5s for listing detail.
- Images served as WebP only; originals never served.
- Public read API rate-limited to 60 requests/min/IP.
- Buyer–seller messages retained 12 months for disputes.

## Goal

"I want a marketplace where small roasters can sell 5 to 50kg green coffee lots to verified buyers with escrow, for under 8% all-in fees." Done means: verified roasters list lots, verified buyers pay into escrow and confirm receipt by QR handoff, BeanLine's margin stays ≤ 5.1% (≤ 8% all-in), browse renders in ≤ 1s p95 on cellular, and the quality lead approves a new listing in ≤ 10 minutes.

## Not yet specified

- fog: should disputes be arbitrated by the quality lead or by a third party? — needs the first real dispute volume before it can be stated as a claim

## Test Strategy

| isc | type | check | threshold | tool | anchors_to | severity |
|-----|------|-------|-----------|------|------------|----------|
| ISC-1 | shell | deploy command exits 0 | exit 0 | `make deploy` | derived: shippable | |
| ISC-2 | http | home page serves HTML | 200 + text/html | `curl -sfI https://beanline.example.com \| grep -qi "content-type: text/html"` | derived: shippable | critical |
| ISC-3 | shell | no third-party requests on browse | 0 | `python scripts/third_party_audit.py /browse` | derived: privacy | |
| ISC-4 | http | every image URL is WebP | 100% image/webp | `python scripts/image_format_audit.py` | derived: image-policy | |
| ISC-5 | test | roaster can submit a complete listing | 201 + pending | `python -m pytest tests/test_listing.py -k submit` | literal | |
| ISC-6 | http | pending listings invisible to anonymous users | 404 | `python scripts/probe_pending.py` | literal | |
| ISC-7 | manual | quality-lead approval time | p95 ≤ 600s | weekly ops review (user attests) | literal | |
| ISC-8 | http | approved listing live within 60s | 200 ≤ 60s | `python scripts/probe_publish_latency.py` | literal | |
| ISC-9 | http | sold-out lot hidden within 60s | absent ≤ 60s | `python scripts/probe_soldout.py` | derived: catalog-truth | |
| ISC-10 | http | browse paginates 20 per page | 20 | `python scripts/probe_browse.py --count` | derived: discovery | |
| ISC-11 | test | region filter | only region lots | `python -m pytest tests/test_browse.py -k region` | derived: discovery | |
| ISC-12 | test | process filter | only process lots | `python -m pytest tests/test_browse.py -k process` | derived: discovery | |
| ISC-13 | shell | browse p95 on simulated 4G | ≤ 1000ms | `python scripts/perf_p95.py /browse 1000` | derived: responsiveness | |
| ISC-14 | shell | listing p95 on simulated 4G | ≤ 1500ms | `python scripts/perf_p95.py /lots/sample 1500` | derived: responsiveness | |
| ISC-15 | property | search matches origin/process/notes case-insensitively | 1000 runs | `python -m pytest tests/test_search_props.py` | derived: discovery | |
| ISC-16 | test | magic link is single-use and expires in 15 min | pass | `python -m pytest tests/test_auth.py -k magic` | derived: trust | |
| ISC-17 | test | session cookie flags | HttpOnly Secure SameSite=Lax | `python -m pytest tests/test_auth.py -k cookie` | derived: trust | |
| ISC-18 | test | verification queue elevates roles only after review | pass | `python -m pytest tests/test_verify.py` | literal | |
| ISC-19 | http | unverified users cannot list | 403 | `python scripts/probe_rbac.py list` | literal | |
| ISC-20 | http | unverified users cannot buy | 403 | `python scripts/probe_rbac.py checkout` | literal | |
| ISC-21 | test | checkout holds funds in escrow | held | `python -m pytest tests/test_checkout.py -k escrow` | literal | critical |
| ISC-22 | test | fees on a $250 lot within cap | ≤ $20 | `python -m pytest tests/test_checkout.py -k fee_cap` | literal | |
| ISC-23 | test | QR scan releases escrow | transfer fires | `python -m pytest tests/test_handoff.py -k release` | literal | critical |
| ISC-24 | test | escrow auto-releases on day 8 | transfer ≤ 60s after cron | `python -m pytest tests/test_handoff.py -k day8` | derived: escrow-timeout | |
| ISC-25 | test | messages scoped to one listing | pass | `python -m pytest tests/test_messages.py -k scope` | derived: disputes | |
| ISC-26 | shell | message retention ≥ 12 months | policy row present | `python scripts/check_retention.py` | derived: disputes | |
| ISC-27 | http | public API rate limit | 61st request → 429 | `python scripts/probe_ratelimit.py` | derived: abuse | |
| ISC-28 | http | social-graph endpoints absent | 404 | `python scripts/probe_absent.py /api/follow /api/dm` | literal | |
| ISC-29 | property | no fee path exceeds 8% all-in | 10000 runs | `python -m pytest tests/test_fee_props.py` | literal | |
| ISC-30 | screenshot | listing page readable at 390px | viewed, no overflow | browser capture of /lots/sample at 390px, viewed | derived: mobile | |

## Features

### F0 · Cross-cutting
Why: invariants that hold on every page: it ships, it leaks nothing to third parties, images stay small.

- [x] ISC-1: The production deploy command exits 0.
- [x] ISC-2: The home page returns HTTP 200 with `text/html`.
- [x] ISC-3: Anti: browse makes zero third-party network requests on first load.
- [x] ISC-4: Anti: no image URL ever serves an original camera JPEG.

### F1 · Listing pipeline
Why: a roaster can go from "I have a lot" to "it's public" in one sitting, with a human checking quality in between.

- [x] ISC-5: A verified roaster can submit a listing with every required field and one photo.
- [x] ISC-6: Submitted listings stay invisible to anonymous users until approved.
- [ ] ISC-7: The quality lead approves or rejects a pending lot in ≤ 10 minutes at p95.
- [x] ISC-8: An approved listing is live within 60 seconds of approval (after: ISC-6).
- [ ] ISC-9: A sold-out lot disappears from browse within 60 seconds.

### F2 · Browse and search
Why: a buyer's first three searches return relevant lots, because that's when they decide to stay.

- [x] ISC-10: Browse paginates available lots 20 per page, newest first.
- [x] ISC-11: The region filter returns only lots from that region.
- [x] ISC-12: The process filter returns only lots with that process.
- [ ] ISC-13: Browse p95 cold load on simulated 4G is ≤ 1000ms.
- [ ] ISC-14: Listing detail p95 cold load is ≤ 1500ms.
- [ ] ISC-15: Search matches origin, process and notes case-insensitively for every generated query.

### F3 · Auth and verification
Why: only real roasters sell and only real wholesale buyers buy, which is the whole trust story.

- [x] ISC-16: A magic link is single-use and expires after 15 minutes.
- [x] ISC-17: The session cookie is `HttpOnly; Secure; SameSite=Lax`.
- [x] ISC-18: Roles elevate from unverified only after a manual review is recorded.
- [ ] ISC-19: Anti: an unverified user's listing submission returns 403.
- [ ] ISC-20: Anti: an unverified user's checkout returns 403 with "verification required".

### F4 · Payments and escrow
Why: the roaster gets paid only when the buyer confirms the beans arrived in good shape, and never waits forever.

- [x] ISC-21: Checkout holds funds in escrow until handoff.
- [ ] ISC-22: Total fees on a $250 lot stay ≤ $20 (8%).
- [ ] ISC-23: Scanning the handoff QR releases escrow to the roaster (after: ISC-21).
- [ ] ISC-24: Unconfirmed escrow auto-releases on day 8 with an audit entry (after: ISC-23).
- [ ] ISC-29: Anti: no combination of lot price and quantity yields fees above 8% all-in.

### F5 · Messaging and limits
Why: disputes can be settled from the record, and nobody can scrape or spam the catalog.

- [ ] ISC-25: Buyer–roaster messages are scoped to a single listing.
- [ ] ISC-26: Messages are retained for at least 12 months.
- [ ] ISC-27: The public read API returns 429 on the 61st request in a minute.
- [ ] ISC-28: Anti: follow, DM and other social-graph endpoints return 404.
- [ ] ISC-30: The listing page reads without horizontal overflow at a 390px viewport.

## Decisions

- 2026-02-01 17:00: Single edge platform over a separate app host plus database, because co-location wins the cellular budget and the fee math only works with low compute cost.
- 2026-02-08 11:30: Magic-link auth over password + OAuth, because the v1 user base is small and known, and password reset would be the most expensive auth surface.
- 2026-02-22 14:00: ❌ DEAD END: Tried buyer self-attestation (upload a business license, auto-accept). 3 of the first 8 were retail shops sourcing for resale. Reverted to manual review. Don't retry without an automated business-registry cross-check.
- 2026-03-04 09:00: refined: ISC-7 sharpened from "approves listings quickly" to "≤ 10 minutes per lot at p95"; the first wording was unfalsifiable.
- 2026-03-15 22:00: ❌ DEAD END: Tried dynamic social-card image generation. It added 40KB of JS and broke the bundle budget. Reverted to static meta tags.
- 2026-04-01 10:00: refined: added ISC-29 as a property over all prices and quantities after ISC-22's single example passed while the margin crept past 5.1% on large lots.
- 2026-04-12 16:30: refined: ISC-24 added (day-8 auto-release) after early buyers never scanned the QR and escrow sat indefinitely.
- 2026-04-22 22:00: [arch] All money arithmetic in integer cents through one `fees` module; every other module calls it. Floats are banned in payment paths.

## Learning

- 2026-02-22 | conjectured: buyer self-attestation will scale verification at low ops cost
  refuted by: 3 of the first 8 attestations were the wrong buyer profile (retail, not wholesale)
  learned: verification is the load-bearing trust signal; skipping review degrades the buyer pool, which kills roaster trust, which kills supply
  criterion now: ISC-18 requires a recorded manual review before any role elevation

- 2026-04-01 | conjectured: one example fee test proves the cap
  refuted by: large lots crossed a rounding boundary and pushed the margin over 5.1% while the $250 example stayed green
  learned: a cap is a universal claim and needs a universal probe
  criterion now: ISC-29 added as a property over the full price × quantity domain

## Verification

- ISC-1: shell — deploy log, commit 3f9a2c1
- ISC-2: http — `curl -sfI` 200 text/html, 2026-04-25
- ISC-3: shell — third_party_audit 0 requests, commit 7d1e004
- ISC-4: http — image_format_audit 247/247 WebP, 2026-04-22
- ISC-5: test — tests/test_listing.py::test_submit, commit 51b0a9e
- ISC-6: http — probe_pending 404 anonymous, 2026-04-15
- ISC-8: http — probe_publish_latency 22s, 2026-04-15
- ISC-10: http — probe_browse count 20, 2026-04-18
- ISC-11: test — tests/test_browse.py::test_region, commit 9c2e7aa
- ISC-12: test — tests/test_browse.py::test_process, commit 9c2e7aa
- ISC-16: test — tests/test_auth.py::test_magic_single_use, commit 0aa41f2
- ISC-17: test — tests/test_auth.py::test_cookie_flags, commit 0aa41f2
- ISC-18: test — tests/test_verify.py, commit 12de9b0
- ISC-21: test — tests/test_checkout.py::test_escrow_hold, commit 4410c3d

## Remaining Work

- [ ] Write the quality lead's review checklist as a one-page doc — not a claim of this run; waits on the first month of approvals
