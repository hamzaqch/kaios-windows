---
name: arxiv
description: "Search and retrieve arXiv papers by topic, category, author or paper ID, with AlphaXiv AI-generated overviews layered on top so a paper can be triaged in seconds. Stdlib Atom API client; no API key. Three workflows: Latest (newest papers in a field), Search (topic, keyword or author), Paper (deep-dive one paper from an ID or URL). Covers every arXiv category, with shortcuts for cs.AI, cs.LG, cs.CL, cs.CR, cs.MA, cs.SE, cs.IR, cs.CV and cs.RO. Use when the user says arxiv, papers, latest papers, new papers on X, research papers, recent ML papers, find papers about X, papers by <author>, paper lookup, explain this paper, summarize paper 2401.12345, an arxiv.org or alphaxiv.org link, latest LLM papers, AI safety papers, or what's new in AI research. NOT FOR general web research (use /research) or applying a summarization prompt to text you already have (use /fabric)."
argument-hint: "latest <topic> | search <query> | paper <id-or-url>"
---
# arXiv

Wraps the arXiv Atom API (search fields, booleans, sort, rate limit, XML) and pulls AlphaXiv's markdown overview per paper when one exists. Tool:

```
python ~/.copilot/skills/arxiv/tools/arxiv.py latest "<topic or cs.XX[ OR cs.YY]>" [--max 15] [--days 7] [--json]
python ~/.copilot/skills/arxiv/tools/arxiv.py search "<query>" [--field all|ti|abs|au] [--sort submitted|updated|relevance] [--months 12] [--max 15] [--json]
python ~/.copilot/skills/arxiv/tools/arxiv.py paper <id-or-url> [--no-overview] [--json]
python ~/.copilot/skills/arxiv/tools/arxiv.py categories
```

Exit 0 = results, 1 = nothing found, 2 = usage error, 3 = network/parse error.

## Routing

| Trigger | Workflow |
|---|---|
| "latest papers in X", "new papers on X", "what's new in AI research" | `Workflows/Latest.md` |
| "search arxiv for X", "find papers about X", "papers by <author>" | `Workflows/Search.md` |
| arXiv/AlphaXiv URL, an ID like `2401.12345`, "explain this paper" | `Workflows/Paper.md` |

**Done looks like:** every paper listed is real and carries its arXiv link; papers are ordered by relevance to what the user asked (not just recency); AlphaXiv-derived claims are marked as AI-generated; the reply ends with a short "worth reading" pick with one reason each.

## Gotchas

- **`lastUpdatedDate` resurfaces old papers.** An edit to a 2019 paper makes it "latest". `latest` sorts by update but `--days N` filters on the original `published` date; use it when the user wants genuinely new work.
- **The API returns Atom XML, never JSON.** The tool parses it; don't hand-parse API output with regexes in the shell.
- **Rate limit: 3 seconds between calls.** The tool waits automatically between its own requests. Don't fire several tool invocations in parallel against the API; run them one after another.
- **AlphaXiv overviews are AI-generated.** Good for triage; verify against the abstract or PDF before quoting a number or claim. A missing overview just means none has been generated yet; the tool falls back to AlphaXiv full text, then to the abstract.
- **Category search includes cross-lists.** `cat:cs.AI` returns papers whose primary category is elsewhere but cross-listed to cs.AI. The `primary_category` field tells you which is which.
- **Plain phrases are quoted.** `search "prompt injection"` becomes `all:"prompt injection"` (exact phrase). For looser matching pass raw syntax: `search "all:prompt AND all:injection"`.
- **`search` hides papers older than 12 months by default** (except with `--sort relevance`, which searches all time). Pass `--months 0` for all-time results when the user wants classic or older work.
