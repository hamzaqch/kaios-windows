"""arxiv.py - arXiv Atom API client with AlphaXiv overview enrichment. Stdlib only.

  python arxiv.py latest <topic-or-categories> [--max N] [--days N] [--json]
  python arxiv.py search "<query>" [--field all|ti|abs|au] [--sort submitted|updated|relevance]
                         [--months N] [--max N] [--json]
  python arxiv.py paper <id-or-url> [--no-overview] [--json]
  python arxiv.py overview <id-or-url>         AlphaXiv overview markdown only
  python arxiv.py categories                   topic -> category map

Queries in `search` may use raw arXiv syntax (ti:, au:, abs:, cat:, all:, AND/OR/ANDNOT);
a plain phrase is searched as all:"<phrase>" (or the --field you pick).

Exit codes: 0 ok, 1 nothing found / not found, 2 usage error, 3 network error.
No API key needed. The arXiv API asks for >= 3 s between calls; this tool waits
automatically between its own requests.
"""
import datetime as dt
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

API = "https://export.arxiv.org/api/query"
ATOM = "{http://www.w3.org/2005/Atom}"
ARXIV_NS = "{http://arxiv.org/schemas/atom}"
UA = "kai-arxiv/1.0 (stdlib urllib)"
MIN_GAP = 3.0
_last_call = [0.0]

TOPICS = [
    (("ai safety", "alignment"), ["cs.AI", "cs.CL", "cs.LG"]),
    (("agent", "multi-agent", "multiagent"), ["cs.MA", "cs.AI"]),
    (("llm", "language model", "nlp", "language"), ["cs.CL"]),
    (("security", "cyber", "crypto", "privacy"), ["cs.CR"]),
    (("machine learning", "ml", "deep learning", "neural"), ["cs.LG"]),
    (("software engineering", "software", "code generation", "programming"), ["cs.SE"]),
    (("retrieval", "rag", "information retrieval", "search"), ["cs.IR"]),
    (("vision", "image", "computer vision"), ["cs.CV"]),
    (("robot",), ["cs.RO"]),
    (("ai", "artificial intelligence"), ["cs.AI"]),
]
CAT_RE = re.compile(r"^[a-z\-]+(\.[A-Za-z\-]+)?$")
ID_RE = re.compile(r"(\d{4}\.\d{4,5}(?:v\d+)?|[a-z\-]+(?:\.[A-Z]{2})?/\d{7}(?:v\d+)?)")

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


class NetError(Exception):
    pass


# ------------------------------------------------------------------ helpers

def topic_to_categories(topic):
    """Map a plain topic or explicit category list to arXiv categories."""
    parts = [p for p in re.split(r"[,\s+]+", topic.strip()) if p and p.lower() != "or"]
    if parts and all(CAT_RE.match(p) and "." in p for p in parts):
        return parts
    low = f" {topic.lower()} "
    for keys, cats in TOPICS:
        if any(re.search(rf"(?<![a-z]){re.escape(k)}s?(?![a-z])", low) for k in keys):
            return cats
    return ["cs.AI"]


def extract_id(text):
    """arXiv id from a bare id or an arxiv/alphaxiv abs/pdf URL. Returns None if absent."""
    text = text.strip()
    m = re.search(r"(?:arxiv\.org|alphaxiv\.org)/(?:abs|pdf|overview)/([^\s?#]+)", text)
    if m:
        text = re.sub(r"\.(pdf|md)$", "", m.group(1))
    m = ID_RE.search(text)
    return m.group(1) if m else None


def strip_version(pid):
    return re.sub(r"v\d+$", "", pid)


def build_search_query(query, field="all"):
    """Plain phrase -> field:"phrase"; raw arXiv syntax passes through untouched."""
    q = query.strip()
    if re.search(r"\b(ti|au|abs|cat|all|co|jr|rn|id):", q) or re.search(r"\b(AND|OR|ANDNOT)\b", q):
        return q
    words = q.split()
    if len(words) == 1:
        return f"{field}:{q}"
    return f'{field}:"{q}"'


def clean(s):
    return re.sub(r"\s+", " ", (s or "")).strip()


def parse_feed(xml_text):
    """Atom XML -> list of paper dicts. Pure; unit-tested."""
    root = ET.fromstring(xml_text)
    papers = []
    for e in root.findall(f"{ATOM}entry"):
        raw_id = clean(e.findtext(f"{ATOM}id"))
        if not raw_id or "api/errors" in raw_id:
            continue
        pid = extract_id(raw_id) or raw_id.rsplit("/", 1)[-1]
        authors = [clean(a.findtext(f"{ATOM}name")) for a in e.findall(f"{ATOM}author")]
        cats = [c.get("term") for c in e.findall(f"{ATOM}category") if c.get("term")]
        prim = e.find(f"{ARXIV_NS}primary_category")
        pdf = ""
        for link in e.findall(f"{ATOM}link"):
            if link.get("title") == "pdf" or link.get("type") == "application/pdf":
                pdf = link.get("href", "")
        base = strip_version(pid)
        papers.append({
            "id": pid,
            "title": clean(e.findtext(f"{ATOM}title")),
            "authors": authors,
            "published": clean(e.findtext(f"{ATOM}published"))[:10],
            "updated": clean(e.findtext(f"{ATOM}updated"))[:10],
            "summary": clean(e.findtext(f"{ATOM}summary")),
            "primary_category": prim.get("term") if prim is not None else (cats[0] if cats else ""),
            "categories": cats,
            "doi": clean(e.findtext(f"{ARXIV_NS}doi")),
            "comment": clean(e.findtext(f"{ARXIV_NS}comment")),
            "abs_url": f"https://arxiv.org/abs/{base}",
            "pdf_url": pdf or f"https://arxiv.org/pdf/{base}",
            "alphaxiv_url": f"https://alphaxiv.org/abs/{base}",
        })
    return papers


def total_results(xml_text):
    m = re.search(r"<opensearch:totalResults[^>]*>(\d+)<", xml_text)
    return int(m.group(1)) if m else None


def filter_since(papers, since_date):
    """Keep papers whose *published* date is on/after since_date (YYYY-MM-DD)."""
    return [p for p in papers if p["published"] and p["published"] >= since_date]


def short_authors(authors, n=3):
    return ", ".join(authors[:n]) + (" et al." if len(authors) > n else "")


def first_sentences(text, n=3):
    parts = re.split(r"(?<=[.!?])\s+", text)
    return " ".join(parts[:n])


# ------------------------------------------------------------------ network

def http_get(url, timeout=30, throttle=False):
    if throttle:
        wait = MIN_GAP - (time.monotonic() - _last_call[0])
        if wait > 0:
            time.sleep(wait)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", "replace")
            return r.status, body
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception as e:
        raise NetError(str(getattr(e, "reason", e)))
    finally:
        if throttle:
            _last_call[0] = time.monotonic()


def api_query(params):
    url = API + "?" + urllib.parse.urlencode(params, safe=":")
    code, body = http_get(url, throttle=True)
    if code != 200:
        raise NetError(f"arXiv API returned HTTP {code}")
    return body


def fetch_overview(pid):
    """-> (source, markdown) with source in overview|fulltext, or (None, None)."""
    base = strip_version(pid)
    for kind, url in (("overview", f"https://alphaxiv.org/overview/{base}.md"),
                      ("fulltext", f"https://alphaxiv.org/abs/{base}.md")):
        try:
            code, body = http_get(url, timeout=20)
        except NetError:
            continue
        if code == 200 and body.strip() and not body.lstrip().lower().startswith("<!doctype"):
            return kind, body
    return None, None


# ------------------------------------------------------------------ output

def render_list(heading, papers):
    lines = [f"## {heading}", ""]
    for p in papers:
        lines.append(f"### {p['title']}")
        lines.append(f"**{short_authors(p['authors'])}** | {p['published']} | `{p['id']}` | {p['primary_category']}")
        lines.append(first_sentences(p["summary"]))
        lines.append(f"[arXiv]({p['abs_url']}) · [PDF]({p['pdf_url']}) · [AlphaXiv]({p['alphaxiv_url']})")
        lines.append("")
    return "\n".join(lines)


def render_paper(p, overview_kind, overview):
    lines = [f"# {p['title']}", "",
             f"**Authors:** {', '.join(p['authors'])}",
             f"**Published:** {p['published']} (updated {p['updated']}) | **Categories:** {', '.join(p['categories'])}"]
    if p["doi"]:
        lines.append(f"**DOI:** {p['doi']}")
    lines.append(f"**Links:** [arXiv]({p['abs_url']}) | [PDF]({p['pdf_url']}) | [AlphaXiv]({p['alphaxiv_url']})")
    lines += ["", "## Abstract", p["summary"], ""]
    if overview:
        label = "AlphaXiv overview (AI-generated; verify before citing)" if overview_kind == "overview" \
            else "AlphaXiv full text (markdown)"
        lines += [f"## {label}", overview.strip(), ""]
    else:
        lines += ["## Overview", "No AlphaXiv overview yet; work from the abstract or the PDF.", ""]
    return "\n".join(lines)


# ------------------------------------------------------------------ commands

def opt(args, name, default=None, cast=str):
    if name in args:
        i = args.index(name)
        if i + 1 < len(args):
            try:
                return cast(args[i + 1])
            except ValueError:
                raise SystemExit(f"{name} expects a {cast.__name__}")
        raise SystemExit(f"{name} needs a value")
    return default


def positional(args, valued=("--max", "--days", "--field", "--sort", "--months")):
    out, skip = [], False
    for a in args:
        if skip:
            skip = False
            continue
        if a in valued:
            skip = True
            continue
        if not a.startswith("--"):
            out.append(a)
    return out


def cmd_latest(args):
    pos = positional(args)
    if not pos:
        sys.stderr.write("usage: arxiv.py latest <topic-or-categories> [--max N] [--days N]\n")
        return 2
    cats = topic_to_categories(" ".join(pos))
    n = opt(args, "--max", 15, int)
    days = opt(args, "--days", None, int)
    q = " OR ".join(f"cat:{c}" for c in cats)
    body = api_query({"search_query": q, "sortBy": "lastUpdatedDate", "sortOrder": "descending",
                      "start": 0, "max_results": min(max(n * 3 if days else n, 1), 200)})
    papers = parse_feed(body)
    if days:
        since = (dt.date.today() - dt.timedelta(days=days)).isoformat()
        papers = filter_since(papers, since)
    papers = papers[:n]
    if "--json" in args:
        print(json.dumps({"categories": cats, "query": q, "papers": papers}, indent=2, ensure_ascii=False))
    else:
        print(render_list(f"Latest in {', '.join(cats)} - {dt.date.today().isoformat()}", papers))
    return 0 if papers else 1


def cmd_search(args):
    pos = positional(args)
    if not pos:
        sys.stderr.write('usage: arxiv.py search "<query>" [--field all|ti|abs|au] [--sort ...]\n')
        return 2
    field = opt(args, "--field", "all")
    if field not in ("all", "ti", "abs", "au"):
        sys.stderr.write("--field must be all, ti, abs or au\n")
        return 2
    sort = {"submitted": "submittedDate", "updated": "lastUpdatedDate",
            "relevance": "relevance"}.get(opt(args, "--sort", "submitted"))
    if not sort:
        sys.stderr.write("--sort must be submitted, updated or relevance\n")
        return 2
    n = opt(args, "--max", 15, int)
    # relevance means "best match regardless of date": no default window unless --months is given
    months = opt(args, "--months", 0 if sort == "relevance" else 12, int)
    q = build_search_query(" ".join(pos), field)
    body = api_query({"search_query": q, "sortBy": sort, "sortOrder": "descending",
                      "start": 0, "max_results": min(max(n * 2, 1), 200)})
    papers = parse_feed(body)
    if months and months > 0:
        since = (dt.date.today() - dt.timedelta(days=30 * months)).isoformat()
        papers = filter_since(papers, since)
    papers = papers[:n]
    if "--json" in args:
        print(json.dumps({"query": q, "total": total_results(body), "papers": papers}, indent=2, ensure_ascii=False))
    else:
        print(render_list(f"arXiv search: {q}", papers))
    return 0 if papers else 1


def cmd_paper(args):
    pos = positional(args)
    pid = extract_id(pos[0]) if pos else None
    if not pid:
        sys.stderr.write("usage: arxiv.py paper <id-or-url>   (e.g. 2401.12345 or https://arxiv.org/abs/2401.12345)\n")
        return 2
    body = api_query({"id_list": pid, "max_results": 1})
    papers = parse_feed(body)
    if not papers:
        sys.stderr.write(f"no arXiv paper with id {pid}\n")
        return 1
    p = papers[0]
    kind, ov = (None, None) if "--no-overview" in args else fetch_overview(pid)
    if "--json" in args:
        print(json.dumps({"paper": p, "overview_source": kind, "overview": ov}, indent=2, ensure_ascii=False))
    else:
        print(render_paper(p, kind, ov))
    return 0


def cmd_overview(args):
    pid = extract_id(args[0]) if args else None
    if not pid:
        sys.stderr.write("usage: arxiv.py overview <id-or-url>\n")
        return 2
    kind, ov = fetch_overview(pid)
    if not ov:
        sys.stderr.write(f"no AlphaXiv overview or full text for {pid} yet\n")
        return 1
    print(ov)
    return 0


def cmd_categories(_):
    for keys, cats in TOPICS:
        print(f"{', '.join(keys):45} -> {' OR '.join(cats)}")
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 0
    cmds = {"latest": cmd_latest, "search": cmd_search, "paper": cmd_paper,
            "overview": cmd_overview, "categories": cmd_categories}
    fn = cmds.get(argv[0])
    if not fn:
        sys.stderr.write(__doc__)
        return 2
    try:
        return fn(argv[1:])
    except NetError as e:
        sys.stderr.write(f"network error: {e}\n")
        return 3
    except ET.ParseError as e:
        sys.stderr.write(f"could not parse arXiv response: {e}\n")
        return 3
    except SystemExit as e:
        if isinstance(e.code, str):
            sys.stderr.write(e.code + "\n")
            return 2
        raise


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
