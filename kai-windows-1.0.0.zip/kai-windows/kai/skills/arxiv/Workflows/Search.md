# Search: find papers by topic, keyword or author

## Build the query

| User intent | Command |
|---|---|
| Topic or keywords (exact phrase) | `search "prompt injection"` → `all:"prompt injection"` |
| Title-only match | `search "retrieval augmented generation" --field ti` |
| Author | `search "Vaswani" --field au` |
| Combined or loose | raw syntax: `search "au:Yao AND all:agent"`, `search "ti:retrieval AND abs:security"` |
| Narrow to a field | add `AND cat:cs.CR` in raw syntax |

Booleans are `AND`, `OR`, `ANDNOT` (uppercase). Fields: `ti` title, `au` author, `abs` abstract, `cat` category, `all` everything.

## Run

```
python ~/.copilot/skills/arxiv/tools/arxiv.py search "<query>" [--field ...] --max 15
```

- Default sort is `submitted` (newest submissions first), which is what "recent work on X" means. Use `--sort relevance` when the user wants the best match regardless of date.
- Default window is the last 12 months. Use `--months 0` for all time, or `--months 36` when the user asks for "the last few years".
- If results are thin, loosen once (drop the exact phrase, switch `ti` to `all`) before reporting nothing found.

Fetch AlphaXiv overviews (`arxiv.py overview <id>`) for the top 3 to 5 results, one call at a time.

## Output

Same per-paper block as `Latest.md`, ordered most relevant first (judge by title and abstract against the user's intent, not just date). Drop clearly off-topic hits rather than listing them.

Close with **Related searches** when a refinement would obviously help:

```markdown
## Related searches
- `cat:cs.CR AND all:"prompt injection"` for security-only results
- `au:<name> AND cat:cs.CL` to narrow an author to NLP work
```
