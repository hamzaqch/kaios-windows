# Paper: deep-dive one paper

## Input

Any of: `2603.12345`, `2603.12345v2`, `https://arxiv.org/abs/2603.12345`, `https://arxiv.org/pdf/2603.12345`, `https://alphaxiv.org/abs/2603.12345`, or an old-style ID like `hep-th/9901001`. The tool extracts the ID.

## Run

```
python ~/.copilot/skills/arxiv/tools/arxiv.py paper <id-or-url>
```

This fetches arXiv metadata (title, all authors, abstract, categories, dates, DOI) and then tries, in order, the AlphaXiv overview, the AlphaXiv full-text markdown, and finally falls back to the abstract alone. The output says which source it used. If only the abstract is available and the user needs depth, point them to the PDF link and offer to read it with the web fetch tool.

## Output

```markdown
# <Paper title>

**Authors:** <full list>
**Published:** <date> | **Categories:** <cats>
**Links:** [arXiv](https://arxiv.org/abs/<id>) | [PDF](https://arxiv.org/pdf/<id>) | [AlphaXiv](https://alphaxiv.org/abs/<id>)

## Overview
<What the paper does and finds, from the AlphaXiv overview (say so) or the abstract>

## Key contributions
<3-5 bullets on what is new>

## Relevance
<How it connects to what the user is working on or asked about>

## Worth reading?
<Skim, read, or skip, and why, in two sentences>
```

Mark any number or claim taken from the AlphaXiv overview as AI-summarized unless you confirmed it in the abstract.
