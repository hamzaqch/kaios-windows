# Latest: browse recent papers in a field

## Input

A topic area ("AI agents", "LLM security", "machine learning") or explicit categories (`cs.CR`, `cs.AI OR cs.MA`). The tool maps common topics to categories (`arxiv.py categories` prints the map); pass categories directly when the mapping would be wrong.

| Topic | Categories |
|---|---|
| AI, artificial intelligence | `cs.AI` |
| machine learning, deep learning | `cs.LG` |
| LLMs, NLP, language models | `cs.CL` |
| security, privacy | `cs.CR` |
| agents, multi-agent | `cs.MA OR cs.AI` |
| software engineering, code generation | `cs.SE` |
| retrieval, RAG | `cs.IR` |
| computer vision | `cs.CV` |
| robotics | `cs.RO` |

## Run

```
python ~/.copilot/skills/arxiv/tools/arxiv.py latest "<topic or categories>" --max 15 --days 7
```

Use `--days` whenever the user says "this week", "today", "new" or "recent"; it filters on first-submission date so edited old papers drop out. Use `--json` when you need to rank programmatically.

Then fetch AlphaXiv overviews for the 3 to 5 papers most relevant to the user's interest, one at a time:

```
python ~/.copilot/skills/arxiv/tools/arxiv.py overview <id>
```

Exit 1 there means no overview exists yet; use the abstract.

## Output

```markdown
## Latest in <categories> — <date>

### <Paper title>
**<First 3 authors et al.>** | <published> | `<id>`
<2-3 sentence summary: AlphaXiv overview if present (marked "AI overview"), else the abstract>
**Why it matters:** <one sentence tied to what the user asked about>
[arXiv](https://arxiv.org/abs/<id>) · [AlphaXiv](https://alphaxiv.org/abs/<id>)

---
```

Lead with the papers most relevant to the request. End with **Papers worth reading**: 2 or 3 picks, one sentence each on why.
