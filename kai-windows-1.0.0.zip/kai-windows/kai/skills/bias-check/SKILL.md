---
name: bias-check
description: "Three-layer bias analysis on any URL, file or pasted text. Fetches the content and any study it cites, then audits biases inside the data, conflicts of interest in the source organization, and distortions the journalism added on top, and separates what the data actually supports from what was editorialized. Read-only. Use when the user says bias check, analyze bias, check this study, who funded this, is this source biased, fact-check this article, methodological flaws, source credibility, or what's wrong with this claim. Not for psychological analysis of an author, research synthesis across many sources (use the research skill), or due diligence on a person or company."
argument-hint: "<url | file | pasted text>"
---

# Bias check

## What it does

Runs a three-layer bias audit on any source: a URL, a file path, or raw text. It fetches the content plus any study it cites, then checks (1) biases inside the data, (2) conflicts of interest in the source organization, and (3) distortions the journalism added on top. The output separates what the data actually supports from what got editorialized.

## The problem

Most "this is biased" arguments are vibes: a feeling about a source, with nothing concrete underneath. They're not repeatable and they don't tell you where the distortion lives. The other failure is analyzing an article without ever reaching the study it cites, so you critique the headline and never see that the underlying data was fine (or that it was junk). A fixed taxonomy and a fixed output shape fix both: the analysis is repeatable, the gaps are visible, and every claim ties to a specific tell.

## How it works

1. **The data itself**: biases inside the underlying study, paper or dataset (funding, sampling, instrument design, demand characteristics, self-report distance from behavior, causal inflation, missing benchmark, publication availability).
2. **The source organization**: who paid for or produced the work, what they sell, what conclusion would be inconvenient.
3. **The journalism on top**: what the reporter or commentator added: headline-to-source distortion, frame escalation, echo-chain amplification, causal claims layered over correlational data.

Output cleanly separates **what the data actually supports** from **what was editorialized on top**. Confidence is anchored to specifics. No vibes-based "this seems biased."

## Workflow routing

| Workflow | Trigger | File |
|----------|---------|------|
| **Check** | "bias check", "analyze bias on", "check this study/source/article" | `Workflows/Check.md` |

## Quick reference

- **Input:** one argument: URL, file path, raw text, or any combination.
- **Always tries to find the primary source.** If the input is journalism citing a study, the skill fetches the study itself, not just the article. If the primary source can't be located, that's a finding.
- **Three-layer output.** Never collapse layers; the distortion usually lives in the layer the source is least transparent about.
- **Hard separation between supported and editorialized.** This is the deliverable shape.
- **Bias taxonomy reference:** `BiasTaxonomy.md` (load on demand for the full category catalog with definitions and tells).

## Read-only

This skill is analysis. It never edits, creates or deletes files. Use web fetch, web search and `view` only.

## Running on Copilot

- URLs: web fetch. Primary-source hunting: web fetch the cited link, then one round of web search if there's no link.
- Files: `view` the file. For a large PDF or document the user hands you, ask them to export the relevant pages to text if `view` can't read it.
- For a source with several cited studies, fetch them with parallel `task` calls to `@kai-researcher` (one study each, returning the methodology facts from Step 3 of the workflow) and run the three-layer analysis yourself on the merged facts.

## Examples

**Example 1: Article citing a vendor study**
```
User: "bias check <url of an article citing a consultancy survey>"
→ Check workflow
→ Fetches the article, identifies the cited survey, fetches the consultancy's own report
→ Three-layer audit: vendor conflict of interest, sample/question-design biases, the journalism's headline-vs-source swap
→ Structured bias report + supported-vs-editorialized split
```

**Example 2: Raw paste of a study abstract**
```
User: "bias check this abstract: [pastes 4 paragraphs from a paper]"
→ Check workflow
→ Skips Layer 3 (no journalism on top; the input IS the primary source)
→ Audits Layers 1 + 2 only: funding disclosure, sample, methodology, conflict of interest
→ Notes if the abstract is insufficient to assess methodology (publication availability bias)
```

**Example 3: File path**
```
User: "bias check Downloads/some-report.pdf"
→ Check workflow
→ Reads the file
→ Identifies upstream sources it cites; fetches what it can
→ Three-layer audit with specifics
```

## Output requirements

- **Format:** Markdown with the fixed section structure defined in `Workflows/Check.md`.
- **Length:** scales with source complexity. A single-claim post gets ~200 words; a vendor-funded study plus a viral article gets 800-1500.
- **Tone:** plain. Specific. No vibes. Every bias claim ties to a concrete tell: a quoted phrase, a sample-frame fact, a missing disclosure.
- **Must include:** methodology line (sample, dates, instrument availability), the three layers, the supported-vs-editorialized split, a one-paragraph bottom line, a sources list with URLs.
- **Must avoid:** hedging ("could potentially be biased"). Diagnose or don't. The reader gets to disagree, but they should know what the analyst actually thinks.

## Gotchas

- **Always try to find the primary source.** The single biggest failure mode is analyzing an article without ever reaching the underlying study. If the input cites a study, report, paper or dataset, the skill MUST attempt to fetch it. Inability to locate the primary source is itself a finding (publication availability bias) and goes in the output.
- **An impossibly high consensus number is a tell about the question.** When a survey claims 95%+ agreement on a substantive question, that almost always means the question was a low-bar yes/no. Note it explicitly even when the instrument is hidden.
- **Vendor research is research; treat it that way.** Don't dismiss a big-consultancy or analyst-firm report because they sell services. Their funding bias is a multiplier on the analysis, not an automatic disqualifier. Specific finding beats generic "vendor bias."
- **Don't conflate Layer 1 and Layer 3.** A bad headline doesn't make the underlying data bad. A flawed study doesn't make the journalism dishonest. Keep them separate even when both have problems.
- **Headlines travel; bodies don't.** Most readers see only the headline. A headline-to-source mismatch is the most consequential journalism bias and should always be flagged when present.
- **A charitable reading is required.** Before concluding the source is misleading, articulate what the data DOES support. This anchors the critique in specifics.
- **Don't go beyond the source you fetched.** No drive-by claims about the organization's other reports if you only read one. No "they always do X". Stick to what's in the artifact.
- **Pure opinion piece with no data?** This skill is the wrong tool. Bias check needs claims with empirical scaffolding; say so and stop.
- **Author background is out of scope.** This skill audits the source artifact, not the author's biography. For "who is this writer and what's their track record," use the research skill.
