---
name: evals
description: "Assertion-first AI eval framework: typed deterministic asserts plus a forced-structured LLM judge over an input-to-assert case schema, pass^k and pass@k, capability vs regression suites, prompt and model A/B comparisons, failure-seeded cases and multi-turn scenarios, all graded through the Copilot CLI on your subscription. Use when the user says eval, evaluate, benchmark, regression test, assertion, llm-rubric, judge, pass@k, pass^k, grade this output, compare prompts, compare models, is the cheaper model enough, A/B this prompt, test my agent or custom instructions, did my change break behaviour. NOT FOR scientific-method framing of a question (use /science), property or mutation testing of code (use /hardening), or checking a live UI in a browser."
---
# Evals: assertion-first AI evaluation

An eval gives an AI an input and applies **assertions** to its output. A case is `{id, prompt, assert:[...]}`. Each assertion is **deterministic** (code: fast, free, reproducible) or **model-graded** (an LLM judge). Cases run several trials and report **pass^k** (every trial passed: the honest metric for anything reliability-critical) and **pass@k** (at least one passed). Every model call is one `copilot` CLI run on the user's subscription; there is no API-key path.

Grounded in Anthropic's [Demystifying evals for AI agents](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents) and [Define success criteria and develop tests](https://docs.anthropic.com/en/docs/test-and-evaluate/develop-tests). When designing a new suite class, re-read the first one and say where it has moved past what this skill encodes. Report the gap; don't silently adopt it.

## Tools

All under `~/.copilot/skills/evals/tools/`; run with `python`.

| Command | Does |
|---|---|
| `evals.py run -s <suite> [-t N] [--case id] [--json]` | Runs a suite: agent under test per case and trial, asserts, pass^k/pass@k, 95% CI; saves full transcripts. Exit 0 = passed. |
| `evals.py new <name> [--type capability\|regression]` | Scaffolds a suite with one should-do and one should-not case. |
| `evals.py validate <suite>` / `show <suite>` / `list` | Schema check; cases + saturation; all suites with their last score. |
| `evals.py results <suite> [--failed] [--history] [--run id]` | Reads stored runs, per-trial asserts and outputs. |
| `evals.py saturation <suite>` / `graduate <suite>` | 3 runs in a row at or above the saturation threshold: graduate capability to regression, or add harder cases. |
| `evals.py compare -s <suite> --variant A=a.md --variant B=b.md` or `--models m1,m2` | A/B/C on the same cases; paired permutation test; optional `--pairwise "<criterion>"` position-swapped judge. |
| `evals.py failure log\|list\|convert` | Log real failures, convert them to draft cases. |
| `evals.py draft --from-rule "<rule>"` or `--from-failure "<text>"` [`--run`] | Model drafts one case into `drafts/`; never into a live suite. |
| `evals.py grade --output <file\|-> (--asserts '<json>' \| --suite s --case id)` | Grades an existing output; use it for "grade this" and to calibrate a judge on known-good and known-bad outputs. |
| `evals.py scenario <file.json>` | Multi-turn: scripted user turns or a simulated user, judged on criteria over the transcript. |
| `evals.py selftest` / `assertions.py` | Offline self-test of the assert engine and the pass^k math. |

Storage, kept across reinstalls, under `~/.copilot/kai/MEMORY/EVALS/`: `suites/{capability,regression}/*.json` (yours; these win over the shipped examples in `Suites/`), `drafts/`, `results/<suite>/<run>/run.json` + `latest.json`, `failures.jsonl`.

## Workflow routing

| Request | Workflow |
|---|---|
| run the eval, run the suite, grade this | `Workflows/RunEval.md` |
| new eval, create a suite, what should I test | `Workflows/CreateSuite.md` |
| write a judge, rubric, grading criteria | `Workflows/CreateJudge.md` |
| compare prompts, which instructions are better, A/B | `Workflows/ComparePrompts.md` |
| compare models, is the cheaper model enough | `Workflows/CompareModels.md` |
| eval results, how did it score, saturation | `Workflows/ViewResults.md` |
| turn failures into tests, it did X wrong again | `Workflows/FailureToCase.md` |
| multi-turn eval, scenario, conversation test | `Workflows/Scenario.md` |

Reference: `AssertReference.md` (suite schema and every assert type), `BestPractices.md` (judge design, statistics), `ScienceMapping.md` (evals as the scientific method).

## Doctrine

- **Grade the outcome, not the path.** There are no tool-sequence asserts by design; rigid path-matching is brittle.
- **Capability suites start low** (a hill to climb); **regression suites target ~100%**. Saturated capability suites graduate.
- **pass^k for reliability**, pass@k only where one success is enough.
- **Partial credit via weights. Balance should-do and should-not cases**; one-sided suites produce one-sided optimisation. Mark should-not cases `"negative": true`.
- **Judge discipline:** reason then score, forced JSON verdict, a judge configuration distinct from the agent under test, and UNKNOWN counts as a miss.
- **Never trust a score until you have read transcripts.** `results <suite> --failed` shows them.

## Gotchas

- **Every trial and every model assert is a premium request.** A 10-case suite with 3 trials and one rubric per case is about 60 requests. Say the estimate before running a big suite, and start with `-t 1 --case <id>` while authoring.
- **The agent under test runs with no tools.** The runner appends an `[EVALUATION CONTEXT]` note so the model answers instead of narrating tool calls. Keep it for output-graded cases; set `"eval_context": false` only when the prompt itself handles this.
- **By default the agent under test loads your custom instructions** (the live Kai constitution), so a change to `copilot-instructions.md` shows up in scores. Judges run with `--no-custom-instructions`. Set `"instructions": false` in a suite to test a bare model, or `system_prompt` / `system_file` to test a specific prompt.
- **The live constitution wraps every answer in the Kai banner and closer.** Deterministic asserts anchored at the start (`starts-with`, `^` regexes) will hit the banner; set `"strip_format": true` in the suite (or `grade --strip-format`). Found in a live run.
- **Some models reject `--reasoning-effort`, including the default `auto`.** The runner retries the call without it, so `judge_effort` is best-effort unless you also pin `judge_model`.
- **Judge equals generator is a warning.** If `agent_model` and `judge_model` are the same, vary `judge_effort` or pick a different judge model.
- **`is-json` checks the whole output; `contains-json` looks for an embedded object.** Don't use `is-json` on prose that merely includes JSON.
- **Kai hooks see eval traffic.** Runs set `KAI_EVAL=1` and `KAI_FORMAT_GATE=0` so the format gate never blocks a judge reply.
- **Suites are JSON, not YAML.** Python's standard library has no YAML parser.
