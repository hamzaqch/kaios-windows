# RunEval

Run a suite and report what it shows, with evidence.

## Done looks like

- The suite ran with a stated trial count, and the user saw the request estimate (cases x trials x (1 + model asserts)) before anything large started.
- The report gives pass^k, pass@k, mean with 95% CI, and a per-case line.
- At least the failing transcripts were read, and the report says whether each failure is the agent, the case, or the judge.

## Tool contract

```
python "$HOME/.copilot/skills/evals/tools/evals.py" validate <suite>                 # always first; a broken case wastes every trial
python "$HOME/.copilot/skills/evals/tools/evals.py" run -s <suite> -t 1 --case <id>  # smoke test one case while authoring
python "$HOME/.copilot/skills/evals/tools/evals.py" run -s <suite>                   # full run (suite trials, default 3)
python "$HOME/.copilot/skills/evals/tools/evals.py" run -s <suite> --json            # machine-readable
python "$HOME/.copilot/skills/evals/tools/evals.py" results <suite> --failed         # read failing transcripts
```

Overrides: `--agent-model`, `--judge-model`, `--system-file <prompt.md>`, `--label <text>` (tags the run in history).

If the suite is not found, list what exists (`python "$HOME/.copilot/skills/evals/tools/evals.py" list`) and offer `CreateSuite.md`. If every trial errors, the usual causes are: Copilot CLI not on PATH, not logged in (`copilot login`), or an unavailable `--model` (the CLI fails fast with "not available").

## Report shape

```
<suite> (<type>): PASSED | BELOW THRESHOLD
pass^k X% · pass@k Y% · mean Z% (95% CI a-b%) · k trials x n cases
| case | pass^k | mean | verdict on failures (agent / case / judge) |
Transcripts: <run.json path>
Next: <graduate | add harder cases | fix case X | investigate regression>
```
