# CompareModels

Find out whether a model (or a cheaper reasoning effort) is good enough for a job, on the same cases.

## Done looks like

- Every model ran the same suite with the same trials and the same judge.
- The report shows mean, pass^k and 95% CI per model, the paired test against the baseline, and the cost side (premium requests per run, latency from `run.json` `seconds`).
- The recommendation names the cheapest model that clears the suite threshold with pass^k you'd accept.

## Tool contract

```
python "$HOME/.copilot/skills/evals/tools/evals.py" compare -s <suite> --models <baseline-model>,<candidate-model>[,...] [-t 3] [--judge-model <model>]
```

The first model is the baseline. Model names are whatever `copilot --model` accepts; an unavailable model fails fast with "Model ... is not available", so check names with the user first. Pin `--judge-model` so the judge is constant across arms and differs from every model under test where possible; a model judging its own output inflates its score.

To compare reasoning effort instead of models, make two copies of the suite with different `agent_effort` values and run each, then compare the `latest.json` files, or put the effort in the suite and run with `--label`.

## Report

```
| model | mean | pass^k | 95% CI | avg seconds/trial |
Verdict vs baseline: delta, p-value, meaningful (yes/no against --min-delta)
Recommendation: <model> for <job>, because <evidence>
```
