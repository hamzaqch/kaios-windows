# ComparePrompts

A/B (or A/B/C) test prompt or instruction variants on identical cases. This is the scientific method; see `../ScienceMapping.md`.

## Before running (pre-commit; write these down in the reply)

- The hypothesis and why: "B improves verification honesty because it states the evidence rule up front."
- What would disprove it: "B's mean is not at least 5 points higher at p < 0.05."
- The metric that matters and the minimum meaningful delta (`--min-delta`, default 0.05).
- Consider a third variant to guard against confirmation bias toward the first alternative.

If the user can't say what would disprove the hypothesis, stop and settle that first.

## Tool contract

```
python "$HOME/.copilot/skills/evals/tools/evals.py" compare -s <suite> --variant A=prompts/v1.md --variant B=prompts/v2.md [--variant C=prompts/v3.md] --hypothesis "B beats A on ..." --min-delta 0.05 [-t 3] [--pairwise "<one-sentence criterion>"]
```

Each variant file is prepended to every case as `<system_instructions>`. The first variant is the baseline. Each later variant gets a paired permutation test against it on per-case means; `--pairwise` adds a position-swapped judge comparison of first-trial outputs and a sign test. Results save to `MEMORY/EVALS/results/<suite>/comparisons/`.

To compare edits to the live constitution, copy the relevant section of `~/.copilot/copilot-instructions.md` into variant files and set `"instructions": false` in the suite, so the installed copy doesn't leak into both arms.

## Sample size

10 cases is weak, 20-30 is good, 50+ is high confidence. With few cases, say the result is directional.

## Decision table

| Outcome | Action |
|---|---|
| B significantly better by at least the pre-committed delta | adopt B, keep A's file for history |
| A significantly better | keep A, iterate on B |
| no significant difference | keep the simpler variant, or add cases |
| mixed by case | read transcripts; consider merging the parts that won |

Report the table `compare` prints, the verdict, and one transcript excerpt per variant that shows the difference.
