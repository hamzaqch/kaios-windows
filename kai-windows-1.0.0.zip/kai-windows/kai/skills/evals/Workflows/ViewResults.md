# ViewResults

Read stored runs and say what they mean.

## Tool contract

```
python "$HOME/.copilot/skills/evals/tools/evals.py" list                          # every suite with its last pass^k and date
python "$HOME/.copilot/skills/evals/tools/evals.py" results <suite>               # latest run, all trials, assert reasons, outputs
python "$HOME/.copilot/skills/evals/tools/evals.py" results <suite> --failed      # failing trials only
python "$HOME/.copilot/skills/evals/tools/evals.py" results <suite> --history     # one line per run (trend)
python "$HOME/.copilot/skills/evals/tools/evals.py" results <suite> --run <id>    # a specific run
python "$HOME/.copilot/skills/evals/tools/evals.py" saturation <suite>            # last runs vs saturation threshold, recommended action
```

Raw files: `~/.copilot/kai/MEMORY/EVALS/results/<suite>/<run_id>/run.json` (full detail including every output), `latest.json` (summary), `comparisons/*.json`.

## Done looks like

- The answer leads with the headline numbers (pass^k, mean, CI) and the trend versus earlier runs.
- Each failing case is classified after reading its transcript: the agent was wrong, the case is ambiguous, or the judge misgraded.
- Saturation is reported when relevant: a capability suite three runs in a row above threshold should graduate (`python "$HOME/.copilot/skills/evals/tools/evals.py" graduate <suite>`); a saturated regression suite needs harder cases.
