# FailureToCase

Turn real failures into regression cases, so the same mistake can't come back unnoticed. Twenty to fifty cases drawn from real failures make a strong first suite.

## Tool contract

```
python "$HOME/.copilot/skills/evals/tools/evals.py" failure log "<what went wrong>" --expected "<what should have happened>" --actual "<what happened>" [--prompt "<the user turn that triggered it>"] [--category <word>] [--severity low|medium|high|critical]
python "$HOME/.copilot/skills/evals/tools/evals.py" failure list
python "$HOME/.copilot/skills/evals/tools/evals.py" failure convert [--suite <name>]     # pending failures -> MEMORY/EVALS/drafts/<name>.json
python "$HOME/.copilot/skills/evals/tools/evals.py" draft --from-failure "<description>" --run   # alternative: model writes the prompt and asserts
```

`convert` is deterministic: each failure becomes a weighted `llm-rubric` on the expected behaviour plus a negative `llm-assert` on the actual one. Without `--prompt` the case gets a `TODO-PROMPT` placeholder that must be replaced before the case means anything.

## Done looks like

- Every failure that a single output can show became a case; failures about cost, speed or tool choice were noted as not eval-able by an output-graded case and left out, with the count stated.
- Each draft case has a real prompt and at least one cheap deterministic assert added where one fits.
- The reviewed draft was moved into `~/.copilot/kai/MEMORY/EVALS/suites/regression/` and run once; the case fails on the old behaviour and passes on the fixed one.
