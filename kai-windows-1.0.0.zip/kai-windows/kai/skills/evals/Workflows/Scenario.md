# Scenario

Multi-turn evaluation: does the agent hold up across a conversation, not just one reply?

## When

- A conversation pattern caused a real failure (it forgot a constraint by turn three, it stopped asking one question at a time).
- The behaviour only shows up over two or more turns.

For single-turn behaviour use a suite instead (`CreateSuite.md`).

## Scenario file

JSON, saved anywhere (convention: `~/.copilot/kai/MEMORY/EVALS/scenarios/<name>.json`). Schema in `../AssertReference.md`; example in `../Scenarios/example-support.json`.

- `turns`: fixed user messages, for deterministic regression runs.
- `simulate`: a model plays the user from `description` and `persona` until it ends the conversation or `max_turns` is reached. Good for capability exploration; noisier for regression.
- `criteria`: narrow, testable statements judged over the whole transcript. "Assistant is helpful" is too vague; "Assistant offers to escalate when the user says they are frustrated" is testable.

## Tool contract

```
python "$HOME/.copilot/skills/evals/tools/evals.py" scenario <file.json> [-t 3]
```

Each trial is one real Copilot session (`--session-id`, resumed per turn), so every turn is a premium request, plus one per simulated user turn and one per judge call. Results: `MEMORY/EVALS/results/scenarios/<name>/<run>.json` with the full transcript.

## Done looks like

The scenario passes on good behaviour and fails on the failure it was written for; the criteria verdicts were read against the transcript; flaky criteria were sharpened until repeated trials agree.
