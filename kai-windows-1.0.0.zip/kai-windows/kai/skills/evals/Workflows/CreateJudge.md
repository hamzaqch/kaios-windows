# CreateJudge

Write the model-graded part of a case so the judge agrees with an expert.

## Done looks like

- Each rubric asks one yes/no question about something visible in the output. "Is it good?" is not a rubric; "Does the answer name the command that would verify the fix?" is.
- Multi-part expectations are split into an `llm-assert` list of literal statements, so partial credit is visible.
- Weights reflect importance (they need not sum to anything; the runner normalises).
- The judge was tested against one known-good and one known-bad output and separated them.

## Writing rubrics

- 3-5 criteria per case at most; more becomes impossible to calibrate.
- Criteria don't overlap; each measures one thing.
- Describe what a high and a low score look like when the line is fuzzy.
- Reference material (a golden answer, source facts) goes inside the rubric text, labelled, so the judge can compare.
- For pairwise A/B judging, write one criterion sentence and pass it to `compare --pairwise`; ordering is swapped automatically.

## Testing the judge

Save one known-good and one known-bad output to files, then:

```
python "$HOME/.copilot/skills/evals/tools/evals.py" grade --output good.txt --suite <suite> --case <id>
python "$HOME/.copilot/skills/evals/tools/evals.py" grade --output bad.txt  --suite <suite> --case <id>
# or try a rubric before it is in any suite:
python "$HOME/.copilot/skills/evals/tools/evals.py" grade --output good.txt --asserts '{"type": "llm-rubric", "value": "..."}'
```

Each assert prints its reason. The good output must pass and the bad one fail.

If the judge passes a bad output, sharpen the rubric to name the exact failure. If it returns UNKNOWN, the rubric asks about something the output can't show; rewrite it or move the check to a deterministic assert.

For a reusable judge prompt with criteria tables and weighted dimensions, render the template in the /prompting skill: `Templates/Evals/Judge.md`, then paste the rendered criteria into the rubric `value`.
