# CreateSuite

Build a new suite that measures one behaviour well.

## Done looks like

- One behaviour per suite, named for it. The description says what it guards and why.
- Cases are concrete prompts a real user would send, answerable in one message.
- Should-do cases are balanced by should-not cases (`"negative": true`).
- Every case has at least one cheap deterministic assert where one fits, and model asserts only for nuance.
- `validate` reports VALID, and a one-trial smoke run passed for at least one case and failed for a deliberately bad output, so the asserts can tell good from bad.

## Inputs to settle (ask only what isn't clear from context)

What is being tested (custom instructions, an agent, a prompt file, a model), what good output looks like, a real example or two, and whether this is a capability suite (expected to start low) or a regression suite (expected near 100%).

## Tool contract

```
python "$HOME/.copilot/skills/evals/tools/evals.py" new <name> --type capability|regression --description "..."
# edit ~/.copilot/kai/MEMORY/EVALS/suites/<type>/<name>.json
python "$HOME/.copilot/skills/evals/tools/evals.py" validate <name>
python "$HOME/.copilot/skills/evals/tools/evals.py" run -s <name> -t 1 --case <id>
```

Seed cases from real failures when they exist (`FailureToCase.md`), or draft one from a rule: `python "$HOME/.copilot/skills/evals/tools/evals.py" draft --from-rule "<rule>" --run`. Drafts land in `MEMORY/EVALS/drafts/` and go live only when you move them into `suites/`.

Schema and every assert type: `../AssertReference.md`. Test what the suite's target sees: to evaluate a prompt file, set `system_file`; to evaluate a custom agent, set `"agent": "kai-engineer"`; to evaluate the bare model, set `"instructions": false`.

## Case distribution

2-3 easy cases, 3-4 typical edge cases, 2-3 hard or ambiguous ones. Use the distribution of real requests, not the ones that are easy to grade.
