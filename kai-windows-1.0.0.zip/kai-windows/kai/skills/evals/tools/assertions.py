"""Deterministic assertion engine for Kai evals (stdlib only).

An assertion is a dict: {"type": str, "value": any, "threshold": number, "weight": number}.
Any deterministic type may carry a "not-" prefix to invert it. Model-graded types
(llm-rubric, llm-assert) are recognised here but graded by llm.py.

Grade the OUTPUT, not the path: there are deliberately no tool-sequence asserts.

Run this file directly for the self-test:  python assertions.py
"""
import json
import re
import sys

DETERMINISTIC_TYPES = (
    "equals", "contains", "icontains", "contains-all", "contains-any", "regex",
    "starts-with", "ends-with", "is-json", "contains-json", "max-length", "min-length",
    "max-words", "min-words",
)
MODEL_TYPES = ("llm-rubric", "llm-assert")
ALL_TYPES = DETERMINISTIC_TYPES + MODEL_TYPES


def base_type(t):
    t = str(t or "")
    return t[4:] if t.startswith("not-") else t


def is_model_assert(t):
    return base_type(t) in MODEL_TYPES


def _s(v):
    return v if isinstance(v, str) else json.dumps(v, ensure_ascii=False)


def _list(v):
    if isinstance(v, (list, tuple)):
        return [_s(x) for x in v]
    return [_s(v)]


def _num(v, default):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _find_json_fragment(text):
    """True if any balanced {...} or [...] span in text parses as JSON."""
    dec = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch in "{[":
            try:
                dec.raw_decode(text[i:])
                return True
            except ValueError:
                continue
    return False


def evaluate(output, a):
    """Grade one deterministic assertion. Returns {type, passed, score, reason, weight}."""
    output = output if isinstance(output, str) else _s(output)
    t = str(a.get("type", ""))
    weight = _num(a.get("weight", 1), 1.0)
    neg = t.startswith("not-")
    b = base_type(t)
    v = a.get("value")
    if b == "equals":
        passed = output.strip() == _s(v).strip()
        reason = "exact match" if passed else "not an exact match"
    elif b == "contains":
        passed = _s(v) in output
        reason = ("contains " if passed else "missing ") + repr(_s(v))
    elif b == "icontains":
        passed = _s(v).lower() in output.lower()
        reason = ("contains (ci) " if passed else "missing (ci) ") + repr(_s(v))
    elif b == "contains-all":
        missing = [x for x in _list(v) if x not in output]
        passed = not missing
        reason = "contains all" if passed else "missing: " + ", ".join(missing)
    elif b == "contains-any":
        items = _list(v)
        hit = next((x for x in items if x in output), None)
        passed = hit is not None
        reason = f"contains {hit!r}" if passed else f"none of {len(items)} present"
    elif b == "regex":
        try:
            rx = re.compile(_s(v))  # no implicit flags; use (?m) or (?i) inline
        except re.error as exc:
            return {"type": t, "passed": False, "score": 0.0, "reason": f"bad regex: {exc}", "weight": weight}
        passed = rx.search(output) is not None
        reason = ("matches /" if passed else "no match /") + _s(v) + "/"
    elif b == "starts-with":
        passed = output.lstrip().startswith(_s(v))
        reason = "starts with expected" if passed else "does not start with expected"
    elif b == "ends-with":
        passed = output.rstrip().endswith(_s(v))
        reason = "ends with expected" if passed else "does not end with expected"
    elif b == "is-json":
        try:
            json.loads(output.strip())
            passed, reason = True, "valid JSON"
        except ValueError:
            passed, reason = False, "not valid JSON"
    elif b == "contains-json":
        passed = _find_json_fragment(output)
        reason = "contains a JSON fragment" if passed else "no valid JSON fragment"
    elif b in ("max-length", "min-length"):
        n = len(output)
        lim = _num(a.get("threshold", v), None)
        if lim is None:
            return {"type": t, "passed": False, "score": 0.0, "reason": f"{b} needs a numeric threshold", "weight": weight}
        passed = n <= lim if b == "max-length" else n >= lim
        reason = f"length {n} {'<=' if b == 'max-length' else '>='} {lim:g}: {passed}"
    elif b in ("max-words", "min-words"):
        n = len(output.split())
        lim = _num(a.get("threshold", v), None)
        if lim is None:
            return {"type": t, "passed": False, "score": 0.0, "reason": f"{b} needs a numeric threshold", "weight": weight}
        passed = n <= lim if b == "max-words" else n >= lim
        reason = f"words {n} {'<=' if b == 'max-words' else '>='} {lim:g}: {passed}"
    else:
        return {"type": t, "passed": False, "score": 0.0, "reason": f"unknown deterministic assert: {b}", "weight": weight}
    if neg:
        passed = not passed
        reason = f"NOT({reason})"
    return {"type": t, "passed": passed, "score": 1.0 if passed else 0.0, "reason": reason, "weight": weight}


def validate_assertion(a):
    """Return a list of problems with one assertion dict (empty = valid)."""
    probs = []
    if not isinstance(a, dict):
        return ["assertion is not an object"]
    t = a.get("type")
    if not isinstance(t, str) or base_type(t) not in ALL_TYPES:
        probs.append(f"unknown type {t!r}")
        return probs
    b = base_type(t)
    if b in ("max-length", "min-length", "max-words", "min-words") and _num(a.get("threshold", a.get("value")), None) is None:
        probs.append(f"{t} needs a numeric threshold")
    if b in ("contains", "icontains", "equals", "starts-with", "ends-with", "regex", "contains-all", "contains-any",
             "llm-rubric", "llm-assert") and a.get("value") in (None, "", []):
        probs.append(f"{t} needs a value")
    if b == "regex":
        try:
            re.compile(_s(a.get("value")))
        except re.error as exc:
            probs.append(f"bad regex: {exc}")
    if "weight" in a and (_num(a.get("weight"), -1) < 0):
        probs.append("weight must be a non-negative number")
    return probs


SELFTEST = [
    ("Hello world", {"type": "equals", "value": "Hello world"}, True),
    ("Hello world", {"type": "equals", "value": "hello"}, False),
    ("Hello world", {"type": "contains", "value": "world"}, True),
    ("Hello world", {"type": "not-contains", "value": "should work"}, True),
    ("Hello WORLD", {"type": "icontains", "value": "world"}, True),
    ("a b c", {"type": "contains-all", "value": ["a", "c"]}, True),
    ("a b c", {"type": "contains-all", "value": ["a", "z"]}, False),
    ("a b c", {"type": "contains-any", "value": ["x", "b"]}, True),
    ("v1.2.3", {"type": "regex", "value": r"^v\d+\.\d+\.\d+$"}, True),
    ("No, not by default", {"type": "starts-with", "value": "No"}, True),
    ('{"a":1}', {"type": "is-json"}, True),
    ("nope", {"type": "is-json"}, False),
    ('prefix {"a":1} suffix', {"type": "contains-json"}, True),
    ("short", {"type": "max-length", "threshold": 10}, True),
    ("this is quite long", {"type": "max-length", "threshold": 5}, False),
    ("should work", {"type": "not-contains", "value": "should work"}, False),
    ("one two three", {"type": "max-words", "threshold": 3}, True),
    ("done.", {"type": "ends-with", "value": "."}, True),
]


def selftest(verbose=True):
    ok = 0
    for out, a, want in SELFTEST:
        r = evaluate(out, a)
        good = r["passed"] == want
        ok += good
        if verbose:
            print(f"{'PASS' if good else 'FAIL'} {a['type']:<14} on {out[:20]!r:<24} -> {r['passed']} (want {want}) {r['reason']}")
    if verbose:
        print(f"\n{ok}/{len(SELFTEST)} deterministic assert cases passed")
    return ok == len(SELFTEST)


if __name__ == "__main__":
    sys.exit(0 if selftest() else 1)
