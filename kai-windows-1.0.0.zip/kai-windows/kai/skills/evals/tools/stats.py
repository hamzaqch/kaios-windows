"""Eval statistics (stdlib only): pass@k / pass^k, mean, SEM, confidence intervals,
and paired comparison tests for prompt/model A/B runs.

pass@k  = probability at least one of k sampled trials passes (one success suffices).
pass^k  = probability all k sampled trials pass (the honest reliability metric).
With n trials of which c passed, the unbiased estimators are
    pass@k = 1 - C(n-c, k) / C(n, k)        pass^k = C(c, k) / C(n, k)
At k == n they reduce to "any passed" and "all passed".
"""
import math
import random

# two-sided 95% t critical values by degrees of freedom (df 1..30); df > 30 uses 1.96
_T95 = [12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228,
        2.201, 2.179, 2.160, 2.145, 2.131, 2.120, 2.110, 2.101, 2.093, 2.086,
        2.080, 2.074, 2.069, 2.064, 2.060, 2.056, 2.052, 2.048, 2.045, 2.042]


def pass_at_k(n, c, k):
    n, c, k = int(n), int(c), int(k)
    if n <= 0 or k <= 0:
        return 0.0
    k = min(k, n)
    if n - c < k:
        return 1.0
    return 1.0 - math.comb(n - c, k) / math.comb(n, k)


def pass_hat_k(n, c, k):
    """pass^k: probability that k trials drawn without replacement all pass."""
    n, c, k = int(n), int(c), int(k)
    if n <= 0 or k <= 0:
        return 0.0
    k = min(k, n)
    if c < k:
        return 0.0
    return math.comb(c, k) / math.comb(n, k)


def mean(xs):
    xs = list(xs)
    return sum(xs) / len(xs) if xs else 0.0


def stdev(xs):
    xs = list(xs)
    if len(xs) < 2:
        return 0.0
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))


def sem(xs):
    xs = list(xs)
    return stdev(xs) / math.sqrt(len(xs)) if len(xs) > 1 else 0.0


def t_crit(df):
    if df < 1:
        return float("nan")
    return _T95[df - 1] if df <= 30 else 1.96


def ci95(xs):
    """(low, high) 95% confidence interval for the mean of xs (t-distribution)."""
    xs = list(xs)
    if len(xs) < 2:
        m = mean(xs)
        return (m, m)
    m, e = mean(xs), sem(xs)
    h = t_crit(len(xs) - 1) * e
    return (m - h, m + h)


def paired_permutation(a, b, iterations=20000, seed=1234):
    """Two-sided paired permutation (sign-flip) test on per-case differences a[i]-b[i].

    Exact enumeration for n <= 16, otherwise seeded Monte Carlo. Returns
    {n, mean_diff, p_value, ci95, exact}.
    """
    diffs = [float(x) - float(y) for x, y in zip(a, b)]
    n = len(diffs)
    if n == 0:
        return {"n": 0, "mean_diff": 0.0, "p_value": 1.0, "ci95": (0.0, 0.0), "exact": True}
    obs = abs(sum(diffs))
    extreme = 0
    total = 0
    if n <= 16:
        for mask in range(1 << n):
            s = 0.0
            for i, d in enumerate(diffs):
                s += -d if (mask >> i) & 1 else d
            if abs(s) >= obs - 1e-12:
                extreme += 1
            total += 1
        exact = True
    else:
        rng = random.Random(seed)
        for _ in range(iterations):
            s = sum(d if rng.random() < 0.5 else -d for d in diffs)
            if abs(s) >= obs - 1e-12:
                extreme += 1
            total += 1
        exact = False
    return {"n": n, "mean_diff": mean(diffs), "p_value": extreme / total, "ci95": ci95(diffs), "exact": exact}


def sign_test(wins_a, wins_b):
    """Exact two-sided binomial sign test ignoring ties."""
    n = wins_a + wins_b
    if n == 0:
        return 1.0
    k = min(wins_a, wins_b)
    p = sum(math.comb(n, i) for i in range(0, k + 1)) / (2 ** n)
    return min(1.0, 2 * p)


def summarize_trials(scores, passes):
    """Case-level summary from per-trial scores (0..1) and pass booleans."""
    n = len(passes)
    c = sum(1 for p in passes if p)
    return {
        "trials": n,
        "passed_trials": c,
        "mean_score": mean(scores),
        "pass_at_k": pass_at_k(n, c, n),
        "pass_hat_k": pass_hat_k(n, c, n),
    }
