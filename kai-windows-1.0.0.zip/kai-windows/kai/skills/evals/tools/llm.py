"""Model calls for Kai evals, routed through the GitHub Copilot CLI (stdlib only).

Every call is one non-interactive `copilot` run billed to the user's Copilot
subscription; no API keys. The prompt goes in on stdin (multi-line safe on
Windows, where `copilot.cmd` shims mangle newlines in arguments), and the reply
is parsed from `--output-format json` (JSONL): the final text is the last
`assistant.message` event with non-empty content.

Override the CLI for tests or custom setups with KAI_EVAL_LLM_CMD, either a JSON
list ('["python", "fake.py"]') or a plain command string.

Judge discipline (from "Demystifying evals for AI agents"): reason first, then a
forced JSON verdict; a distinct judge configuration from the agent under test;
an explicit UNKNOWN escape hatch that is scored as a miss.
"""
import json
import os
import shlex
import shutil
import subprocess
import tempfile
import time
import uuid

DEFAULT_TIMEOUT = 300


def base_command():
    raw = os.environ.get("KAI_EVAL_LLM_CMD", "").strip()
    if raw:
        if raw.startswith("["):
            try:
                cmd = json.loads(raw)
                if isinstance(cmd, list) and cmd:
                    return [str(c) for c in cmd]
            except ValueError:
                pass
        return shlex.split(raw, posix=(os.name != "nt"))
    exe = shutil.which("copilot") or shutil.which("copilot.cmd") or shutil.which("copilot.exe") or "copilot"
    return [exe]


def _kill_tree(proc):
    """Kill a child and its descendants. On Windows `copilot` is a .cmd shim, so
    proc.kill() alone would only end cmd.exe and leave node holding the pipes."""
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
        else:
            import signal
            os.killpg(proc.pid, signal.SIGKILL)
    except Exception:
        pass
    try:
        proc.kill()
    except Exception:
        pass


def _run(cmd, data, cwd, env, timeout):
    """subprocess.run equivalent whose timeout reliably ends the whole process tree."""
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else:
        kw["start_new_session"] = True
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            cwd=cwd, env=env, **kw)
    try:
        out, err = proc.communicate(data, timeout=timeout)
    except subprocess.TimeoutExpired:
        _kill_tree(proc)
        try:
            proc.communicate(timeout=10)
        except Exception:
            pass
        raise
    return subprocess.CompletedProcess(cmd, proc.returncode, out, err)


def parse_jsonl(stdout):
    """Pull final text, model, session id, exit code and usage out of a JSONL event stream."""
    text, model, session, exit_code, usage = "", "", "", None, {}
    for line in (stdout or "").splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        typ = ev.get("type")
        data = ev.get("data") or {}
        if typ == "assistant.message":
            c = data.get("content")
            if isinstance(c, str) and c.strip():
                text = c
                model = data.get("model") or model
        elif typ == "session.auto_mode_resolved" and not model:
            model = data.get("chosenModel") or model
        elif typ == "result":
            session = ev.get("sessionId") or session
            exit_code = ev.get("exitCode")
            usage = ev.get("usage") or {}
    return {"text": text, "model": model, "session_id": session, "exit_code": exit_code, "usage": usage}


def complete(prompt, model=None, effort=None, timeout=DEFAULT_TIMEOUT, instructions=True,
             session_id=None, agent=None, cwd=None, extra_args=None):
    """Run one Copilot turn. Returns {ok, text, error, model, session_id, usage, seconds}.

    instructions=False passes --no-custom-instructions (used for judges, so the
    grader is not steered by the same instructions as the agent under test).
    session_id creates a session with that UUID or resumes it (multi-turn scenarios).
    """
    cmd = base_command() + ["--output-format", "json", "--no-ask-user"]
    if model:
        cmd += ["--model", str(model)]
    if effort:
        cmd += ["--reasoning-effort", str(effort)]
    if not instructions:
        cmd += ["--no-custom-instructions"]
    if session_id:
        cmd += ["--session-id", str(session_id)]
    if agent:
        cmd += ["--agent", str(agent)]
    if extra_args:
        cmd += [str(x) for x in extra_args]
    env = dict(os.environ)
    env["KAI_EVAL"] = "1"            # lets Kai hooks recognise eval traffic
    env["KAI_FORMAT_GATE"] = "0"     # never block a judge/agent reply on the Kai format gate
    tmp = None
    if cwd is None:
        tmp = tempfile.mkdtemp(prefix="kai-eval-")
        cwd = tmp
    t0 = time.time()
    try:
        proc = _run(cmd, prompt.encode("utf-8"), cwd, env, timeout)
        out = proc.stdout.decode("utf-8", errors="replace")
        err = proc.stderr.decode("utf-8", errors="replace")
        if proc.returncode != 0 and effort and "reasoning effort" in (err + out).lower():
            # Some models (including the default "auto") reject --reasoning-effort; retry without it.
            i = cmd.index("--reasoning-effort")
            cmd = cmd[:i] + cmd[i + 2:]
            proc = _run(cmd, prompt.encode("utf-8"), cwd, env, timeout)
            out = proc.stdout.decode("utf-8", errors="replace")
            err = proc.stderr.decode("utf-8", errors="replace")
        parsed = parse_jsonl(out)
        ok = proc.returncode == 0 and bool(parsed["text"].strip())
        error = "" if ok else (err.strip()[-500:] or f"exit {proc.returncode}, no assistant message")
        return {"ok": ok, "text": parsed["text"], "error": error, "model": parsed["model"],
                "session_id": parsed["session_id"] or (session_id or ""), "usage": parsed["usage"],
                "seconds": round(time.time() - t0, 2)}
    except FileNotFoundError:
        return {"ok": False, "text": "", "error": "copilot CLI not found on PATH (install GitHub Copilot CLI or set KAI_EVAL_LLM_CMD)",
                "model": "", "session_id": "", "usage": {}, "seconds": 0.0}
    except subprocess.TimeoutExpired:
        return {"ok": False, "text": "", "error": f"timed out after {timeout}s", "model": "", "session_id": "",
                "usage": {}, "seconds": round(time.time() - t0, 2)}
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)


def new_session_id():
    return str(uuid.uuid4())


def extract_json(text):
    """Last parseable JSON object in text; fenced ```json blocks are tried first."""
    import re
    cands = [m.strip() for m in re.findall(r"```(?:json)?\s*(.*?)```", text or "", re.S | re.I)]
    dec = json.JSONDecoder()
    found = None
    s = text or ""
    i = 0
    while i < len(s):
        if s[i] == "{":
            try:
                obj, end = dec.raw_decode(s, i)
                if isinstance(obj, dict):
                    found = obj        # keep the last top-level object
                i = end
                continue
            except ValueError:
                pass
        i += 1
    for c in reversed(cands):
        try:
            obj = json.loads(c)
            if isinstance(obj, dict):
                return obj
        except ValueError:
            continue
    return found


RUBRIC_SYSTEM = """You are a strict, fair evaluator grading an AI OUTPUT against a RUBRIC.
Do not use any tools. Do not add any banner, greeting or sign-off.
First reason briefly about how the output meets or misses the rubric. THEN emit exactly one fenced JSON block and nothing after it:
```json
{"score": <integer 1-5>, "pass": <true|false>, "reason": "<one sentence>"}
```
1 = fails the rubric, 5 = fully satisfies it. If you genuinely cannot determine it from the output, set "pass": false and begin "reason" with "UNKNOWN:". Judge only what is present; do not assume unstated facts."""

ASSERT_SYSTEM = """You are a strict assertion checker. For each ASSERTION, decide if it is TRUE of the OUTPUT.
Do not use any tools. Do not add any banner, greeting or sign-off.
Be literal. If you cannot verify an assertion from the output alone, mark it UNKNOWN (which counts as not satisfied). First reason briefly, THEN emit exactly one fenced JSON block and nothing after it:
```json
{"results": [{"assertion": "<verbatim>", "verdict": "TRUE|FALSE|UNKNOWN"}]}
```"""

PAIRWISE_SYSTEM = """You compare two AI OUTPUTS for the same TASK against a CRITERION.
Do not use any tools. Do not add any banner, greeting or sign-off.
Reason briefly, THEN emit exactly one fenced JSON block and nothing after it:
```json
{"winner": "1|2|tie", "reason": "<one sentence>"}
```
Position must not matter: judge content only."""


def _judge_prompt(system, body):
    return f"{system}\n\n{body}"


def judge_assertion(output, a, judge=None, caller=complete):
    """Grade one model assertion (llm-rubric / llm-assert). judge = {model, effort, timeout}."""
    judge = judge or {}
    t = str(a.get("type", ""))
    neg = t.startswith("not-")
    b = t[4:] if neg else t
    try:
        weight = float(a.get("weight", 1))
    except (TypeError, ValueError):
        weight = 1.0
    kw = {"model": judge.get("model"), "effort": judge.get("effort", "high"),
          "timeout": judge.get("timeout", DEFAULT_TIMEOUT), "instructions": False}

    def fail(reason):
        return {"type": t, "passed": False, "score": 0.0, "reason": reason, "weight": weight}

    if b == "llm-rubric":
        rubric = a.get("value") if isinstance(a.get("value"), str) else json.dumps(a.get("value"))
        res = caller(_judge_prompt(RUBRIC_SYSTEM, f"## RUBRIC\n{rubric}\n\n## OUTPUT\n{output}"), **kw)
        if not res["ok"]:
            return fail(f"judge error: {res['error']}")
        j = extract_json(res["text"])
        if not j or not isinstance(j.get("score"), (int, float)):
            return fail("judge returned unparseable verdict")
        norm = max(0.0, min(1.0, (float(j["score"]) - 1) / 4))
        reason = str(j.get("reason", ""))
        unknown = reason.strip().lower().startswith("unknown:")
        thr = float(a.get("threshold", 0.6))
        passed = (not unknown) and j.get("pass") is True and norm >= thr
        score = 0.0 if unknown else norm
        if neg:
            passed, score = not passed, 1.0 - score
        return {"type": t, "passed": passed, "score": score, "reason": reason or f"score {j['score']}/5", "weight": weight}

    if b == "llm-assert":
        v = a.get("value")
        items = [str(x) for x in v] if isinstance(v, list) else [str(v)]
        body = "## OUTPUT\n" + output + "\n\n## ASSERTIONS\n" + "\n".join(f"{i + 1}. {s}" for i, s in enumerate(items))
        res = caller(_judge_prompt(ASSERT_SYSTEM, body), **kw)
        if not res["ok"]:
            return fail(f"judge error: {res['error']}")
        j = extract_json(res["text"]) or {}
        results = j.get("results") or []
        if not results:
            return fail("judge returned no assertion verdicts")
        true_n = sum(1 for r in results[:len(items)] if str((r or {}).get("verdict", "")).upper() == "TRUE")
        score = true_n / len(items)
        passed = true_n == len(items)
        if neg:
            passed, score = not passed, 1.0 - score
        return {"type": t, "passed": passed, "score": score, "reason": f"{true_n}/{len(items)} assertions TRUE", "weight": weight}

    return fail(f"unknown model assert: {b}")


def judge_pairwise(task, out_a, out_b, criterion, judge=None, caller=complete):
    """Position-swapped pairwise comparison. Returns {a_score, b_score, verdicts, reason}.

    Each ordering is judged once; a win is 1, a tie 0.5. Averaging the two orderings
    cancels position bias; disagreement between orderings shows up as 0.5/0.5.
    """
    judge = judge or {}
    kw = {"model": judge.get("model"), "effort": judge.get("effort", "high"),
          "timeout": judge.get("timeout", DEFAULT_TIMEOUT), "instructions": False}
    verdicts = []
    a_pts = 0.0
    for first, second, a_is_first in ((out_a, out_b, True), (out_b, out_a, False)):
        body = f"## TASK\n{task}\n\n## CRITERION\n{criterion}\n\n## OUTPUT 1\n{first}\n\n## OUTPUT 2\n{second}"
        res = caller(_judge_prompt(PAIRWISE_SYSTEM, body), **kw)
        j = extract_json(res.get("text", "")) if res.get("ok") else None
        w = str((j or {}).get("winner", "tie")).strip().lower()
        if w not in ("1", "2"):
            w = "tie"
        verdicts.append({"order": "A,B" if a_is_first else "B,A", "winner": w,
                         "reason": (j or {}).get("reason", res.get("error", ""))})
        if w == "tie":
            a_pts += 0.5
        elif (w == "1") == a_is_first:
            a_pts += 1.0
    a_score = a_pts / 2
    return {"a_score": a_score, "b_score": 1.0 - a_score, "verdicts": verdicts}
