"""Kai evals CLI: assertion-first suites, pass^k/pass@k, A/B comparisons, failure-seeded
cases and multi-turn scenarios, all graded through the Copilot CLI (stdlib only).

    python evals.py run -s <suite> [-t trials] [--case id] [--json]
    python evals.py list | show <suite> | validate <suite|file> | new <name> [--type capability]
    python evals.py results <suite> [--run <id>] [--failed]
    python evals.py saturation <suite> | graduate <suite>
    python evals.py compare -s <suite> --variant A=prompt_a.md --variant B=prompt_b.md [--pairwise "<criterion>"]
    python evals.py compare -s <suite> --models modelA,modelB
    python evals.py failure log "<what went wrong>" --expected "..." [--actual "..."] [--category c] [--severity s]
    python evals.py failure list | failure convert [--suite name]
    python evals.py draft --from-rule "<rule>" | --from-failure "<failure>" [--run]
    python evals.py scenario <file.json> [-t trials]
    python evals.py grade --output out.txt (--asserts '[{"type":"contains","value":"x"}]' | --suite s --case id)
    python evals.py selftest

Exit codes: run/scenario 0 = passed, 1 = below threshold or error; others 0 = ok, 2 = bad input.
"""
import argparse
import datetime as _dt
import json
import os
import random
import re
import string
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import assertions as A  # noqa: E402
import llm as L  # noqa: E402
import stats as S  # noqa: E402

SKILL_DIR = Path(__file__).resolve().parent.parent
SHIPPED_SUITES = SKILL_DIR / "Suites"


def kai_home():
    if os.environ.get("KAI_HOME"):
        return Path(os.environ["KAI_HOME"])
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"]) / "kai"
    return Path.home() / ".copilot" / "kai"


def evals_root():
    return kai_home() / "MEMORY" / "EVALS"


def user_suites():
    return evals_root() / "suites"


def results_dir():
    return evals_root() / "results"


def drafts_dir():
    return evals_root() / "drafts"


def failures_file():
    return evals_root() / "failures.jsonl"


def now_iso():
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def run_id():
    return "run_" + _dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "_" + "".join(
        random.choice(string.ascii_lowercase + string.digits) for _ in range(5))


def slug(text, n=48):
    s = re.sub(r"[^a-z0-9]+", "_", (text or "").lower()).strip("_")
    return (s[:n] or "case").rstrip("_")


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except Exception:
        return default


# ------------------------------------------------------------------ suites

DEFAULT_EVAL_CONTEXT = (
    "\n\n---\n[EVALUATION CONTEXT] You are being evaluated in a single-shot setting with NO tools available. "
    "Do not narrate or simulate tool calls. Give your best final answer directly, applying your normal judgment, "
    "voice, and verification discipline within the answer itself (for example, state plainly when something would need checking)."
)


def resolve_suite(name):
    """Path to a suite by name or path. User suites (Kai memory) win over shipped examples."""
    p = Path(name)
    if p.suffix == ".json" and p.exists():
        return p
    for root in (user_suites(), SHIPPED_SUITES):
        for sub in ("", "regression", "capability"):
            cand = root / sub / f"{name}.json" if sub else root / f"{name}.json"
            if cand.exists():
                return cand
    return None


def all_suites():
    seen, out = set(), []
    for root, origin in ((user_suites(), "user"), (SHIPPED_SUITES, "shipped")):
        if not root.exists():
            continue
        for f in sorted(root.rglob("*.json")):
            if "drafts" in f.parts:
                continue
            if f.stem in seen:
                continue
            seen.add(f.stem)
            out.append((f.stem, f, origin))
    return out


def validate_suite(suite):
    probs = []
    if not isinstance(suite, dict):
        return ["suite is not a JSON object"]
    if "tasks" in suite and "cases" not in suite:
        return ["legacy format: has `tasks:` but no `cases:`; this runner needs cases with prompt + assert"]
    cases = suite.get("cases")
    if not isinstance(cases, list) or not cases:
        return ["suite has no `cases` list"]
    if suite.get("type", "regression") not in ("regression", "capability"):
        probs.append("type must be regression or capability")
    for key in ("pass_threshold",):
        if key in suite and not (isinstance(suite[key], (int, float)) and 0 <= suite[key] <= 1):
            probs.append(f"{key} must be a number in [0, 1]")
    if "trials" in suite and not (isinstance(suite["trials"], int) and suite["trials"] >= 1):
        probs.append("trials must be an integer >= 1")
    ids = set()
    for i, c in enumerate(cases):
        where = f"case[{i}]"
        if not isinstance(c, dict):
            probs.append(f"{where} is not an object")
            continue
        cid = c.get("id")
        if not isinstance(cid, str) or not cid:
            probs.append(f"{where} needs an id")
        elif cid in ids:
            probs.append(f"{where} duplicate id {cid!r}")
        ids.add(cid)
        if not isinstance(c.get("prompt"), str) or not c["prompt"].strip():
            probs.append(f"{where} ({cid}) needs a prompt")
        asserts = c.get("assert")
        if not isinstance(asserts, list) or not asserts:
            probs.append(f"{where} ({cid}) needs a non-empty assert list")
            continue
        for j, a in enumerate(asserts):
            for p in A.validate_assertion(a):
                probs.append(f"{where} ({cid}) assert[{j}]: {p}")
    am, jm = suite.get("agent_model"), suite.get("judge_model")
    if am and jm and am == jm and suite.get("agent_effort") == suite.get("judge_effort"):
        probs.append("warning: judge configuration equals the agent under test; use a different judge_model or judge_effort")
    return probs


def load_suite(name):
    path = resolve_suite(name)
    if not path:
        return None, None, [f"suite not found: {name}"]
    suite = read_json(path)
    if suite is None:
        return None, path, [f"invalid JSON in {path}"]
    errors = [p for p in validate_suite(suite) if not p.startswith("warning:")]
    return suite, path, errors


def system_text(suite, override_file=None):
    if override_file:
        return Path(override_file).read_text(encoding="utf-8")
    if suite.get("system_file"):
        sf = Path(suite["system_file"]).expanduser()
        if not sf.is_absolute():
            base = Path(suite.get("_path", ".")).parent
            sf = base / sf
        return sf.read_text(encoding="utf-8")
    return suite.get("system_prompt") or ""


def agent_prompt(system, user_prompt, eval_context=True):
    parts = []
    if system.strip():
        parts.append("<system_instructions>\n" + system.strip() + "\n</system_instructions>\n")
    parts.append(user_prompt)
    if eval_context:
        parts.append(DEFAULT_EVAL_CONTEXT)
    return "\n".join(parts)


KAI_BANNER = re.compile(r"^\s*═+\s*Kai\b[^\n]*\n?")
KAI_CLOSER = re.compile(r"\n?[^\S\n]*🗣️\s*Kai:[^\n]*\s*$")


def strip_format(text):
    """Drop the Kai banner line and the closer line so asserts see the answer itself."""
    return KAI_CLOSER.sub("", KAI_BANNER.sub("", text, count=1)).strip()


def grade(output, asserts, judge, caller):
    out = []
    for a in asserts:
        if A.is_model_assert(a.get("type")):
            out.append(L.judge_assertion(output, a, judge=judge, caller=caller))
        else:
            out.append(A.evaluate(output, a))
    return out


def weighted(results):
    tw = sum(r["weight"] for r in results)
    return sum(r["score"] * r["weight"] for r in results) / tw if tw > 0 else 0.0


def run_suite(suite, trials=None, case_filter=None, system_override=None, agent_model=None,
              judge_model=None, caller=None, persist=True, label=None, quiet=False):
    caller = caller or L.complete
    threshold = float(suite.get("pass_threshold", 0.75))
    k = int(trials or suite.get("trials", 3))
    system = system_text(suite, system_override)
    agent = {"model": agent_model or suite.get("agent_model"), "effort": suite.get("agent_effort"),
             "instructions": suite.get("instructions", True), "agent": suite.get("agent"),
             "timeout": int(suite.get("timeout", L.DEFAULT_TIMEOUT))}
    judge = {"model": judge_model or suite.get("judge_model"), "effort": suite.get("judge_effort", "high"),
             "timeout": int(suite.get("timeout", L.DEFAULT_TIMEOUT))}
    eval_ctx = suite.get("eval_context", True)
    cases = [c for c in suite["cases"] if not case_filter or c["id"] in case_filter]
    rid = run_id()
    case_results = []
    for c in cases:
        cthr = float(c.get("threshold", threshold))
        trial_rows = []
        for t in range(k):
            res = caller(agent_prompt(system, c["prompt"], eval_ctx), model=agent["model"], effort=agent["effort"],
                         timeout=agent["timeout"], instructions=agent["instructions"], agent=agent["agent"])
            if res["ok"]:
                output = res["text"].strip()
                graded = grade(strip_format(output) if suite.get("strip_format") else output, c["assert"], judge, caller)
                score = weighted(graded)
            else:
                output, graded, score = "", [], 0.0
            passed = res["ok"] and score >= cthr
            trial_rows.append({"trial": t + 1, "score": score, "passed": passed, "output": output,
                               "asserts": graded, "error": "" if res["ok"] else res["error"],
                               "model": res.get("model", ""), "seconds": res.get("seconds", 0)})
            if not quiet:
                mark = "PASS" if passed else "FAIL"
                err = f"  ({res['error'][:80]})" if not res["ok"] else ""
                print(f"  {c['id']} t{t + 1}: {mark} {score * 100:.0f}%{err}", file=sys.stderr)
        summ = S.summarize_trials([r["score"] for r in trial_rows], [r["passed"] for r in trial_rows])
        summ.update({"id": c["id"], "negative": bool(c.get("negative")), "trials_detail": trial_rows})
        case_results.append(summ)
    n = len(case_results) or 1
    mean_score = sum(c["mean_score"] for c in case_results) / n
    pass_hat = sum(c["pass_hat_k"] for c in case_results) / n
    pass_at = sum(c["pass_at_k"] for c in case_results) / n
    case_means = [c["mean_score"] for c in case_results]
    lo, hi = S.ci95(case_means)
    result = {
        "suite": suite.get("name", "?"), "label": label or "", "type": suite.get("type", "regression"),
        "run_id": rid, "ts": now_iso(), "trials": k, "pass_threshold": threshold,
        "passed": bool(case_results) and mean_score >= threshold,
        "score": mean_score, "pass_hat_k": pass_hat, "pass_at_k": pass_at,
        "sem": S.sem(case_means), "ci95": [lo, hi],
        "agent": {k2: v for k2, v in agent.items() if v not in (None, "")},
        "judge": {k2: v for k2, v in judge.items() if v not in (None, "")},
        "summary": f"pass^k {pass_hat * 100:.0f}%, pass@k {pass_at * 100:.0f}%, mean {mean_score * 100:.1f}% "
                   f"(95% CI {lo * 100:.0f}-{hi * 100:.0f}%) over {k} trial(s) x {len(case_results)} case(s)",
        "cases": [{x: c[x] for x in ("id", "mean_score", "pass_hat_k", "pass_at_k", "passed_trials", "trials")}
                  for c in case_results],
    }
    if persist:
        d = results_dir() / slug(result["suite"], 80)
        write_json(d / rid / "run.json", dict(result, detail=case_results))
        write_json(d / "latest.json", result)
        result["run_path"] = str(d / rid / "run.json")
    result["_detail"] = case_results
    return result


def print_result(r):
    status = "PASSED" if r["passed"] else "BELOW THRESHOLD"
    print(f"\n{status}: {r['suite']} ({r['type']}{', ' + r['label'] if r.get('label') else ''})")
    print(f"  {r['summary']}")
    for c in r["cases"]:
        print(f"  - {c['id']}: pass^k {c['pass_hat_k'] * 100:.0f}%  pass@k {c['pass_at_k'] * 100:.0f}%  "
              f"mean {c['mean_score'] * 100:.0f}%  ({c['passed_trials']}/{c['trials']} trials)")
    if r.get("run_path"):
        print(f"  transcripts: {r['run_path']}")
    print("  Read the transcripts before trusting the score.")


# ------------------------------------------------------------------ history / saturation

def run_history(suite_name, limit=10):
    d = results_dir() / slug(suite_name, 80)
    if not d.exists():
        return []
    runs = []
    for rd in sorted(p for p in d.iterdir() if p.is_dir() and p.name.startswith("run_")):
        r = read_json(rd / "run.json")
        if r:
            runs.append(r)
    return runs[-limit:]


def saturation(suite, history):
    sat_thr = float(suite.get("saturation_threshold", 0.95))
    recent = history[-3:]
    above = [r for r in recent if float(r.get("pass_hat_k", 0)) >= sat_thr]
    saturated = len(recent) >= 3 and len(above) == 3
    if saturated and suite.get("type", "regression") == "capability":
        action = "graduate_to_regression"
    elif saturated:
        action = "add_harder_cases"
    else:
        action = "keep"
    return {"saturated": saturated, "consecutive_above": len(above), "threshold": sat_thr,
            "recommended_action": action,
            "history": [{"run": r.get("run_id"), "ts": r.get("ts"), "pass_hat_k": r.get("pass_hat_k"),
                         "score": r.get("score")} for r in history]}


# ------------------------------------------------------------------ commands

def cmd_run(args):
    suite, path, errors = load_suite(args.suite)
    if errors:
        for e in errors:
            print(f"error: {e}", file=sys.stderr)
        return 1
    suite["_path"] = str(path)
    suite.setdefault("name", Path(path).stem)
    print(f"Running suite {suite['name']} ({path})", file=sys.stderr)
    r = run_suite(suite, trials=args.trials, case_filter=set(args.case) if args.case else None,
                  system_override=args.system_file, agent_model=args.agent_model, judge_model=args.judge_model,
                  label=args.label)
    r.pop("_detail", None)
    if args.json:
        print(json.dumps(r, indent=2, ensure_ascii=False))
    else:
        print_result(r)
    return 0 if r["passed"] else 1


def cmd_list(args):
    rows = all_suites()
    if not rows:
        print("No suites yet. Create one with: python evals.py new <name>")
        return 0
    for name, path, origin in rows:
        s = read_json(path, {}) or {}
        latest = read_json(results_dir() / slug(s.get("name", name), 80) / "latest.json")
        last = f"last pass^k {latest['pass_hat_k'] * 100:.0f}% ({latest['ts'][:10]})" if latest else "never run"
        print(f"{name:<32} {s.get('type', 'regression'):<11} {len(s.get('cases') or []):>3} cases  {origin:<8} {last}")
    return 0


def cmd_show(args):
    suite, path, errors = load_suite(args.suite)
    if suite is None:
        print("\n".join(errors), file=sys.stderr)
        return 2
    name = suite.get("name", Path(path).stem)
    print(f"Suite: {name}\nFile: {path}\nType: {suite.get('type', 'regression')}  threshold: {suite.get('pass_threshold', 0.75)}"
          f"  trials: {suite.get('trials', 3)}\nCases: {len(suite.get('cases', []))}")
    for c in suite.get("cases", []):
        kinds = ", ".join(a.get("type", "?") for a in c.get("assert", []))
        print(f"  - {c.get('id')}{' (should-not)' if c.get('negative') else ''}: {kinds}")
    sat = saturation(suite, run_history(name))
    print(f"Saturation: {'yes' if sat['saturated'] else 'no'} ({sat['consecutive_above']}/3 recent runs >= "
          f"{sat['threshold'] * 100:.0f}% pass^k) -> {sat['recommended_action'].replace('_', ' ')}")
    for p in validate_suite(suite):
        print(f"  ! {p}")
    return 0


def cmd_validate(args):
    path = resolve_suite(args.suite)
    if not path:
        print(f"suite not found: {args.suite}", file=sys.stderr)
        return 2
    suite = read_json(path)
    probs = ["invalid JSON"] if suite is None else validate_suite(suite)
    hard = [p for p in probs if not p.startswith("warning:")]
    for p in probs:
        print(("  " if p.startswith("warning:") else "  error: ") + p)
    print(f"{path}: {'VALID' if not hard else 'INVALID'}")
    return 0 if not hard else 2


def cmd_new(args):
    name = slug(args.name, 64).replace("_", "-")
    target = user_suites() / args.type / f"{name}.json"
    if target.exists() and not args.force:
        print(f"exists: {target} (use --force to overwrite)", file=sys.stderr)
        return 2
    suite = {
        "name": name,
        "description": args.description or "What this suite guards and why.",
        "type": args.type,
        "pass_threshold": 0.95 if args.type == "regression" else 0.7,
        "saturation_threshold": 0.95,
        "trials": 3,
        "judge_effort": "high",
        "cases": [
            {"id": "should_do_example", "prompt": "Replace with a realistic user turn that exercises the behaviour.",
             "assert": [{"type": "not-icontains", "value": "should work", "weight": 1},
                        {"type": "llm-rubric", "value": "Does the answer do X without Y?", "weight": 2}]},
            {"id": "should_not_example", "negative": True,
             "prompt": "Replace with a turn where the behaviour must NOT fire.",
             "assert": [{"type": "llm-assert", "value": ["The response does not do X"], "weight": 1}]},
        ],
        "created": now_iso(),
    }
    write_json(target, suite)
    print(f"Created {target}\nEdit the two example cases, then: python evals.py validate {name}")
    return 0


def cmd_results(args):
    hist = run_history(args.suite, limit=1000)
    if not hist:
        print(f"No runs recorded for {args.suite} under {results_dir()}")
        return 0
    if args.run:
        run = next((r for r in hist if r.get("run_id") == args.run), None)
        if not run:
            print(f"run not found: {args.run}", file=sys.stderr)
            return 2
    elif args.history:
        for r in hist:
            print(f"{r.get('run_id')}  {r.get('ts', '')[:16]}  pass^k {r.get('pass_hat_k', 0) * 100:5.1f}%  "
                  f"mean {r.get('score', 0) * 100:5.1f}%  {r.get('label', '')}")
        return 0
    else:
        run = hist[-1]
    print(f"{run['suite']}  {run['run_id']}  {run['ts']}\n  {run['summary']}")
    for c in run.get("detail", []):
        for t in c.get("trials_detail", []):
            if args.failed and t.get("passed"):
                continue
            print(f"\n--- {c['id']} trial {t['trial']}: {'PASS' if t['passed'] else 'FAIL'} {t['score'] * 100:.0f}%"
                  f"{' error: ' + t['error'] if t.get('error') else ''}")
            for a in t.get("asserts", []):
                print(f"    [{'x' if a['passed'] else ' '}] {a['type']}: {a['reason']}")
            if t.get("output"):
                print("    output: " + t["output"][:600].replace("\n", "\n            "))
    return 0


def cmd_saturation(args):
    suite, path, errors = load_suite(args.suite)
    if suite is None:
        print("\n".join(errors), file=sys.stderr)
        return 2
    sat = saturation(suite, run_history(suite.get("name", Path(path).stem)))
    print(json.dumps(sat, indent=2))
    return 0


def cmd_graduate(args):
    path = resolve_suite(args.suite)
    if not path:
        print(f"suite not found: {args.suite}", file=sys.stderr)
        return 2
    suite = read_json(path) or {}
    if suite.get("type") != "capability":
        print("only capability suites graduate", file=sys.stderr)
        return 2
    suite["type"] = "regression"
    suite["pass_threshold"] = max(float(suite.get("pass_threshold", 0.7)), 0.95)
    suite["graduated"] = now_iso()
    target = user_suites() / "regression" / f"{Path(path).stem}.json"
    write_json(target, suite)
    if Path(path).resolve() != target.resolve() and user_suites() in Path(path).resolve().parents:
        Path(path).unlink()
    print(f"Graduated to regression: {target} (threshold {suite['pass_threshold']})")
    return 0


def cmd_compare(args):
    suite, path, errors = load_suite(args.suite)
    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    suite["_path"] = str(path)
    suite.setdefault("name", Path(path).stem)
    variants = []
    for v in args.variant or []:
        if "=" not in v:
            print(f"--variant needs NAME=path, got {v!r}", file=sys.stderr)
            return 2
        nm, f = v.split("=", 1)
        variants.append({"name": nm, "system_file": f})
    for m in (args.models.split(",") if args.models else []):
        if m.strip():
            variants.append({"name": m.strip(), "model": m.strip()})
    if len(variants) < 2:
        print("compare needs at least two --variant or --models entries", file=sys.stderr)
        return 2
    if args.hypothesis:
        print(f"Hypothesis (pre-committed): {args.hypothesis}\nMin meaningful delta: {args.min_delta}", file=sys.stderr)
    runs = []
    for v in variants:
        print(f"\n== variant {v['name']}", file=sys.stderr)
        runs.append(run_suite(suite, trials=args.trials, system_override=v.get("system_file"),
                              agent_model=v.get("model"), judge_model=args.judge_model, label=f"variant:{v['name']}"))
    base = runs[0]
    report = {"suite": suite["name"], "hypothesis": args.hypothesis or "", "min_delta": args.min_delta,
              "variants": [], "pairwise": []}
    for v, r in zip(variants, runs):
        report["variants"].append({"name": v["name"], "score": r["score"], "pass_hat_k": r["pass_hat_k"],
                                   "ci95": r["ci95"], "run_id": r["run_id"]})
    base_scores = {c["id"]: c["mean_score"] for c in base["_detail"]}
    for v, r in zip(variants[1:], runs[1:]):
        other = {c["id"]: c["mean_score"] for c in r["_detail"]}
        ids = [i for i in base_scores if i in other]
        test = S.paired_permutation([other[i] for i in ids], [base_scores[i] for i in ids])
        delta = test["mean_diff"]
        if test["p_value"] < 0.05 and abs(delta) >= args.min_delta:
            verdict = f"{v['name']} better" if delta > 0 else f"{variants[0]['name']} better"
        else:
            verdict = "no significant difference (keep the simpler variant, or add cases)"
        entry = {"a": variants[0]["name"], "b": v["name"], "cases": len(ids), "mean_diff_b_minus_a": delta,
                 "p_value": test["p_value"], "ci95": test["ci95"], "exact": test["exact"], "verdict": verdict}
        if args.pairwise:
            judge = {"model": args.judge_model or suite.get("judge_model"), "effort": suite.get("judge_effort", "high")}
            a_out = {c["id"]: c["trials_detail"][0]["output"] for c in base["_detail"]}
            b_out = {c["id"]: c["trials_detail"][0]["output"] for c in r["_detail"]}
            prompts = {c["id"]: c["prompt"] for c in suite["cases"]}
            wins_a = wins_b = ties = 0
            for i in ids:
                pw = L.judge_pairwise(prompts[i], a_out[i], b_out[i], args.pairwise, judge=judge)
                if pw["a_score"] > 0.5:
                    wins_a += 1
                elif pw["a_score"] < 0.5:
                    wins_b += 1
                else:
                    ties += 1
            entry["pairwise"] = {"criterion": args.pairwise, "a_wins": wins_a, "b_wins": wins_b, "ties": ties,
                                 "sign_test_p": S.sign_test(wins_a, wins_b), "position_swapped": True}
        report["pairwise"].append(entry)
    out = results_dir() / slug(suite["name"], 80) / "comparisons" / f"{run_id()}.json"
    write_json(out, report)
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print(f"\nComparison on {suite['name']}")
        print(f"{'variant':<24} {'mean':>7} {'pass^k':>7}   95% CI")
        for v in report["variants"]:
            print(f"{v['name']:<24} {v['score'] * 100:6.1f}% {v['pass_hat_k'] * 100:6.1f}%   "
                  f"{v['ci95'][0] * 100:.0f}-{v['ci95'][1] * 100:.0f}%")
        for e in report["pairwise"]:
            print(f"\n{e['b']} vs {e['a']}: delta {e['mean_diff_b_minus_a'] * 100:+.1f} pts over {e['cases']} cases, "
                  f"p={e['p_value']:.3f} ({'exact' if e['exact'] else 'monte carlo'}) -> {e['verdict']}")
            if "pairwise" in e:
                pw = e["pairwise"]
                print(f"  pairwise judge ({pw['criterion']}): {e['a']} {pw['a_wins']} / {e['b']} {pw['b_wins']} / "
                      f"ties {pw['ties']}, sign test p={pw['sign_test_p']:.3f}")
        print(f"\nSaved: {out}")
    return 0


def load_failures():
    f = failures_file()
    out = []
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
    return out


def save_failures(rows):
    f = failures_file()
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")


def failure_to_case(fl):
    """Deterministic v2 case from a logged failure: a rubric guarding the expected behaviour
    plus a negative llm-assert on the actual (bad) behaviour. Needs a human-written prompt;
    the failure's `prompt` field (if given) is used, otherwise a placeholder is flagged."""
    expected = fl.get("expected") or "completes the task correctly"
    actual = fl.get("actual") or ""
    asserts = [{"type": "llm-rubric", "weight": 2,
                "value": f"The response should: {expected}" + (f"\nThe response should NOT: {actual}" if actual else "")
                         + "\nDoes the response avoid the failure mode described?"}]
    if actual:
        asserts.append({"type": "llm-assert", "weight": 1, "value": [f"The response does not {actual.rstrip('.')}"]})
    return {"id": slug(f"{fl.get('category', 'general')}_{fl.get('description', '')}", 60),
            "prompt": fl.get("prompt") or f"TODO-PROMPT: write the user turn that triggered: {fl.get('description', '')}",
            "assert": asserts, "source": {"failure_id": fl.get("id"), "severity": fl.get("severity")}}


def cmd_failure(args):
    rows = load_failures()
    if args.action == "log":
        if not args.text:
            print("failure log needs a description", file=sys.stderr)
            return 2
        fl = {"id": "failure_" + _dt.datetime.now().strftime("%Y%m%d%H%M%S") + "_" + slug(args.text, 16),
              "ts": now_iso(), "description": args.text, "expected": args.expected or "", "actual": args.actual or "",
              "prompt": args.prompt or "", "category": args.category, "severity": args.severity, "converted": None}
        rows.append(fl)
        save_failures(rows)
        print(f"Logged {fl['id']} ({len(rows)} total; Anthropic: 20-50 real failures make a strong first suite)")
        return 0
    if args.action == "list":
        if not rows:
            print("No failures logged yet.")
        for r in rows:
            print(f"{'converted' if r.get('converted') else 'pending  '}  {r.get('severity', '?'):<8} "
                  f"[{r.get('category', '?')}] {r.get('description', '')[:80]}")
        return 0
    if args.action == "convert":
        pending = [r for r in rows if not r.get("converted")]
        if not pending:
            print("Nothing to convert.")
            return 0
        cases = [failure_to_case(r) for r in pending]
        name = args.suite or "from-failures"
        target = drafts_dir() / f"{slug(name, 64)}.json"
        existing = read_json(target, None) or {"name": name, "type": "regression", "pass_threshold": 0.95,
                                                "trials": 3, "cases": [], "draft": True}
        have = {c["id"] for c in existing["cases"]}
        for c in cases:
            base, i = c["id"], 2
            while c["id"] in have:
                c["id"] = f"{base}_{i}"
                i += 1
            have.add(c["id"])
            existing["cases"].append(c)
        write_json(target, existing)
        for r, c in zip(pending, cases):
            r["converted"] = c["id"]
        save_failures(rows)
        todo = sum(1 for c in cases if c["prompt"].startswith("TODO-PROMPT"))
        print(f"Drafted {len(cases)} case(s) into {target}"
              + (f"; {todo} need a real prompt (search TODO-PROMPT)" if todo else "")
              + f"\nReview, then move the file into {user_suites() / 'regression'} to make it live.")
        return 0
    return 2


AUTHOR_SYSTEM = """You author ONE assertion-first eval case that guards a behavioural property of an AI assistant.
Do not use any tools. Do not add any banner, greeting or sign-off.
Given a RULE or FAILURE, produce a realistic single-turn user PROMPT that would exercise it, plus ASSERTIONS that grade the assistant's OUTPUT (grade what it produced, not its path).

Available assert types:
- Deterministic (prefer when exact): equals, contains, icontains, contains-all, contains-any, regex, starts-with, ends-with, is-json, contains-json, max-length, min-length, max-words, min-words. Any takes a "not-" prefix to invert. Fields: {type, value, weight} (length types use threshold).
- Model-graded (for nuance): llm-rubric {type, value:"<yes/no rubric question>", weight}, llm-assert {type, value:["<assertion>", ...], weight}.

Rules: 2-4 assertions, weighted for partial credit. Prefer a cheap deterministic assert plus a model-graded one. Make the prompt concrete and answerable in one message. Keep each rubric or assertion literal and objectively checkable.

Reason briefly, THEN emit exactly one fenced JSON block and nothing after:
```json
{"id":"snake_case_id","prompt":"...","assert":[{"type":"...","value":"...","weight":1}]}
```"""


def cmd_draft(args):
    if not (args.from_rule or args.from_failure):
        print("draft needs --from-rule or --from-failure", file=sys.stderr)
        return 2
    kind = "RULE / DISPOSITION TO GUARD" if args.from_rule else "FAILURE TO PREVENT"
    src = args.from_rule or args.from_failure
    res = L.complete(f"{AUTHOR_SYSTEM}\n\n## {kind}\n{src}" + (f"\n\n(id hint: {args.topic})" if args.topic else ""),
                     effort="high", instructions=False)
    if not res["ok"]:
        print(f"model call failed: {res['error']}", file=sys.stderr)
        return 1
    case = L.extract_json(res["text"])
    if not case or not isinstance(case.get("prompt"), str) or not isinstance(case.get("assert"), list):
        print("could not parse a valid draft case from the model reply", file=sys.stderr)
        return 1
    case["id"] = slug(case.get("id") or args.topic or src, 60)
    probs = [p for a in case["assert"] for p in A.validate_assertion(a)]
    target = drafts_dir() / f"{case['id']}.json"
    write_json(target, {"name": case["id"], "type": "capability", "draft": True, "trials": 1,
                        "source": {"kind": "rule" if args.from_rule else "failure", "text": src}, "cases": [case]})
    print(f"Draft written: {target}\n" + json.dumps(case, indent=2, ensure_ascii=False))
    for p in probs:
        print(f"  ! {p}")
    if args.run:
        r = run_suite({"name": "__draft__", "type": "capability", "trials": 1, "cases": [case]}, persist=False)
        print(f"\ndraft dry-run: {r['summary']}")
    return 0


SIM_SYSTEM = """You are simulating a USER talking to an AI assistant, to test the assistant.
Do not use any tools. Do not add any banner, greeting or sign-off. Stay in character as the user described below.
Reply with ONLY the user's next message. If the conversation has reached its natural end, reply with exactly: <<DONE>>"""


def run_scenario(sc, caller=None, trials=None, quiet=False):
    caller = caller or L.complete
    k = int(trials or sc.get("trials", 1))
    criteria = sc.get("criteria") or []
    turns = sc.get("turns") or []
    sim = sc.get("simulate") or {}
    max_turns = int(sim.get("max_turns", sc.get("max_turns", len(turns) or 4)))
    system = sc.get("system_prompt") or ""
    judge = {"model": sc.get("judge_model"), "effort": sc.get("judge_effort", "high")}
    rows = []
    for t in range(k):
        sid = L.new_session_id()
        convo, err = [], ""
        for i in range(max_turns if sim else len(turns)):
            if sim:
                if i == 0 and sim.get("opening"):
                    user_msg = sim["opening"]
                else:
                    hist = "\n\n".join(f"{r.upper()}: {m}" for r, m in convo) or "(no messages yet)"
                    s = caller(f"{SIM_SYSTEM}\n\n## USER PERSONA AND GOAL\n{sc.get('description', '')}\n"
                               f"{sim.get('persona', '')}\n\n## CONVERSATION SO FAR\n{hist}",
                               model=sim.get("model"), instructions=False)
                    if not s["ok"]:
                        err = f"simulator: {s['error']}"
                        break
                    user_msg = s["text"].strip()
                    if user_msg == "<<DONE>>" or not user_msg:
                        break
            else:
                user_msg = turns[i]
            first = not convo
            prompt = agent_prompt(system, user_msg, eval_context=False) if first else user_msg
            res = caller(prompt, model=sc.get("agent_model"), effort=sc.get("agent_effort"),
                         instructions=sc.get("instructions", True), session_id=sid)
            convo.append(("user", user_msg))
            if not res["ok"]:
                err = f"agent: {res['error']}"
                break
            convo.append(("assistant", res["text"].strip()))
        transcript = "\n\n".join(f"{r.upper()}: {m}" for r, m in convo)
        graded = []
        if not err and criteria:
            graded = [L.judge_assertion(transcript, {"type": "llm-assert", "value": criteria}, judge=judge, caller=caller)]
        for a in sc.get("assert") or []:
            last = next((m for r, m in reversed(convo) if r == "assistant"), "")
            graded.append(L.judge_assertion(last, a, judge=judge, caller=caller) if A.is_model_assert(a.get("type"))
                          else A.evaluate(last, a))
        score = weighted(graded) if graded else 0.0
        passed = not err and bool(graded) and all(g["passed"] for g in graded)
        rows.append({"trial": t + 1, "passed": passed, "score": score, "transcript": convo, "asserts": graded,
                     "error": err, "session_id": sid})
        if not quiet:
            print(f"  {sc.get('name', 'scenario')} t{t + 1}: {'PASS' if passed else 'FAIL'} {score * 100:.0f}%"
                  f"{'  (' + err[:80] + ')' if err else ''}", file=sys.stderr)
    summ = S.summarize_trials([r["score"] for r in rows], [r["passed"] for r in rows])
    return {"scenario": sc.get("name", "scenario"), "run_id": run_id(), "ts": now_iso(),
            "passed": summ["pass_hat_k"] == 1.0, **summ, "detail": rows}


def cmd_scenario(args):
    sc = read_json(args.file)
    if not isinstance(sc, dict) or not (sc.get("turns") or sc.get("simulate")):
        print("scenario file must be JSON with `turns` (list of user messages) or `simulate` {persona, max_turns}",
              file=sys.stderr)
        return 2
    r = run_scenario(sc, trials=args.trials)
    write_json(results_dir() / "scenarios" / slug(r["scenario"], 80) / f"{r['run_id']}.json", r)
    print(f"\n{'PASSED' if r['passed'] else 'FAILED'}: {r['scenario']}  pass^k {r['pass_hat_k'] * 100:.0f}%  "
          f"pass@k {r['pass_at_k'] * 100:.0f}%  mean {r['mean_score'] * 100:.0f}%")
    for t in r["detail"]:
        for a in t["asserts"]:
            print(f"  t{t['trial']} [{'x' if a['passed'] else ' '}] {a['type']}: {a['reason']}")
    return 0 if r["passed"] else 1


def cmd_grade(args):
    """Grade an existing output (file or stdin) against a case's asserts or an inline assert list."""
    text = sys.stdin.read() if args.output == "-" else Path(args.output).read_text(encoding="utf-8")
    if args.asserts:
        try:
            asserts = json.loads(args.asserts)
        except ValueError as exc:
            print(f"--asserts is not valid JSON: {exc}", file=sys.stderr)
            return 2
        asserts = asserts if isinstance(asserts, list) else [asserts]
        judge = {"model": args.judge_model, "effort": "high"}
    else:
        suite, _, errors = load_suite(args.suite or "")
        if suite is None or not args.case:
            print("grade needs --asserts JSON, or --suite and --case", file=sys.stderr)
            return 2
        case = next((c for c in suite["cases"] if c["id"] == args.case), None)
        if not case:
            print(f"case not found: {args.case}", file=sys.stderr)
            return 2
        asserts = case["assert"]
        judge = {"model": args.judge_model or suite.get("judge_model"), "effort": suite.get("judge_effort", "high")}
    probs = [p for a in asserts for p in A.validate_assertion(a)]
    if probs:
        print("\n".join("error: " + p for p in probs), file=sys.stderr)
        return 2
    text = strip_format(text) if args.strip_format else text.strip()
    results = grade(text, asserts, judge, L.complete)
    score = weighted(results)
    if args.json:
        print(json.dumps({"score": score, "asserts": results}, indent=2, ensure_ascii=False))
    else:
        for r in results:
            print(f"[{'x' if r['passed'] else ' '}] {r['type']} ({r['score']:.2f} x {r['weight']:g}): {r['reason']}")
        print(f"weighted score: {score * 100:.0f}%")
    return 0 if all(r["passed"] for r in results) else 1


def cmd_selftest(args):
    ok = A.selftest(verbose=True)
    p = S.pass_hat_k(3, 2, 3) == 0.0 and S.pass_at_k(3, 2, 3) == 1.0 and abs(S.pass_hat_k(4, 3, 2) - 0.5) < 1e-9
    print(f"stats: {'PASS' if p else 'FAIL'} (pass^k / pass@k estimators)")
    return 0 if ok and p else 1


def build_parser():
    ap = argparse.ArgumentParser(prog="evals.py", description="Kai assertion-first evals (Copilot-graded)")
    sp = ap.add_subparsers(dest="cmd")
    r = sp.add_parser("run")
    r.add_argument("-s", "--suite", required=True)
    r.add_argument("-t", "--trials", type=int)
    r.add_argument("--case", action="append")
    r.add_argument("--system-file")
    r.add_argument("--agent-model")
    r.add_argument("--judge-model")
    r.add_argument("--label")
    r.add_argument("--json", action="store_true")
    sp.add_parser("list")
    for n in ("show", "validate", "saturation", "graduate"):
        x = sp.add_parser(n)
        x.add_argument("suite")
    n = sp.add_parser("new")
    n.add_argument("name")
    n.add_argument("--type", choices=("regression", "capability"), default="capability")
    n.add_argument("--description")
    n.add_argument("--force", action="store_true")
    res = sp.add_parser("results")
    res.add_argument("suite")
    res.add_argument("--run")
    res.add_argument("--failed", action="store_true")
    res.add_argument("--history", action="store_true")
    c = sp.add_parser("compare")
    c.add_argument("-s", "--suite", required=True)
    c.add_argument("--variant", action="append")
    c.add_argument("--models")
    c.add_argument("-t", "--trials", type=int)
    c.add_argument("--judge-model")
    c.add_argument("--pairwise", metavar="CRITERION")
    c.add_argument("--hypothesis")
    c.add_argument("--min-delta", type=float, default=0.05)
    c.add_argument("--json", action="store_true")
    f = sp.add_parser("failure")
    f.add_argument("action", choices=("log", "list", "convert"))
    f.add_argument("text", nargs="?")
    f.add_argument("--expected")
    f.add_argument("--actual")
    f.add_argument("--prompt")
    f.add_argument("--category", default="general")
    f.add_argument("--severity", choices=("low", "medium", "high", "critical"), default="medium")
    f.add_argument("--suite")
    d = sp.add_parser("draft")
    d.add_argument("--from-rule")
    d.add_argument("--from-failure")
    d.add_argument("--topic")
    d.add_argument("--run", action="store_true")
    s = sp.add_parser("scenario")
    s.add_argument("file")
    s.add_argument("-t", "--trials", type=int)
    g = sp.add_parser("grade")
    g.add_argument("--output", required=True, help="file with the output to grade, or - for stdin")
    g.add_argument("--asserts", help="JSON assert or list of asserts")
    g.add_argument("--suite")
    g.add_argument("--case")
    g.add_argument("--judge-model")
    g.add_argument("--strip-format", action="store_true", help="drop the Kai banner and closer before grading")
    g.add_argument("--json", action="store_true")
    sp.add_parser("selftest")
    return ap


COMMANDS = {"run": cmd_run, "list": cmd_list, "show": cmd_show, "validate": cmd_validate, "new": cmd_new,
            "results": cmd_results, "saturation": cmd_saturation, "graduate": cmd_graduate, "compare": cmd_compare,
            "failure": cmd_failure, "draft": cmd_draft, "scenario": cmd_scenario, "grade": cmd_grade, "selftest": cmd_selftest}


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = build_parser()
    args = ap.parse_args(argv)
    if not args.cmd:
        ap.print_help()
        return 2
    return COMMANDS[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
