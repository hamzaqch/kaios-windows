# Eval best practices

## Judge design

- **Reason before scoring.** The judge prompts require a short rationale before the JSON verdict; it measurably improves grading accuracy.
- **Use a 1-5 scale or literal TRUE/FALSE.** 0-100 scales calibrate poorly.
- **Don't self-judge.** Use a different `judge_model`, or at least a different `judge_effort`, from the agent under test.
- **Position-swap pairwise comparisons.** Judges favour whichever output comes first. `compare --pairwise` judges both orders and averages.
- **Give the judge an exit.** A judge that cannot tell says UNKNOWN, and UNKNOWN is a miss. Conservative for regression, correct for gates.
- **Several judges beat one big judge** when a rubric is genuinely subjective. Run the same suite with two `--judge-model` values and compare.

## Building cases

- **Seed from real failures.** 20-50 simple cases drawn from things that actually went wrong make a strong first suite (`failure log`, then `failure convert`).
- **Deterministic first, model second.** Code asserts are free and reproducible; reserve `llm-rubric` and `llm-assert` for what a code check can't capture. A useful starting mix is roughly 60% deterministic weight and 40% model weight; quality-critical suites shift toward the model.
- **Balance should-do and should-not.** For every "does X" case, add a "does not do X where it shouldn't" case.
- **Make the task unambiguous.** If two domain experts would grade an output differently, the case is broken, not the agent.
- **Cover the distribution:** a few easy cases, several typical edge cases, a few genuinely hard or ambiguous ones.

## Running

- **Start small.** `-t 1 --case <id>` while authoring; full trials once the case is stable.
- **Five to ten cases minimum** before reading anything into a suite score; 20-30 to detect modest differences between variants.
- **Track over time.** Run regression suites after every change to instructions, agents or skills.

## Statistics

- Report the mean with its standard error and 95% confidence interval; `run` prints both.
- A difference between variants needs a paired test over the same cases. `compare` uses a paired permutation test (exact for 16 cases or fewer) and a sign test for pairwise wins.
- Pre-commit the minimum meaningful difference (`--min-delta`) before looking at results.
- Don't trust a score until you have read transcripts. Most surprising results are a broken case or a broken judge.
