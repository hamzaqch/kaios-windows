# Evals as the scientific method

Evals are the scientific method applied to prompts, instructions and models.

| Science phase | In evals |
|---|---|
| Goal | the behaviour a suite guards, its pass threshold |
| Observe | baseline run of the current prompt or model |
| Hypothesize | "variant B beats A because ..." |
| Experiment | `compare` with control and treatment on identical cases |
| Measure | scores, SEM, 95% CI, pass^k |
| Analyze | paired permutation test, pairwise wins, transcript reading |
| Iterate | refine the variant and rerun, or declare a winner |

## Rigor

- **Falsifiability.** Before comparing, answer: what result would show B is NOT better? If you can't say, you don't have a hypothesis yet. Example: "B is better at verification language" is falsified if B's mean on `verification` cases is not at least 5 points higher at p < 0.05.
- **Pre-commitment.** Success criteria, thresholds and `--min-delta` are fixed before the run. No moving goalposts after seeing data.
- **Plurality.** Consider A/B/C, not just A/B. A third variant guards against confirmation bias toward the first alternative and shows whether a different direction exists.
- **Bias countermeasures.** Position-swapped pairwise judging, a judge distinct from the generator, more than one judge for subjective rubrics, and significance required before declaring a winner.

## When to switch to /science

- Three or more iterations without improvement: step back and question the framing.
- Contradictory or confusing results.
- High stakes that justify a written record.
- The real question is "should we be testing something else entirely?"
