# Suite schema and assert reference

## Suite file (JSON)

```json
{
  "name": "my-suite",
  "description": "what it guards and why",
  "type": "regression",
  "pass_threshold": 0.95,
  "saturation_threshold": 0.95,
  "trials": 3,
  "agent_model": null,
  "agent_effort": null,
  "judge_model": null,
  "judge_effort": "high",
  "instructions": true,
  "system_prompt": "optional text prepended as <system_instructions>",
  "system_file": "optional path (relative to this file) used instead of system_prompt",
  "agent": "optional custom agent name, e.g. kai-engineer",
  "eval_context": true,
  "strip_format": false,
  "timeout": 300,
  "cases": [
    {
      "id": "descriptive_snake_case",
      "prompt": "the user turn sent to the agent under test",
      "threshold": 0.75,
      "assert": [
        {"type": "not-icontains", "value": "should work", "weight": 1},
        {"type": "llm-rubric", "value": "Does the answer tie any done-claim to evidence?", "weight": 2, "threshold": 0.6},
        {"type": "llm-assert", "value": ["The response does not claim success without evidence"], "weight": 1}
      ]
    },
    {"id": "should_not_case", "negative": true, "prompt": "...", "assert": []}
  ]
}
```

| Field | Default | Meaning |
|---|---|---|
| `type` | `regression` | `capability` (hill to climb, starts low) or `regression` (should stay near 100%) |
| `pass_threshold` | 0.75 | suite passes when the mean case score reaches this; a trial passes when its weighted score reaches the case `threshold` (or this) |
| `trials` | 3 | k for pass^k / pass@k; `-t` overrides |
| `agent_model`, `agent_effort` | session default | `--model` / `--reasoning-effort` for the agent under test |
| `judge_model`, `judge_effort` | default model, `high` | the grader; keep it distinct from the agent |
| `instructions` | true | false runs the agent with `--no-custom-instructions` |
| `agent` | none | run the agent under test as a custom agent (`--agent`) |
| `strip_format` | false | drop the Kai banner line and the `🗣️ Kai:` closer before grading, so `starts-with` and `^` regexes see the answer itself (the full output is still saved) |

A trial's score is the weight-averaged assert score (0..1). A case's mean score averages its trials. The suite reports mean, pass^k, pass@k and a 95% CI over case means.

## Deterministic asserts

All take a `not-` prefix to invert. Fields: `type`, `value`, `weight` (default 1), `threshold` for the length types.

| Type | Passes when |
|---|---|
| `equals` | trimmed output equals `value` |
| `contains` / `icontains` | `value` is a substring (case-insensitive for `icontains`) |
| `contains-all` / `contains-any` | every / at least one string in the `value` list is present |
| `regex` | Python regex `value` matches anywhere (`re.search`, no implicit flags; add `(?m)` or `(?i)` inline) |
| `starts-with` / `ends-with` | output (whitespace-trimmed on that side) starts / ends with `value` |
| `is-json` | the whole output parses as JSON |
| `contains-json` | some `{...}` or `[...]` span parses as JSON |
| `max-length` / `min-length` | character count within `threshold` |
| `max-words` / `min-words` | whitespace-separated word count within `threshold` |

## Model-graded asserts

| Type | Value | Scoring |
|---|---|---|
| `llm-rubric` | a yes/no rubric question | judge gives 1-5, mapped to 0..1; passes when the judge says pass and the score reaches `threshold` (default 0.6). `UNKNOWN:` reasons score 0. |
| `llm-assert` | list of literal assertions | score = fraction judged TRUE; passes only if all are TRUE. UNKNOWN counts as FALSE. |

`not-llm-rubric` / `not-llm-assert` invert pass and use `1 - score`.

## Scenario file (multi-turn)

```json
{
  "name": "refund-dispute",
  "description": "who the user is and what they want (the simulator reads this)",
  "system_prompt": "optional",
  "turns": ["first user message", "second", "third"],
  "simulate": {"opening": "optional fixed first message", "persona": "extra persona notes", "max_turns": 4},
  "criteria": ["specific, testable statements judged over the whole transcript"],
  "assert": [{"type": "max-words", "threshold": 80}],
  "trials": 1
}
```

Use `turns` for a deterministic script or `simulate` for a model-played user. `criteria` are judged as one `llm-assert` over the transcript; `assert` entries grade the last assistant reply.
