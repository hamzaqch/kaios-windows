---
name: teach-me
description: Shortcut for the teach skill. Runs an interactive tutorial on the current conversation topic, or a named one, one idea per step with a question after each. Use when the user says /teach-me, teach me, tutorial, or quiz me.
---
# teach-me

Run the `/teach` skill on the topic the user named, or on the current conversation if they named none.
