---
name: teach
description: "Interactive Socratic tutorial on whatever the current conversation is about, or a named topic: teaches beat by beat with an ASCII diagram per idea, asks exactly one question per beat, responds to the learner's actual answer, and finishes with a short quiz and a recap map. Use when the user says teach me, teach me this, tutorial, walk me through this interactively, explain this like a lesson, learn mode, quiz me, help me actually understand what we just did, I want to learn how this works. NOT FOR a plain written explanation with no dialogue (just answer), authored or published content, or a discovery interview that shapes a half-formed idea (use /isa)."
---
# Teach

Turns the current topic into a live tutorial. Each beat is one idea: a short spoken-style lead, a readable explanation, an ASCII diagram, and one question. The learner's answer drives the next beat. The session is done when the ideas have landed, not when the material has been printed.

## Workflow routing

| Request | Workflow |
|---|---|
| teach me, tutorial, walk me through, quiz me | `Workflows/Teach.md` |

## Gotchas

- **A beat ends at its question. Stop the turn there.** Answering your own question and continuing turns the tutorial back into a lecture, which is the failure this skill exists to prevent.
- **Respond to what the learner actually said.** Quote their words, then confirm, sharpen or correct. A canned "Correct!" teaches nothing, and a wrong answer gets named wrong, kindly.
- **The Kai closer line carries the question.** In the Kai response format the `🗣️ Kai:` closer is the beat's question, so it is the last thing the learner reads. Don't repeat the lesson in the closer.
- **Diagrams fit a terminal and the Copilot app.** 80 columns, about 20 lines, inside a code fence, carrying real structure (flow, hierarchy, comparison, timeline), never decoration.
- **Don't run the whole Algorithm per beat.** A tutorial turn is conversation; keep each one light and fast.

## Examples

- "teach me" after a debugging session on DNS: names the topic, maps 3-5 ideas, beat 1 shows the resolver chain and asks "which server actually holds the answer?", the learner answers, the next beat builds on it, then a 2-3 question quiz and a recap map.
- "/teach OAuth refresh tokens": teaches the named topic instead of the conversation's.
- "quiz me on what we just covered": skips the beats and runs the quiz protocol on the session's material.
