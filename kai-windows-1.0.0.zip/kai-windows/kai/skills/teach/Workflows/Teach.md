# Teach

Run an interactive tutorial on the current topic. The learner drives it by answering; it is done when the ideas have been talked through.

## Step 0: sufficiency check

The default topic is whatever this conversation has been working on. An explicit topic ("teach me OAuth refresh tokens") overrides it.

- Clear topic: announce it, list the 3-5 ideas you'll cover as a small concept map, and start beat 1.
- Several live candidates: ask one question, "Teach you X, or Y?"
- No topic and no argument: ask what to teach. Never invent a topic.

## Ideal state

A finished session looks like this, in whatever order the dialogue takes:

- Every concept got a beat with a visual: an ASCII diagram carrying real structure, not decoration.
- The learner answered a question on every beat, got a genuine response to their answer (quoting their words; confirm, sharpen or correct), and the next beat built on it.
- Misconceptions surfaced by wrong answers were re-taught from a different angle before moving on.
- A 2-3 question quiz tested the whole arc near the end, each answer responded to individually.
- The session closed with a recap and one final ASCII map of everything covered.
- The learner ended satisfied: "got it", "stop", or a clean quiz.

## Constraints

- 3-5 concepts per session. More than that: say so and offer a part two.
- One idea, one diagram, one question per beat. A beat that needs two diagrams is two beats.
- Difficulty tracks the answers: strong answers earn depth and edge cases; misses earn a simpler framing.
- Diagrams: code fence, at most 80 columns and about 20 lines.

## Output-format contract: one beat per turn

Every tutorial turn renders, in order:

1. **Lead line**: the teaching point in one or two plain conversational sentences, as if said aloud (when responding to an answer, the lead is the response: "Right, and here's the part most people miss...").
2. **Explanation**: two or three sentences that make the point precise.
3. **Diagram** in a code fence.
4. **Exactly one question**: a comprehension check, a prediction ("what happens if..."), or a quiz item.
5. **End the turn.** In the Kai format, put the question in the `🗣️ Kai:` closer so it is the last line, and keep the banner and sections minimal for tutorial turns.

## Quiz protocol

- Runs near the end of the arc, or immediately on "quiz me".
- 2-3 questions, one per turn, drawn from the beats actually taught. Prefer application over recall ("given X, what breaks?").
- Each answer gets an individual verdict and a one-line why. Two misses on the same concept: re-teach that beat differently before the next question.
- After the last answer: a recap, a final ASCII map of the whole arc, and an honest read on what stuck and what to revisit.

## End conditions

Stop and recap immediately when the learner says stop, done or got it. Finish normally after the quiz. Offer part two if concepts were deferred at Step 0.
