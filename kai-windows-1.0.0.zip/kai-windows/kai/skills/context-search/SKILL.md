---
name: context-search
description: "Search prior work to ground a request in what was already done, or to browse previous sessions on a topic: task ISAs, project ISAs, session logs and past Copilot sessions, ranked by relevance and recency, with date phrases like yesterday, last week or 2026-11-02. Shortcut for the cortex skill's recall workflow. Use when the user says /context-search, cs, search prior work, what did we do about X, find that session, previous sessions on X, remind me where we were, load context on X, or before continuing work that obviously started earlier. NOT FOR the curated knowledge notes (use /cortex search) or the web (use /research)."
argument-hint: "<topic or date phrase>"
---
# Context search

Thin router to the cortex skill's **Recall** workflow (`~/.copilot/skills/cortex/Workflows/Recall.md`). Run:

```
python ~/.copilot/skills/cortex/tools/cortex.py recall "<arguments>" --limit 10
```

If no arguments were given, ask what topic or time window to search, in one line.

**Standalone use** (the user asked to search or recall): show the ranked results, read the top hit's path, then close with "Context loaded on <topic>. Most recent: <title, date>. What would you like to do?"

**Paired with a request** (the user wants something that continues earlier work): run the search quietly first, read the best one or two paths, and answer the request grounded in them, naming the prior session or ISA you built on in one line.

No results means no evidence: say so plainly rather than reconstructing past work from guesswork.
