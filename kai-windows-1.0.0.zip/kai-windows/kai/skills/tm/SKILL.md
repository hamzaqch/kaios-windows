---
name: tm
description: "Shortcut for /teach: an interactive Socratic tutorial on the current conversation topic or a named one, one idea per beat with an ASCII diagram and exactly one question, then a short quiz and a recap map. Use when the user types /tm, tm <topic>, or says teach me, tutorial, quiz me. NOT FOR a plain written explanation with no dialogue (just answer)."
argument-hint: "[topic]"
---
# tm: teach shortcut

Thin alias. Read `$HOME/.copilot/skills/teach/SKILL.md` and run its Teach workflow (`$HOME/.copilot/skills/teach/Workflows/Teach.md`) on the arguments.

If no arguments were given, the topic is whatever this conversation has been working on; on a fresh session with no topic, the workflow asks.
