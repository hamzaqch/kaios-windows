"""isdown.py - is a site down for everyone, or just you? Stdlib only.

Probes the site from several vantage points and compares:
  1. LOCAL  - direct HTTP request from this machine
  2. REMOTE - downforeveryoneorjustme.com public API (their vantage point)
  3. --deep - check-host.net multi-node sweep (up to 7 nodes worldwide)

Usage:
  python isdown.py <domain-or-url> [--deep] [--json] [--timeout <seconds>]

Exit codes:
  0 = up for everyone (or mixed/partial)
  1 = down for everyone
  2 = down just for you (local fails, the world reaches it)
  3 = usage / probe error (unreachable locally and no checker answered)

Verdict rules:
  - A checker node that never reports is "no answer", NOT down; it is excluded
    from verdict math (counting pending nodes as down produced false
    "regional outage" verdicts).
  - A single down node among 3+ reporting up nodes is checker noise: shown in
    the table, but it does not flip the verdict.
"""
import json
import re
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

UA = "Mozilla/5.0 (compatible; isdown-cli)"
HOST_RE = re.compile(r"^([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$", re.I)
IPV4_RE = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")

EXIT = {"up-everywhere": 0, "down-everywhere": 1, "just-you": 2, "mixed": 0, "unknown": 3}

USAGE = """Usage: isdown <domain-or-url> [--deep] [--json] [--timeout <seconds>]

Checks whether a site is down for everyone or just you.
  --deep     Also sweep up to 7 nodes worldwide via check-host.net
  --json     Machine-readable output
  --timeout  Per-probe timeout in seconds (default 10)"""


def check(vantage, status, detail):
    return {"vantage": vantage, "status": status, "detail": detail}


def parse_args(argv):
    """-> (target, flags:set, timeout:float) or raises ValueError(message, exit_code)."""
    flags, positional, timeout = set(), [], 10.0
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--timeout":
            if i + 1 >= len(argv):
                raise ValueError("--timeout needs a number of seconds")
            try:
                timeout = float(argv[i + 1])
                if timeout <= 0:
                    raise ValueError
            except ValueError:
                raise ValueError("--timeout must be a positive number")
            i += 2
            continue
        if a.startswith("--"):
            flags.add(a)
        else:
            positional.append(a)
        i += 1
    if "--help" in flags or "-h" in positional:
        return None, flags, timeout
    if len(positional) != 1:
        raise ValueError("expected exactly one domain or URL")
    return positional[0], flags, timeout


def normalize(raw):
    """-> (url, hostname). Raises ValueError on garbage."""
    url = raw if re.match(r"^https?://", raw, re.I) else f"https://{raw}"
    try:
        host = urllib.parse.urlsplit(url).hostname or ""
    except ValueError:
        host = ""
    if not (HOST_RE.match(host) or IPV4_RE.match(host) or ":" in host):
        raise ValueError(f"Invalid domain or URL: {raw} (parsed hostname: {host or 'none'})")
    return url, host


def http_get(url, timeout, accept=None):
    """-> (status_code, body_bytes). HTTP error statuses are returned, not raised."""
    headers = {"User-Agent": UA}
    if accept:
        headers["Accept"] = accept
    req = urllib.request.Request(url, headers=headers)
    ctx = ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            return r.status, r.read(1_000_000)
    except urllib.error.HTTPError as e:
        try:
            body = e.read(100_000)
        except Exception:
            body = b""
        return e.code, body


def err_text(exc):
    reason = getattr(exc, "reason", None)
    return str(reason or exc) or exc.__class__.__name__


def probe_local(url, timeout):
    start = time.monotonic()
    try:
        code, _ = http_get(url, timeout)
        ms = int((time.monotonic() - start) * 1000)
        return check("Local (this machine)", "up" if code < 500 else "down", f"HTTP {code} · {ms}ms")
    except Exception as e:
        return check("Local (this machine)", "down", err_text(e))


def probe_remote(host, timeout):
    vantage = "downforeveryoneorjustme.com"
    try:
        code, body = http_get(
            f"https://downforeveryoneorjustme.com/api/httpcheck/{urllib.parse.quote(host)}", timeout + 5)
        if code != 200:
            return check(vantage, "no-answer", f"checker API returned HTTP {code}")
        data = json.loads(body.decode("utf-8", "replace"))
        return check(vantage, "down" if data.get("isDown") else "up", f"HTTP {data.get('statusCode')}")
    except Exception as e:
        return check(vantage, "no-answer", err_text(e))


def interpret_deep(nodes, results):
    """Turn check-host.net node info + results into check rows. Pure; unit-tested."""
    out = []
    for node, info in nodes.items():
        info = info or []
        vantage = ", ".join(str(x) for x in info[1:3] if x) or node
        entry = (results.get(node) or [None])[0] if isinstance(results.get(node), list) else None
        if not isinstance(entry, list) or not entry:
            out.append(check(vantage, "no-answer", "node did not report in time"))
            continue
        ok = entry[0] == 1
        secs = entry[1] if len(entry) > 1 and isinstance(entry[1], (int, float)) else None
        if ok:
            code = entry[3] if len(entry) > 3 else "?"
            ms = f" · {int(round(secs * 1000))}ms" if secs is not None else ""
            out.append(check(vantage, "up", f"HTTP {code}{ms}"))
        else:
            msg = entry[2] if len(entry) > 2 and entry[2] else "unreachable"
            out.append(check(vantage, "down", str(msg)))
    return out


def probe_deep(url, timeout, sleep=time.sleep):
    q = urllib.parse.urlencode({"host": url, "max_nodes": 7})
    code, body = http_get(f"https://check-host.net/check-http?{q}", timeout + 5, accept="application/json")
    if code != 200:
        raise RuntimeError(f"check-host.net returned HTTP {code}")
    start = json.loads(body.decode("utf-8", "replace"))
    request_id, nodes = start.get("request_id"), start.get("nodes") or {}
    results = {}
    for _ in range(10):  # poll ~20s; unreported nodes stay null
        sleep(2)
        code, body = http_get(f"https://check-host.net/check-result/{request_id}", timeout,
                              accept="application/json")
        if code == 200:
            try:
                results = json.loads(body.decode("utf-8", "replace")) or {}
            except ValueError:
                results = {}
            if results and all(v is not None for v in results.values()):
                break
    return interpret_deep(nodes, results)


def verdict_of(local, world):
    """-> (verdict, note). Pure; unit-tested."""
    reporting = [c for c in world if c["status"] != "no-answer"]
    up = sum(1 for c in reporting if c["status"] == "up")
    down = len(reporting) - up
    local_up = local["status"] == "up"
    if not reporting:
        if local_up:
            return "up-everywhere", "no external checker answered - verdict from local probe only"
        return "unknown", None
    if not local_up:
        if up == 0:
            return "down-everywhere", None
        return "just-you", (f"{down} external node(s) also failed" if down else None)
    if down == 0:
        return "up-everywhere", None
    if down == 1 and up >= 3:
        return "up-everywhere", "1 checker node failed - single-node noise, not an outage signal"
    if up == 0:
        return "mixed", "up for you but no external node reaches it - geo-block or local cache?"
    return "mixed", None


HEADLINE = {
    "up-everywhere": "[UP] {d} is UP for everyone",
    "down-everywhere": "[DOWN] {d} is DOWN for everyone (not just you)",
    "just-you": "[JUST YOU] {d} is down JUST FOR YOU - the rest of the internet reaches it",
    "mixed": "[PARTIAL] {d} is partially reachable - possible regional outage",
    "unknown": "[UNKNOWN] {d} unreachable locally and no checker answered - can't tell if it's the site or your connection",
}


def render_text(domain, verdict, note, checks, counts, deep_error):
    lines = [HEADLINE[verdict].format(d=domain), ""]
    width = max(len(c["vantage"]) for c in checks) + 2
    lines.append(f"   {'VANTAGE POINT'.ljust(width)} {'RESULT'.ljust(10)} DETAIL")
    for c in checks:
        label = "no answer" if c["status"] == "no-answer" else c["status"]
        lines.append(f"   {c['vantage'].ljust(width)} {label.ljust(10)} {c['detail']}")
    parts = [f"{counts['up']} up", f"{counts['down']} down"]
    if counts["noAnswer"]:
        parts.append(f"{counts['noAnswer']} no answer")
    lines += ["", f"   Checked {counts['checked']} vantage points: {' · '.join(parts)}"]
    if note:
        lines.append(f"   Note: {note}")
    if deep_error:
        lines.append(f"   Note: deep sweep failed ({deep_error})")
    return "\n".join(lines)


def main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    try:
        target, flags, timeout = parse_args(argv)
    except ValueError as e:
        sys.stderr.write(f"{e}\n\n{USAGE}\n")
        return 3
    if target is None:
        print(USAGE)
        return 0
    try:
        url, domain = normalize(target)
    except ValueError as e:
        sys.stderr.write(f"{e}\n")
        return 3

    box = {}

    def run(key, fn, *a):
        try:
            box[key] = fn(*a)
        except Exception as e:  # only the deep sweep raises
            box[key] = err_text(e)

    threads = [threading.Thread(target=run, args=("local", probe_local, url, timeout)),
               threading.Thread(target=run, args=("remote", probe_remote, domain, timeout))]
    if "--deep" in flags:
        threads.append(threading.Thread(target=run, args=("deep", probe_deep, url, timeout)))
    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(timeout + 45)

    local = box.get("local") or check("Local (this machine)", "down", "probe did not finish")
    remote = box.get("remote") or check("downforeveryoneorjustme.com", "no-answer", "probe did not finish")
    deep_out = box.get("deep")
    deep_error = deep_out if isinstance(deep_out, str) else None
    if "--deep" in flags and deep_out is None:
        deep_error = "sweep did not finish"
    deep = deep_out if isinstance(deep_out, list) else []

    world = [remote] + deep
    verdict, note = verdict_of(local, world)
    checks = [local] + world
    counts = {"checked": len(checks),
              "up": sum(1 for c in checks if c["status"] == "up"),
              "down": sum(1 for c in checks if c["status"] == "down"),
              "noAnswer": sum(1 for c in checks if c["status"] == "no-answer")}
    if "--json" in flags:
        print(json.dumps({"domain": domain, "url": url, "verdict": verdict, "note": note, "counts": counts,
                          "checks": checks, "deepError": deep_error}, indent=2, ensure_ascii=False))
    else:
        print(render_text(domain, verdict, note, checks, counts, deep_error))
    return EXIT[verdict]


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
