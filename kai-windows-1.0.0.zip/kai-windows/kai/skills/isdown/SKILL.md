---
name: isdown
description: "Check whether a website is down for everyone or just you: a local HTTP probe plus the downforeveryoneorjustme public API, with --deep for a sweep from up to 7 check-host.net nodes worldwide. Returns a verdict line (up everywhere, down everywhere, down just for you, partial/regional, unknown), per-vantage evidence, and a meaningful exit code. Use when the user says is X down, isdown, is it just me, site not loading, can't reach, website down, outage check, is GitHub down, check if a site is up, or regional outage. NOT FOR monitoring your own services over time or load testing."
argument-hint: "<domain-or-url> [--deep] [--json] [--timeout <seconds>]"
---
# isdown

One command answers "is it the site or is it me?" by comparing what this machine sees with what outside checkers see.

```
python ~/.copilot/skills/isdown/tools/isdown.py <domain-or-url> [--deep] [--json] [--timeout <seconds>]
```

| Exit | Verdict |
|---|---|
| 0 | up for everyone, or partially reachable (mixed) |
| 1 | down for everyone |
| 2 | down just for you |
| 3 | usage error, or unreachable locally with no checker answering |

**Done looks like:** the reply leads with the verdict line, then the per-vantage table (with `--deep`, every node row), then the one most likely next step for that verdict.

## Reading the verdict

- **Just you:** the world reaches it and you don't. Suggest the usual local culprits in likelihood order: DNS cache (`ipconfig /flushdns` on Windows), VPN or proxy, the hosts file (`C:\Windows\System32\drivers\etc\hosts`), corporate firewall, then the router. Offer `--deep` if only one outside checker answered.
- **Down everywhere:** it is the site. Point to the service's status page if one is commonly known, and stop troubleshooting the local machine.
- **Partial / mixed:** possibly a regional outage, CDN edge problem or geo-block. Run `--deep` if it wasn't already, and name which regions failed.
- **Unknown:** this machine has no connectivity to the site and no checker answered. Check general connectivity first (can it reach any other site?).

## Gotchas

- **A node that never reports is "no answer", not "down".** Counting pending check-host.net nodes as down produced false regional-outage verdicts; the tool excludes them from the math and shows them as `no answer`.
- **One failing node among three or more healthy ones is noise.** It stays in the table but doesn't flip the verdict.
- **HTTP 4xx counts as up.** A 403 or 404 means the server answered. Only 5xx and connection failures count as down.
- **`--deep` takes up to ~25 seconds** because check-host.net results arrive asynchronously. Run without it first unless the user asked for a worldwide view.
- **Corporate TLS interception** can make the local probe fail with a certificate error while browsers work. If the local detail mentions `CERTIFICATE_VERIFY_FAILED`, say that the local result is a TLS-inspection artifact, not proof of an outage.
