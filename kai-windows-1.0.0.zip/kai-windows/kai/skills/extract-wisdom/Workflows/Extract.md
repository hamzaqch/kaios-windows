# Extract workflow

Extract dynamic, content-adaptive wisdom from any content source.

## Input sources

| Source | Method |
|--------|--------|
| YouTube or podcast URL | Get a transcript (see below) |
| Article URL | Web fetch the page |
| File path | `view` the file |
| Pasted text | Use directly |

### Getting a transcript

1. Look for a published transcript: the creator's show-notes page, a podcast transcript page, or an accompanying article. Web fetch it.
2. If the user has a local transcript tool installed (for example a subtitle downloader), run it and read the output file.
3. Otherwise ask the user to paste the transcript (YouTube: "...more" → "Show transcript" → copy). Never guess content from the title or description.

For long content, save the transcript to a working file and chunk it. Don't extract from a 3-hour transcript in one pass. For very long sources, fan out parallel `task` calls, one per chunk, each returning candidate bullets with the exact quote that supports them, then merge, dedupe and keep the strongest material.

## The deliverable

Get the full content via the method above, then produce the extraction defined in `SKILL.md`:

- Sections named specifically for THIS content (the depth-level table sets the count), each with at least 3 Level-3 bullets.
- Bullets that sound spoken, carry the specific detail or quote, and preserve any contrarian take undiluted.
- Closing sections per the depth-level table.

Output in the format from `SKILL.md`, and pass its Quality check before delivering.
