---
name: extract-wisdom
description: "Content-adaptive wisdom extraction from videos, podcasts, interviews and articles. Reads the content first, detects which wisdom domains are actually present, and builds custom sections around them instead of fixed headers, at five depth levels (Instant, Fast, Basic, Full, Comprehensive) with mandatory contrarian takes, a one-sentence takeaway, an If You Only Have 2 Minutes list and references worth following. Use when the user says extract wisdom, analyze this video, analyze this podcast, extract insights, key takeaways, what's interesting in this, summarize this interview, or distill this content. Not for the static fixed-template extract_wisdom pattern (use /fabric) or for research synthesis across many sources (use the research skill)."
argument-hint: "<url | file | pasted text> [instant|fast|basic|full|comprehensive]"
---

# Extract wisdom

## What it does

Pulls the best ideas out of videos, podcasts, interviews and articles. It reads the content first, detects what kinds of wisdom are actually in there, then builds custom sections around what it finds instead of forcing the same headers every time. Five depth levels run from Instant to Comprehensive. Output always ends (at Full depth) with a one-sentence takeaway, an "If You Only Have 2 Minutes" list, and references worth following.

## The problem

Static extraction templates force every piece of content into the same boxes (IDEAS, QUOTES, HABITS, FACTS), so a security talk and a business podcast come out looking identical and the real gems get flattened into generic bullets. The output reads like a book report, not like a smart friend telling you the parts that made them stop. This skill adapts its sections to the content and writes the points the way you'd actually say them out loud, so the contrarian takes and first-time revelations survive instead of getting watered down.

## How it works

Instead of static sections, the skill detects what wisdom domains exist in the content and builds custom sections around them.

A programming interview gets "Programming Philosophy" and "Developer Workflow Tips." A business podcast gets "Contrarian Business Takes" and "Money Philosophy." A security talk gets "Threat Model Insights" and "Defense Strategies." The sections adapt because the content dictates them.

## When to use

- Analyzing YouTube videos, podcasts, interviews, articles
- The user says "extract wisdom", "what's interesting in this", "key takeaways"
- Processing any content where you want to capture the best stuff
- When standard extraction patterns miss the gems

## Depth levels

Default is **Full** if no level is specified.

| Level | Sections | Bullets/section | Closing sections | When |
|-------|----------|-----------------|------------------|------|
| **Instant** | 1 | 8 | None | Quick hit. One killer section. |
| **Fast** | 3 | 3 | None | Skim in 30 seconds. |
| **Basic** | 3 | 5 | One-Sentence Takeaway only | Solid overview without the deep cuts. |
| **Full** | 5-12 | 3-15 | All three | The default. Complete extraction. |
| **Comprehensive** | 10-15 | 8-15 | All three + Themes & Connections | Maximum depth. Nothing left behind. |

**How to invoke:** "extract wisdom (fast)", "extract wisdom at comprehensive level", or just "extract wisdom" for Full.

**Comprehensive extras:**
- **Themes & Connections** closing section: 3-5 throughlines that connect multiple sections. These are the deeper patterns the speaker may not even realize they're revealing, never summaries.
- Prioritize breadth. Every significant wisdom domain gets its own section.
- No merging sections to save space. If the content supports 15 sections, use 15.

**All levels use the same voice, tone rules and quality standards.** Only the structure changes. An Instant extraction should hit just as hard per bullet as a Comprehensive one.

## Workflow routing

| Workflow | Trigger | File |
|----------|---------|------|
| **Extract** | "extract wisdom from", "analyze this", a YouTube or article URL, a file, pasted text | `Workflows/Extract.md` |

## Tone rules (critical)

If the user's own section of `~/.copilot/copilot-instructions.md` ("Your rules") defines a writing voice, that voice wins. Otherwise, the bullets should sound like the user telling a friend about it over coffee: actual spoken observations, never compressed info nuggets or clever one-liners.

**Three levels. We're aiming for Level 3.**

**Level 1 (bad: documentation):**
- The speaker discussed the importance of self-modifying software in the context of agentic AI development
- It was noted that financial success has diminishing returns beyond a certain threshold
- The distinction between "vibe coding" and "agentic engineering" was emphasized as meaningful

**Level 2 (better, but still "smart bullet points"):**
- He built self-modifying software basically by accident — just made the agent aware of its own source code
- Money has diminishing returns. A cheeseburger is a cheeseburger no matter how rich you are.
- "Vibe coding is a slur" — he calls it agentic engineering, and only does vibe coding after 3am

**Level 3 (yes: conversational, the user's voice):**
- He wasn't trying to build self-modifying software. He just let the agent see its own source code and it started fixing itself.
- Past a certain point, money stops mattering. A cheeseburger is a cheeseburger no matter how rich you are.
- He calls vibe coding a slur. What he does is agentic engineering. The vibe coding only happens after 3am, and he regrets it in the morning.

**The difference between Level 2 and 3:** Level 2 is compressed info with em-dashes. Level 3 is how you'd actually SAY it. Varied sentence lengths. Letting a thought breathe. Being clear and direct and a little bit personal instead of trying to be clever.

**Key signals of Level 3:**
- Reads naturally when spoken aloud
- Varied sentence lengths, some short, some longer
- Understated; lets the content carry the weight
- Uses periods, not em-dashes, to let ideas land
- Feels opinionated ("Past a certain point, money stops mattering"), more than informational
- The reader should think "I want to watch this", not "I got the summary"

## Bullets: the voice contract

The one-line target: sections specific to the content, bullets that sound spoken. The three levels above are the standard, and every bullet lands at Level 3. A good bullet has these properties:

- **Spoken, not summarized.** Reads like you telling a friend what you just watched, never a press release or a compressed tweet.
- **Specific over vague.** Carries the actual detail, quote or number ("a cheeseburger is a cheeseburger no matter how rich you are"), never "he talked about money." Use the speaker's own words when they're already perfect.
- **Insight over inventory.** "He picked a language he doesn't even like because the ecosystem fits agents" beats "he uses Go for CLIs." A contradiction or reversal is the wisdom.
- **8-16 words, varied length.** Mix short and medium; periods between thoughts, not em-dashes. Verbatim quotes are exempt.
- **Human moments count.** Burnout, doubt, something that moved the speaker: that's wisdom too, even when it isn't "technical."

**Contrarian takes are mandatory.** If the speaker has a genuinely hot take ("screw MCPs", "X is dead", "Y is overhyped"), it MUST appear, undiluted. Spicy takes are the most memorable and shareable material. Losing one is a failed extraction, including between drafts.

## Sections: adapt to the content

Sections are named for THIS content, never from a fixed list. A programming interview gets "Programming Philosophy"; a business podcast gets "Money Philosophy"; a security talk gets "Threat Model Insights." Name them like a magazine editor ("The Death of 80% of Apps" beats "Technology Predictions"). The name should make the reader curious.

- Section count follows the depth-level table.
- Every section needs at least 3 strong bullets (except Fast, where 3 tight bullets IS the section). Can't find 3? Merge it into a related section.
- Include "Quotes That Hit Different" when the content has quotable moments; include "First-Time Revelations" when there are genuinely new ideas.
- No inventory sections. A bare list of facts isn't wisdom. Go deeper on why the choices matter, or merge into a philosophy section.
- Don't split what belongs together. Don't drop your best material between drafts: a spicy take or stunning moment found in an early pass MUST survive to the final.

## Closing sections

| Level | Closing sections |
|-------|------------------|
| **Instant** | None |
| **Fast** | None |
| **Basic** | One-Sentence Takeaway only |
| **Full** | One-Sentence Takeaway + If You Only Have 2 Minutes + References & Rabbit Holes |
| **Comprehensive** | All three above + Themes & Connections |

**One-Sentence Takeaway**: the single most important thing from the entire piece, in 15-20 words.

**If You Only Have 2 Minutes**: the 5-7 absolute must-know points. The cream of the cream.

**References & Rabbit Holes**: people, projects, books, tools and ideas mentioned that are worth following up on, with brief context for each.

**Themes & Connections** (Comprehensive only): 3-5 throughlines that connect multiple sections. The deeper patterns the speaker may not realize they're revealing. Synthesis, not summary.

## Output format

```markdown
# EXTRACT WISDOM: {Content Title}
> {One-line description of what this is and who's talking}

---

## {Dynamic Section 1 Name}

- {bullet}
- {bullet}
- {bullet}

## {Dynamic Section 2 Name}

- {bullet}
- {bullet}

[... more dynamic sections ...]

---

## One-Sentence Takeaway

{15-20 word sentence}

## If You Only Have 2 Minutes

- {essential point 1}
- {essential point 2}
- {essential point 3}
- {essential point 4}
- {essential point 5}

## References & Rabbit Holes

- **{Name/Project}** — {one-line context of why it's worth looking into}
- **{Name/Project}** — {context}
```

## Quality check

Before delivering output, verify:
- [ ] Sections are specific to THIS content, never generic
- [ ] No bullet sounds like it was written by a committee
- [ ] Every bullet has a specific detail, quote or insight, never a vague summary
- [ ] Section names are conversational and headline-worthy (no category labels)
- [ ] Section count matches depth level (Instant=1, Fast/Basic=3, Full=5-12, Comprehensive=10-15)
- [ ] Closing sections match depth level (see Closing sections table)
- [ ] No bullet starts with "The speaker" or "It was noted that"
- [ ] No more than 3 bullets per section start with "He" or the speaker's name
- [ ] No bullet exceeds 25 words
- [ ] No inventory sections (just listing facts without insight)
- [ ] "If You Only Have 2 Minutes" bullets are each under 20 words
- [ ] Reading the output makes you want to consume the original content

## Running on Copilot

- Articles: web fetch the URL. Files: `view` the file. Pasted text: use it directly.
- YouTube and podcasts: get a real transcript first (see `Workflows/Extract.md`). Never extract from a title or description.
- For a long transcript, save it to a working file and process it in chunks; for a very long one, run parallel `task` calls (one per chunk, each returning candidate bullets with quotes and timestamps) and merge them yourself so the best material survives.

## Gotchas

- **Content-adaptive sections mean output structure varies by input type.** Don't expect identical output format for a podcast and an article.
- **Get the transcript before extracting.** A YouTube URL alone is not content.
- **Long content needs chunking.** Don't try to extract wisdom from a 3-hour podcast transcript in one pass.

## Examples

**Example 1: YouTube interview**
```
User: "extract wisdom from this security researcher interview" + URL
→ Gets the transcript (published transcript, local tool, or the user pastes it)
→ Content-adaptive extraction (interview format)
→ Returns: dynamic sections, contrarian takes, closing sections at Full depth
```

**Example 2: Article**
```
User: "extract the key insights from this blog post (fast)"
→ Web fetches the article
→ 3 sections x 3 bullets, no closing sections
```
