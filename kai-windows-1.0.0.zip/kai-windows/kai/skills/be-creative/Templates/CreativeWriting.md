# Creative Writing Prompt Template

Use when writing a prompt that asks another model or agent for stories, poems, dialogue or other creative prose. Replace `{{type}}` and `{{request}}`.

```markdown
## Instructions

Maximum creativity. Before writing, explore privately and widely:
- several unusual perspectives, voices and genres
- every assumption about format, structure and content, questioned
- connections across unrelated domains and artistic traditions
- low-probability but fascinating possibilities, well past the first 3-5 obvious approaches
- what would make this unique, memorable and emotionally resonant

Generate 5 candidate directions (p < 0.10 each), then write the {{type}} from the
most genuinely novel one. Aim for something distinct, surprising and
sophisticated, with unusual metaphors, perspectives and structures, and
fully coherent.

## Request

{{request}}
```

**`{{type}}` values:** short story, poem, opening paragraph, character description, plot twist, dialogue exchange, world-building concept.

## Genre-blend variant

```markdown
## Instructions

Explore privately how {{genre_1}} and {{genre_2}} could genuinely integrate:
the core elements of each, the thematic resonances between them, and entry
points that make both authentically present rather than surface decoration.
Skip the familiar mashup tropes. Then create the story concept from your most
interesting discovery.

## Request

{{request}}
```

## Levers that raise creativity

- **Name the cliche to route around it:** "a poem about the passage of time, avoiding clocks, rivers and seasons."
- **Specify an unusual viewpoint:** "from the viewpoint of..."
- **Request a device:** synesthesia, an unreliable narrator, second person.
- **Impose a formal constraint:** reverse chronology, a lipogram, a fixed word count.
- **Combine genres:** "a noir detective story in a fantasy world."

## Example

```markdown
## Instructions
[instructions block above, with {{type}} = short story]

## Request
Write a 300-word short story about a person who discovers they can see one
minute into the future.
```
