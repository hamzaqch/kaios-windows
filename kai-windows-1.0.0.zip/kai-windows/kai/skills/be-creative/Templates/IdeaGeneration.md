# Idea Generation Prompt Template

Use when writing a brainstorming prompt for another model or agent, or as your own private checklist. Replace `{{problem}}`, and swap in the analysis questions for the problem type.

```markdown
## Instructions

### Analysis
Before generating ideas, examine the problem privately:
- What assumptions underlie the conventional solutions?
- What would a solution from a completely different industry look like?
- What if the problem were inverted or reframed entirely?
- What counter-intuitive or paradoxical approaches might work?
- What would a 10x (not 10%) better solution look like?
- What can't we see from our current perspective?

### Ideation
Generate 5 diverse approaches (p < 0.10 each) that challenge the assumptions
you found, draw from different domains, and favor brilliant and interesting
over safe and conventional. Develop each with its rationale. Present the
strongest first, with why it beats the obvious answer.

## Problem

{{problem}}
```

## Analysis question sets by problem type

**Business strategy**
- What industry assumptions are we taking for granted?
- What would competitors never do, and why might that be valuable?
- What asymmetric advantages could we use?
- Include at least one "dangerous" idea that could disrupt.

**Problem solving**
- What is the root cause versus the symptom?
- Could we eliminate the problem instead of solving it? What would prevention look like?
- How could we flip the problem into an advantage?
- What second-order effects are we missing?
- Include both high-tech and low-tech answers, and one that feels too simple.

**Product innovation**
- Which user need is the product actually serving, and what else could serve it?
- What would this look like for a user who hates the current category?

## Domain add-on lines

- **Technical:** consider both cutting-edge technology and creative use of existing technology.
- **Social or process:** focus on changing behavior and incentives, not adding features.
- **Creative projects:** prioritize emotional impact and unexpected experiences.
- **Business models:** challenge revenue-model assumptions; consider unconventional value exchanges.

## Reframing levers

- "How might we..." instead of "We need to..."
- Add a constraint: "...without increasing budget", "...using only existing resources".
- Reverse it: "How could we make this worse?", then invert each answer.
- Cross-pollinate: "What would a hospital, a game studio, an airline do?"
- Rescale: "How would this work at 10x scale, or with 1/10 the resources?"

## Evaluating the ideas

Score the set on: most novel, most viable soonest, most impactful, highest variance (could fail or win spectacularly), and best hybrid of two or more ideas. Well-developed ideas beat long lists of shallow ones.
