---
name: be-creative
description: "Divergent ideation and corpus expansion via Verbalized Sampling. Generates several internally diverse, low-probability candidates and surfaces the strongest, or expands a small seed corpus into a large, diverse dataset for evals and test sets. Use when the user says be creative, brainstorm, think outside the box, divergent ideas, creative solutions, maximum creativity, radically different, tree of thoughts, name this, creative angle, novel algorithm or architecture idea, expand this corpus, synthetic data, generate diverse examples, or create a test set from these. Not for tasks with one objectively correct answer."
---
# Be Creative

Ask a model for "a creative idea" and you get the most probable idea: the safe, already-seen one. Alignment training makes outputs collapse toward the mode (typicality bias). **Verbalized Sampling** (Zhang et al. 2025, arXiv:2510.01171) counters this by asking for several candidates *with their probabilities* and requiring each to come from the low-probability tail (p < 0.10). The paper reports a 1.6-2.1x diversity gain with quality held or improved, under benchmark conditions; real-world lift varies by prompt type.

The core move, used by every workflow below: **generate 5 internally diverse candidates (p < 0.10 each) in private reasoning, then output the single strongest.** Diversity comes from the sampling; quality comes from developing each candidate with real reasoning before choosing. The user sees one polished answer selected from a wide distribution, unless they ask to see the spread.

If your runtime has no private reasoning channel, list the five candidates in one line each, then deliver the chosen one in full.

## What makes the five genuinely diverse

- Each candidate breaks a *different* assumption of the request. Five variations on one idea is a failure.
- At least one candidate imports a mechanism from an unrelated domain. Creativity lives at domain intersections.
- Ask of each: what would the conventional answer be, and how does this one escape it?
- Balance novelty with coherence: creative, but comprehensible and usable against the real constraints.

## Workflow routing

| Request | Mode |
|---|---|
| "be creative", most creative tasks, one polished answer | Standard (below) |
| "maximum creativity", "radically different", "experimental" | Maximum (below) |
| "brainstorm", "ideas for", "solve this problem" | Idea generation (below) |
| creativity judged by a domain's own bar (art, business, product) | Domain-specific (below) |
| complex, multi-factor problem; several paths must be weighed | Tree of thoughts (below) |
| algorithms, architectures, data structures, protocols, performance | `Workflows/TechnicalCreativity.md` |
| expand 5-20 seed examples into an N-example dataset | `Workflows/SyntheticDataExpansion.md` |

Prompt skeletons for creative writing and structured brainstorming live in `Templates/CreativeWriting.md` and `Templates/IdeaGeneration.md`. Use them when you are writing a prompt for another model or agent rather than answering directly.

## Standard

Generate 5 candidates (p < 0.10 each), develop each enough to judge it, output the strongest, polished.

Done when: the five are genuinely distinct, not rephrasings, and the surfaced answer is the least obvious of the five that still fully satisfies the request.

## Maximum

Same move, pushed further into the tails. Every candidate must be non-formulaic, and the five must span different formats, framings or genres. Elaborate the chosen direction fully rather than just naming it.

Done when: no candidate resembles a stock or cliched answer, and the chosen one is developed, not sketched.

## Idea generation

Generate 5 solution approaches (p < 0.10 each), each resting on a different underlying assumption. Useful levers: invert the problem, borrow from another industry, eliminate the problem instead of solving it, ask what a 10x (not 10%) answer looks like, ask what competitors would never do. Present the strongest with a short reason it beats the conventional answer.

Done when: the approaches rest on different assumptions, at least one comes from a domain unrelated to the problem's home field, and the presented one says why it beats the obvious answer.

After presenting, if the user wants to pick among several, score them on: most novel, most viable soonest, most impactful, highest variance (could fail or win big), and best hybrid of two.

## Domain-specific

Run the standard move, but select against the domain's own success criteria instead of generic novelty: emotional impact and coherence for art; scalability, customer behavior and sustainability for business; adoption and simplicity for product.

Done when: the candidates break a real convention of the named domain, and the selection is justified against that domain's criteria, not "most creative".

## Tree of thoughts

Branch into 3-5 fundamentally different strategies, expand the promising ones into variations, evaluate every path on both creativity and viability, then synthesize the strongest elements into one solution.

Done when: the branches are different strategies, not variants of one; the final solution names which branches it draws from and why; and the synthesis is both novel and practical against the stated constraints.

## Delegation

For high-stakes ideation, an independent second spread reduces your own mode collapse. Use the `task` tool, or dispatch to `@kai-architect` with the same request and constraints, then merge both spreads before selecting. Send the finalist to `@kai-reviewer` for an adversarial check on viability if it will be built.

## Examples

- "Write a story about a bear." The modal answer is forest, honey, hibernation. The tail holds a noir detective bear, a bear as unreliable narrator, a story told in reverse chronology.
- "Ideas for improving team communication." The modal answer is chat tools, meetings, email rules. The tail holds async video diaries, deliberate silence windows, AI-written daily digests that replace status meetings.
- "Name this security tool." Explore metaphors from unrelated fields (biology, navigation, folklore), wordplay, and invented words; present the best with its reasoning.

## Gotchas

- This is single-pass divergent ideation. For multi-round evolutionary ideation, run this skill repeatedly and feed survivors back in as seeds.
- Self-reported probabilities are unreliable. Judge diversity by how different the candidates actually are, not by the numbers the model attached.
- No lift on factually constrained tasks. When there is one right answer, answer it.
