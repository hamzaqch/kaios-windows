# TechnicalCreativity Workflow

**When to use:** engineering creativity: algorithms, system architectures, data structures, protocols, performance optimizations. For writing, naming or marketing angles, use the main skill's modes instead.

Technical creativity is constrained creativity. The candidates must be diverse, but every one must also survive hard constraints, so constraints and success criteria are part of the input, not an afterthought.

## Inputs

- **Problem:** the technical challenge, stated concretely.
- **Constraints:** hard (latency, throughput, memory, scale, compatibility) and soft (cost, maintainability, timeline).
- **Success criteria:** measurable outcomes.

If any of these is missing and cannot be inferred from the codebase or conversation, ask before generating.

## Method

Generate 5-10 mutually distinct technical solutions using Verbalized Sampling (each from the low-probability tail). Span these regions so the set does not collapse onto one design:

- radical rethinks of the problem framing
- hybrid paradigms combining two known approaches
- counter-intuitive optimizations (do more work somewhere to do far less elsewhere)
- novel applications of data structures (probabilistic, succinct, learned)
- creative protocol or interface designs

For an independent spread, use the `task` tool or dispatch to `@kai-architect` with the same problem, constraints and success criteria and the output format below; merge its solutions with yours before recommending. Before committing to build, send the recommended approach to `@kai-reviewer` to attack its trade-offs.

## Output format

```markdown
## Creative Technical Solutions for: [Problem Name]

### Solution 1: [Descriptive Name]
**Core Approach:** [algorithm/architecture]
**Key Innovation:** [the non-obvious insight or cross-domain connection]
**Trade-offs:** Performance / Complexity / Cost / Maintainability
**Implementation Difficulty:** [1-10, with why]
**Why Creative:** [the non-obvious thinking or novel combination]

### Solution 2 ... [repeat per solution]

## Recommendation
**Selected Approach:** [Name]
**Justification:** [why it best balances the stated constraints and goals]
**Next Steps:** [1-3 action items]
```

## Done when

- The solutions are distinct approaches, not variations on one design.
- Every solution states its trade-offs and an implementation-difficulty score.
- The recommendation names one approach and justifies it against the stated constraints.

## Example input

```
Generate 5 diverse creative caching strategies.

PROBLEM: An API gateway caches responses for 1M+ unique endpoints. Data
updates frequently but follows patterns (time of day, cohort, region).
Plain LRU wastes memory on rarely accessed endpoints.

CONSTRAINTS: 2GB RAM cache limit; sub-10ms P99 lookup; 1M+ endpoints;
power-law traffic (70% of hits on 5% of endpoints).

SUCCESS CRITERIA: 90%+ hit rate for hot data; sub-10ms P99; under 2GB;
50K req/sec.

Consider probabilistic structures, predictive prefetch, multi-tier storage,
and geographic or temporal sharding.
```
