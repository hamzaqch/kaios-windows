# SyntheticDataExpansion Workflow

**When to use:** you have a small seed corpus (5-20 examples) and need a diverse N-example dataset for evals, training data, prompt-injection test sets, writing-style corpora, synthetic Q&A for retrieval evals, or anything else that benefits from variety.

**Why it works:** Verbalized Sampling, multi-turn variant (VS-Multi; Zhang et al. 2025, arXiv:2510.01171). Each turn samples from progressively rarer regions of the distribution that aligned models encode but no longer surface by default. The paper reports VS-Multi synthetic math training data raising downstream accuracy from 30.6% to 37.5% averaged across MATH500, OlympiadBench and Minerva Math.

**Word choice:** say **"confidence"**, not "probability", in the generation prompts. The paper found this elicitation word works better for VS-Multi specifically.

## Inputs

- **Seed corpus:** 5-20 anchor examples, in full.
- **Schema:** what each example must contain (fields, format, constraints).
- **Target N:** final corpus size.
- **Domain hints (optional):** regions the user wants covered.

## Outputs

Write to `~/.copilot/kai/MEMORY/WORK/{slug}/synthetic-data/` (Windows: `%USERPROFILE%\.copilot\kai\MEMORY\WORK\{slug}\synthetic-data\`):

- `seed.json`: the original seed corpus
- `schema.json`: the validation schema
- `generations.jsonl`: every accepted example with provenance (turn, confidence, timestamp)
- `rejected.jsonl`: every rejected example with reason (`schema-fail`, `semantic-dup`, `too-typical`, `low-quality`)
- `summary.md`: final stats (N achieved, dedupe rate, turn count, diversity notes)

These files are the durable artifact. Point the user at them rather than pasting the corpus inline.

## Multi-turn loop

Each turn is a fresh generation request that sees every accepted example so far, to enforce non-duplication.

### Turn 1 prompt

```markdown
You are expanding a seed corpus into a diverse dataset via Verbalized Sampling.

## Schema
{schema}

## Seed corpus
{seed examples}

## Task
Generate 5 NEW examples matching the schema, each with your confidence.
Sample from the tails where confidence < 0.10: pull from regions of the
distribution the seed corpus does NOT cover. Each example must match the
schema exactly, be semantically distinct from every seed example, and be
plausible rather than absurd.

## Output format
JSON array: [{"example": <object>, "confidence": <number>,
"rationale": "<one sentence on which region of the distribution this comes from>"}]
```

### Turn 2+ prompt

```markdown
Continue expanding. All examples accepted so far ({k} total):

{accepted corpus}

Generate 5 MORE examples with confidences, sampling from confidence < 0.10.
Each must be semantically distinct from every example above. Earlier turns
covered the obvious novel regions; this turn must reach rarer ground.

Same JSON output format.
```

For large targets, turns can be fanned out with the `task` tool, but each worker must receive the full accepted corpus, and acceptance checks run centrally after every batch.

### Acceptance check (per generated example)

1. **Schema validation:** must satisfy the schema, else reject `schema-fail`.
2. **Semantic dedupe:** compare against all accepted examples; if more than ~85% similar to any, reject `semantic-dup`.
3. **Confidence sanity:** reject examples the model rated `confidence > 0.20` as `too-typical` (likely a rephrased seed).

### Termination

Stop when any of these is true:

- Target N reached.
- The last turn rejected 40% or more of its generations as semantic duplicates (diversity collapse).
- Three consecutive turns produced fewer than 2 accepted examples (the model is stuck).

When termination is due to diversity collapse, say so plainly in `summary.md` so the user knows the real diversity ceiling for this seed.

## Not for

- Tasks with one objectively correct answer (VS gives no lift on factually constrained tasks).
- Producing one best example or one polished creative output (use the main skill's Standard or Maximum mode).

## Gotchas

- **Confidence inflation is normal.** The model will claim `confidence: 0.05` for mildly novel examples. Trust the dedupe check over self-reported confidence.
- **Seed quality dominates.** A narrow seed cannot be expanded into regions it never hints at. Ask for domain hints when the seed is narrow.
- **Don't combine with tree of thoughts.** That mode branches on a single problem; this one expands a corpus. Pick one.
