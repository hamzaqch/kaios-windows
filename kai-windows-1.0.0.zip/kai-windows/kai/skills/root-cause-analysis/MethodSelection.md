# Method Selection

Which method fits which failure. The method matters: Five Whys on a safety-critical failure, or a fault tree on a simple defect, both produce bad results.

## Decision flow

```
Incident or defect?
│
├─ Incident (production outage, security event, data loss)
│    └─ Postmortem as the wrapper
│         ├─ Single thread, clear mechanism      → Five Whys inside
│         ├─ Several suspected categories        → Fishbone inside
│         ├─ "Works here, not there", subtle     → Kepner-Tregoe inside
│         └─ Safety/security-critical, redundant → Fault Tree inside
│
├─ Defect (recurring bug, quality drift, process failure)
│    ├─ Simple, single-thread             → Five Whys
│    ├─ Multi-category, brainstorm needed → Fishbone + Pareto
│    ├─ Deviation from known-good         → Kepner-Tregoe
│    ├─ Novel, never happened before      → Apollo-style causal graph (see Foundation.md)
│    └─ Complex interacting failures      → Fault Tree
│
└─ Nothing has failed yet (pre-launch, design review) → FMEA, optionally Fault Tree
```

## Comparison

| Criterion | Five Whys | Fishbone | Fault Tree | Apollo | Kepner-Tregoe | FMEA |
|---|---|---|---|---|---|---|
| Complexity | Simple-moderate | Moderate-complex | Complex | Moderate-complex | Moderate | Moderate-complex |
| Causal structure | Chain (branching) | Parallel categories | Boolean, probabilistic | Evidence-backed graph | IS/IS NOT deviation | Mode → effect, ranked |
| People | Solo / small team | Group brainstorm | Engineers + analysts | Formal panel | Solo / small team | Cross-functional team |
| Time | Minutes-hours | Hours | Days-weeks | Hours-days | Hours | Hours-days |
| Safety-critical | No | No | Yes | Yes | No | Yes |
| Gives probabilities | No | No | Yes | No | No | Ordinal ranking |
| Novel failures | Moderate | Yes | Yes | Yes | Moderate | Anticipates them |
| Regulatory defensibility | No | Partial | Yes | Yes | Partial | Yes |
| Timing | Reactive | Reactive | Either | Reactive | Reactive | Proactive |
| Output | Chain + fix | Category map + Pareto | Cut sets + probabilities | Causal graph + evidence | Distinction + change | Ranked failure modes + actions |

## Combinations

Methods nest; they are not mutually exclusive.

- **Software operations:** Postmortem (wrapper) → Five Whys per thread → Swiss Cheese layer review → action items ranked by strength.
- **Quality investigation:** Fishbone (breadth) → Pareto (vital few) → Five Whys (depth on the top causes) → verification.
- **Subtle defect:** Kepner-Tregoe (find the change) → Five Whys (why the change wasn't caught) → corrective action.
- **Safety-critical:** Fault Tree (top-down map) → FMEA (modes ranked by RPN/AP) → Postmortem if an incident occurred → action items at several defensive layers.

## Anti-patterns

| Anti-pattern | Signal | Switch to |
|---|---|---|
| Five Whys where Fishbone fits | Each "why" has three valid parallel answers and you keep getting stuck | Fishbone |
| Fishbone where Five Whys fits | You already know the category and need depth, not breadth | Five Whys |
| Fault Tree without probability data | You're just drawing a tree; the quantitative benefit is gone | Fishbone + Five Whys |
| Kepner-Tregoe without a baseline | No "worked before" state exists to deviate from | Apollo or Fishbone |
| Skipping the Postmortem for a "small" incident | You're making exceptions | Run it anyway; the discipline compounds, the skipped learning doesn't come back |

## Method by domain

| Domain | Primary | Secondary |
|---|---|---|
| Production software outage | Postmortem + Five Whys | Swiss Cheese, Fishbone |
| Distributed-systems failure | Postmortem + Apollo-style graph | Fault Tree |
| Security incident | Postmortem + Swiss Cheese | Kepner-Tregoe for subtle defects |
| Manufacturing / quality defect | Fishbone + Pareto | Five Whys |
| Intermittent / environment-specific | Kepner-Tregoe | Five Whys |
| Safety-critical engineering | Fault Tree | FMEA, Apollo |
| Pre-launch risk analysis | FMEA | Fault Tree |
| Process / organizational failure | Fishbone (4 P's) | Five Whys |
| Regulatory investigation | Apollo with full evidence | Fault Tree |

## Speed vs thoroughness

| Time available | Method |
|---|---|
| 10 minutes | Quick Five Whys |
| 1 hour | Five Whys + Fishbone |
| Half a day | Postmortem with several methods inside |
| Days | Postmortem + Fault Tree + FMEA |
| Regulatory deadline | Apollo with full evidence |

When the same contributing factors show up across several postmortems, the cause is structural: hand off to `/systems-thinking` (Iceberg or FindArchetype).
