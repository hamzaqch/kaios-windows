# Root Cause Analysis: Foundation

Origins, theory, and the bias catalog behind the methods. Load when you need depth.

## Five Whys

Sakichi Toyoda, 1930s; embedded in the Toyota Production System by Taiichi Ohno ("by repeating why five times, the nature of the problem as well as its solution becomes clear"). It was first used to understand why new features were needed, not as formal RCA, which explains its limits:

- **Stopping at blame.** If the chain ends at a person, ask one more why.
- **Single-chain bias.** Real causes branch; a strictly linear chain misses parallel factors.
- **Skipping levels.** Jumping from symptom to a distant cause produces a chain that feels complete but omits mechanisms.
- **Knowledge ceiling.** It can't go beyond the investigator's knowledge; different people produce different chains for the same failure (poor repeatability).
- **Too shallow** for problems that need structural analysis (a criticism from inside Toyota itself).

**Five Hows:** after the root cause, ask "how do we prevent this?" five times so the fix is as deep as the diagnosis.

## Ishikawa / Fishbone

Kaoru Ishikawa, Kawasaki Steel Works, 1943; one of the seven basic quality tools in *Guide to Quality Control* (1968). Ishikawa recommended adapting categories to context:

- **6 M's** (technical): Manpower, Machine, Method, Material, Measurement, Mother Nature.
- **4 P's** (service): People, Process, Policies, Procedures.
- **8 M's:** 6 M's + Management, Maintenance.
- **8 P's** (business): Product, Price, Place, Promotion, People, Process, Physical Evidence, Partners.

Classic combination: Fishbone for breadth, Pareto for priority, Five Whys for depth on the vital few.

## Pareto analysis

Pareto's 80/20 observation (1896), applied to quality by Joseph Juran ("vital few, trivial many"). Pareto tells you **which** causes matter most, never **why** they occur. It prioritizes; always follow it with a depth method.

## Fault Tree Analysis

H.A. Watson, Bell Labs, 1961, for the Minuteman missile program. Standardized in IEC 61025, NRC NUREG-0492, SAE ARP4761. Top-down and deductive: an undesired top event decomposed through AND / OR / Priority-AND / Inhibit gates down to basic events with estimable probabilities.

**Minimal cut sets:** the smallest sets of basic events whose joint occurrence causes the top event. Many single-event cut sets mean fragility; all cut sets of size 3+ mean real defense in depth.

**Independence caveat:** Boolean propagation assumes basic events are independent. Common-mode failures (shared deploy, dependency, power, operator) make an AND gate far more likely than the product suggests. Flag them.

## Apollo RCA / RealityCharting

Dean Gano, after work on the Three Mile Island analysis; *Apollo Root Cause Analysis* (1999, 3rd ed. 2007). Failures have no single root cause, only a continuum of causes linked by cause and effect. Build a causal graph comprehensive enough to support effective solutions and bounded where actionable interventions exist. Differences from Five Whys:

- **Evidence required at every node** (observation, measurement, data). A cause without evidence is a hypothesis, not a finding.
- **"What caused this?"** instead of "why?", which yields mechanisms rather than blame.
- **Explicit branching**: each effect typically has at least an action cause and a condition cause.

Preferred over plain Five Whys for distributed systems and novel failures.

## FMEA

Failure Mode and Effects Analysis: MIL-P-1629 (1949), adopted by NASA and the automotive industry, codified in IEC 60812; current automotive standard is the AIAG/VDA FMEA Handbook (2019). FMEA is **proactive** (before failure); RCA is **reactive** (after). RCA findings reveal modes FMEA missed; FMEA findings feed prevention.

- **RPN = Severity × Occurrence × Detection**, each 1-10.
- **Caveat:** RPN multiplies three ordinal scales; it is not a ratio metric (an RPN of 200 is not "twice as risky" as 100, and a severity-10 mode can hide behind a moderate RPN). The 2019 AIAG/VDA handbook replaced RPN as the primary ranking with **Action Priority (High / Medium / Low)**, which weights severity first.
- **Variants:** Design FMEA (DFMEA) for a product or system design during design; Process FMEA (PFMEA) for a manufacturing or operational process.

## Kepner-Tregoe problem analysis

Charles Kepner and Benjamin Tregoe, *The Rational Manager* (1965), from research on how effective managers actually solve problems versus how they think they do. Every problem is a deviation from expected performance, and every deviation has a cause that changed something. IS / IS NOT specification locates that change. **The test:** a valid cause explains every IS entry and is consistent with every IS NOT entry. Causes that fail either side are eliminated.

## Swiss Cheese model

James Reason, *Human Error* (1990) and *Managing the Risks of Organizational Accidents* (1997); used in aviation, healthcare, nuclear safety. Every system has defensive layers (procedures, training, automation, monitoring, supervision, physical barriers), each with holes. An accident happens when holes in several layers line up.

- **Active failures:** unsafe acts at the sharp end (errors, violations, misjudgments). Immediate and visible.
- **Latent conditions:** weaknesses built in by designers, managers, maintainers (poor interfaces, production pressure, understaffing, ambiguous procedures). Present long before the incident; "may lie dormant within the system for many years before they combine with active failures and local triggers."

The reframe: not "who made the error?" but "why did the defenses fail to catch it?" Plugging one layer is not enough if the system depends on it. The most durable fixes target latent conditions.

## Postmortem culture

Google *Site Reliability Engineering* (2016) ch. 15 and the SRE Workbook (2018) ch. 10; Etsy's Debriefing Facilitation Guide (John Allspaw, 2016); Sidney Dekker, *The Field Guide to Understanding Human Error*.

- **Blameless:** a written record of the incident, impact, actions, causes, and follow-ups, conducted without indicting any individual. The goal is systemic learning.
- **Why it works:** people who fear blame under-report and hide context. Safety makes the full causal picture visible.
- **Hindsight bias:** knowing the outcome makes it look obvious. Reconstruct the timeline forward from before the incident, using what people knew at each moment ("the sharp end").

## Common RCA mistakes

- **Stopping at the proximate cause.** If the corrective action is "be more careful," you stopped there.
- **Confirmation bias.** Teams form a hypothesis in the first hour and collect support. Collect evidence before ranking hypotheses; assign someone to argue against the leading one.
- **Single-root-cause assumption.** Complex failures need several contributing causes, none sufficient alone. Say "contributing factors" (Will Gallego, "No, Seriously. Root Cause is a Fallacy," 2018).
- **Correlation as causation.** A coincident change is a candidate. Require a mechanism.
- **Humans as root cause.** "Operator didn't follow procedure" ends the investigation early. Ask why the system made that possible.
- **Weak corrective actions.** Training and reminder emails rely on memory under pressure, the mechanism that already failed.

## The actionability test

A root cause is **the deepest cause at which you can implement a change that prevents recurrence**.

- **Too shallow:** "the deployment failed." You can't change that. Go deeper.
- **Too deep:** "humans make errors." True, not actionable. Back up a level.
- **Test:** can you name a specific, implementable intervention for this cause that is within your organization's authority? If yes, that's an actionable root cause. If not, keep looking.

## RCA in software

- SRE practice lists all contributing factors; distributed systems fail through **conjunctions** of conditions.
- Cause and effect cross service boundaries. You need correlated logs (structured logging with trace IDs), distributed tracing (e.g. OpenTelemetry), and timeline reconstruction across clocks (clock skew is a real confounder).
- Standard postmortem categories: (1) proximate cause, (2) contributing factors, (3) detection failure (why didn't we know sooner?), (4) response failure (why did recovery take as long as it did?). Each gets its own corrective actions.
- Single-chain Five Whys breaks down across microservices; use explicit branching with evidence at each node.
- **Observability is a precondition.** When it was insufficient, the first action item is instrumentation.

## Citations

Ohno, *Toyota Production System* (1988). Ishikawa, *Guide to Quality Control* (1968). Kepner & Tregoe, *The New Rational Manager* (1981). Reason, *Human Error* (1990); *Managing the Risks of Organizational Accidents* (1997). Gano, *Apollo Root Cause Analysis*, 3rd ed. (2007). Beyer et al., *Site Reliability Engineering* (2016), ch. 15. Allspaw, "Debriefing Facilitation Guide" (Etsy, 2016). Dekker, *The Field Guide to Understanding Human Error*, 3rd ed. (2014). Juran, *Juran on Quality by Design* (1992). Watson, "Launch Control Safety Study" (Bell Labs, 1961). IEC 61025, *Fault Tree Analysis*. Vesely et al., *Fault Tree Handbook* (NUREG-0492, 1981). AIAG/VDA FMEA Handbook (2019). Gallego, "No, Seriously. Root Cause is a Fallacy" (2018).
