# Fishbone (Ishikawa)

Build a cause-and-effect map that sorts contributing factors into named categories. Unlike Five Whys (depth-first, one chain), Fishbone is deliberately **breadth-first**: it makes you consider every category of cause before drilling down. Use it when causes plausibly span several categories, when several people hold domain knowledge, or before Five Whys to avoid fixating on one category too early.

```
     People          Process         Material
        \               \               \
─────────\───────────────\───────────────\──────────▶ PROBLEM
         /               /               /
    Machine        Measurement      Environment
```

Problem at the head, categories as major bones, specific causes as sub-bones.

## Category sets

Adapt categories to the context (Ishikawa's own advice).

**6 M's: technical systems (default for software)**

| Category | Covers |
|---|---|
| Manpower (People) | Skills, training, experience, fatigue, staffing |
| Machine (Equipment) | Hardware, software, tooling, versions, configuration |
| Method (Process) | Procedures, workflows, algorithms, runbooks |
| Material | Inputs, dependencies, third-party libraries, data quality |
| Measurement | Metrics, monitoring, tests, instrumentation accuracy |
| Mother Nature (Environment) | Network conditions, load, ambient variables, seasonal effects |

**4 P's: service and customer-facing:** People (staff, customers, stakeholders), Process (workflows, SLAs), Policies (rules, standards, governance), Procedures (specific runbooks, scripts). Use for pure process or organizational failures.

**8 M's:** 6 M's + Management (decisions, priorities, allocation) + Maintenance (upkeep, patching, lifecycle).

**8 P's: business strategy:** Product, Price, Place, Promotion, People, Process, Physical Evidence, Partners.

## Method

1. **Problem statement** at the head: measurable and specific.
2. **Pick the category set** and record the choice. If a cause fits no category, add one rather than distorting the cause.
3. **Brainstorm causes per category without evaluating.** Capture every candidate. For each category ask: what here could have contributed? What is unusual, stressed, or recently changed here? What would have to be true for this category to be a cause? **An empty category is a signal**: either it's genuinely not involved, or you're missing the right expert. When working alone, dispatch `@kai-researcher` to fill thin categories from logs, configs, and history.
4. **Sub-bones: nested whys.** For each cause ask "why?" 2-3 times. This is where Five Whys nests inside Fishbone.
   ```
   Process
     ├─ Deploy runbook missing
     │    └─ template predates current architecture
     │         └─ no owner for runbook maintenance
     └─ Rollback procedure untested
          └─ never run in production
               └─ fear of causing a secondary incident
   ```
5. **Prioritize with Pareto.** Quantify each cause (frequency from incident history, estimated impact, or expert estimate), sort descending, compute cumulative percentage, and take the **vital few** (usually 3-5 causes covering ~80% of impact). Park the rest. Pareto says which causes matter, not why; follow with depth on the vital few.
6. **Verify before acting.** A cause on the diagram is a hypothesis. For each vital-few cause: evidence needed, the test (experiment or historical query), and the expected outcome if the cause is real.

## Output

```
FISHBONE: [problem]

PROBLEM: [precise statement]
CATEGORY SET: [6M / 4P / 8M / 8P / custom]

CAUSE MAP:
People:
- [cause]
  └─ why: [...]
Machine:
- [cause]
Method:
- [cause]
  └─ why: [...]
    └─ why: [...]
Material:
- [cause]
Measurement:
- [cause]
Environment:
- [cause]

PARETO:
| Cause | Impact | Cumulative |
|-------|--------|------------|
| [C1]  | 45%    | 45%        |
| [B2]  | 25%    | 70%        |
| [A1]  | 15%    | 85%        |  ← 80% line
| ...   | ...    | ...        |

VITAL FEW:
1. [cause] — verification: [evidence, test, expected outcome]
2. ...

CORRECTIVE ACTIONS (after verification): [action — owner — deadline]
```

## Worked example

```
PROBLEM: Checkout p99 latency rose from 200 ms to 3,200 ms after the 2026-04-10 deploy.
CATEGORY SET: 6 M's

Manpower:
- Deploying engineer new to the service; unfamiliar with its async-only pattern
- Reviewer approved without running benchmarks
Machine:
- Instance type in the infrastructure config underpowered for the new workload
- Connection pool sized for the previous traffic pattern
Method:
- No canary; 100% of traffic shifted at once
- No pre-deploy performance smoke test
Material:
- New dependency introduced a synchronous external API call (previously async)
- Shared library upgrade deprecated the async API
Measurement:
- Pre-deploy checklist checks mean latency only, not percentiles
- No alert on p99 deviation during rollout
Environment:
- Deploy during peak traffic (14:00 UTC)
- External dependency had elevated latency that day

PARETO:
| Synchronous external call (Material) | 65% | 65%  |
| No canary (Method)                   | 15% | 80%  |
| Undersized instance (Machine)        | 10% | 90%  |
| Peak-hour deploy (Environment)       |  5% | 95%  |
| Others                               |  5% | 100% |

VITAL FEW:
1. Sync external call — review the diff; benchmark sync vs async locally
2. No canary — check history: did past full-traffic deploys also spike?
3. Instance size — redeploy on the next size up and compare

CORRECTIVE ACTIONS:
- Restore the async external call — checkout team — Apr 15
- Canary rollout 10% → 50% → 100% with a p99 gate — platform — Apr 30
- Per-service instance sizing review — infra — May 5
```

## Common mistakes

- **Forcing causes into categories.** Add a category instead.
- **Ignoring empty categories.** Find the missing expert.
- **Skipping Pareto.** Trying to fix everything fixes nothing.
- **Skipping verification.** Test the top candidates before remediating.
- **Wrong category set.** 6 M's on a pure policy failure distorts the diagram.
- **Treating the first diagram as final.** For complex incidents it's draft one; new evidence reshapes it.
