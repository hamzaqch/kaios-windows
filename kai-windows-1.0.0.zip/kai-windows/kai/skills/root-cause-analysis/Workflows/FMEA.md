# FMEA: Failure Mode and Effects Analysis

The **proactive** counterpart to RCA: enumerate how a design or process could fail *before* it does, rate each failure mode, and mitigate the riskiest first. RCA asks "why did this fail?"; FMEA asks "how could this fail, how bad would it be, and would we notice?" (MIL-P-1629, 1949; IEC 60812; AIAG/VDA FMEA Handbook, 2019.)

Use for pre-launch risk analysis, design reviews, safety-critical changes, new operational processes, and after a postmortem to sweep for sibling failure modes the incident hinted at.

- **Design FMEA (DFMEA):** a product or system design, during design.
- **Process FMEA (PFMEA):** a manufacturing or operational process (deploys, backups, onboarding, on-call).

## Rating scales (each 1-10)

| Score | Severity (S): impact if it happens | Occurrence (O): likelihood | Detection (D): chance current controls catch it before impact |
|---|---|---|---|
| 1 | No noticeable effect | Practically never | Almost certain to be caught |
| 3-4 | Minor degradation, workaround exists | Rare | High chance of detection |
| 5-6 | Noticeable degradation for some users | Occasional | Moderate |
| 7-8 | Major loss of function, many users affected | Frequent | Low chance of detection |
| 9-10 | Safety, data loss, legal or security exposure; 10 = no warning | Near-certain / constant | Cannot be detected before impact |

Note that Detection is inverted: **high D means poor detection**. Write anchors specific to your domain before rating, and rate as a group or with a second opinion so scores are consistent.

## Method

1. **Scope.** Name the system or process and its boundary. Pick DFMEA or PFMEA.
2. **List functions or steps.** For a design, what each component must do; for a process, each step in order.
3. **Failure modes.** For each function or step: how could it fail to do its job? Consider: doesn't happen, happens partially, happens too late or too early, happens wrongly, happens when it shouldn't, happens silently.
4. **Effects.** For each mode, the consequence for the user, the system, and downstream steps. Rate **Severity** on the worst credible effect.
5. **Causes.** For each mode, the mechanisms that could produce it. Rate **Occurrence** per cause, using history or incident data where you have it.
6. **Current controls.** What exists today to prevent the cause or detect the mode before impact? Rate **Detection** against those controls only, not planned ones.
7. **Prioritize.**
   - **RPN = S × O × D** (1-1000) is the classic ranking.
   - **Caveat:** RPN multiplies ordinal scales; it is not a ratio. An RPN of 200 isn't twice as risky as 100, and a severity-10 mode with low O and D can hide behind a modest RPN.
   - **Action Priority (AP: High / Medium / Low)**, the 2019 AIAG/VDA replacement, weights **severity first**, then occurrence, then detection. Any mode with S 9-10 deserves action unless both O and D are very low. For regulated work, use the handbook's AP table.
8. **Actions.** For each high-priority mode, actions that cut Severity (design change, containment), Occurrence (remove the cause), or Detection (add monitoring, tests, gates). The same strength order as postmortem actions applies: eliminate > forcing function > automation > simplify > standardize > training > reminder. Each action gets an owner and a deadline.
9. **Re-rate.** After actions land, re-score S, O, D and confirm the priority dropped. Keep the FMEA as a living document: update it when the design changes and when a postmortem reveals a mode it missed.

## Output

```
FMEA: [system / process]   TYPE: [DFMEA / PFMEA]
SCOPE: [boundary]

| # | Function/step | Failure mode | Effect | S | Cause | O | Current controls | D | RPN | AP |
|---|---------------|--------------|--------|---|-------|---|------------------|---|-----|----|

TOP RISKS (by AP, then RPN):
1. [mode] — why it ranks high
2. ...

ACTIONS:
| # | Action | Targets (S/O/D) | Owner | Deadline | Expected re-rating |

RE-RATED AFTER ACTIONS: [new S/O/D/RPN/AP for each acted-on mode]
```

## Worked example: nightly database backup (PFMEA)

```
SCOPE: nightly backup of the production database, from job start to the backup
being restorable in an emergency.

| # | Step     | Failure mode                          | Effect                              | S  | Cause                                 | O | Current controls          | D | RPN | AP |
|---|----------|---------------------------------------|-------------------------------------|----|---------------------------------------|---|---------------------------|---|-----|----|
| 1 | Dump     | Job exits 0 but writes an empty file  | No usable backup; found during a crisis | 9 | Credential expiry swallowed by script | 4 | Exit-code alert only      | 8 | 288 | H  |
| 2 | Restore  | Restore fails when needed             | Extended outage, possible data loss | 9  | Restore procedure never exercised     | 5 | None                      | 9 | 405 | H  |
| 3 | Store    | Backups in same region as primary     | Regional outage takes both          | 10 | Default bucket location               | 2 | Architecture review       | 3 | 60  | H  |
| 4 | Retain   | Old backups deleted early             | Can't recover from late-found corruption | 7 | Lifecycle rule misconfigured      | 3 | Quarterly manual check    | 6 | 126 | M  |
| 5 | Schedule | Backup overlaps peak traffic          | Elevated latency for 20 minutes     | 4  | Timezone change shifted cron          | 6 | Latency dashboard         | 2 | 48  | L  |

TOP RISKS:
1. #2 restore never tested: highest RPN, severity 9, no control at all.
2. #1 silent empty backup: severity 9 with weak detection.
3. #3 same-region storage: low RPN (60) but severity 10. RPN alone would
   bury it; severity-first AP keeps it high.

ACTIONS:
| # | Action                                                     | Targets | Owner    | Deadline | Expected      |
|---|------------------------------------------------------------|---------|----------|----------|---------------|
| 2 | Automated weekly restore into a scratch instance, with row-count check | D, O | [person] | +2 weeks | D 9→2, O 5→2 |
| 1 | Validate backup size and checksum; fail loudly on mismatch | D       | [person] | +1 week  | D 8→2         |
| 3 | Replicate backups to a second region                       | S       | [person] | +1 month | S 10→4        |
| 4 | Alert on lifecycle-rule changes; monthly automated audit   | D       | [person] | +1 month | D 6→3         |

RE-RATED: #2 → 9×2×2 = 36; #1 → 9×4×2 = 72; #3 → 4×2×3 = 24; #4 → 7×3×3 = 63.
```

## Common mistakes

- **Ranking by RPN alone.** Severity-10 modes hide behind low RPNs. Use AP or a severity override.
- **Rating Detection against planned controls.** Rate what exists today.
- **Vague failure modes.** "Backup fails" covers five different modes with different causes and controls. Split them.
- **One-person scoring.** Scores drift with the rater. Calibrate with anchors and get a second rater; `@kai-reviewer` works as one.
- **Write once, never update.** FMEA is a living document; feed it from every postmortem.
- **Training as the main action.** Same weakness as in postmortems.

FMEA pairs with `FaultTree.md`: FMEA works bottom-up from single failure modes to their effects; a fault tree works top-down from one undesired event to the combinations that cause it. For safety-critical work, run both.
