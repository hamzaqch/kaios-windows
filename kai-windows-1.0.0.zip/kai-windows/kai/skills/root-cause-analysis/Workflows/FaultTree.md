# Fault Tree Analysis

Build a top-down, deductive, Boolean diagram that decomposes an undesired **top event** into contributing events through logic gates. Five Whys is linear and Fishbone is categorical; a fault tree captures **which combinations** of events must occur. The key output is the set of **minimal cut sets**: the smallest combinations of basic events that produce the top event. (Bell Labs, 1961; IEC 61025, NUREG-0492, SAE ARP4761.)

Use for safety- or security-critical systems, multi-path failures where several defenses could each have stopped it, systems with redundancy, or when you need a probability estimate. Not for fast triage: building a tree typically takes 2-8 hours.

## Terms

```
              [ TOP EVENT ]
                    │
                  (gate)
           ┌────────┼────────┐
       [Event A] [Event B] [Event C]
           │
         (gate)
        ┌──┴──┐
   [Basic 1] [Basic 2]
```

- **Top event:** the undesired outcome at the root.
- **Intermediate events:** internal nodes, decomposed further.
- **Basic events:** leaves; not decomposed further; have assignable probabilities.

## Gates

| Gate | Output occurs when | Meaning |
|---|---|---|
| **OR** | **any** input occurs | Each input alone suffices. No redundancy: single points of failure. |
| **AND** | **all** inputs occur (usually together) | Every defense must fail. Defense in depth. |
| **Priority AND** | all inputs occur **in a specific order** | "A then B" causes it; "B then A" doesn't. |
| **Inhibit** | the input occurs **and** a conditioning event is present | Failure modes exposed only under certain conditions. |
| **Exclusive OR** | exactly one input occurs | Rare in practice. |

## Method

1. **Define the top event precisely**: specific, observable, measurable. "User is charged but the order is not recorded" works; "payment problems" doesn't.
2. **One level at a time.** For the top event, ask what direct causes produce it and in what logical combination. All needed together → AND. Any one sufficient → OR. Order matters → Priority AND. Needs a condition → Inhibit. Draw that one level only.
3. **Decompose recursively** until every leaf is a basic event. Stop a branch at: a component failure with a known rate; a human error with a statistical rate (don't omit these; misconfigurations and deploy mistakes are often the largest basic-event probabilities in software); a condition outside the system boundary; or the point where further decomposition adds nothing.
4. **Find minimal cut sets.** A cut set is a set of basic events whose joint occurrence causes the top event; minimal means no member can be removed. Under OR, each input contributes its own cut sets; under AND, take the Cartesian product of the inputs' cut sets. For large trees use the MOCUS algorithm or FTA software. Many single-event cut sets mean fragility; all cut sets of size 3+ mean strong defense in depth.
5. **Quantify, if you have probabilities.**
   - OR: P = 1 − ∏(1 − Pᵢ), approximately ΣPᵢ for small probabilities.
   - AND: P = ∏Pᵢ, **assuming independence**.
   - **Common-mode check:** shared deploys, dependencies, power, or operators correlate basic events, and then an AND gate is far more likely than the product. Flag every plausible common mode.
6. **Prioritize mitigation.** Rank cut sets by probability. Removing one event from a 3-event cut set collapses that set's probability, so target the cheapest-to-eliminate basic event in the highest-probability cut set. Eliminate single-event cut sets first, harden against common modes, and add defenses that raise the minimum cut-set size.

Without probability data the quantitative payoff is gone; Fishbone plus Five Whys usually serves better. Keep the tree current; an old tree of an old architecture misleads.

## Output

```
FAULT TREE: [top event]

TOP EVENT: [...]

TREE:
  [Top]
   (OR)
    ├── Intermediate A
    │    (AND)
    │     ├── Basic 1 (P=0.01)
    │     └── Basic 2 (P=0.05)
    ├── Intermediate B
    │    (OR)
    │     ├── Basic 3 (P=0.02)
    │     └── Basic 4 (P=0.03)
    └── Basic 5 (P=0.001)

MINIMAL CUT SETS:
1. {Basic 1, Basic 2}  P = 5.0e-4
2. {Basic 3}           P = 0.02
3. {Basic 4}           P = 0.03
4. {Basic 5}           P = 1.0e-3

TOP EVENT PROBABILITY: ≈ 0.051 per exposure

PRIORITY MITIGATION:
1. Basic 4: highest single-event cut set
2. Basic 3: next highest single-event cut set
3. {Basic 1, Basic 2}: acceptable if truly independent

COMMON-MODE FLAGS: [correlated events and why]

RECOMMENDED ACTIONS: [...]
```

## Worked example: payment processing unavailable

```
TOP EVENT: payment processing unavailable for more than 60 seconds.

TREE:
  [Payment unavailable]
   (OR)
    ├── API gateway failure
    │    (OR)
    │     ├── Gateway service down (P=1e-4)
    │     └── DNS resolution failure (P=1e-5)
    ├── Payment service failure
    │    (OR)
    │     ├── Service crash (P=5e-4)
    │     └── Bad config pushed (P=1e-4)
    └── Database unavailable
         (AND)
          ├── Primary DB failure (P=1e-3)
          ├── Replica promotion failure (P=1e-2)
          └── Manual failover not done within SLA (P=0.1)

MINIMAL CUT SETS:
1. {Gateway down}                                   1e-4
2. {DNS failure}                                    1e-5
3. {Service crash}                                  5e-4
4. {Bad config}                                     1e-4
5. {Primary DB, Replica promotion, Manual failover} 1e-6

INSIGHT:
- The AND gate on the database brings it to 1e-6: defense in depth working.
- Gateway and payment service are OR gates with single-event cut sets: weak.
- Service crash is the highest-probability cut set.
- Common-mode check: could one bad deploy cause both "service crash" and
  "bad config"? Could the same infrastructure outage hit primary and replica?

PRIORITY:
1. Reduce P(service crash): watchdog, faster restart, circuit breaker.
2. Reduce P(gateway down): redundant gateway instances.
3. Replica promotion failure is high (1e-2); automate promotion, but the
   AND gate makes it lower priority.
```

## Common mistakes

- **Swapping OR and AND.** OR = single point of failure; AND = defense in depth. Getting it wrong inverts the analysis.
- **Assuming independence.** An AND gate is only as strong as its independence.
- **Decomposing too deep.** Stop at components with known failure rates.
- **Leaving out human-error basic events.**
- **A stale tree.**

For drawing, Mermaid or Graphviz is fine for sketching but computes no cut sets; for more than ~20 basic events use dedicated FTA software (e.g. SAPHIRE). A fault tree pairs with `FMEA.md`: FMEA enumerates failure modes bottom-up, the tree traces their combinations top-down. If common-mode failures keep recurring, the structure is generating them; escalate to `/systems-thinking`.
