# Kepner-Tregoe Problem Analysis

Find the cause of a **deviation** (something that worked and stopped, or works in one context and not another) by specifying exactly what the problem IS and IS NOT, then finding the **distinction** and the **change** behind it. Strongest on subtle, intermittent, environment-specific, hard-to-reproduce defects, and whenever someone says "we didn't change anything." (Kepner and Tregoe, *The Rational Manager*, 1965.)

**Principle:** every problem is a deviation from expected performance, and every deviation has a cause that changed something. The key question: what is different between where the problem exists and where it doesn't?

## The IS / IS NOT matrix

| Dimension | IS | IS NOT | Distinction | Change |
|---|---|---|---|---|
| **What** | The specific thing that's wrong | Similar things that are fine | What makes the problem unique | What changed to create that |
| **Where** | Location / environment where it occurs | Similar places where it doesn't | Location differentiator | What changed there |
| **When** | Times it happens | Times it doesn't | Timing differentiator | What changed at or before then |
| **Extent** | Magnitude, frequency, size | Comparative scale / baseline | Degree differentiator | What changed the degree |

## Method

1. **State the deviation:** expected vs actual. E.g. expected p99 under 300 ms in all regions; actual 2,500 ms in one zone only, after 18:00 UTC, for requests hitting version 3.4.2.
2. **Fill the matrix.** The IS NOT column matters as much as IS; it defines the boundary of the problem. Each cell should be specific and directly comparable with its opposite.
3. **Find distinctions.** Per dimension: what is true of IS and not of IS NOT? Anything true of both columns cannot be the cause.
4. **Find changes.** For each distinction: what changed in that area between last-known-good and first-observed-bad (a longer window for slow drift)? Scan: deploys, releases, config changes; schedules (cron, batch jobs); environment (load, external dependencies); personnel and shift changes; data (migrations, volumes, new user types); hardware and network paths; calendar events (month-end, quarter-end, holidays). People check deploys and miss schedule-driven changes; always scan the calendar.
5. **Generate possible causes.** For each change: how could it produce the deviation? It needs a mechanism. "We changed X" is a correlation; "X causes Y because..." is a hypothesis.
6. **Test each cause against both columns.** A valid cause **explains every IS entry** and **is consistent with every IS NOT entry**. A cause that explains IS but predicts trouble where things are actually fine is falsified. This two-sided test is the heart of the method and what separates it from accepting the first plausible correlation. `@kai-reviewer` makes a good adversarial tester here.
7. **Verify the survivor.** Show it produces the problem when present and not when absent. Ideally revert the change in a test environment and watch recovery.

## Output

```
KEPNER-TREGOE: [deviation]

DEVIATION:
- Expected: [...]
- Actual: [...]

| Dimension | IS | IS NOT | Distinction | Change |
|-----------|----|--------|-------------|--------|
| What      |    |        |             |        |
| Where     |    |        |             |        |
| When      |    |        |             |        |
| Extent    |    |        |             |        |

DISTINCTIONS: [D1], [D2], [D3]
CHANGES: [C1] (area of D1), [C2] (area of D2)

POSSIBLE CAUSES:
- [A] from [C1], mechanism: [...]
- [B] from [C2], mechanism: [...]

TESTING:
- Cause A: explains IS? ✓/✗ [why]; consistent with IS NOT? ✓/✗ [why]
- Cause B: ...

SURVIVING CAUSE: [...]
VERIFICATION PLAN: [...]
```

## Worked example: memory spike

```
DEVIATION:
- Expected: service holds a stable ~400 MB heap on all pods.
- Actual: some pods reach 2.8 GB after 18:00 UTC and are OOM-killed.

| Dim    | IS                 | IS NOT                  | Distinction            | Change                           |
|--------|--------------------|-------------------------|------------------------|----------------------------------|
| What   | Heap grows to 2.8GB| Normal 400 MB           | Unbounded growth       | Nothing new globally             |
| Where  | Zone A pods        | Zone B, other region    | Zone A only            | Zone A got the rolling deploy first |
| When   | After 18:00 UTC    | Before 18:00 UTC        | Evenings only          | 18:00 = peak session creation    |
| Extent | 7x normal          | 1x                      | Leak pattern, not step | —                                |

DISTINCTIONS: Zone A only; after 18:00 only; unbounded growth.

CHANGES:
- C1: version 3.4.2 rolled to zone A first (other zones still on 3.4.1)
- C2: 3.4.2 introduced an in-memory session cache
- C3: session creation peaks at 18:00 (normal, not a change, but interacts with C2)

POSSIBLE CAUSE A: 3.4.2's session cache has no eviction; at peak creation,
entries accumulate faster than they expire.

TESTING (Cause A):
- IS What (unbounded heap): ✓ cache grows without limit
- IS Where (zone A): ✓ only zone A runs 3.4.2
- IS When (after 18:00): ✓ peak session creation
- IS Extent (7x): ✓ cache can grow arbitrarily
- IS NOT Where (other zones fine): ✓ still on 3.4.1, no cache
- IS NOT When (before 18:00 fine): ✓ lower rate, OOM not reached yet
→ consistent on every row

SURVIVING CAUSE: 3.4.2 session cache without eviction, unbounded at peak.
VERIFICATION: heap dump from an affected pod should be dominated by session
objects; confirm in the 3.4.2 diff.
REMEDIATION: roll zone A back now; add LRU eviction and a max size in 3.4.3.
```

## Common mistakes

- **Vague IS NOT column.** It defines the boundary; weak IS NOT means weak analysis.
- **Skipping the IS NOT consistency test.** That test is the method's power.
- **"Nothing changed."** Always wrong here. Something changed or there would be no deviation. Keep looking.
- **Stopping at the first plausible cause.** Test every dimension.
- **Not verifying.** The survivor is a hypothesis until tested.

## When it fits

| Use Kepner-Tregoe when | Use something else when |
|---|---|
| The problem is a deviation from known-good | No baseline exists (novel system) → Fishbone or an evidence graph |
| Intermittent or environment-specific | Consistent, reproducible, obvious |
| "Works here, not there" | Complete system failure |
| Other methods keep guessing wrong | Time-critical triage |
| You have data on both IS and IS NOT | You can't characterize where it doesn't happen (fix observability first) |

Once the change is found, a Five Whys on "why wasn't this change caught?" usually yields the systemic action.
