# Five Whys

Walk a causal chain from symptom to systemic cause by asking "why?" repeatedly. The goal is not five questions but an **actionable systemic cause**, which usually takes 4-7 steps and at least one branch. Fast, low-overhead, the best first tool for most single-thread failures, and the depth tool inside Fishbone and Postmortem.

## Rules

**Problem statement: specific, observable, measurable.** A vague statement produces a vague chain.
- Bad: "Reliability is down."
- Good: "The payments service returned HTTP 500 for 14 minutes from 2026-04-12 23:51 UTC, affecting 3,412 checkouts."

**Each why is the direct cause of the one above.** No skipping to a distant conclusion ("deploys are bad!"); that sounds deep and omits the mechanism.

**Branch where the chain forks.** At each why, check for more than one valid answer and record every branch. A perfectly linear chain is the most common failure: it usually means you took the obvious answer and ignored the rest. **Branches that converge on a shared ancestor mark a high-leverage systemic cause: one fix closes several failure paths.**

**Stop at actionable AND systemic, both required.**
- Actionable but not systemic ("patch this line") → too shallow, keep going.
- Systemic but not actionable ("humans make mistakes") → too deep, back up one level.
- Ends at a person ("engineer made a mistake") → ask one more why. The system allowed the mistake.
- Ends at "that's just how it is" → not a root cause; it suggests no action.

**Validate by reading forward.** "Because [root], therefore [why N-1], ..., therefore [problem]." If the forward read doesn't hold, there's a logical jump; fix it before concluding.

**Judge decisions by what was known then.** Ask "what would this person reasonably have believed at that moment?", not "why didn't they see it?"

**Optional: Five Hows.** After the root cause, ask "how do we prevent this?" five times so the fix is as rigorous as the diagnosis.

## Output

```
FIVE WHYS: [problem, ~12 words]

PROBLEM: [precise statement]

CHAIN:
- WHY 1: [cause]
- WHY 2: [cause of WHY 1]
- WHY 3: [cause of WHY 2]
- WHY 4: [cause of WHY 3]
- WHY 5: [cause of WHY 4]

BRANCHES:
- At WHY N:
  ├─ Branch A: ...
  └─ Branch B: ...

ROOT CAUSE(S): [systemic, actionable]
- [cause 1]
- [cause 2]  ← where branches converged

CORRECTIVE ACTIONS:
- [specific action] — owner — deadline

VALIDATION (read forward):
Because [root], therefore [WHY 4], therefore [WHY 3], ..., therefore [problem].
```

## Worked example

```
PROBLEM: Production API returned HTTP 500 on 1,200 requests, 2026-04-12 14:00-14:14 UTC.

CHAIN:
- WHY 1: The payments database connection pool was exhausted.
- WHY 2: Query time spiked from 40 ms p99 to 3,800 ms p99.
- WHY 3: Queries were doing full table scans on the orders table.
- WHY 4: No index on (customer_id, created_at), a frequently joined pair.
- WHY 5: The migration that introduced the join pattern shipped without the index.
- WHY 6: The migration PR template doesn't require a query plan (EXPLAIN ANALYZE) for new query patterns.

ROOT CAUSE: the migration review process has no query-plan step.

CORRECTIVE ACTIONS:
- Add EXPLAIN ANALYZE output to the migration PR template — platform — Apr 18
- Create the missing index now — payments on-call — today
- Runtime query-plan monitoring alerting on new full scans — observability — Apr 25

VALIDATION: Because migrations don't require query plans, the index was missed,
which caused full scans, which spiked query time, which exhausted the pool,
which returned 500s.
```

## Common mistakes

- **Stopping at blame.** Systems allow mistakes; the root cause is in the system.
- **Skipping levels.**
- **Single-chain bias.** Real incidents branch.
- **Hindsight bias.** You know the outcome; they didn't.
- **Actions that rely on vigilance.** "Train harder" and "remind everyone" are the weakest actions. Prefer automation, checks, and process changes that make the failure hard to repeat.

## When not to use it

- **Safety-critical systems:** use `FaultTree.md`; Five Whys gives no probabilities.
- **Failures crossing many service boundaries:** use Fishbone or an evidence-backed branching graph inside a Postmortem; the single-thread assumption breaks.
- **"Works here, not there":** use `KepnerTregoe.md`.
- **Missing domain knowledge:** the method can't exceed the investigator's knowledge. Bring in experts or switch to Fishbone, where several people contribute. `@kai-researcher` can gather the missing technical facts.

If the chain keeps branching into structural causes that recur across incidents, escalate to `/systems-thinking` (Iceberg).
