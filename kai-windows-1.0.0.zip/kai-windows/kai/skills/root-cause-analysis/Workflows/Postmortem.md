# Blameless Postmortem

Produce a structured, **blameless** written record of an incident: impact, timeline, contributing factors, resolution, follow-up actions. The postmortem is the **wrapper**: inside it, use Five Whys, Fishbone, Kepner-Tregoe, or Fault Tree per contributing thread. The goal is systemic learning, not individual accountability. Postmortems that drift into blame produce worse postmortems, not better behavior. (Google SRE, Etsy debriefing practice, Sidney Dekker.)

## When to run one

Any of: user-visible downtime or degradation above threshold; data loss of any kind; on-call had to intervene; a novel failure mode (even with no customer impact, if it could have been worse); a monitoring failure (it should have been detected sooner); a security incident or near-miss; anything the system's own design says should not happen. **Default to running one.** Skipping costs the learning; running costs a few hours.

## The blameless principle

A written record conducted **without indicting any individual for bad behavior**. People who fear blame under-report and withhold context; safety exposes the full picture, including a responder's reasoning under incomplete information.

Blameless is not accountability-free: action items have owners and deadlines. What it excludes is personal judgment, punitive framing, and "why did you do that?"

Facilitation rules:
- Ask "what did you see, what did you know, what were you trying to do?", never "why did you do that?"
- Reconstruct the timeline **forward**, to fight hindsight bias.
- Study the sharp end: what was it like to be on call at that moment with that information?
- Never combine a postmortem with a performance conversation.

## Method

**Phase 1: Timeline, before any hypothesis.** Chronological: every signal available to responders, every action, every communication, every decision point and what was known there. Sources: incident channel, alert history, deploy logs, on-call notes. Building the timeline after forming a hypothesis bends it toward that hypothesis. Dispatch `@kai-researcher` to assemble raw timeline evidence when the sources are scattered.

**Phase 2: Investigate each contributing thread** with the fitting method:
- clear single thread → `FiveWhys.md`
- several suspected categories → `Fishbone.md`
- "works on X, not Y" → `KepnerTregoe.md`
- complex multi-path or redundant defenses → `FaultTree.md`

Multiple contributing factors is the default. Never settle for one root cause.

**Phase 3: Classify each factor.** Each class gets its own corrective actions:
- **Proximate cause:** the immediate trigger.
- **Contributing factor:** conditions that enabled the trigger or worsened the impact.
- **Detection failure:** why wasn't it caught sooner?
- **Response failure:** why did recovery take longer than it should have?

**Phase 4: Swiss Cheese map.** List each defensive layer that should have stopped the incident and the hole in it. Separate **active failures** (what someone did) from **latent conditions** (what the system allowed). Latent conditions have been present for a long time and fire only when an active failure lines up with them; fixing them prevents a whole class of incidents.

```
Layer 1: [defense]   hole: [why it didn't stop this]
Layer 2: [defense]   hole: [...]
Layer 3: [defense]   hole: [...]
→ incident when the holes aligned
```

**Phase 5: Action items.** Each has a named **owner** (a person, not a team), a **deadline**, a **verification** (how you'll know it's done), and a **strength rating**:

| Strength | Type | Example |
|---|---|---|
| Strongest | Eliminate | Remove the ability to do the wrong thing |
| Strong | Forcing function | A required step that blocks the wrong path |
| Strong | Automation | A check replaces human vigilance |
| Medium | Simplify | Fewer ways to get it wrong |
| Medium | Standardize | The right way becomes the default |
| Weak | Training | Teach people about the risk |
| Weakest | Reminder | Email, poster, documentation |

If the top action items are training and documentation, go back: they rely on the same vigilance that just failed. Have `@kai-reviewer` red-team the action list: "how would this incident happen again despite these actions?"

**Phase 6: Write the document** (template below).

**Phase 7: Distribute and track.** Publish internally; link it to the incident record; track every action item to completion (a postmortem without follow-through is documentation theater); revisit at 30 days: did the actions actually prevent the class of failure? If similar incidents are happening across services, escalate to `/systems-thinking`.

## Document template

```
# Postmortem: [incident title]

Date: YYYY-MM-DD | Authors: [...] | Status: Draft/Final | Classification: [...]

## Summary
[1-2 paragraphs a non-technical reader can follow]

## Impact
- Users: [N affected, M% of traffic, X minutes]
- Revenue: [if calculable]
- Data: [loss, corruption, exposure]
- On-call: [who was paged, for how long]

## Timeline (UTC)
- 23:47 Deploy D-1234 to production
- 23:49 Traffic shifted to new version
- 23:51 First p99 latency alert
- 23:52 On-call engineer paged
- 23:53 Acknowledged; investigation starts
- 23:55 Elevated 500s identified in payments
- 23:58 Rollback started
- 00:01 Rollback complete; metrics recover
- 00:05 Incident closed

## Contributing factors
### Proximate cause
### Systemic factors
1. [factor]: evidence; why it existed
### Detection gaps
### Response gaps

## Swiss Cheese analysis
- Layer 1, CI gate: tests passed; hole: no load test covering this query pattern
- Layer 2, Canary: not used; hole: process doesn't require canary for payments
- Layer 3, Pre-deploy checklist: no p99 check; hole: checklist predates p99 monitoring
- Layer 4, Monitoring: p99 alert fired after 2 min; hole: evaluation window too long

## What went well
[always include; it reinforces what kept the incident from being worse]
- Rollback ran cleanly; on-call response within SLA; clear incident-channel communication

## What went poorly
[process failures, not people]
- Deploy process allowed full-traffic cutover without canary
- Checklist out of date; alert window too long for this class of problem

## Action items
| # | Action | Strength | Owner | Deadline | Verification |
|---|--------|----------|-------|----------|--------------|
| 1 | Require canary (10/50/100 with p99 gate) for payments | Automation (Strong) | [person] | Apr 30 | Used on next 3 deploys |
| 2 | Add p99 check to pre-deploy checklist | Standardize (Medium) | [person] | Apr 18 | Checklist change merged |
| 3 | Cut payments p99 alert window from 5m to 1m | Simplify (Medium) | [person] | Apr 22 | Alert config change merged |
| 4 | Create the missing index | Eliminate (Strongest) | [person] | Today | Query plan uses it |
| 5 | Require EXPLAIN ANALYZE in migration PR template | Forcing function (Strong) | [person] | Apr 25 | Next 3 migrations include it |

## Lessons learned
- Deploy tests don't cover query-plan regressions; we relied on a latent assumption.
- Alert latency matters as much as alert accuracy.
- The structural hole was the migration review process, not the engineer or the deploy.

## Follow-up
- [ ] Action items tracked in [ticket system]
- [ ] 30-day re-review of completion and effect
- [ ] Pattern check across services (escalate to /systems-thinking if yes)
```

## Common mistakes

- **Single-root-cause framing.** Use "contributing factors."
- **Drifting into blame.** The moment the question becomes "why did this person do X?", rewind.
- **Weak action items.** Rank by strength; prefer automation and forcing functions.
- **Skipping "what went well."** It isn't decoration.
- **No owner or deadline.** Unowned means undone.
- **Merging with performance review.** Never.
- **Hindsight in the timeline.** "They should have noticed X": with the signals available at that minute, would you have? Record what was known, not what was discoverable later.

Findings from postmortems also feed `FMEA.md`: each newly discovered failure mode belongs in the next proactive review.
