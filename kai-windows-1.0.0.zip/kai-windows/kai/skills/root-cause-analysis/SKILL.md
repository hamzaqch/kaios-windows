---
name: root-cause-analysis
description: "Structured, blameless failure investigation with six methods: Five Whys, Fishbone (Ishikawa), blameless Postmortem, Fault Tree Analysis, Kepner-Tregoe IS/IS-NOT, and FMEA for pre-launch risk. Traces failures past the proximate cause to actionable systemic contributing factors instead of blaming people. Use when the user says root cause, RCA, 5 whys, five whys, fishbone, ishikawa, postmortem, incident review, incident analysis, fault tree, FTA, Kepner-Tregoe, is/is-not, works here but not there, FMEA, failure modes, why does this keep failing, recurring bug, outage, or blameless. Not for mapping feedback loops behind a recurring pattern across many incidents (use /systems-thinking)."
---
# Root Cause Analysis

Investigate why something failed: past the proximate cause, down to the contributing factors and latent conditions that made the failure possible, ending in changes that prevent a whole class of failure.

**Done means:** three or more actionable, systemic contributing factors, named blamelessly, each with a corrective action strong enough to prevent the class of failure. Not a single blame target. If the same failure could happen again tomorrow, you've done triage, not RCA.

## Axioms

1. **Proximate cause is not root cause.** "The deploy failed because X crashed" is where analysis starts.
2. **There is rarely one cause.** Incidents combine active failures (what someone did) with latent conditions (what the system allowed). Reason's Swiss Cheese model.
3. **Humans are not root causes.** "Operator error" is a stop sign for analysis, not a conclusion. If a person could make the mistake, the system allowed it. Go deeper.
4. **Actionability is the stop condition.** A cause is root enough when it points at a change you can make. Too shallow misses the fix; too deep ("physics") can't be acted on.
5. **RCA is a fight against bias.** Hindsight, confirmation, single-cause, and outcome bias all corrupt investigations. The structure exists to resist them.

## Methods

| Method | Use when | File |
|---|---|---|
| **Five Whys** | single-thread failure with a clear proximate cause; quick triage | `Workflows/FiveWhys.md` |
| **Fishbone** | causes suspected in several categories (people, process, tools); structured brainstorm | `Workflows/Fishbone.md` |
| **Postmortem** | production outage, security event, data loss; formal blameless review. Wraps the other methods | `Workflows/Postmortem.md` |
| **Fault Tree** | safety- or security-critical, multi-path failure, redundant defenses, probability needed | `Workflows/FaultTree.md` |
| **Kepner-Tregoe** | deviation from known-good; intermittent; "works here but not there"; "we didn't change anything" | `Workflows/KepnerTregoe.md` |
| **FMEA** | before launch: enumerate and rank failure modes proactively | `Workflows/FMEA.md` |

For any non-trivial incident, **the Postmortem wraps the others**: use Five Whys, Fishbone, Kepner-Tregoe, or Fault Tree inside it, one per contributing thread. The full decision flow, comparison table, method combinations, and anti-patterns are in `MethodSelection.md`. Theory, origins, and the bias catalog are in `Foundation.md`.

## Quick reference

- **Five Whys:** branching causal chain; stop at actionable AND systemic; validate by reading forward.
- **Fishbone:** 6 M's (Manpower, Machine, Method, Material, Measurement, Mother Nature) for technical systems; 4 P's (People, Process, Policies, Procedures) for services. Then Pareto, then verify.
- **Postmortem:** forward timeline → causes → classify (proximate / contributing / detection / response) → Swiss Cheese → strength-ranked action items.
- **Fault Tree:** AND/OR gates, minimal cut sets, probability propagation, common-mode check.
- **Kepner-Tregoe:** IS / IS NOT across What, Where, When, Extent → distinctions → changes → a cause must explain every IS and be consistent with every IS NOT.
- **FMEA:** failure mode → effect → Severity × Occurrence × Detection (or Action Priority), mitigate highest first.

## Examples

**Production outage** ("payments was down 14 minutes last night") → Postmortem.
Timeline: deploy 23:47 → health check passed → traffic shift 23:49 → p99 spike 23:51 → auto-rollback 00:01. Five Whys inside: p99 spiked ← cold cache ← new pod group ← no warm-up in the deploy script ← not in the checklist ← template predates the caching layer. Contributing factors: stale deploy template (latent), no warm-up step (active), no cold-cache canary (latent). Actions: update template, add warm-up, add a cold-cache canary gate.

**Recurring defect** ("same auth failure, fixed three times") → Fishbone.
Manpower: ops rotates keys without telling infra. Method: no rotation runbook. Machine: secret-cache TTL exceeds the rotation window. Material: shared key instead of per-service. Measurement: no key-expiry dashboard. Three categories contribute; a single-point fix won't hold.

**Subtle defect** ("flaky test fails only in CI") → Kepner-Tregoe.
IS/IS NOT: CI vs local; Tuesdays vs other days; shared runners vs dedicated; parallel workers vs serial. Distinctions point to timezone + concurrency + shared filesystem. Hypothesis: a local-timezone assumption plus a race on a shared temp directory, both only present in CI.

## Gotchas

- **"Human error" is where the investigation begins.** Every human error sits on a system that made it possible or likely.
- **The first plausible cause is rarely the only one.** Keep going after you find one.
- **Stopping at the proximate cause is failure.** X crashed because Y returned null; why null, why unhandled, why untested?
- **Too deep is not better.** "The second law of thermodynamics" isn't actionable. Stop at the deepest actionable level.
- **More than ~5 whys usually means you switched chains.** Redraw as a tree.
- **Correlation is a hypothesis.** Require a mechanism.
- **Outcome bias.** Judge decisions by what was known at the time, not by how they turned out.
- **Weak actions.** "Training" and "reminders" rely on the same vigilance that just failed. Prefer elimination, forcing functions, automation.
- **No observability, no RCA.** If the system couldn't be observed, the first action item is to instrument it so the next incident is diagnosable.

## Working with other skills and agents

- Dispatch `@kai-researcher` to pull logs, deploy history, alert timelines, and chat transcripts for the timeline. Dispatch `@kai-reviewer` as the root-cause auditor: have it argue against the leading hypothesis (counters confirmation bias) and red-team the action items ("how would this happen again despite these fixes?").
- `/systems-thinking`: RCA stops at contributing factors. When several postmortems surface the same factors, escalate to its Iceberg or FindArchetype workflow.
- `/science`: RCA is the scientific method applied to failure. Use it to frame competing hypotheses and the experiments that separate them.
- When an ISA exists for the work, record verified causes and action items as criteria with probes.

Sources: Sakichi Toyoda and Taiichi Ohno (Five Whys), Kaoru Ishikawa (*Guide to Quality Control*, 1968), James Reason (*Human Error*, 1990), Dean Gano (*Apollo Root Cause Analysis*), Kepner and Tregoe (*The Rational Manager*, 1965), H.A. Watson (fault trees, 1961), AIAG/VDA FMEA Handbook (2019), Google *Site Reliability Engineering* (2016, ch. 15), John Allspaw (Etsy debriefing guide), Sidney Dekker.
