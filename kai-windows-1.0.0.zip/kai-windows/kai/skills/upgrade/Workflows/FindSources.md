# FindSources

Discover, evaluate and add sources worth monitoring.

**Done looks like:** each proposed source has been fetched and checked (it exists, it updates regularly, it has extractable technique content, it isn't a duplicate of an existing source), and accepted sources are added to `MEMORY/STATE/upgrade-sources.local.json` and confirmed with `upgrade.py check --only <key> --no-save`.

## What makes a good source

| Keep | Skip |
|---|---|
| Ships concrete techniques: configs, code, release notes, measured results | Pure news or opinion with nothing to adopt |
| Machine-readable: a changelog file, an RSS/Atom feed, a releases.atom, a stable docs page | Pages that change on every load (dynamic dashboards) |
| Updates at least monthly | Abandoned blogs |
| About Copilot, agent harnesses, skills, hooks, MCP, evals, prompt injection | General AI hype |

Useful patterns: any GitHub repo's releases (`https://github.com/<owner>/<repo>/releases.atom`) or commits (`.../commits/<branch>.atom`), a raw changelog (`https://raw.githubusercontent.com/<owner>/<repo>/<branch>/CHANGELOG.md`), a docs page (type `docs`), or a listing page with a link pattern (type `index`).

## Adding one

Create or extend `~/.copilot/kai/MEMORY/STATE/upgrade-sources.local.json`:

```json
{"sources": [
  {"key": "my-source", "name": "Readable name", "type": "feed", "priority": "MEDIUM",
   "url": "https://example.com/feed.xml", "note": "why it is worth watching"}
]}
```

Types: `changelog`, `feed`, `docs`, `index` (needs `link_pattern`, a regex the article URLs match). Then test it: `upgrade.py check --only my-source --no-save`. An `error` or `skipped` coverage line means the type or URL is wrong. Trending queries can be extended the same way with a `github_trending` block (`{"queries": [...], "min_stars": 50}`).
