# AlgorithmUpgrade

Propose section-targeted improvements to `~/.copilot/kai/ALGORITHM.md` from Kai's own track record, plus any external technique that bears on how the Algorithm runs.

**Done looks like:** a short list of proposed edits, each naming the exact Algorithm section, quoting the current text, giving the replacement text, and citing at least two pieces of internal evidence (or one internal plus one external source). Nothing is edited until the user approves.

## Steps

1. Read the current `ALGORITHM.md` and `ISA_FORMAT.md` in full, and note their version lines.
2. Run `MineLearnings.md` and keep only themes about how work is run: scoping, ISA quality, verification, delegation to subagents, loops and stalls, response format.
3. Map each theme to the section it belongs in:

| Theme | Where it lands |
|---|---|
| vague or unprovable criteria, missing probes | the ISA and criteria sections, and `ISA_FORMAT.md` |
| claims closed without evidence | the verify phase |
| prior work missed, repeated rediscovery | the observe phase (context recovery via `/cortex recall`) |
| wrong or excessive subagent use | the delegation guidance |
| repeated tool loops, stalls | the build/execute guidance (and possibly a hook nudge) |
| format-gate blocks | the response format section of `copilot-instructions.md` |

4. Write each proposal as a before/after pair with its evidence. Prefer removing or sharpening a rule over adding one; a smarter model needs fewer rules, not more (see `/create-skill`'s authoring standard).
5. Record each proposal: `upgrade.py add --target algorithm --claim ... --recommendation ... --evidence ...`.
6. On approval, apply the edit, bump the Algorithm's version line, and `upgrade.py set <id> applied`.
