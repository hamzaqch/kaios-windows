# ResearchUpgrade

Deep-dive one upgrade opportunity until it is an actionable, verified implementation plan.

**Input:** a feature name or recommendation id from an Upgrade report, a changelog entry, a docs URL, or a repo.

**Done looks like:** a plan that states what the feature does (with quotes from the authoritative source), whether and how it works in this Copilot version (verified, not assumed), exactly which Kai files change and how, the risks and rollback, and the test that proves it works.

## Steps

1. **Authoritative sources first.** The Copilot changelog bullet, the docs page, the release notes. Fetch and quote them. Then examples in the wild (awesome lists, repos using it) for practical gotchas.
2. **Parallel angles when it is big.** Dispatch up to four `task` subagents or `@kai-researcher` passes: official docs, changelog history of the feature (when it landed, later fixes), real-world usage, and known problems (issues, discussions). Each returns quotes with URLs.
3. **Verify behavior live when the claim matters.** Use a throwaway Copilot home so nothing touches the real one: create a temp folder, copy only what the experiment needs, set `COPILOT_HOME` to it for that one command, run `copilot -p "<probe prompt>"` non-interactively, and read the transcript under `<temp>/session-state/*/events.jsonl`. Record exactly what was observed. Delete the temp folder afterwards (it may contain a copy of auth config).
4. **Map to Kai.** `upgrade.py state` and `upgrade.py probe` for the touchpoints. Name every file to change: `kai_hook.py` or a `hooks/ext/*.py` module, `install.py` (hook registration), a `SKILL.md`, an agent, `copilot-instructions.md`.
5. **Write the plan:** summary, evidence (quotes + URLs + live-test observations), changes per file, test plan (the command whose output proves it), risks and rollback.
6. Update the store: `upgrade.py add` if new, or note the plan's path in the existing record's evidence by re-adding with the same claim (it will report duplicate; then mention the plan path in your reply).
