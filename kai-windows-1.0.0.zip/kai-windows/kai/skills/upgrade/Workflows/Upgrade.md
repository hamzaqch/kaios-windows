# Upgrade

## Ideal state of a finished run

The user reads a report shaped exactly by `../References/OutputFormat.md` in which:
- Every worthwhile new technique from the sources (Copilot first, then agent-ecosystem repos, practitioners and trending repos) is extracted with a quote and mapped to the Kai file it would improve.
- Every recommendation carries a Prior Status tag with evidence gathered this run; nothing already implemented, deferred or rejected is re-recommended. Already-done items appear in Skipped with file:line evidence, the visible proof the prior-state check ran.
- Internal signal is present (`MineLearnings.md` method), and where internal pain and an external technique point at the same gap, the report says so.
- Recommendations are tiered by judgment: CRITICAL (a gap or breakage risk Kai should not run with, for example a Copilot change that breaks a hook contract), HIGH (clear capability or efficiency win), MEDIUM (worthwhile when convenient), LOW (awareness). Only non-empty tiers print.
- Coverage is honest: what was checked, skipped and timed out.
- State is current: `check` and `trending` saved their cursors, and every CRITICAL/HIGH/MEDIUM item is in the store.

## Steps

1. **Ground first.** `upgrade.py state` (Kai version, Copilot version, hooks, plugins, skills, agents, rejected claims, recent learnings). Also skim `~/.copilot/copilot-instructions.md` (the Kai block), `~/.copilot/kai/ALGORITHM.md`, and the newest task ISAs' Decisions. Run `upgrade.py list --status all` to see what was already proposed.
2. **Collect.** In one go: `upgrade.py check --days 30` and `upgrade.py trending --days 30`. For the full text behind a promising item (a release note, a docs diff, a repo README), fetch that page with the web fetch tool. Network sources can be split across parallel `task` subagents or `@kai-researcher` when there are many deep reads; keep it to about 8 and give each a short deadline.
3. **Extract.** For each item, find the technique: the exact new hook event, setting, frontmatter key, flag or pattern. Skip announcements with nothing Kai could adopt.
4. **Probe.** For each candidate, `upgrade.py probe "<distinctive term>"` (for example the hook event name or the frontmatter key). Hits mean DONE or PARTIAL (read the hit to decide); zero hits are the evidence for NEW. Check the store for a rejected or applied record of the same idea.
5. **Internal thread.** Run `MineLearnings.md` (abbreviated is fine) and look for overlaps with the external findings.
6. **Write the report** per `OutputFormat.md`.
7. **Persist.** For each CRITICAL/HIGH/MEDIUM recommendation: `upgrade.py add --claim ... --recommendation ... --target ... --priority ... --current ... --evidence <url>`. Duplicates are reported and skipped automatically.
8. **Registry note.** If a finding is a stable new capability Kai should route to (a new skill, an agent, a hook), add a short "Registry update proposals" section; otherwise write "No registry updates needed this cycle."

Applying a recommendation is a separate, user-approved step. When one is applied, mark it: `upgrade.py set <id> applied`.
