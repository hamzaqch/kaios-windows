# MineLearnings

Mine Kai's own records for recurring weaknesses that suggest changes to the Algorithm, skills, hooks or instructions.

## Sources (all under `~/.copilot/kai/MEMORY/`)

| Source | What it says |
|---|---|
| `LEARNING/learnings.md` | one-line lessons recorded after mistakes and discoveries |
| `LEARNING/sessions/YYYY-MM/*.md` | per-session logs: prompts, tool counts, ISAs touched |
| `LEARNING/sessions.jsonl` | one line per session: tools, prompts, ISAs, end reason |
| `OBSERVABILITY/events.jsonl` | hook events: `preToolUse.deny` / `.ask`, `postToolUseFailure`, `agentStop.formatBlock`, `*.error`, `ext_error`, `ext.load_error` |
| `WORK/*/ISA.md` | criteria left open, Decisions, Verification notes |

## Signals, strongest first

| Signal | Why it matters |
|---|---|
| The same lesson phrased several ways in `learnings.md` | the lesson isn't sticking; it needs to move into instructions, a skill, or a hook |
| Repeated `agentStop.formatBlock` events | the response-format rule isn't landing; the instruction is unclear or too far from the model's attention |
| Repeated `postToolUseFailure` for the same tool | a tool contract is misunderstood; a skill gotcha or a hook nudge is missing |
| `preToolUse.ask` for the same command pattern | either the user keeps approving it (candidate for an allow rule) or the model keeps reaching for something risky |
| Hook `*.error` / `ext_error` entries | Kai machinery is broken; usually CRITICAL |
| Task ISAs closed with open criteria, or long sessions with no ISA | verification or scoping discipline is slipping |

## Method

1. Read the sources. For events, count by `event` (and by `tool` or `reason` within each event) instead of reading lines one by one; a short Python one-liner over the JSONL is fine.
2. Cluster into themes. Each theme needs at least two independent occurrences; a one-off is a note, not a pattern.
3. For each theme: the structural root cause (not the symptom), the proposed fix, the target file (`copilot-instructions.md`, a `SKILL.md`, `ALGORITHM.md`, a hook extension), and 2-3 quoted pieces of evidence with dates.
4. Probe each proposed fix with `upgrade.py probe` so you don't propose something that already exists.

## Output (the Internal section of the report)

```markdown
**Sources:** learnings.md (N lines), events.jsonl (N events since <date>), N session logs
### <Theme> (N occurrences, HIGH/MEDIUM/LOW signal)
**Root cause:** <structural issue>
**Proposed fix:** <concrete change>
**Target:** <Kai file>
**Evidence:**
- <date> <source> - "<quote>"
```

If there is too little data yet: "Not enough history yet; learnings and event logs accumulate with use."
