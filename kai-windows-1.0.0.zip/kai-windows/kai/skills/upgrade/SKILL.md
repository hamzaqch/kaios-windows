---
name: upgrade
description: "Improve Kai from what GitHub Copilot and the best practitioners are shipping: the Copilot CLI changelog and releases, the GitHub Copilot changelog, the Copilot docs for hooks, plugins, agents and skills, agent-skills and MCP repos, trending GitHub repos and top practitioner feeds, plus Kai's own learnings and failure logs. Extracts concrete techniques, checks each against Kai's verified current state so nothing already done or already rejected is re-recommended, and reports tiered, evidence-backed recommendations that are persisted in a deduplicated upgrade store. Use when the user says upgrade, check for upgrades, any updates, what's new in Copilot, new Copilot CLI features, check the changelog, Kai upgrade, improve Kai, mine learnings, what have we learned, algorithm upgrade, research this upgrade, deep dive on <feature>, or find new sources. NOT FOR upgrading third-party packages in a project or general AI news summaries."
argument-hint: "[check | quick | learnings | algorithm | research <feature> | sources]"
---
# Upgrade

**The ideal state:** Kai knows what Copilot and the best people around AI coding harnesses are shipping, and its configuration improves from that input. A run is done when every worthwhile new technique from the monitored sources has been extracted (quoted, mapped to a specific Kai file), every candidate has been checked against what Kai already has or already decided, and the result reaches the user as tiered recommendations they can act on, each also recorded in the upgrade store.

Signal comes from two directions, and a good run uses both: **external** (what Copilot and practitioners ship) and **internal** (what Kai's learnings, session logs and hook event log say is weak). The strongest recommendations are where the two agree.

## Routing

| Workflow | Trigger | File |
|---|---|---|
| Upgrade (default) | "upgrade", "check for upgrades", "what's new in Copilot" | `Workflows/Upgrade.md` |
| MineLearnings | "mine learnings", "what have we learned", "internal improvements" | `Workflows/MineLearnings.md` |
| AlgorithmUpgrade | "algorithm upgrade", "improve the algorithm" | `Workflows/AlgorithmUpgrade.md` |
| ResearchUpgrade | "research this upgrade", "deep dive on <feature>" | `Workflows/ResearchUpgrade.md` |
| FindSources | "find upgrade sources", "add a source" | `Workflows/FindSources.md` |

"Check Copilot only" or similar single-source asks: `upgrade.py check --only copilot-cli-changelog,copilot-cli-releases` with the same grounding and output contract, abbreviated.

## Tool contract

```
python ~/.copilot/skills/upgrade/tools/upgrade.py check [--days 30] [--only k1,k2] [--priority HIGH] [--json]
python ~/.copilot/skills/upgrade/tools/upgrade.py trending [--days 30]
python ~/.copilot/skills/upgrade/tools/upgrade.py state            # Kai's current state for grounding
python ~/.copilot/skills/upgrade/tools/upgrade.py probe "<term>"   # file:line evidence across the installed Kai tree
python ~/.copilot/skills/upgrade/tools/upgrade.py add --claim "..." --recommendation "..." --target hook --priority HIGH --evidence "<url>"
python ~/.copilot/skills/upgrade/tools/upgrade.py list [--status open|applied|rejected|deferred|all]
python ~/.copilot/skills/upgrade/tools/upgrade.py set <id> rejected --reason "..."
```

`check` saves per-source state (`MEMORY/STATE/upgrade-last-check.json`), so each run reports only what is new; pass `--no-save` for a dry look and `--force` to re-report everything in the window. Sources live in `sources.json`; personal additions go in `MEMORY/STATE/upgrade-sources.local.json` (same shape, merged by key).

## The contract (every recommendation)

1. **Grounded in current state.** A Prior Status tag (NEW / PARTIAL / DISCUSSED / REJECTED) backed by evidence gathered this run with `upgrade.py state` and `upgrade.py probe`. Already-implemented items go to Skipped with file:line evidence. A claim that something is missing must be positively probed (a `probe` with zero hits), never inferred.
2. **A technique, not a pointer.** Quote the changelog bullet, doc lines or code; name the exact Kai file it changes; say what it is and how it helps Kai in at most two sentences each. Content with nothing extractable is skipped with a reason.
3. **Won't break what exists.** Check compatibility with current skills, hooks, agents and the installer before recommending adoption.
4. **Formatted per `References/OutputFormat.md`**, and every CRITICAL/HIGH/MEDIUM item recorded with `upgrade.py add`.

## Gotchas

- **Fail open, never block on one source.** `check` runs sources in parallel with a deadline; a slow or broken source comes back as `timed out` or `error` in Coverage. Report it in Sources Processed and move on.
- **Docs pages report "first snapshot taken" on the first run.** Only later runs show the changed lines. Don't present a first snapshot as a change.
- **Copilot behavior is verified, not recalled.** When a finding touches hooks, plugins, agents, skills or settings, confirm it against the docs page or the changelog text in hand, and test with a throwaway `COPILOT_HOME` when the claim matters. Never point an experiment at the real `~/.copilot`.
- **GitHub search without a token is rate-limited** (about 10 searches a minute). `trending` reports 403/429 per query; set `GITHUB_TOKEN` for heavier use. Queries always carry a free-text term because bare qualifier ORs return 422.
- **A setting missing from settings.json is not proof a feature is off.** Hooks can also come from plugins; check `upgrade.py state` (plugins) before concluding something is dark.
