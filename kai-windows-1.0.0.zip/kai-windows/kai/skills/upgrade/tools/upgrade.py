"""upgrade.py - watch what Copilot and top practitioners ship, ground it against Kai's current state,
and keep a deduplicated store of upgrade recommendations. Stdlib only.

Sources
  check [--days 30] [--only key1,key2] [--priority HIGH] [--force] [--no-save] [--timeout 20] [--json]
        new items from every source in sources.json since the last check (state is saved unless --no-save)
  trending [--days 30] [--force] [--json]      new GitHub repos for the configured queries (GITHUB_TOKEN optional)
  sources [--json]                             list configured sources

Grounding
  state [--no-exec] [--json]                   what Kai has today: version, skills, agents, hooks, plugins,
                                               Copilot version, recent learnings, open/rejected upgrades
  probe <term> [--json]                        file:line hits for a term across the installed Kai tree
                                               (positive evidence before claiming something is missing)

Upgrade store (MEMORY/STATE/upgrades.json; dedup by claim)
  add --claim "<one sentence>" --recommendation "<change>" --target <hook|skill|agent|instructions|algorithm|tool|settings>
      [--priority CRITICAL|HIGH|MEDIUM|LOW] [--current "<today>"] [--evidence "<url or ref>"]
  list [--status open|applied|rejected|deferred|all] [--json]
  set <id> <open|applied|rejected|deferred> [--reason "<why>"]

Exit codes: 0 ok, 1 nothing found / not found, 2 usage error.
"""
import concurrent.futures as cf
import datetime as dt
import difflib
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
SOURCES_FILE = SKILL_DIR / "sources.json"


def _kai_home():
    if os.environ.get("KAI_HOME"):
        return Path(os.environ["KAI_HOME"])
    if os.environ.get("COPILOT_HOME"):
        return Path(os.environ["COPILOT_HOME"]) / "kai"
    guess = Path(__file__).resolve().parents[3] / "kai"
    if (guess / "VERSION").exists():
        return guess
    return Path.home() / ".copilot" / "kai"


KAI_HOME = _kai_home()
COPILOT_HOME = Path(os.environ.get("COPILOT_HOME") or KAI_HOME.parent)
STATE = KAI_HOME / "MEMORY" / "STATE"
CHECK_STATE = STATE / "upgrade-last-check.json"
DOC_CACHE = STATE / "upgrade-docs"
TREND_STATE = STATE / "upgrade-trending.json"
STORE = STATE / "upgrades.json"
LOCAL_SOURCES = STATE / "upgrade-sources.local.json"
UA = "kai-upgrade/1.0 (+stdlib urllib)"
PRIORITIES = ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
STATUSES = ["open", "applied", "rejected", "deferred"]
TARGETS = ["hook", "skill", "agent", "instructions", "algorithm", "tool", "settings", "plugin", "memory", "other"]

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


class UsageError(Exception):
    pass


# ---------------------------------------------------------------- io helpers

def load_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def http_get(url, timeout=20, headers=None):
    h = {"User-Agent": UA}
    h.update(headers or {})
    req = urllib.request.Request(url, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read(3_000_000).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, ""


def opt(args, name, default=None):
    if name in args:
        i = args.index(name)
        if i + 1 >= len(args):
            raise UsageError(f"{name} needs a value")
        return args[i + 1]
    return default


def today():
    return dt.date.today().isoformat()


def load_sources():
    base = load_json(SOURCES_FILE, {"sources": [], "github_trending": {}})
    local = load_json(LOCAL_SOURCES, {})
    by_key = {s["key"]: s for s in base.get("sources", [])}
    for s in local.get("sources", []):
        if s.get("key"):
            by_key[s["key"]] = dict(by_key.get(s["key"], {}), **s)
    trending = dict(base.get("github_trending", {}), **local.get("github_trending", {}))
    return list(by_key.values()), trending


# ---------------------------------------------------------------- parsers (pure, unit-tested)

def parse_changelog(md):
    """'## <version> - <date>' sections -> [{version, date, bullets}] newest first (file order)."""
    out = []
    for m in re.finditer(r"^##\s+v?([0-9][\w.\-]*)(?:\s*[-(]\s*(\d{4}-\d{2}-\d{2})\)?)?\s*$(.*?)(?=^##\s|\Z)",
                         md, re.M | re.S):
        bullets = [re.sub(r"\s+", " ", b).strip() for b in re.findall(r"^\s*[-*]\s+(.+)$", m.group(3), re.M)]
        out.append({"version": m.group(1), "date": m.group(2) or "", "bullets": bullets})
    return out


def _decode(s):
    s = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", s, flags=re.S)
    s = html.unescape(re.sub(r"<[^>]+>", " ", html.unescape(s)))
    return re.sub(r"\s+", " ", s).strip()


def _date(raw):
    raw = (raw or "").strip()
    if not raw:
        return ""
    m = re.match(r"(\d{4}-\d{2}-\d{2})", raw)
    if m:
        return m.group(1)
    try:
        from email.utils import parsedate_to_datetime
        return parsedate_to_datetime(raw).date().isoformat()
    except Exception:
        return ""


def parse_feed(xml, limit=20):
    """RSS or Atom -> [{title, link, date, summary}] in feed order."""
    atom = bool(re.search(r"<entry[\s>]", xml)) and not re.search(r"<item[\s>]", xml)
    blocks = re.findall(r"<entry[\s>].*?</entry>" if atom else r"<item[\s>].*?</item>", xml, re.S)
    out = []
    for b in blocks[:limit]:
        title = _decode((re.search(r"<title[^>]*>(.*?)</title>", b, re.S) or [None, ""])[1])
        if atom:
            lm = (re.search(r"<link[^>]*rel=[\"']alternate[\"'][^>]*href=[\"']([^\"']+)", b)
                  or re.search(r"<link[^>]*href=[\"']([^\"']+)", b))
            link = html.unescape(lm.group(1)) if lm else ""
        else:
            link = _decode((re.search(r"<link[^>]*>(.*?)</link>", b, re.S) or [None, ""])[1])
        dm = re.search(r"<(pubDate|published|updated|dc:date)[^>]*>(.*?)</\1>", b, re.S)
        sm = re.search(r"<(summary|description|content)[^>]*>(.*?)</\1>", b, re.S)
        if title and link:
            out.append({"title": title, "link": link, "date": _date(dm.group(2) if dm else ""),
                        "summary": _decode(sm.group(2))[:300] if sm else ""})
    return out


def page_text(page):
    """Main readable text of an HTML page, one block per line."""
    m = re.search(r"<main[\s>].*?</main>", page, re.S | re.I) or re.search(r"<article[\s>].*?</article>",
                                                                       page, re.S | re.I)
    body = m.group(0) if m else page
    body = re.sub(r"<(script|style|noscript|svg|nav|footer|header)[\s>].*?</\1>", " ", body, flags=re.S | re.I)
    body = re.sub(r"</?(p|li|h[1-6]|tr|pre|div|br|dd|dt|td|th)[^>]*>", "\n", body, flags=re.I)
    lines = [re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", l))).strip() for l in body.split("\n")]
    return "\n".join(l for l in lines if len(l) > 2)


def page_links(page, base_url, pattern, limit=40):
    rx, found = re.compile(pattern, re.I), {}
    for href, text in re.findall(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", page, re.S | re.I):
        url = urllib.parse.urljoin(base_url, html.unescape(href)).split("#")[0].split("?")[0].rstrip("/")
        if not rx.search(url) or url == base_url.rstrip("/"):
            continue
        found.setdefault(url, _decode(text)[:140])
        if len(found) >= limit:
            break
    return found


# ---------------------------------------------------------------- source checkers
# Each takes (source, state_entry, ctx) and returns (updates, new_state_entry).

def check_changelog(src, st, ctx):
    code, text = http_get(src["url"], ctx["timeout"])
    if code != 200:
        raise RuntimeError(f"HTTP {code}")
    sections = parse_changelog(text)
    if not sections:
        raise RuntimeError("no '## <version>' sections found")
    last = None if ctx["force"] else st.get("last_version")
    new = []
    for s in sections:
        if s["version"] == last:
            break
        if not last and s["date"] and s["date"] < ctx["since"]:
            break
        new.append(s)
        # first run: 10 newest in the window; a stale cursor (version vanished from the file) must
        # not dump the whole history either
        if len(new) >= (10 if not last else 25):
            break
    ups = [{"title": f"{src['name']}: {s['version']}" + (f" ({s['date']})" if s["date"] else ""),
            "url": src.get("link", src["url"]), "date": s["date"], "detail": s["bullets"]} for s in new]
    return ups, {"last_version": sections[0]["version"], "checked": today()}


def check_feed(src, st, ctx):
    code, text = http_get(src["url"], ctx["timeout"])
    if code != 200:
        raise RuntimeError(f"HTTP {code}")
    items = parse_feed(text)
    if not items:
        raise RuntimeError("feed has no items")
    seen = set() if ctx["force"] else set(st.get("seen", []))
    first = not st.get("seen")
    ups = []
    for it in items:
        if it["link"] in seen:
            continue
        if (first or ctx["force"]) and it["date"] and it["date"] < ctx["since"]:
            continue
        ups.append({"title": f"{src['name']}: {it['title']}", "url": it["link"], "date": it["date"],
                    "detail": [it["summary"]] if it["summary"] else []})
        if first and len(ups) >= 5:
            break
    keep = [it["link"] for it in items] + [s for s in st.get("seen", []) if s not in {i["link"] for i in items}]
    return ups, {"seen": keep[:200], "checked": today()}


def check_docs(src, st, ctx):
    code, page = http_get(src["url"], ctx["timeout"])
    if code != 200:
        raise RuntimeError(f"HTTP {code}")
    text = page_text(page)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
    cache = DOC_CACHE / f"{re.sub(r'[^a-z0-9-]', '-', src['key'].lower())}.txt"
    new_state = {"hash": digest, "checked": today()}
    if not ctx["force"] and st.get("hash") == digest:
        return [], new_state
    old = cache.read_text(encoding="utf-8") if cache.exists() else ""
    if ctx["save"]:
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(text, encoding="utf-8")
    if not old:
        detail = ["first snapshot taken; future runs report the lines that changed"]
    else:
        added = [l[1:].strip() for l in difflib.unified_diff(old.splitlines(), text.splitlines(), lineterm="", n=0)
                 if l.startswith("+") and not l.startswith("+++") and len(l.strip()) > 3]
        detail = [f"+ {a}" for a in added[:20]] or ["page changed (formatting only)"]
        if len(added) > 20:
            detail.append(f"... {len(added) - 20} more added lines")
    return [{"title": f"{src['name']}: page changed", "url": src["url"], "date": today(), "detail": detail}], new_state


def check_index(src, st, ctx):
    code, page = http_get(src["url"], ctx["timeout"])
    if code != 200:
        raise RuntimeError(f"HTTP {code}")
    found = page_links(page, src["url"], src.get("link_pattern") or "$^")
    if not found:
        raise RuntimeError("no links matched link_pattern")
    seen = set() if ctx["force"] else set(st.get("seen", []))
    first = not st.get("seen")
    ups = []
    for url, text in found.items():
        if url in seen:
            continue
        ups.append({"title": f"{src['name']}: {text or url.rsplit('/', 1)[-1]}", "url": url, "date": today(),
                    "detail": []})
        if first and len(ups) >= 8:
            break
    return ups, {"seen": list(dict.fromkeys(list(found) + st.get("seen", [])))[:200], "checked": today()}


CHECKERS = {"changelog": check_changelog, "feed": check_feed, "docs": check_docs, "index": check_index}


def run_check(sources, state, ctx, deadline):
    results, coverage = [], []
    pool = cf.ThreadPoolExecutor(max_workers=8)
    futs = {}
    for s in sources:
        fn = CHECKERS.get(s.get("type"))
        if not fn:
            coverage.append({"key": s.get("key"), "status": "skipped", "detail": f"unknown type {s.get('type')}"})
            continue
        futs[pool.submit(fn, s, state.get(s["key"], {}), ctx)] = s
    try:
        for fut in cf.as_completed(futs, timeout=deadline):
            s = futs[fut]
            try:
                ups, new_st = fut.result()
                for u in ups:
                    u.update({"source": s["key"], "priority": s.get("priority", "MEDIUM")})
                results += ups
                state[s["key"]] = new_st
                coverage.append({"key": s["key"], "status": "ok", "detail": f"{len(ups)} new"})
            except Exception as e:
                coverage.append({"key": s["key"], "status": "error", "detail": str(e)[:160]})
    except cf.TimeoutError:
        pass
    done = {c["key"] for c in coverage}
    for s in futs.values():
        if s["key"] not in done:
            coverage.append({"key": s["key"], "status": "timed out", "detail": f"no answer within {deadline}s"})
    pool.shutdown(wait=False)
    order = {p: i for i, p in enumerate(PRIORITIES)}
    results.sort(key=lambda u: u.get("date") or "", reverse=True)  # newest first within each group
    results.sort(key=lambda u: (order.get(u["priority"], 9), u["source"]))
    return results, coverage


def cmd_sources(args):
    sources, trending = load_sources()
    if "--json" in args:
        print(json.dumps({"sources": sources, "github_trending": trending}, indent=2))
    else:
        for s in sources:
            print(f"{s.get('priority', '?'):6} {s['type']:9} {s['key']:26} {s['url']}")
        print(f"trending queries: {', '.join(trending.get('queries', []))}")
    return 0


def cmd_check(args):
    sources, _ = load_sources()
    only = {k.strip() for k in (opt(args, "--only") or "").split(",") if k.strip()}
    pri = opt(args, "--priority")
    if only:
        sources = [s for s in sources if s["key"] in only]
    if pri:
        if pri not in PRIORITIES:
            raise UsageError(f"--priority must be one of {', '.join(PRIORITIES)}")
        sources = [s for s in sources if PRIORITIES.index(s.get("priority", "LOW")) <= PRIORITIES.index(pri)]
    if not sources:
        raise UsageError("no sources selected")
    days = int(opt(args, "--days", "30"))
    timeout = float(opt(args, "--timeout", "20"))
    ctx = {"timeout": timeout, "force": "--force" in args, "save": "--no-save" not in args,
           "since": (dt.date.today() - dt.timedelta(days=days)).isoformat()}
    state = load_json(CHECK_STATE, {})
    started = time.monotonic()
    results, coverage = run_check(sources, state, ctx, deadline=timeout * 3)
    if ctx["save"]:
        state["_last_run"] = dt.datetime.now().astimezone().isoformat(timespec="seconds")
        save_json(CHECK_STATE, state)
    data = {"updates": results, "coverage": coverage, "seconds": round(time.monotonic() - started, 1),
            "saved": ctx["save"]}
    if "--json" in args:
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        cur = None
        for u in results:
            if u["priority"] != cur:
                cur = u["priority"]
                print(f"\n## {cur}")
            print(f"- {u['title']}  {u['url']}")
            for d in u["detail"][:25]:
                print(f"    {d}")
        print("\nCoverage: " + "; ".join(f"{c['key']}={c['status']}" + (f" ({c['detail']})" if c["status"] != "ok"
                                                                          else "") for c in coverage))
        print(f"{len(results)} update(s) in {data['seconds']}s" + ("" if ctx["save"] else " (state not saved)"))
    return 0 if results else 1


def cmd_trending(args):
    _, cfg = load_sources()
    days = int(opt(args, "--days", "30"))
    since = (dt.date.today() - dt.timedelta(days=days)).isoformat()
    min_stars = int(cfg.get("min_stars", 50))
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    state = load_json(TREND_STATE, {"seen": {}})
    seen = {} if "--force" in args else state.get("seen", {})
    found, errors = {}, []
    for q in cfg.get("queries", []):
        query = f"{q} created:>{since} stars:>={min_stars}"
        url = "https://api.github.com/search/repositories?" + urllib.parse.urlencode(
            {"q": query, "sort": "stars", "order": "desc", "per_page": 5})
        try:
            code, body = http_get(url, 20, headers)
            if code != 200:
                errors.append(f"{q}: HTTP {code}" + (" (rate limited; set GITHUB_TOKEN)" if code in (403, 429) else ""))
                continue
            for r in json.loads(body).get("items", []):
                name = r.get("full_name")
                if name and name not in seen and name not in found:
                    found[name] = {"repo": name, "stars": r.get("stargazers_count"), "url": r.get("html_url"),
                                   "description": (r.get("description") or "")[:200], "query": q,
                                   "created": (r.get("created_at") or "")[:10]}
        except Exception as e:
            errors.append(f"{q}: {e}")
    state.setdefault("seen", {}).update({k: today() for k in found})
    save_json(TREND_STATE, state)
    rows = sorted(found.values(), key=lambda r: -(r["stars"] or 0))
    if "--json" in args:
        print(json.dumps({"repos": rows, "errors": errors}, indent=2, ensure_ascii=False))
    else:
        for r in rows:
            print(f"- {r['repo']} ({r['stars']} stars, {r['created']}) {r['url']}\n    {r['description']}  [{r['query']}]")
        for e in errors:
            print(f"  ! {e}")
        print(f"{len(rows)} new repo(s)")
    return 0 if rows else 1


# ---------------------------------------------------------------- grounding

def frontmatter_desc(path):
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    m = re.search(r"^description:\s*(.+)$", text, re.M)
    return m.group(1).strip().strip('"')[:140] if m else ""


def cmd_state(args):
    settings = load_json(COPILOT_HOME / "settings.json", {})
    hooks = settings.get("hooks", {}) if isinstance(settings, dict) else {}
    hook_events = sorted(ev for ev, arr in hooks.items() if "kai_hook" in json.dumps(arr))
    skills = sorted((p.parent.name, frontmatter_desc(p)) for p in (COPILOT_HOME / "skills").glob("*/SKILL.md"))
    agents = sorted(p.name[:-len(".agent.md")] for p in (COPILOT_HOME / "agents").glob("*.agent.md"))
    exts = sorted(p.stem for p in (KAI_HOME / "hooks" / "ext").glob("*.py") if not p.name.startswith("_"))
    copilot_version = None
    if "--no-exec" not in args and shutil.which("copilot"):
        try:
            r = subprocess.run([shutil.which("copilot"), "--version"], capture_output=True, text=True, timeout=15)
            copilot_version = ((r.stdout or r.stderr).strip().splitlines() or [None])[0]
        except Exception:
            copilot_version = "unavailable"
    learn = KAI_HOME / "MEMORY" / "LEARNING" / "learnings.md"
    learnings = [l[2:] for l in learn.read_text(encoding="utf-8").splitlines() if l.startswith("- ")][-10:] \
        if learn.exists() else []
    store = load_json(STORE, [])
    data = {
        "kai_home": str(KAI_HOME),
        "kai_version": (KAI_HOME / "VERSION").read_text(encoding="utf-8").strip() if (KAI_HOME / "VERSION").exists() else None,
        "copilot_version": copilot_version,
        "instructions": (COPILOT_HOME / "copilot-instructions.md").exists(),
        "hook_events": hook_events, "hook_extensions": exts,
        "plugins": sorted(k for k, v in (settings.get("enabledPlugins") or {}).items() if v) if isinstance(settings, dict) else [],
        "skills": [{"name": n, "description": d} for n, d in skills], "agents": agents,
        "recent_learnings": learnings,
        "upgrades": {s: sum(1 for u in store if u.get("status") == s) for s in STATUSES},
        "rejected_claims": [{"id": u["id"], "claim": u["claim"], "reason": u.get("reason", "")}
                            for u in store if u.get("status") == "rejected"],
        "last_check": load_json(CHECK_STATE, {}).get("_last_run"),
    }

    def text(d):
        out = [f"Kai {d['kai_version']} at {d['kai_home']}; Copilot: {d['copilot_version'] or 'not checked'}",
               f"hooks ({len(d['hook_events'])}): {', '.join(d['hook_events']) or 'none'}",
               f"hook extensions: {', '.join(d['hook_extensions']) or 'none'}",
               f"plugins: {', '.join(d['plugins']) or 'none'}",
               f"agents: {', '.join(d['agents']) or 'none'}",
               f"skills ({len(d['skills'])}): {', '.join(s['name'] for s in d['skills'])}",
               "upgrades: " + ", ".join(f"{k}={v}" for k, v in d["upgrades"].items()),
               f"last source check: {d['last_check'] or 'never'}"]
        if d["rejected_claims"]:
            out.append("rejected (do not re-recommend without a changed-context reason):")
            out += [f"  {r['id']}: {r['claim']} - {r['reason']}" for r in d["rejected_claims"]]
        if d["recent_learnings"]:
            out.append("recent learnings:")
            out += [f"  {l}" for l in d["recent_learnings"]]
        return "\n".join(out)
    print(json.dumps(data, indent=2, ensure_ascii=False) if "--json" in args else text(data))
    return 0


def probe_roots():
    roots = [COPILOT_HOME / "copilot-instructions.md", COPILOT_HOME / "settings.json",
             COPILOT_HOME / "skills", COPILOT_HOME / "agents", KAI_HOME / "hooks", KAI_HOME / "bin",
             KAI_HOME / "RULES", KAI_HOME / "ALGORITHM.md", KAI_HOME / "ISA_FORMAT.md"]
    return [r for r in roots if r.exists()]


def cmd_probe(args):
    terms = [a for a in args if not a.startswith("--")]
    if not terms:
        raise UsageError('usage: upgrade.py probe "<term>"')
    term = " ".join(terms).lower()
    hits = []
    for root in probe_roots():
        files = [root] if root.is_file() else [p for p in root.rglob("*") if p.is_file()
                                               and p.suffix in (".md", ".py", ".json", ".ps1", ".yaml", ".yml")]
        for f in files:
            if "__pycache__" in f.parts or "Patterns" in f.parts:
                continue
            try:
                for n, line in enumerate(f.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                    if term in line.lower():
                        hits.append({"file": str(f), "line": n, "text": line.strip()[:200]})
            except OSError:
                continue
    if "--json" in args:
        print(json.dumps(hits, indent=2, ensure_ascii=False))
    else:
        for h in hits[:60]:
            print(f"{h['file']}:{h['line']}: {h['text']}")
        print(f"{len(hits)} hit(s) for '{term}'" + (" - absence is now positively probed" if not hits else ""))
    return 0 if hits else 1


# ---------------------------------------------------------------- store

def claim_id(claim):
    norm = re.sub(r"[^a-z0-9]+", " ", claim.lower()).strip()
    return "up_" + hashlib.sha1(norm.encode("utf-8")).hexdigest()[:8]


def cmd_add(args):
    claim, rec, target = opt(args, "--claim"), opt(args, "--recommendation"), opt(args, "--target")
    if not claim or not rec or not target:
        raise UsageError('usage: upgrade.py add --claim "<sentence>" --recommendation "<change>" --target <target>')
    if target not in TARGETS:
        raise UsageError(f"--target must be one of {', '.join(TARGETS)}")
    pri = opt(args, "--priority", "MEDIUM")
    if pri not in PRIORITIES:
        raise UsageError(f"--priority must be one of {', '.join(PRIORITIES)}")
    store = load_json(STORE, [])
    uid = claim_id(claim)
    existing = next((u for u in store if u["id"] == uid), None)
    if existing:
        print(f"duplicate: {uid} already recorded (status {existing['status']})")
        return 0
    store.append({"id": uid, "claim": claim, "recommendation": rec, "target": target, "priority": pri,
                  "current": opt(args, "--current", ""), "evidence": opt(args, "--evidence", ""),
                  "status": "open", "created": today(), "updated": today()})
    save_json(STORE, store)
    print(uid)
    return 0


def cmd_list(args):
    status = opt(args, "--status", "open")
    if status != "all" and status not in STATUSES:
        raise UsageError(f"--status must be one of {', '.join(STATUSES)} or all")
    rows = [u for u in load_json(STORE, []) if status == "all" or u.get("status") == status]
    order = {p: i for i, p in enumerate(PRIORITIES)}
    rows.sort(key=lambda u: (order.get(u.get("priority"), 9), u.get("created", "")))
    if "--json" in args:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
    else:
        for u in rows:
            print(f"{u['id']} [{u['priority']}/{u['status']}] {u['target']}: {u['claim']}")
        print(f"{len(rows)} {status} upgrade(s)")
    return 0 if rows else 1


def cmd_set(args):
    pos = [a for a in args if not a.startswith("--") and a != opt(args, "--reason")]
    if len(pos) < 2 or pos[1] not in STATUSES:
        raise UsageError(f"usage: upgrade.py set <id> <{'|'.join(STATUSES)}> [--reason \"<why>\"]")
    store = load_json(STORE, [])
    u = next((x for x in store if x["id"] == pos[0]), None)
    if not u:
        sys.stderr.write(f"no upgrade {pos[0]}\n")
        return 1
    u["status"], u["updated"] = pos[1], today()
    if opt(args, "--reason"):
        u["reason"] = opt(args, "--reason")
    save_json(STORE, store)
    print(f"{u['id']}: {u['status']}")
    return 0


COMMANDS = {"check": cmd_check, "trending": cmd_trending, "sources": cmd_sources, "state": cmd_state,
            "probe": cmd_probe, "add": cmd_add, "list": cmd_list, "set": cmd_set}


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 0
    fn = COMMANDS.get(argv[0])
    if not fn:
        sys.stderr.write(f"unknown command '{argv[0]}'\n\n{__doc__}")
        return 2
    try:
        return fn(argv[1:])
    except UsageError as e:
        sys.stderr.write(f"{e}\n")
        return 2
    except ValueError as e:
        sys.stderr.write(f"bad value: {e}\n")
        return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
