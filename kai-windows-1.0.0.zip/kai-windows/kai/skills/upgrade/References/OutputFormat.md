# Upgrade report format

The single source of truth for the report's structure.

## Section order (fixed)

1. **Discoveries**: what was found, ranked by how interesting it is
2. **Recommendations**: what to do, ranked by priority tier
3. **Technique details**: the full extraction with quotes or code
4. **Internal signal**: findings from Kai's learnings and logs
5. **Summary**: one table and a totals line
6. **Skipped**: already done or rejected, with evidence
7. **Sources processed**: coverage footer

## Header

```markdown
# Kai upgrade report
**Generated:** <timestamp> | **Kai** <version> | **Copilot CLI** <version>
**Sources:** <N> checked, <N> with updates, <N> errors/timeouts | **Findings:** <N> techniques, <N> skipped
```

## Discoveries

Ranked by interestingness, not priority; a LOW item can be discovery #1.

| # | Discovery | Source | Why it's interesting | Kai relevance |
|---|---|---|---|---|

## Recommendations

Every row carries a Prior Status tag with evidence from this run.

- **NEW**: `upgrade.py probe` found nothing and no store record exists
- **PARTIAL**: part exists (cite file:line); the row covers only the missing delta
- **DISCUSSED**: in an ISA, learning or the store as open/deferred, not shipped
- **REJECTED**: previously decided against; only resurfaces with a stated change in context
- **DONE**: implemented; goes to Skipped, never here

Print only tiers that have items:

### CRITICAL: fix now
A gap or breakage risk Kai shouldn't run with (for example a Copilot change that breaks a hook's input or output contract).

### HIGH: this week
### MEDIUM: when convenient
### LOW: awareness

| # | Recommendation | Prior status | Evidence | Kai relevance | Effort | Files |
|---|---|---|---|---|---|---|

Effort is S (under an hour), M (an afternoon) or L (multi-session).

## Technique details

Numbered to match Recommendations, one block each:

```markdown
#### <N>. <Technique>
**Source:** <exact source: changelog version, docs page, repo>  **Priority:** <tier>  **Store id:** <up_xxxxxxxx>
**What it is:** <at most 2 concrete sentences>
**How it helps Kai:** <at most 2 concrete sentences>
**The technique:**
> <quote or code block from the source, not a paraphrase>
**Applies to:** `<Kai file>`
**Implementation sketch:**
<before/after or new code, short>
```

Trending repos use the same block with **Inspiration** (the specific pattern worth borrowing) in place of an implementation.

## Internal signal

The output block from `Workflows/MineLearnings.md`, or "Not enough history yet".

## Summary

| # | Technique | Source | Priority | Kai component | Effort |
|---|---|---|---|---|---|

**Totals:** <N> critical | <N> high | <N> medium | <N> low | <N> skipped | <N> internal

## Skipped

| Content | Source | Why skipped | Evidence |
|---|---|---|---|

Already-done items must appear here with file:line evidence.

## Sources processed

One line: counts by source type, plus each error or timeout by key.

## Hard rules

1. Discoveries, then recommendations, then details; never reorder.
2. Every recommendation has a Prior Status tag with evidence.
3. Every technique quotes its source and names a Kai file.
4. No "go read this" recommendations; extract the technique or skip it.
5. Numbering matches across Discoveries, Recommendations and Technique details.
6. Empty tiers are omitted.
