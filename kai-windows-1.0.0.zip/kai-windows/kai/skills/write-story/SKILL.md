---
name: write-story
description: "Scaffolding that helps a writer build a story they already want to tell. Fills in structure, the hidden wound, theme and prose from the writer's own material across seven narrative layers (meaning, character change, plot, mystery, world, relationships, prose), deriving the spine from their notes as labeled proposals they ratify. Keeps each book as a resumable project with a Story Bible ISA, bans generic AI prose patterns, and scales from a short story to a multi-book series. Use when the user says write a story, fiction, novel, chapter, story bible, character arc, plot outline, creative writing, worldbuilding, draft a story, help me write my story, develop my novel, layer my story, build out my book, or I have notes for a story. Not for narrative summaries of real content."
argument-hint: "<what you have: a line, notes folder, draft chapter> or <book-slug to resume>"
---

# Write story

## What it does

Write story is scaffolding for writing fiction. It takes what the writer already has (a sentence, a folder of notes, a half-drafted chapter) and helps them build the rest of the story one layer at a time, using the systems professional storytellers use on purpose. The writer brings the creativity; the skill fills in the pieces they're missing. It never writes the story for them.

## The problem

Most people who want to write a story never finish one. The spark is there (a character who won't leave you alone, a world you can picture but can't map, an ending that gives you chills), but between that spark and a finished draft are the hard parts: structure, the character's hidden wound, the theme you can feel but can't name, the sentences that should land but don't. The usual tools either leave you alone with those gaps, or they write the story for you and hand back something that isn't yours. This skill fills the gaps without taking the story away from the writer.

## How it works

The work happens across **seven narrative layers**, and each book is a **stateful project** Kai can come back to and keep building.

### The seven layers

1. **Meaning**: theme, the argument the story makes, the question it asks
2. **Character change**: sacred flaw / misbelief → transformation (Storr, Cron)
3. **Plot**: the cause-and-effect chain of events
4. **Mystery**: what the reader knows vs doesn't, and when
5. **World**: setting, politics, rules, the pressure the world puts on people
6. **Relationships**: how the key bonds evolve and squeeze the characters
7. **Prose**: rhetorical figures, voice, aesthetic, style

The layers are the destination. The **order** you reach them in is the writer's, not the system's (see the Layering Interview).

## Workflow routing

| Workflow | Trigger | File |
|----------|---------|------|
| **Interview** | "interview me", "I have notes/an idea for a story", "help me plan a story", "layer my story", resuming a book | `Workflows/Interview.md` |
| **BuildBible** | "build story bible", "create story plan", "map the story" | `Workflows/BuildBible.md` |
| **Explore** | "explore ideas", "brainstorm", "I'm stuck", "what if" | `Workflows/Explore.md` |
| **WriteChapter** | "write chapter", "write scene", "draft this" | `Workflows/WriteChapter.md` |
| **Revise** | "revise", "edit", "improve", "polish" | `Workflows/Revise.md` |

The usual path: **Interview** reads what the writer has and builds the spine with them → **BuildBible** turns it into a Story Bible (a project ISA) → **WriteChapter** drafts off that bible → **Revise** layers and polishes. **Explore** is the idea engine for when a layer is genuinely blank.

## Projects and state

Each book is a project folder in Kai memory, so it survives across sessions and shows up in the session-start list of active work:

```
~/.copilot/kai/MEMORY/WORK/story-<book-slug>/
  interview.md     the saved interview: spine, layers, what's confirmed
  ISA.md           the Story Bible as a project ISA: the living plan, done vs left
  chapters/        drafts the writer has accepted (optional; the writer may keep prose elsewhere)
  PREFERENCES.md   optional: default genre, aesthetic, custom profiles, voice samples
```

Create the ISA with Kai's CLI (it writes `ISA.md` inside the folder you name):

```powershell
python "$HOME/.copilot/kai/bin/kai.py" isa new story-<book-slug> "<the writer's goal for the book, verbatim>" --project "$HOME/.copilot/kai/MEMORY/WORK/story-<book-slug>"
```

The writer can stop mid-book and come back. The Interview re-reads the saved state and picks up where they left off, instead of starting over. To find existing books, list `~/.copilot/kai/MEMORY/WORK/story-*` or run `python "$HOME/.copilot/kai/bin/kai.py" isa list`.

If the writer keeps the book in their own repo or folder instead, put `interview.md` and `ISA.md` at that folder's root (`--project <their folder>`) and say where you put them.

## Frameworks behind it

| Reference | File | Purpose |
|-----------|------|---------|
| Layer architecture | `StoryLayers.md` | The seven-layer system |
| Storr framework | `StorrFramework.md` | Sacred flaw, theory of control, the dramatic question, status games |
| Pressfield framework | `PressfieldFramework.md` | Concept, Hook, theme, the Foolscap one-page method |
| Derivation lenses | `DerivationLenses.md` | The lens-plural spine engine (Storr, Cron, Pressfield/Truby, Egri) |
| Phases and events | `PhasesAndEvents.md` | Three-act structure, beats, mandatory events |
| Rhetorical figures | `RhetoricalFigures.md` | The figures toolbelt (Forsyth) |
| Anti-cliche system | `AntiCliche.md` | Freshness enforcement, banned patterns |
| Story structures | `StoryStructures.md` | Dramatica, Story Grid, Sanderson, Hero's Journey |
| Aesthetic profiles | `AestheticProfiles.md` | Genre and style configuration |
| Critic profiles | `Critics.md` | Multi-pass review for prose |

## The stance

Write story augments a creator. It never substitutes for one. This is the rule the whole skill is built on:

- **Never invent the spine; elaborate the writer's.** Start from what they brought.
- **Every derived element is a proposal the writer ratifies**, never a fact the system asserts. Label where each one came from: "inferred from your seed" vs "a new option I'm offering."
- **Options, not answers.** Offer a few directions to choose among, not one rewrite to approve.
- **Suggest at the sentence/beat level. Never take over a chapter.**
- **Anchor to the writer's own voice**: their favorites, their samples, their cadence.
- **The writer's word always wins.** If they redirect, the redirect is the truth.
- **Only WriteChapter emits prose**, and only off the writer's confirmed bible, framed as a revisable draft they own.

The writer's own pages are their content. Never overwrite a file they wrote; drafts and revisions go to new files (or into the conversation) unless they ask you to edit theirs.

## Running on Copilot

- Read a notes folder with `view` on each file before asking anything (or `powershell` `Get-ChildItem -Recurse` to list it first).
- Use `ask_user` for the interview's one-question-at-a-time checkpoints when it's available; otherwise ask in plain text and wait.
- Parallel idea generation (Explore) and parallel critic passes (WriteChapter) run as `task` calls issued together. Route critics to `@kai-reviewer`; the drafter never critiques its own draft in the same pass.
- For creative divergence, the `/be-creative` skill is the idea engine Explore leans on.

## Examples

**Example 1: A writer who already has a lot**
```
User: "I've got a folder of notes for a novel: a few character sketches,
       a rough world, and two draft scenes. Help me build it out."
→ Interview reads ALL of the folder first
→ Reflects back the story it sees, asks what excites them most
→ Picks a derivation lens that fits what they brought
→ Derives the spine (flaw, dramatic question, theme) as proposals they confirm or redirect
→ Layers outward one dimension at a time, only where they're blank
→ Saves interview.md in the project folder; hands off to BuildBible
```

**Example 2: Building the full story plan**
```
User: "Build the story bible for my novel"
→ BuildBible turns the interview spine into the project ISA
→ Maps all seven layers start to finish, tracks done vs remaining
→ Outputs a living bible that guides every chapter
```

**Example 3: Writing actual prose**
```
User: "Write chapter 3 based on the story bible"
→ WriteChapter reads the bible ISA for chapter 3's beats across all layers
→ Deploys rhetorical figures at key moments, in the writer's aesthetic
→ Produces a fresh, anti-cliche draft the writer owns and revises
```

## Gotchas

- **Augment, never substitute.** Never invent the spine; elaborate the writer's. Every derived element is a proposal they ratify, with its source labeled. If you find yourself generating the story instead of building it with them, stop.
- **Don't force one theory of story.** Sacred-flaw-first is one lens, not the law. Literary, plot-driven genre, ensemble and mood pieces need different spines; pick the lens that fits what the writer brought (`DerivationLenses.md`).
- **Thin or vibe-only seeds need elicitation, not derivation.** If the writer brings only a mood or an image, pull material out of them before deriving any causal structure. Don't fabricate a flaw and call it ratification.
- **Read the writer's material before asking anything.** A generic questionnaire that ignores what they already gave you is the failure mode this skill exists to kill.
- **Story bibles are the source of truth for series continuity.** Always read the project ISA before writing new content.
- **Rhetorical figures are specific devices.** Use them precisely at high-impact moments, never as decoration.
- **Character arcs follow the flaw → crisis → transformation model** (Storr), never a vague "character grows."
