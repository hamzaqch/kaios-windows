<#
  Kai installer (Windows PowerShell 5.1+ or PowerShell 7).
  Usage:  powershell -ExecutionPolicy Bypass -File .\install.ps1 [-InstallPython] [-Migrate all|none|skills,agents,...] [-KeepHistory] [-ResetLogin] [-Uninstall] [-DryRun]
  Kai needs only Python 3.8+ (stdlib). -InstallPython fetches the official python.org
  installer and installs it for the current user (no admin) if no Python is found.
#>
param([switch]$InstallPython, [switch]$Uninstall, [switch]$DryRun, [string]$Migrate, [switch]$KeepHistory, [switch]$ResetLogin, [switch]$ResetApp)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Find-Python {
  foreach ($c in @(@('py','-3'), @('python'), @('python3'))) {
    $cmd = Get-Command $c[0] -ErrorAction SilentlyContinue
    if (-not $cmd) { continue }
    # skip the Microsoft Store alias stub (WindowsApps\python.exe opens the Store)
    if ($cmd.Source -like '*\WindowsApps\*') { continue }
    $args2 = @($c | Select-Object -Skip 1) + @('-c', 'import sys;print(sys.executable);sys.exit(0 if sys.version_info>=(3,8) else 1)')
    try {
      $exe = & $cmd.Source @args2 2>$null
      if ($LASTEXITCODE -eq 0 -and $exe) { return ($exe | Select-Object -Last 1).Trim() }
    } catch {}
  }
  foreach ($p in Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe", "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue) {
    return $p.FullName
  }
  return $null
}

$py = Find-Python
if (-not $py -and $InstallPython) {
  Write-Host '[kai] Python not found - installing Python 3.13 for the current user from python.org'
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'amd64' }
  $url = "https://www.python.org/ftp/python/3.13.9/python-3.13.9-$arch.exe"
  $exeFile = Join-Path $env:TEMP 'kai-python-installer.exe'
  Invoke-WebRequest $url -OutFile $exeFile -UseBasicParsing
  $sig = Get-AuthenticodeSignature $exeFile
  if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
    throw "[kai] Python installer signature check failed ($($sig.Status)); aborting."
  }
  Start-Process $exeFile -ArgumentList '/quiet','InstallAllUsers=0','PrependPath=1','Include_launcher=1','Include_test=0' -Wait
  $env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
  $py = Find-Python
}
if (-not $py) {
  Write-Host '[kai] Python 3.8+ was not found.'
  Write-Host '      Re-run with -InstallPython, or install it from https://www.python.org/downloads/windows/'
  exit 1
}
Write-Host "[kai] using Python: $py"
$a = @((Join-Path $here 'install.py'))
if ($Uninstall) { $a += '--uninstall' }
if ($DryRun) { $a += '--dry-run' }
if ($Migrate) { $a += @('--migrate', $Migrate) }
if ($KeepHistory) { $a += '--keep-history' }
if ($ResetLogin) { $a += '--reset-login' }
if ($ResetApp) { $a += '--reset-app' }
& $py @a
exit $LASTEXITCODE
